# Evento Project Handoff & Restart Guide

**Document Version:** 1.0  
**Snapshot Date:** 2026-10-13  
**Target Audience:** Succeeding AI Engineering Agent / Software Engineer  

---

## 1. Quick Project Summary

**Evento** is an enterprise-grade, **strictly offline attendance management and QR verification system** for Android. It consists of:

- **`:app` (Evento Admin):** Desktop/tablet/handheld app for event configuration, attendee rosters, Excel import/export, WYSIWYG badge design, multi-card PDF batch generation, offline analytics, and cryptographic `.evento` package generation.
- **`:checkin` (Evento Check-In):** Decoupled handheld terminal app for gate security and staff. Handles offline package import, ECDSA signature verification, runtime license enforcement, CameraX QR scanning, idempotent attendance recording, and SAF CSV export.
- **`:core` (Shared Protocol Library):** Protocol serialization, Room database for check-in, package verification engine, license rules, and QR grammar parsing.

---

## 2. Current Verified State

- **Milestone:** Release Candidate 1.0 — Design System Phase 1 Tokens Verified.
- **Test Baseline:** **346/346 automated tests passing** (100% green; `:app` 223/223 passed, `:checkin` 123/123 passed, 0 failures, 0 errors, 0 skipped).
  - *Historical Phase 0 Baseline:* 345/346 passed (1 dialog timing failure in `CheckInSettingsClearAttendanceRoboTest`).
  - *Current Verified Run:* `CheckInSettingsClearAttendanceRoboTest.testClearAttendanceCardAndConfirmationFlow` passed in targeted rerun and full suite. Confirmed directly from `TEST-com.evento.checkin.CheckInSettingsClearAttendanceRoboTest.xml`.
- **Design System Phase 1 Status:**
  - Strictly six theme files updated across `:app` and `:checkin`: `Color.kt`, `Type.kt`, `Theme.kt`.
  - Evento Signature commercial palette mapped to Material 3 light/dark color schemes.
  - Complete 12-role Material 3 typography scale harmonized across both apps with `letterSpacing = 0.sp` for Arabic (RTL) and Latin (LTR) legibility.
  - Legacy theme aliases (`Emerald*`, `Mint*`, `Slate*`, `Purple*`, `Pink*`) preserved for backwards compatibility.
  - System-following dark mode remains active (`isSystemInDarkTheme()`); user-selectable and persisted theme mode is **NOT** implemented yet.
  - **Boundary Guardrail:** Token foundation only; zero individual application screens or layouts have been altered yet.
- **Build & Artifact Status:**
  - `gradle :app:compileDebugKotlin :checkin:compileDebugKotlin :core:compileDebugKotlin` -> Succeeded (`1s`).
  - `gradle :app:assembleDebug :checkin:assembleDebug` -> Succeeded (`4s`).
  - `gradle packageDistribution` -> Succeeded (`4s`), publishing `distribution/admin/Evento-Admin.apk` (46,028,542 bytes) and `distribution/checkin/Evento-Check-In.apk` (44,497,484 bytes).
- **Distribution Endpoint Reality:**
  - Local serving: Verified HTTP 200 (`application/vnd.android.package-archive`) on `http://localhost:3000/distribution/...` and `http://localhost:8080/distribution/...`.
  - External Development URL (`ais-dev-...`): Returns HTTP 200 with `text/html` (AI Studio auth login page, not direct APK binary download).
  - External Shared URL (`ais-pre-...`): Returns HTTP 404 (not published).
  - External downloads are **NOT** publicly accessible or ready.
- **Version Control Reality:** Git is not initialized in this workspace (`.git` missing); standard git diff/history verification is unavailable.
- **Air-Gap Status:** Conforming. Both apps have `INTERNET` and `ACCESS_NETWORK_STATE` stripped from manifests via `tools:node="remove"`. Zero network dependencies, zero Firebase, zero remote telemetry.
- **Last Completed Task:** Phase 1 Design System Tokens & Typography Harmonization (verified).
- **Task Currently in Progress:** Phase 1 complete — awaiting explicit approval for Phase 2 Reusable UI Component Normalization.

---

## 3. Exact Next Recommended Action

1. **Primary Next Action:**
   - Propose Phase 2 Reusable UI Component Normalization file list and scope (e.g. standardizing cards, buttons, status badges across `:app` and `:checkin`).
   - Await explicit user approval before modifying any component files.
   - Do **NOT** redesign screens, alter layouts, or modify core protocol/security logic in Phase 2.

2. **Caution Regarding Features & Redesign:**
   - **DO NOT** begin arbitrary UI redesigns or rewrite core database entities without reviewing `docs/DECISIONS_LOG.md`.
   - Maintain strict backwards compatibility with `EVENTO-CANONICAL-V2` and `V2.1` package formats.

---

## 4. Critical File Paths & Directory Map

| Path | Purpose & Why It Matters |
| :--- | :--- |
| `settings.gradle.kts` | Declares modules: `:core`, `:app`, `:checkin`. |
| `build.gradle.kts` | Root build file containing `packageDistribution` task. |
| `gradle/libs.versions.toml` | Version catalog: AGP `9.1.1`, Kotlin `2.2.10`, Compose BOM `2024.09.00`, Room `2.7.0`. |
| `app/src/main/java/com/example/data/local/EventDatabase.kt` | Admin Room DB (v5, 5 tables). Do NOT modify schemas without non-destructive migration. |
| `core/src/main/java/com/evento/checkin/data/local/CheckInDatabase.kt` | Check-In Room DB (v3, 3 tables). Holds imported events, rosters, and attendance records. |
| `app/src/main/java/com/example/util/packageexport/security/EventoPackageSigner.kt` | Generates hardware-backed ECDSA P-256 keys in `AndroidKeyStore`. |
| `core/src/main/java/com/evento/checkin/util/packageutil/CheckInTrustAnchorRegistry.kt` | Check-In's public-key-only trust registry. Holds zero access to private signing keys. |
| `core/src/main/java/com/example/util/packageexport/EventoPackageCanonicalizer.kt` | Deterministic UTF-8 canonical byte serialization for package signing (`V2` and `V2.1`). |
| `core/src/main/java/com/evento/checkin/domain/qr/QrPayloadParser.kt` | Strict QR grammar parser enforcing `EVT1:<uuid>` with zero PII. |
| `core/src/main/java/com/evento/checkin/domain/engine/CheckInEngine.kt` | Idempotent check-in recording, license expiration, and device binding enforcement. |
| `public/index.html` & `server.js` | Bilingual Distribution Portal serving APK downloads on port 3000 / 8080. |
| `docs/MASTER_ROADMAP.md` | Strategic phase roadmap, milestone acceptance criteria, and status labels. |
| `docs/PROJECT_STATUS.md` | Current verified technical snapshot, SDK versions, test counts, and boundaries. |
| `docs/DECISIONS_LOG.md` | Architecture Decision Records (ADRs) and rejected alternatives. |

---

## 5. Standard Build & Verification Commands

```bash
# 1. Compile all Kotlin and Android modules
gradle :app:compileDebugKotlin :checkin:compileDebugKotlin :core:compileDebugKotlin

# 2. Run the complete automated test suite (346 tests)
gradle :app:testDebugUnitTest :checkin:testDebugUnitTest

# 3. Assemble debug APKs
gradle :app:assembleDebug :checkin:assembleDebug

# 4. Package distribution bundle into distribution/ and public/
gradle packageDistribution

# 5. Start distribution web portal (port 3000, proxied by nginx on 8080)
nohup node server.js > /tmp/server.log 2>&1 &
```

> **IMPORTANT:** In this cloud environment, always run Gradle via `gradle <task>`, never `./gradlew`.

---

## 6. Known Risks & Invariants to Guard

1. **Zero-Network Invariant:**
   - **Never** add network client libraries (Retrofit for external calls, Ktor, Volley) or analytics SDKs.
   - **Never** remove `<uses-permission android:name="android.permission.INTERNET" tools:node="remove" />` from the AndroidManifest files.
2. **Database Migration Safety:**
   - Always write explicit, non-destructive Room `Migration` objects for any schema alteration. Never rely on destructive fallback in production.
3. **Cryptographic Key Separation:**
   - The private EC key alias `evento_package_signing_key` belongs exclusively in `:app`. The `:checkin` module must only verify signatures via `CheckInTrustAnchorRegistry`.
4. **QR Grammar & Attendee Privacy:**
   - The badge QR code format must remain strictly `EVT1:<uuid>`. Never embed attendee names, emails, phones, or event titles into QR payloads.
5. **Cloud Run 32 MiB Payload Limit:**
   - The public Cloud Run proxy enforces a 32 MiB response size limit on responses with fixed `Content-Length`. In `server.js`, APK downloads must stream dynamically (chunked) without fixed `Content-Length`.

---

## 7. Session Resume Checklist

When resuming development in a new chat turn or session:

- [ ] **Step 1:** Confirm working directory is `/app/applet`.
- [ ] **Step 2:** Check `docs/PROJECT_STATUS.md` and `docs/MASTER_ROADMAP.md` for current verified state.
- [ ] **Step 3:** Verify build health: run `gradle :app:compileDebugKotlin :checkin:compileDebugKotlin`.
- [ ] **Step 4:** Ensure test baseline passes: run `gradle :app:testDebugUnitTest :checkin:testDebugUnitTest`.
- [ ] **Step 5:** Proceed strictly with the agreed next phase task without breaking air-gap or protocol compatibility.
