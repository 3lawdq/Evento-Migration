# Evento Master Roadmap

**Document Version:** 1.0  
**Last Verified Date:** 2026-10-13  
**Status:** ACTIVE BASELINE  
**Maintainer:** Senior Android Architect  

---

## 1. Product Vision & Responsibilities

Evento is a high-security, **100% offline-first attendance management and QR verification platform**, engineered for commercial events, conferences, and high-security gatherings. Evento explicitly rejects cloud-connected event management models to ensure zero network leakage, absolute attendee privacy, and reliable operation in air-gapped venues.

The system is decoupled into two independent Android applications and a shared protocol library:

```
                          ┌──────────────────────────┐
                          │   Evento Admin (:app)    │
                          │   com.aistudio.evento.   │
                          │        admin.evtd        │
                          └────────────┬─────────────┘
                                       │
                 Exports Tamper-Proof  │ .evento Archive
                 ECDSA P-256 Signed    │ (V2 / V2.1 + License)
                                       ▼
┌──────────────────────────┐     ┌──────────────────────────┐
│   Shared Core (:core)    │◄────┤  Evento Check-In (:checkin)
│     com.evento.core      │     │   com.aistudio.evento.   │
│  - Canonicalizer         │     │       checkin.ckin       │
│  - Package Verifier      │     └──────────────────────────┘
│  - License Validator     │
│  - CheckInDatabase (v3)  │
│  - QrPayloadParser       │
└──────────────────────────┘
```

### Module Responsibilities

1. **Evento Admin (`:app`)**:
   - **Target Audience:** Event organizers, operations directors, badge coordinators.
   - **Key Responsibilities:**
     - Event lifecycle management (creation, active switching, archiving, capacity limits).
     - Guest roster management (CRUD, attendance status, attendee hygiene scoring).
     - Roster data exchange: Offline Excel (`.xlsx`) import and export with UTF-8 / Arabic support.
     - WYSIWYG Badge Designer: Visual element positioning, multi-template support, background image management, square QR enforcement, RTL/LTR normalized coordinate math.
     - PDF Multi-Badge Batch Generator: Native Android PDF generation across standard paper sizes (A4, A5, Letter, A3, Single Badge), live layout preview, overflow warnings, cut marks, pagination.
     - Offline Analytics & Reporting: Post-event attendance summaries, arrival timelines, peak traffic detection, demographic distributions.
     - Secure Event Package Export: Generates `.evento` cryptographic containers signed with hardware-backed ECDSA P-256 keys via `AndroidKeyStore`, with optional offline event licensing and terminal device binding.

2. **Evento Check-In (`:checkin`)**:
   - **Target Audience:** Security personnel, gate attendants, reception staff.
   - **Key Responsibilities:**
     - Standalone execution: Zero dependency on `:app`; can be installed on dedicated guard terminals.
     - Package Ingestion: Imports `.evento` containers via Android Storage Access Framework (SAF).
     - Cryptographic Verification: Validates manifest SHA-256 digests and ECDSA P-256 digital signatures using an isolated public-key trust registry (`CheckInTrustAnchorRegistry`).
     - Runtime License Enforcement: Enforces event validity dates, max guest capacity, and terminal device identity bindings (`TERM-<UUID>`).
     - Real-Time QR Scanner: CameraX preview with bundled on-device Google ML Kit barcode scanner (100% local, no Google Play Services download needed).
     - Attendance Engine: Idempotent check-in recording, duplicate scan alerts, atomic SQLite persistence.
     - Offline Reporting & SAF Export: Filtered attendance logs, search with Arabic normalization, privacy-preserving CSV export via SAF with UTF-8 BOM.

3. **Shared Core Library (`:core`)**:
   - **Key Responsibilities:**
     - Domain models: `Event`, `Guest`, `AttendanceRecord`, `LicenseTerms`.
     - Protocol serialization: `EventoPackageCanonicalizer` (`EVENTO-CANONICAL-V2` and `V2.1`).
     - Verification engine: `EventoPackageVerifier` and `EventLicenseValidator`.
     - Data storage: `CheckInDatabase` (Room v3) and `CheckInDao`.
     - Security foundation: `QrPayloadParser` (`EVT1:<uuid>` grammar) and `CheckInDeviceIdentityManager`.

---

## 2. Architecture & Module Boundaries

| Metric / Boundary | Evento Admin (`:app`) | Evento Check-In (`:checkin`) | Shared Core (`:core`) |
| :--- | :--- | :--- | :--- |
| **Application ID** | `com.aistudio.evento.admin.evtd` | `com.aistudio.evento.checkin.ckin` | N/A (Android Library) |
| **Namespace** | `com.example` | `com.evento.checkin` | `com.evento.core` |
| **Compile / Target SDK** | 36 / 36 | 36 / 36 | 36 / 36 |
| **Min SDK** | 24 (Android 7.0) | 24 (Android 7.0) | 24 (Android 7.0) |
| **Room Database** | `EventDatabase` (v5, 5 tables) | Uses `:core` `CheckInDatabase` | `CheckInDatabase` (v3, 3 tables) |
| **Network Perms** | Stripped (`INTERNET` removed) | Stripped (`INTERNET` removed) | None |
| **Private Keys** | `AndroidKeyStore` EC Private Key | **ZERO ACCESS** | **ZERO ACCESS** |
| **Public Keys** | N/A | `CheckInTrustAnchorRegistry` | Models & Canonicalizer |

---

## 3. Major Project Phases & Verification Matrix

### Completed Phases

| Phase | Description | Key Deliverables | Status | Evidence Paths |
| :--- | :--- | :--- | :--- | :--- |
| **Phase 1–6** | Foundations & Admin Core | Room DB, Event/Guest CRUD, Card Designer Canvas, QR generator (`EVT1:`), PDF generator. | `VERIFIED COMPLETE` | `app/src/main/java/com/example/` |
| **Phase 7.1–7.5** | Check-In Terminal Core | CameraX + ML Kit scanning, Room `CheckInDatabase`, idempotent scan engine, CSV export, Arabic search. | `VERIFIED COMPLETE` | `checkin/src/main/java/`, `core/src/main/java/` |
| **Phase 7.6** | Asymmetric Digital Signing | ECDSA P-256 signing, `AndroidKeyStore` key isolation, `EVENTO-CANONICAL-V2`, Check-In trust anchor. | `VERIFIED COMPLETE` | `EventoPackageSigner.kt`, `CheckInTrustAnchorRegistry.kt` |
| **Phase 7.7** | Offline Licensing & Binding | `EVENTO-CANONICAL-V2.1`, `license.json`, device identity (`TERM-<UUID>`), Check-In DB migration v2->v3. | `VERIFIED COMPLETE` | `EventLicenseValidator.kt`, `CheckInDatabase.kt` |
| **Phase 7.8** | Air-Gap & Dependency Audit | Removal of Firebase plugins, strip transitive internet perms, clean build pipeline. | `VERIFIED COMPLETE` | `app/build.gradle.kts`, `AndroidManifest.xml` |
| **Phase 8** | Release Candidate Acceptance | 100% Arabic string parity (470 keys), end-to-end workflow verification, automated regression tests. | `VERIFIED COMPLETE` | `res/values-ar/strings.xml`, `ROADMAP.md` |
| **Phase 9** | Capacity, Multi-Template, PDF Grid | Guest capacity slots, background images, multi-template badges, multi-card PDF grid (A4, A5, Letter, A3). | `VERIFIED COMPLETE` | `PdfLayoutComponents.kt`, `Phase9ComprehensiveTest.kt` |
| **Phase 10** | Enterprise Polish & UX | IME soft input insets, square QR constraint, QR slider, dirty-state indicator, Enterprise light theme. | `VERIFIED COMPLETE` | `BadgeCanvas.kt`, `Phase10ComprehensiveTest.kt` |
| **Phase 11.1** | Reactive Dashboard Metrics | Room flow aggregation (`combine`), durable package export tracking (`exported_packages`, DB v4->v5). | `VERIFIED COMPLETE` | `DashboardViewModel.kt`, `DashboardMetricsTest.kt` |
| **Phase 11.2** | Post-Event Offline Analytics | `ReportsScreen`, arrival timeline, peak window detection, demographic breakdown, hygiene scoring. | `VERIFIED COMPLETE` | `ReportsScreen.kt`, `AnalyticsViewModelTest.kt` |
| **Phase 11.3** | Guest Excel Export | Offline `.xlsx` roster exporter, OpenXML `XlsxWriter`, round-trip parser compatibility, SAF sharing. | `VERIFIED COMPLETE` | `ExcelGuestExporter.kt`, `ExcelGuestExportTest.kt` |
| **Phase 11.4** | Cross-App Compatibility Audit | End-to-end tamper rejection matrix, Unicode/Arabic preservation, RFC-4122 UUID cross-app invariants. | `VERIFIED COMPLETE` | `CheckInPackageCompatibilityTest.kt` |
| **RC 1.0** | Production Readiness Audit | Zero-PII QR verification, zero-network air-gap compliance, log sanitization, database migration safety. | `VERIFIED COMPLETE` | `CHANGELOG.md` |

---

### Ongoing & Planned Phases

| Phase | Description | Scope & Acceptance Criteria | Priority | Status |
| :--- | :--- | :--- | :--- | :--- |
| **Phase 12** | Documentation Baseline | Establish repository-backed `MASTER_ROADMAP.md`, `PROJECT_STATUS.md`, `PROJECT_HANDOFF.md`, `DECISIONS_LOG.md`. | **P0 (Current)** | `IN PROGRESS` |
| **Phase 13** | Target Hardware & Device Acceptance | Test on physical devices running Android 8.0 through Android 15: CameraX autofocus in low-light, SAF file picker compatibility. | **P1** | `NEEDS VERIFICATION` (Blocked on physical device) |
| **Phase 14** | Production Release Signing Automation | CI/CD pipeline integration with external secret injection for release keystore (`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`). | **P1** | `PLANNED` |
| **Phase 15** | Card Designer Multi-Asset & Typography | Multiple custom vector logos, custom font loading, layered element ordering (Z-index). | **P2** | `PLANNED` |
| **Phase 16** | Multi-Terminal Attendance Reconciliation | Secure, offline merge tool in Admin to import attendance records from multiple check-in terminals without data collisions. | **P2** | `PLANNED` |

---

## 4. Phase Dependencies & Recommended Sequence

```
[Phase 12: Documentation Baseline] (CURRENT)
                  │
                  ▼
[Phase 13: Target Hardware & Device Acceptance] ◄── Requires physical test device
                  │
                  ▼
[Phase 14: Release Signing & CI/CD Packaging]
                  │
                  ├──────────────────────────────┐
                  ▼                              ▼
[Phase 15: Card Designer Enhancements]    [Phase 16: Multi-Terminal Reconciliation]
```

### Milestone Acceptance Criteria

1. **Hardware Acceptance Milestone (Phase 13):**
   - Check-In APK installed and launched on minimum API 24 physical device.
   - CameraX preview initializes cleanly; scans printed `EVT1:<uuid>` badge in < 300ms.
   - SAF document picker loads `.evento` archive from internal storage / USB drive.
   - No crash on orientation change, backgrounding, or process kill.

2. **Release Signing Milestone (Phase 14):**
   - `./gradlew assembleRelease` outputs signed APKs using production keystore.
   - `apksigner verify --verbose` confirms APK Signature Scheme v2/v3 validity.
   - ProGuard / R8 rules verified against Moshi codegen and Room reflection.
