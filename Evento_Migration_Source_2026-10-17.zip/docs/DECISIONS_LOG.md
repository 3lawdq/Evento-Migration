# Evento Architecture Decisions Log (ADR)

**Document Version:** 1.0  
**Snapshot Date:** 2026-10-13  
**Status:** RATIFIED & ACTIVE  
**Maintainer:** Senior Android Architect  

---

## Index of Decisions

- [ADR-001: Separation into Two Standalone Applications](#adr-001-separation-into-two-standalone-applications)
- [ADR-002: Strict 100% Air-Gapped Offline-First Architecture](#adr-002-strict-100-air-gapped-offline-first-architecture)
- [ADR-003: Asymmetric Cryptographic Package Signing (ECDSA P-256)](#adr-003-asymmetric-cryptographic-package-signing-ecdsa-p-256)
- [ADR-004: Decoupled Public-Key Trust Anchor Architecture in Check-In](#adr-004-decoupled-public-key-trust-anchor-architecture-in-check-in)
- [ADR-005: Privacy-Preserving Zero-PII QR Grammar](#adr-005-privacy-preserving-zero-pii-qr-grammar)
- [ADR-006: Deterministic Canonicalization Protocol (V2 & V2.1)](#adr-006-deterministic-canonicalization-protocol-v2--v21)
- [ADR-007: Cryptographic & License Validation Fail-Closed Security Policy](#adr-007-cryptographic--license-validation-fail-closed-security-policy)
- [ADR-008: On-Device Barcode Analysis via ML Kit](#adr-008-on-device-barcode-analysis-via-ml-kit)
- [ADR-009: Room Database Migration and Integrity Policy](#adr-009-room-database-migration-and-integrity-policy)
- [ADR-010: Android FileProvider Zero-Permission Sharing](#adr-010-android-fileprovider-zero-permission-sharing)
- [ADR-011: Material 3 Enterprise Light Theme & Full Bilingual Arabic RTL Parity](#adr-011-material-3-enterprise-light-theme--full-bilingual-arabic-rtl-parity)

---

### ADR-001: Separation into Two Standalone Applications
- **Date:** 2026-09-14
- **Status:** `ACCEPTED`
- **Scope:** System Architecture / Gradle Modules
- **Decision:** Split the platform into two independent Android application modules (`:app` for Evento Admin and `:checkin` for Evento Check-In) alongside a shared `:core` library.
- **Rationale:**
  1. Security isolation: Gate guards and receptionists operating check-in terminals must never have access to event creation, attendee editing, private cryptographic signing keys, or full organizer databases.
  2. Memory and resource footprint: Check-In devices are often rugged, low-cost handheld scanners that should not load heavy PDF generators, OpenXML parsers, or WYSIWYG badge designers.
  3. Independent APK deployment: Venues can install only the Check-In APK on gate devices while retaining the Admin APK strictly on management hardware.
- **Rejected Alternatives:**
  - *Single Monolithic App with Role-Based UI:* Rejected because client-side role toggles on offline devices are vulnerable to privilege escalation and unnecessarily expose organizer tools and signing logic on guard devices.

---

### ADR-002: Strict 100% Air-Gapped Offline-First Architecture
- **Date:** 2026-09-18
- **Status:** `ACCEPTED`
- **Scope:** Security & Network Policy
- **Decision:** Remove all network permissions (`INTERNET`, `ACCESS_NETWORK_STATE`) from production manifests via `tools:node="remove"`, completely eliminate cloud SDKs (Firebase, telemetry), and operate entirely offline.
- **Rationale:**
  1. High-security venues (defense, diplomatic, enterprise governance) frequently forbid network-connected devices.
  2. Reliability: Event gates frequently experience cellular congestion or RF jamming. Real-time gate operations must never depend on server connectivity.
  3. Total attendee privacy: Zero attendee PII ever leaves local terminal hardware over the internet.
- **Rejected Alternatives:**
  - *Cloud Sync with Offline Cache (e.g. Firestore / REST):* Rejected due to network dependency during peak ingress, privacy regulations, and security policies prohibiting cloud transmission of sensitive attendee data.

---

### ADR-003: Asymmetric Cryptographic Package Signing (ECDSA P-256)
- **Date:** 2026-09-15
- **Status:** `ACCEPTED`
- **Scope:** Cryptography & Trust Layer
- **Decision:** Protect `.evento` event packages using ECDSA digital signatures over the NIST P-256 (secp256r1) elliptic curve with `SHA256withECDSA`, backed by non-exportable hardware-isolated keys in `AndroidKeyStore`.
- **Rationale:**
  1. Non-repudiation and authenticity: Only authorized Admin terminals with the private signing key can issue valid event packages.
  2. Hardware security: `AndroidKeyStore` prevents extraction of the private key even on rooted or compromised hardware.
  3. Compact signature: P-256 signatures are compact (~70 bytes DER), fitting cleanly in package metadata.
- **Rejected Alternatives:**
  - *Symmetric Shared Secret (HMAC-SHA256):* Used in legacy V1 packages, but superseded for V2/V2.1 because symmetric HMAC requires sharing the secret key with Check-In terminals, enabling any terminal to forge packages.

---

### ADR-004: Decoupled Public-Key Trust Anchor Architecture in Check-In
- **Date:** 2026-09-15
- **Status:** `ACCEPTED`
- **Scope:** Check-In Terminal Security
- **Decision:** Evento Check-In holds only trusted public keys within a dedicated `CheckInTrustAnchorRegistry` and has zero access to private signing keys or `AndroidKeyStore` signing infrastructure.
- **Rationale:**
  1. Principle of least privilege: Gate terminals only need to verify packages, never sign them.
  2. Compromise containment: If a gate terminal is lost, stolen, or extracted, the attacker gains no ability to forge event packages.
- **Rejected Alternatives:**
  - *Bundling Admin Key Infrastructure in Core:* Rejected because distributing signing capabilities into Check-In violates security boundaries.

---

### ADR-005: Privacy-Preserving Zero-PII QR Grammar
- **Date:** 2026-09-14
- **Status:** `ACCEPTED`
- **Scope:** QR Engine & Attendee Privacy
- **Decision:** Attendee QR codes must strictly follow the format `EVT1:<RFC-4122 UUID>`. QR payloads must contain zero names, emails, phone numbers, job titles, or event metadata.
- **Rationale:**
  1. Eavesdropping prevention: Anyone photographing a badge across a room or in public cannot read attendee personal information without the verified offline database.
  2. Strict grammar enforcement: `QrPayloadParser` rejects any input with whitespace, newlines, extra delimiters, URLs, or JSON characters, preventing injection attacks.
- **Rejected Alternatives:**
  - *JSON or vCard Payloads:* Rejected because encoding attendee contact information directly onto printed badges exposes personal data to unauthorized visual scanning.

---

### ADR-006: Deterministic Canonicalization Protocol (V2 & V2.1)
- **Date:** 2026-09-15 / 2026-09-17
- **Status:** `ACCEPTED`
- **Scope:** Package Integrity Specification
- **Decision:** Standardize deterministic UTF-8 canonical byte serialization:
  - `DESCRIPTOR_V2` (`EVENTO-CANONICAL-V2`): Binds format version, package type, event attributes, guest count, guest scope, payload format, and SHA-256 digests of `event.json` and `guests.json`.
  - `DESCRIPTOR_V2_1` (`EVENTO-CANONICAL-V2.1`): Binds all V2 fields plus `licenseJsonSha256` for licensed packages.
- **Rationale:**
  1. Eliminates JSON serialization indeterminism across different JSON libraries or platforms.
  2. Guarantees bit-level identical signature inputs across Admin export and Check-In verification.
- **Rejected Alternatives:**
  - *Signing the Raw ZIP Archive Directly:* Rejected because ZIP archive headers vary by compression tool, timestamp, and filesystem entry ordering.

---

### ADR-007: Cryptographic & License Validation Fail-Closed Security Policy
- **Date:** 2026-09-17
- **Status:** `ACCEPTED`
- **Scope:** Verification & Attendance Engine
- **Decision:** If any signature verification, digest check, license expiry check, guest capacity bound, or device binding fails, the system immediately fails closed: the package is rejected, no database writes occur, and no check-in is logged.
- **Rationale:**
  1. Prevents unauthorized entry, forged attendees, or expired package reuse.
  2. Protects event security contracts under all error conditions.
- **Rejected Alternatives:**
  - *Warn and Allow (Permissive Mode):* Rejected because security terminals must never permit entry on untrusted or tampered packages.

---

### ADR-008: On-Device Barcode Analysis via ML Kit
- **Date:** 2026-09-16
- **Status:** `ACCEPTED`
- **Scope:** Camera & QR Scanning Pipeline
- **Decision:** Use Google ML Kit Barcode Scanning bundled on-device (`mlkit-barcode-scanning:17.3.0`) integrated with CameraX.
- **Rationale:**
  1. Instant scanning performance (< 50ms per frame) on low-power devices.
  2. Bundled model runs 100% offline without requiring Google Play Services model downloads.
- **Rejected Alternatives:**
  - *ZXing Android Embedded for Scanning:* Rejected due to inferior scanning speed, poor autofocus management on budget cameras, and weak low-light detection compared to ML Kit. (ZXing Core is retained solely for generating QR bitmap images in Admin).

---

### ADR-009: Room Database Migration and Integrity Policy
- **Date:** 2026-09-23
- **Status:** `ACCEPTED`
- **Scope:** Persistence Layer
- **Decision:** Enforce strict, non-destructive Room database migrations across all schema changes:
  - `EventDatabase` (v5): `MIGRATION_3_4` and `MIGRATION_4_5` with foreign-key cascading deletes.
  - `CheckInDatabase` (v3): `MIGRATION_1_2` and `MIGRATION_2_3`.
- **Rationale:**
  1. Prevents user data loss during app updates.
  2. Enforces relational integrity (e.g. deleting an event cascades to exported packages, guests, and badge templates).
- **Rejected Alternatives:**
  - *Destructive Fallback Migrations in Production:* Rejected because dropping database tables destroys organizer rosters and recorded attendance logs.

---

### ADR-010: Android FileProvider Zero-Permission Sharing
- **Date:** 2026-09-24
- **Status:** `ACCEPTED`
- **Scope:** Android Storage & Permissions
- **Decision:** All file export and sharing actions (PDF badges, Excel rosters, CSV attendance logs, `.evento` packages) must use Android `FileProvider` scoped to internal cache directories (`cacheDir/exported_*`) or SAF document creation (`ACTION_CREATE_DOCUMENT`).
- **Rationale:**
  1. Compliance with modern Android storage policies (scoped storage).
  2. Zero broad storage permissions (`MANAGE_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE` are never requested).
  3. Eliminates Google Play policy scrutiny and user permission friction.
- **Rejected Alternatives:**
  - *Writing directly to Public External Storage:* Rejected due to strict Android 11+ permission restrictions and privacy leakage risks.

---

### ADR-011: Material 3 Enterprise Light Theme & Full Bilingual Arabic RTL Parity
- **Date:** 2026-09-24
- **Status:** `ACCEPTED`
- **Scope:** UI Design & Internationalization
- **Decision:** Implement an Enterprise Light theme built on Material Design 3 guidelines with 100% string key parity between English (`res/values/strings.xml`) and Arabic (`res/values-ar/strings.xml`), accompanied by native RTL layout mirroring.
- **Rationale:**
  1. Arabic is a primary language requirement for Middle East commercial event markets.
  2. High-contrast light theme ensures legibility outdoors and under bright indoor venue lights.
  3. Mirroring layout direction (RTL) guarantees natural visual ergonomics for Arabic-speaking gate attendants.
- **Rejected Alternatives:**
  - *Partial or Machine Translation Fallbacks:* Rejected to maintain professional terminology across technical terms (e.g., cryptographic verification, badge dimensions, cut marks).
