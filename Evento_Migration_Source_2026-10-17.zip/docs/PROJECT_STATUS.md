# Evento Project Status

**Snapshot Date:** 2026-10-13  
**Architecture Lead:** Senior Android Architect  
**Project Health:** RELEASE CANDIDATE (RC 1.0) — DESIGN SYSTEM PHASE 1 TOKENS VERIFIED (346/346 TESTS PASSING)  

---

## 1. Verified Repository State

### Module & Artifact Matrix

| Attribute | Evento Admin (`:app`) | Evento Check-In (`:checkin`) | Shared Core (`:core`) |
| :--- | :--- | :--- | :--- |
| **Gradle Module** | `:app` | `:checkin` | `:core` |
| **Module Type** | `com.android.application` | `com.android.application` | `com.android.library` |
| **Application ID** | `com.aistudio.evento.admin.evtd` | `com.aistudio.evento.checkin.ckin` | N/A |
| **Namespace** | `com.example` | `com.evento.checkin` | `com.evento.core` |
| **Compile SDK** | 36 (minorApiLevel = 1) | 36 (minorApiLevel = 1) | 36 (minorApiLevel = 1) |
| **Target SDK** | 36 | 36 | N/A |
| **Min SDK** | 24 (Android 7.0) | 24 (Android 7.0) | 24 (Android 7.0) |
| **Version Code / Name** | `1` / `"1.0"` | `1` / `"1.0"` | N/A |
| **Source Compatibility**| Java 11 / JVM 11 | Java 11 / JVM 11 | Java 11 / JVM 11 |

### Dependency Versions (via `gradle/libs.versions.toml`)

- **Android Gradle Plugin (AGP):** `9.1.1`
- **Kotlin:** `2.2.10`
- **Compose BOM:** `2024.09.00`
- **Jetpack Compose Compiler:** Integrated via `org.jetbrains.kotlin.plugin.compose`
- **Material 3:** `1.3.0` (resolved from Compose BOM)
- **Room Persistence Library:** `2.7.0` (with KSP `2.3.5`)
- **Navigation Compose:** `2.8.9`
- **Lifecycle & ViewModel:** `2.8.7`
- **CameraX:** `1.5.0` (`camera-camera2`, `camera-lifecycle`, `camera-view`, `camera-core`)
- **Google ML Kit Barcode Scanning:** `17.3.0` (bundled on-device)
- **ZXing Core:** `3.5.3` (used for bitmap QR generation)
- **Moshi:** `1.15.2` (with codegen)
- **Robolectric:** `4.16.1`

---

## 2. Implemented Features Supported by Source Evidence

### A. Evento Admin (`:app`)
- **Event Lifecycle & Capacity Engine:**
  - Create, view, edit, activate, and archive events with capacity enforcement.
  - Auto-slot allocation with UUID pre-generation (`EVT1:<uuid>`).
  - Evidence: `app/src/main/java/com/example/ui/screens/events/EventsViewModel.kt`, `app/src/main/java/com/example/data/repository/EventRepository.kt`
- **Attendee Roster Management & Hygiene Scoring:**
  - Full attendee CRUD, invitation states (`INVITED`, `CONFIRMED`, `CHECKED_IN`, `DECLINED`).
  - Guest data hygiene scoring evaluating record completeness and contact validity.
  - Evidence: `app/src/main/java/com/example/data/model/GuestDataQuality.kt`, `app/src/main/java/com/example/ui/screens/guests/GuestsViewModel.kt`
- **Roster Excel Import & Export (`.xlsx`):**
  - OpenXML native spreadsheet generator and parser with zero Apache POI dependencies.
  - 8 standardized columns, RFC-4122 UUID preservation, Unicode & Arabic XML escaping.
  - Android `FileProvider` export sheet integration without external storage permissions.
  - Evidence: `app/src/main/java/com/example/util/excel/XlsxWriter.kt`, `app/src/main/java/com/example/util/excel/ExcelGuestExporter.kt`, `app/src/main/java/com/example/data/importer/ExcelGuestParser.kt`
- **WYSIWYG Card Designer:**
  - Multi-template creation, duplication with elements, active template toggling.
  - Normalized coordinate drag math ensuring consistent behavior in both LTR and RTL.
  - Background image URI loading and aspect-ratio preservation.
  - Strict 1:1 square constraint for QR code elements with real-time size slider.
  - Evidence: `app/src/main/java/com/example/ui/screens/designer/components/BadgeCanvas.kt`, `app/src/main/java/com/example/ui/screens/designer/CardDesignerViewModel.kt`
- **PDF Multi-Card Batch Generator:**
  - Native Android `PdfDocument` generation across paper formats (A4, A5, Letter, A3, Single).
  - Dynamic grid layout (rows × columns), configurable margins, zero-margin toggle, cut marks.
  - Real-time scaled visual preview sheet with overflow boundary validation.
  - Evidence: `app/src/main/java/com/example/util/pdf/AndroidPdfGenerator.kt`, `app/src/main/java/com/example/ui/screens/pdf/components/PdfLayoutComponents.kt`
- **Offline Analytics & Reports:**
  - Reactive Room aggregation across `EventDatabase` and `CheckInDatabase`.
  - Timeline distribution, peak arrival window algorithms, demographic breakdowns.
  - Evidence: `app/src/main/java/com/example/ui/screens/reports/AnalyticsViewModel.kt`, `app/src/main/java/com/example/ui/screens/reports/ReportsScreen.kt`
- **Cryptographic Package Export (`.evento`):**
  - ZIP container bundling `manifest.json`, `event.json`, `guests.json`, and optional `license.json`.
  - Hardware-backed ECDSA P-256 signing via `AndroidKeyStore` (`evento_package_signing_key`).
  - Durable export tracking persisted in Room `exported_packages` table.
  - Evidence: `app/src/main/java/com/example/util/packageexport/EventoPackageWriter.kt`, `app/src/main/java/com/example/util/packageexport/security/EventoPackageSigner.kt`, `app/src/main/java/com/example/data/local/dao/ExportedPackageDao.kt`

### B. Evento Check-In (`:checkin`)
- **Standalone Terminal Architecture:**
  - Fully decoupled launcher with zero dependencies on `:app` source code or assets.
  - Evidence: `checkin/src/main/AndroidManifest.xml`, `checkin/build.gradle.kts`
- **Cryptographic Package Ingestion & Verification:**
  - SAF document picker ingestion with Zip-Slip path-traversal blocking (`../`).
  - SHA-256 file digest checks and ECDSA P-256 signature verification against isolated public-key trust registry (`CheckInTrustAnchorRegistry`).
  - Evidence: `core/src/main/java/com/evento/checkin/util/packageutil/EventoPackageVerifier.kt`, `core/src/main/java/com/evento/checkin/util/packageutil/EventoPackageImporter.kt`
- **Offline License & Device Binding:**
  - Validates package validity periods (`issuedAt`, `expiresAt`), capacity caps, and terminal device identity binding (`TERM-<UUID>`).
  - Fail-closed evaluation preventing unauthorized terminals from recording check-ins.
  - Evidence: `core/src/main/java/com/evento/checkin/domain/license/EventLicenseValidator.kt`, `core/src/main/java/com/evento/checkin/security/CheckInDeviceIdentityManager.kt`
- **Real-Time QR Scanner:**
  - CameraX preview pipeline with on-device Google ML Kit barcode analysis.
  - Strict grammar parser for `EVT1:<uuid>` payload with zero PII exposure.
  - Haptic and audio feedback on valid, duplicate, or unrecognized badge scans.
  - Evidence: `checkin/src/main/java/com/evento/checkin/scanner/MlKitQrCodeDecoder.kt`, `core/src/main/java/com/evento/checkin/domain/qr/QrPayloadParser.kt`
- **Attendance Records & Privacy CSV Export:**
  - Room-backed persistent attendance logging with unique constraint on `(eventId, guestUuid)`.
  - Offline attendee log search with Arabic normalization (alef, teh marbuta, diacritics).
  - Privacy-preserving CSV export via SAF with UTF-8 BOM, omitting private attendee contact info.
  - Evidence: `core/src/main/java/com/evento/checkin/domain/export/AttendanceCsvExporter.kt`, `checkin/src/main/java/com/evento/checkin/ui/screens/records/AttendanceRecordsViewModel.kt`

### C. Design System & Theming (Phase 1 Tokens Implemented & Verified)
- **Centralized Brand Palette & Material 3 Mapping:**
  - Approved Evento Signature commercial palette mapped cleanly to Material 3 `lightColorScheme` and `darkColorScheme` across both applications.
  - Light Palette: Primary `#1D4ED8` (Royal Blue), onPrimary `#FFFFFF`, primaryContainer `#EFF6FF`, secondary/copper `#C56A4A` (restrained accent), background `#F8FAFC`, surface `#FFFFFF`, onBackground/onSurface `#172033` (WCAG AAA high contrast), onSurfaceVariant `#64748B`, outline/outlineVariant `#E2E8F0`.
  - Dark Palette: Primary `#8AB4FF` (Accessible Blue), onPrimary `#0B1220`, primaryContainer `#1E3A8A`, secondary/copper `#E7B89B` (restrained accent), background `#0B1220`, surface `#111C2E`, onBackground/onSurface `#F1F5F9` (WCAG AAA), onSurfaceVariant `#A8B3C7`, outline/outlineVariant `#28364A`.
  - Check-In emerald palette retired from active theme; legacy color aliases (`Emerald80`, `Emerald40`, `Mint80`, `Slate*`, etc.) and Admin template aliases (`Purple*`, `Pink*`) preserved in `Color.kt` for strict backwards compatibility.
- **Harmonized 12-Role Typography Scale:**
  - Standardized complete Material 3 typography scale across both applications (`displayLarge`, `headlineLarge`, `headlineMedium`, `titleLarge`, `titleMedium`, `titleSmall`, `bodyLarge`, `bodyMedium`, `bodySmall`, `labelLarge`, `labelMedium`, `labelSmall`).
  - Standardized `letterSpacing = 0.sp` across all 12 roles in both apps for optimal bilingual Arabic (RTL) and Latin (LTR) glyph rendering and legibility.
- **Theming Implementation Boundary:**
  - Strictly contained to six theme files:
    1. `app/src/main/java/com/example/ui/theme/Color.kt`
    2. `app/src/main/java/com/example/ui/theme/Type.kt`
    3. `app/src/main/java/com/example/ui/theme/Theme.kt`
    4. `checkin/src/main/java/com/evento/checkin/ui/theme/Color.kt`
    5. `checkin/src/main/java/com/evento/checkin/ui/theme/Type.kt`
    6. `checkin/src/main/java/com/evento/checkin/ui/theme/Theme.kt`
  - Existing system-following dark mode behavior remains active (`darkTheme = isSystemInDarkTheme()`); manual user-selectable theme mode and persisted preference are **NOT** implemented yet.
  - **Scope Constraint:** Token foundation only. No individual screens or custom components have been redesigned yet.
- **Evidence:** Verified source inspections in `app/src/main/java/com/example/ui/theme/` and `checkin/src/main/java/com/evento/checkin/ui/theme/`.

---

## 3. Database & Persistence Architecture

### Evento Admin: `EventDatabase` (`evento_admin.db`, Version 5)
- **Entities:**
  1. `EventEntity` (table `events`): Primary event definitions, status, capacity (`guest_capacity`).
  2. `GuestEntity` (table `guests`): Attendee metadata, RFC-4122 UUID, invitation status.
  3. `BadgeTemplateEntity` (table `badge_templates`): Canvas dimensions, background URI, active state (`is_active`).
  4. `BadgeElementEntity` (table `badge_elements`): Canvas elements (Text, QR, Image), coordinates, styles.
  5. `ExportedPackageEntity` (table `exported_packages`): Audit trail of generated `.evento` packages with foreign key cascade to `events`.
- **Migrations:**
  - `MIGRATION_3_4`: Adds `guest_capacity` to `events`, adds `is_active` to `badge_templates`.
  - `MIGRATION_4_5`: Creates table `exported_packages` and indexes on `event_id` and `exported_at`.

### Evento Check-In: `CheckInDatabase` (`evento_checkin.db`, Version 3)
- **Entities:**
  1. `ImportedEventEntity` (table `imported_events`): Active event attributes and license terms (`licenseId`, `licenseExpiresAt`, `licenseMaxGuests`, `licenseBoundDeviceId`, `licenseStatus`).
  2. `ImportedGuestEntity` (table `imported_guests`): Read-only attendee roster with immutable RFC-4122 UUIDs.
  3. `AttendanceRecordEntity` (table `attendance_records`): Timestamped scan records with unique composite index `(eventId, guestUuid)`.
- **Migrations:**
  - `MIGRATION_1_2`: Creates table `attendance_records` and unique index `(eventId, guestUuid)`.
  - `MIGRATION_2_3`: Adds licensing columns to `imported_events`.

---

## 4. Build, Verification, & Test Matrix

### Build Commands Verified by Repository

```bash
# Compile both applications and verify dependencies
gradle :app:compileDebugKotlin :checkin:compileDebugKotlin :core:compileDebugKotlin

# Run full unit & Robolectric test suites
gradle :app:testDebugUnitTest :checkin:testDebugUnitTest

# Assemble debug APKs
gradle :app:assembleDebug :checkin:assembleDebug

# Bundle distribution artifacts into distribution/ and public/
gradle packageDistribution
```

### Automated Test Suite Baseline
- **Phase 0 Historical Baseline Run (2026-10-13):**
  - Executed command: `gradle :app:testDebugUnitTest :checkin:testDebugUnitTest`
  - Total tests executed: **346 tests** (223 in `:app`, 123 in `:checkin`).
  - **`:app` Suite:** 223/223 passed (100% green, 0 failures, 0 errors, 0 skipped across 22 test files).
  - **`:checkin` Suite:** 122/123 passed (1 failure: `CheckInSettingsClearAttendanceRoboTest.testClearAttendanceCardAndConfirmationFlow` due to Robolectric assertion on dialog display timing).
  - Core Module Tests: Verified via application Robolectric suites.
- **Phase 1 Verified Full Suite & Rerun (2026-10-13):**
  - Executed commands:
    - `gradle :app:compileDebugKotlin :checkin:compileDebugKotlin :core:compileDebugKotlin` -> `BUILD SUCCESSFUL in 1s` (clean compilation across all modules).
    - `gradle :app:testDebugUnitTest :checkin:testDebugUnitTest --rerun-tasks` -> `BUILD SUCCESSFUL in 3m 47s` (79 tasks executed).
    - `gradle :checkin:testDebugUnitTest --tests "com.evento.checkin.CheckInSettingsClearAttendanceRoboTest*"` -> `BUILD SUCCESSFUL in 22s`.
    - `gradle :app:assembleDebug :checkin:assembleDebug` -> `BUILD SUCCESSFUL in 4s`.
    - `gradle packageDistribution` -> `BUILD SUCCESSFUL in 4s`.
  - Total tests executed: **346 tests** (223 in `:app`, 123 in `:checkin`).
  - **`:app` Suite:** 223/223 passed (100% green, 0 failures, 0 errors, 0 skipped across 22 test files).
  - **`:checkin` Suite:** 123/123 passed (100% green, 0 failures, 0 errors, 0 skipped across 12 test files).
  - **Overall Status:** **100% Pass Rate (346/346)**.
  - **Targeted Test Fix Confirmation:** The previously failing test `CheckInSettingsClearAttendanceRoboTest.testClearAttendanceCardAndConfirmationFlow` passed cleanly in both the targeted rerun (duration 16.672s) and the full rerun. Verified directly from `checkin/build/test-results/testDebugUnitTest/TEST-com.evento.checkin.CheckInSettingsClearAttendanceRoboTest.xml` (`tests="1" skipped="0" failures="0" errors="0"`).
- **Key Test Suites in Repository:**
  - `CheckInPackageCompatibilityTest.kt`: 19 end-to-end cross-application integration scenarios.
  - `CheckInLicensePackageVerificationTest.kt`: Cryptographic license validation and tampering rejection.
  - `CheckInLicensePersistenceAndEnforcementTest.kt`: Scan-time license constraint enforcement.
  - `ExcelGuestExportTest.kt`: Large roster export (1,000+ guests), Unicode/Arabic safety, round-trip import.
  - `DashboardMetricsTest.kt`: Room flow metric combinations and cascade integrity.
  - `AnalyticsViewModelTest.kt`: Timeline bucketing and arrival rate algorithms.
  - `Phase10ComprehensiveTest.kt` & `Phase9ComprehensiveTest.kt`: UI, PDF math, capacity allocation.

---

## 5. Security & Air-Gap Compliance Status

| Security Control | Implementation Mechanism | Status |
| :--- | :--- | :--- |
| **Air-Gap Enforcement** | Manifest `tools:node="remove"` for `INTERNET` and `ACCESS_NETWORK_STATE` | `VERIFIED CONFORMANT` |
| **No Cloud SDKs** | Zero Firebase, zero AWS, zero analytics SDKs in production dependencies | `VERIFIED CONFORMANT` |
| **Zero-PII QR Grammar** | `EVT1:<uuid>` grammar validated strictly by `QrPayloadParser`; zero PII in payloads | `VERIFIED CONFORMANT` |
| **Key Isolation** | Private EC key stored in `AndroidKeyStore`; Check-In holds only public trust anchor | `VERIFIED CONFORMANT` |
| **Tamper Resistance** | Canonical UTF-8 byte serialization (`EVENTO-CANONICAL-V2.1`) with fail-closed rejection | `VERIFIED CONFORMANT` |
| **Zip-Slip Protection** | Canonical path validation blocking path traversal entries (`../`) | `VERIFIED CONFORMANT` |
| **Privacy SAF Export** | UTF-8 BOM CSV export strips attendee contact info, internal IDs, and phone numbers | `VERIFIED CONFORMANT` |

---

## 6. Known Warnings & Unverified Areas

1. **Manifest Merger Warnings:**
   - Warning: `uses-permission#android.permission.INTERNET was tagged at AndroidManifest.xml:12 to remove other declarations but no other declaration present`
   - Evaluation: Harmless intentional safeguard ensuring transitive dependencies cannot inject network permissions.
2. **Physical Device Verification:**
   - Status: `UNVERIFIED` on real physical hardware.
   - Reason: Cloud execution environment lacks USB-connected physical Android devices (`adb devices` is empty).
   - Remaining Verification Need: Testing CameraX autofocus under low ambient light and SAF file picker integration across different vendor OEM skins (Samsung OneUI, Xiaomi MIUI, Google Pixel).
3. **Release Keystore Configuration:**
   - Status: Pending external production credentials.
   - Current State: `app/build.gradle.kts` references environment variables `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`; falls back to local JKS placeholder if not set. Debug builds use valid committed `debug.keystore`.
4. **Git Version Control Status:**
   - Status: `UNAVAILABLE` (`.git` repository metadata is not present in the workspace root).
   - Consequence: Normal Git diff, blame, and commit history verification cannot be performed. Code state is verified through direct filesystem inspection, checksum comparison, and build/test artifacts.
5. **Distribution Endpoint Availability & Verification Reality:**
   - Local Serving: Verified returning `HTTP 200 OK` with binary `Content-Type: application/vnd.android.package-archive` on both `http://localhost:3000/distribution/...` and `http://localhost:8080/distribution/...`.
   - External Development URL (`https://ais-dev-.../distribution/...`): Returns `HTTP 200 OK` with `Content-Type: text/html` (AI Studio web authentication bridge login page, not direct binary APK download).
   - External Shared URL (`https://ais-pre-.../distribution/...`): Returns `HTTP 404 Not Found` (shared deployment has not been published via AI Studio).
   - Operational Reality: External downloads are **NOT** publicly accessible or ready for end-user distribution without an active developer AI Studio session.
6. **Next Planned Milestone (Phase 2):**
   - Stage: Phase 2 Reusable UI Component Normalization.
   - Status: Pending explicit user approval.
   - Guardrail: Phase 1 implemented design tokens and typography only; zero individual application screens or layouts have been altered yet.
