# Evento Project Roadmap

## Phase 7: Evento Check-In Terminal

- [x] **Phase 7.1 — Check-In Foundation**: App structure, architecture, security constraints, and foundational UI.
- [x] **Phase 7.2 — Event Package Import & Verification**: Tamper-proof `.evento` package parsing, SHA-256 HMAC verification, atomic database ingestion.
- [x] **Phase 7.3A — Attendance Database + Check-In Engine**: Offline-first Room persistence, idempotent scans, duplicate check-in prevention.
- [x] **Phase 7.3B — QR Parser + Offline Guest Lookup**: Secure payload parser, guest lookup engine, and comprehensive validation.
- [x] **Phase 7.3C — CameraX + Offline QR Scanner**: CameraX integration, ML Kit barcode scanning, audio/haptic feedback, instant offline verification.
- [x] **Phase 7.4 — Operational UX + Live Statistics**: Live check-in statistics, breakdown by organization and timeline, recent check-in cards.
- [x] **Phase 7.5 — Attendance Records + Export + Local Data Management**: Complete offline attendance terminal records view, search/filtering (name/org/job title/today), privacy-preserving CSV export via SAF with UTF-8 BOM, and event-scoped local attendance records clearance.
- [x] **Phase 7.6 — Secure Event Package Signing & Trust Anchor**: Asymmetric ECDSA P-256 digital signature, AndroidKeyStore key isolation, deterministic canonicalization, public-key-only Check-In trust anchor registry, fail-closed verification, and dual-mode security UI badges.
- [x] **Phase 7.7 — Event License Validation & Device Binding Foundation**:
  - [x] **Step 1 — Check-In License-Aware Package Verification**: `license.json` extraction, SHA-256 integrity check, `EVENTO-CANONICAL-V2.1` canonicalization binding, `EventLicenseValidator` integration, and fail-closed security pipeline.
  - [x] **Step 2 — License Room Migration & Storage**: Non-destructive Room Migration V2 -> V3, `imported_events` schema extension, and entity persistence.
  - [x] **Step 3 — CheckInEngine License & Device Enforcement**: Offline capacity, expiration, and terminal device identity binding validation on scan.
  - [x] **Step 4 — Device Identity Wiring & Admin License Configuration**: Full end-to-end integration across Admin export UI and Check-In terminal security.
- [x] **Phase 7.8 — Production Hardening & Release Readiness**:
  - [x] Baseline and regression test suite audit (265 unit/Robolectric tests passing green).
  - [x] Removal of unused Google Services plugin and unused Firebase dependencies/configurations.
  - [x] Verification of clean offline build without FirebaseApp initialization failures.

## Phase 8: Release Candidate & Real-Device Acceptance
- [x] **Baseline & Automated Test Suite Verification**: 265/265 unit and Robolectric tests passing green; compilation and assembleDebug clean.
- [x] **End-to-End Workflow Audit**: Complete verification across Admin (event creation, guest management, EVT1 QR, Card Designer, PDF generation, .evento package export) and Check-In (package import, license verification, offline QR scanning, idempotent attendance, live statistics, CSV export).
- [x] **Package Security & Cryptographic Integrity**: ECDSA P-256 signature verification, SHA-256 HMAC integrity, V2.1 canonicalization binding, zip-slip/path-traversal protection, and fail-closed tampering rejection.
- [x] **Offline-First Zero-Cloud Architecture**: 100% offline verification; zero network permissions, zero cloud SDKs, zero remote dependencies; ML Kit barcode scanning runs strictly on-device.
- [x] **Database & Migrations**: Verified Room schema integrity, non-destructive V1 -> V2 -> V3 migrations, atomic package ingestion, and event-scoped local data management.
- [x] **UI & Dual-Language Localization**: 100% string key parity between English and Arabic (470 keys), full RTL support, localized scanner feedback, and error reporting.
- [!] **Physical Device Testing**: Formally marked `UNVERIFIED` due to lack of connected physical hardware (`adb devices` list empty) in the cloud build container; Robolectric JVM acceptance and build verification fully passed.

## Phase 9: Guest Capacity, Card Background, Multi-Template, & Multi-Card PDF Layout Engine
- [x] **Guest Capacity & Slot Allocation**: Event capacity configuration, transactional empty slot allocation, unique cryptographic UUID assignment, safe expansion and reduction, validation blocking reduction below populated guest count, and cross-event isolation.
- [x] **Card Designer Background Image Management**: Background image selection, preview, Room persistence, in-place replacement, and safe removal.
- [x] **Multiple Badge Templates**: Multi-template creation, renaming, duplication with elements, active template selection, and cascading deletion.
- [x] **Horizontal Drag Coordinate Math**: Coordinate normalization ensuring rightward/leftward dragging behaves consistently across both LTR and RTL layouts.
- [x] **PDF Multi-Card Layout Engine**: Multi-card grid placement supporting A4, A5, US Letter, A3, and Single Badge with Portrait/Landscape orientation swapping, zero margins, custom margins/spacing, and cut marks.
- [x] **PDF Live Layout Preview**: Mathematically scaled live preview reflecting paper size, orientation, grid rows/cols, margins, card aspect ratio, and overflow warning banner.
- [x] **Dual-Language Localization**: Full string key parity across English and Arabic dictionaries.
- [x] **Comprehensive Automated Verification**: 281 tests passing (265 regression + 16 new Phase 9 tests) covering capacity invariants, template lifecycle, PDF pagination, and layout math.

## Phase 10: Enterprise Production Polish & Real-Device UX Refinement
- [x] **IME & Keyboard Inset Handling**: Form scrolling with keyboard open via `imePadding()` and window soft input resize.
- [x] **Square QR Constraint**: Enforced strict 1:1 aspect ratio constraint for QR elements regardless of card orientation.
- [x] **Card Designer Controls**: Dedicated QR size slider and template save button with dirty-state indicator.
- [x] **PDF & Excel Exporters**: Clean single-action export buttons and UUID preservation for attendees.
- [x] **Enterprise Light Theme**: Clean M3 light theme palette and robust RTL styling.

## Phase 11: Production Integration & Advanced Analytics
- [x] **Phase 11.1 — Live Dashboard Metrics & Reactive Overview**:
  - Replaced hardcoded stats with Room-backed reactive metrics (`totalEvents`, `activeEvents`, `totalGuests`, `designedBadges`, `preparedPackages`).
  - Added Room Migration 4 -> 5 creating `exported_packages` table with cascading foreign keys for durable package export tracking.
  - Added `getTotalTemplatesCount()` query and repository method.
  - Implemented `DashboardViewModel` combining Room flows with zero polling and zero in-memory full list allocations.
  - Added `DashboardMetricsTest` verifying all metrics, reactive state emissions, and cascade deletion.
- [x] **Phase 11.2 — Post-Event Analytics & Reports**:
  - Offline-first Room-backed post-event analytics engine querying both `EventDatabase` and `CheckInDatabase`.
  - Aggregated metrics: Attendance Summary (total, attended, remaining, attendance & non-attendance percentages), Invitation Status Breakdown, and Cross-Analysis.
  - Check-in activity timeline bucketed chronologically by hour with peak arrival window detection.
  - Guest data hygiene & completeness analysis leveraging `GuestDataQualityEvaluator`.
  - Demographic breakdowns by organization and job title.
  - Material 3 `ReportsScreen` with event selector dropdown, visual progress bars, and full English + Arabic RTL localization.
  - Unit test suite (`AnalyticsViewModelTest`) verifying calculations, cross-analysis, and peak window detection.
- [x] **Phase 11.3 — Guest Excel Roster Export**:
  - Event-scoped, offline, Room-backed `.xlsx` roster export system reusing `ExcelGuestExporter` and `XlsxWriter`.
  - Full support for 8 standardized fields: Full Name, Organization, Job Title, Email, Phone, Status, UUID, Notes.
  - UUID preservation (zero regeneration), strict read-only database invariants, and zero modification to attendees.
  - Cross-event isolation ensuring exported rosters contain only attendees where `guest.eventId == selectedEventId`.
  - Unicode and Arabic character preservation in exported content and sanitized filenames without path traversal.
  - Round-trip compatibility verified against the frozen `ExcelGuestParser`.
  - Sharing via Android `FileProvider` (`cacheDir/exported_excel`) with zero broad storage permissions.
  - Automated test suite (`ExcelGuestExportTest`) covering all 10 core verification scenarios.
- [x] **Phase 11.4 — Check-In Package Compatibility Verification**:
  - End-to-end verification of the full compatibility chain: Admin Export (`EventoPackageWriter`) -> .evento archive -> Check-In Import (`EventoPackageImporter`) -> Verification (`EventoPackageVerifier`) -> Room Persistence (`CheckInDatabase`) -> QR Engine (`CheckInEngine` / `QrCheckInService`) -> Attendance.
  - Verified ECDSA P-256 digital signature generation and verification across `EVENTO-CANONICAL-V2` and `EVENTO-CANONICAL-V2.1`.
  - Verified SHA-256 integrity checks across `manifest.json`, `event.json`, `guests.json`, and `license.json`.
  - Verified complete tamper rejection matrix: modified manifests, event details, guest list, license metadata, invalid signatures, missing files, path-traversal attacks, and duplicate ZIP entries fail closed.
  - Verified runtime license constraints: expiry, max guests, and device binding (`boundDeviceId`).
  - Verified Arabic and multilingual Unicode text preservation from Admin through Check-In and Room database.
  - Verified immutable RFC-4122 UUID preservation matching `EVT1:<uuid>` QR badge grammar and idempotent attendance records.
  - Automated test suite (`CheckInPackageCompatibilityTest`) with 19 comprehensive end-to-end scenarios.
- [x] **Release Candidate — Production Readiness & Security Audit**:
  - Overall Status: Automated verification complete — physical acceptance pending.
  - Verified production build configurations for Evento Admin and Evento Check-In.
  - Offline security hardening: confirmed zero Firebase SDKs, zero telemetry/analytics SDKs, and stripped transitive network permissions (`INTERNET` / `ACCESS_NETWORK_STATE`) via manifest merger rules for strict air-gapped operation.
  - Zero broad storage permissions: safe file sharing via Android `FileProvider`.
  - Audited Room database versions and verified non-destructive migration pathways (Admin v5, Check-In v3).
  - Production code logging audit: verified zero sensitive logging, zero PII leakage, zero debug bypasses.
  - Validated release compilation (`compileReleaseKotlin`, `dexBuilderRelease`, `lintVitalRelease`).
  - Test suite baseline verified: 341 tests passing with 0 failures and 0 errors.




