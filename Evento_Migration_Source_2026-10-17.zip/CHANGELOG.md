# Changelog

## [Release Candidate 1.0] - 2026-09-24

### Production Readiness & Release Candidate Audit
- **Security & Air-Gapped Operation**:
  - Hardened AndroidManifest against transitive network permissions (`INTERNET`, `ACCESS_NETWORK_STATE`) via `tools:node="remove"`, guaranteeing zero-network air-gapped compliance.
  - Verified complete absence of Firebase SDKs, telemetry, crash reporting libraries, and external HTTP network clients in production code.
  - Verified zero PII in QR payloads (`EVT1:<uuid>` format only).
  - Audited production code for logging: verified zero `Log.*`, `println`, or `printStackTrace` statements outputting sensitive attendee or cryptographic metadata.
  - Verified no private keys, passwords, or production secrets are committed in source code or repository.
- **Database & Migration Audit**:
  - Evento Admin Room database: Version 5 (EventEntity, GuestEntity, BadgeTemplateEntity, BadgeElementEntity, ExportedPackageEntity), non-destructive migrations `MIGRATION_3_4` and `MIGRATION_4_5` verified.
  - Evento Check-In Room database: Version 3 (ImportedEventEntity, ImportedGuestEntity, AttendanceRecordEntity), non-destructive migrations `MIGRATION_1_2` and `MIGRATION_2_3` verified.
  - Process death & restart resilience verified via persistent SQLite storage.
- **Build & Verification Status**:
  - Full automated suite: 341/341 tests passing (0 failures, 0 errors, 0 skipped).
  - Debug APK assembled cleanly (45MB).
  - Release compilation succeeded across all tasks (`compileReleaseKotlin`, `dexBuilderRelease`, `lintVitalRelease`); release package signing pending external production keystore configuration.
  - Real-device status: Automated/static verification complete; physical-device acceptance remains pending target hardware testing.

## [Phase 11.4] - 2026-09-24

### Added & Completed
- **Check-In Package Compatibility Verification (Cross-Application End-to-End Audit)**:
  - Verified the complete end-to-end package export and import pipeline: Evento Admin (`EventoPackageWriter`) -> `.evento` container -> Evento Check-In (`EventoPackageImporter`) -> Security Engine (`EventoPackageVerifier`) -> Room persistence (`CheckInDatabase`) -> QR attendance engine (`CheckInEngine` / `QrCheckInService`).
  - **Cryptographic & Protocol Alignment**: Validated package format version (V2), signature format (V2 / V2.1 with SHA256withECDSA over NIST P-256), canonical byte reconstruction (`EVENTO-CANONICAL-V2` and `EVENTO-CANONICAL-V2.1`), and SHA-256 file hashes.
  - **Tamper Resistance Matrix**: Confirmed fail-closed rejection for tampered manifests, modified event details, altered guest rosters, tampered license terms, missing signature files, forged ECDSA signatures, path traversal (`../`) attacks, and duplicate ZIP entries.
  - **License & Governance Rules**: Verified enforcement of license validity periods (expired or not-yet-valid), guest capacity limits, and terminal device identity binding (`boundDeviceId`).
  - **Unicode & Arabic Support**: Verified complete preservation of Arabic names, titles, organizations, locations, and special XML/JSON punctuation across both applications.
  - **QR Code & Offline Attendance**: Confirmed seamless interoperability between Admin guest UUIDs and Check-In QR scanner grammar (`EVT1:<uuid>`), verifying idempotent duplicate check-in warnings and cross-event isolation.
  - **Automated Verification Suite**: Added comprehensive test suite `CheckInPackageCompatibilityTest` with 19 end-to-end integration test scenarios.

## [Phase 11.3] - 2026-09-24

### Added & Completed
- **Guest Excel Roster Export System (Production Hardening)**:
  - Hardened offline `.xlsx` guest roster export system leveraging native lightweight OpenXML generator `XlsxWriter` and `ExcelGuestExporter`.
  - **Standardized Field Export**: Exports all 8 canonical fields: `Full Name`, `Organization`, `Job Title`, `Email`, `Phone`, `Invitation Status`, `UUID`, and `Notes`.
  - **UUID & Database Integrity**: Preserves original immutable cryptographic UUIDs with zero regeneration; read-only operations ensure no changes to attendance, database rows, or event records.
  - **Cross-Event Isolation**: Strictly enforces `guest.eventId == selectedEventId` ensuring cross-event guest roster isolation.
  - **Arabic & RTL Support**: Complete UTF-8 character and XML entity escaping for Arabic, English, and mixed-language attendee and organization data.
  - **Safe Unicode Filename Sanitization**: Retains Arabic letters in exported filenames (`Evento_<event_name>_Guests_<timestamp>.xlsx`) while preventing path traversal and illegal filesystem characters.
  - **Round-Trip Import/Export Compatibility**: Verified compatibility with the frozen `ExcelGuestParser` import engine without modifying parser code.
  - **Zero-Permission File Sharing**: Uses `FileProvider` (`cacheDir/exported_excel`) for native Android share sheet integration with zero external storage permissions (`MANAGE_EXTERNAL_STORAGE` / `WRITE_EXTERNAL_STORAGE`).
- **Automated Verification**:
  - Added comprehensive test suite `ExcelGuestExportTest` covering empty lists, single & multiple guests, Arabic text, XML characters, UUID preservation, cross-event isolation, large roster export (1,000+ guests in < 500ms), and round-trip parsing with `ExcelGuestParser`.
  - Total automated test count increased to 322 tests passing green.

## [Phase 11.2] - 2026-09-23

### Added & Completed
- **Post-Event Analytics & Reports System (Offline-First)**:
  - Built an offline-first, Room-backed analytics engine in `AnalyticsViewModel` synthesizing live data from `EventDatabase` (`GuestEntity`, `EventEntity`) and `CheckInDatabase` (`AttendanceRecordEntity`).
  - **Attendance Overview**: Computes total guests, checked-in guests, remaining un-checked-in, attendance percentage, and non-attendance percentage.
  - **Invitation Status Breakdown & Cross-Analysis**: Aggregates distribution across `INVITED`, `CONFIRMED`, `CHECKED_IN`, and `DECLINED` statuses, cross-referencing planned status with actual check-in records.
  - **Check-in Timeline & Peak Arrival Period**: Computes hourly check-in distribution and dynamically identifies peak traffic period and rate.
  - **Demographic Breakdown**: Provides distribution and attendance percentages grouped by organization and job title.
  - **Guest Data Hygiene & Quality Evaluation**: Evaluates record completeness, missing email/phone/job title fields using `GuestDataQualityEvaluator`.
- **UI & Presentation**:
  - Implemented Material 3 `ReportsScreen` featuring an event selector, high-visibility metric overview cards, status progress indicators, chronological activity lists, and quality summaries.
  - Complete dual-language localization in English (`values/strings.xml`) and Arabic (`values-ar/strings.xml`) with native RTL support.
  - Integrated into `EventoApp` drawer navigation with factory-based ViewModel injection.
- **Automated Verification**:
  - Added `AnalyticsViewModelTest` covering initial empty states, accurate attendance/cross-analysis calculations, organization & job title breakdowns, and timeline/peak window algorithms.
  - Full test suite passes green (312/312 tests).

## [Phase 11.1] - 2026-09-23

### Added & Completed
- **Live Dashboard Metrics & Reactive Room Flow Architecture**:
  - Replaced all hardcoded values on the Dashboard (`stat_badges`, `stat_checkin`) with real, Room-backed reactive metrics.
  - Implemented `DashboardViewModel` with `DashboardUiState` aggregating counts via `combine(...)` for `totalEvents`, `activeEvents`, `totalGuests`, `designedBadges`, and `preparedPackages`.
  - Zero polling, zero manual refresh, and zero full guest list memory allocations (backed by optimized Room `COUNT(*)` queries).
- **Durable Package Export Tracking & Room Migration 4 -> 5**:
  - Created `ExportedPackageEntity` and `ExportedPackageDao` with foreign key cascade on `event_id`.
  - Added non-destructive Room `MIGRATION_4_5` creating table `exported_packages` and indexes on `event_id` and `exported_at`.
  - Updated `EventPackageRepository` and `EventPackageRepositoryImpl` to persist metadata (`fileName`, `guestCount`, `fileSizeBytes`, `isLicensed`, `exportedAt`) upon successful `.evento` package creation.
  - Retained historical re-export records while preserving cryptographic ZIP structure and signing.
- **Badge Metrics Query & Repository Extension**:
  - Added `getTotalTemplatesCount(): Flow<Int>` to `BadgeDao` and exposed it through `BadgeTemplateRepository`.
- **Automated Verification Suite**:
  - Added `DashboardMetricsTest` covering initial empty state, event counts, active status changes, guest insertions/deletions, template additions/deletions, package exports, re-exports, cascade deletion on event removal, and migration 4 -> 5 integrity.
  - All 309 automated tests in the test suite pass green with zero regressions.

## [Phase 10] - 2026-09-22

### Added & Completed
- **Enterprise UX Polish & Real-Device Refinement**:
  - IME keyboard inset padding ensuring scrollable forms and visible action buttons.
  - Enforced 1:1 square aspect ratio for QR elements across portrait and landscape card orientations.
  - Added QR size slider and template save button with dirty-state indicator.
  - Added direct PDF and Excel export buttons with attendee UUID preservation.
  - Polished Enterprise Light Theme styling.

## [Phase 9] - 2026-09-19

### Added & Completed
- **Guest Capacity & Slot Allocation Engine**:
  - Event capacity model with atomic creation of empty attendee slots (`autoCreateSlots = true`).
  - Cryptographically secure unique UUID assignment (`EVT1:<uuid>`) for all attendee slots.
  - Safe capacity expansion adding unassigned slots, safe capacity reduction pruning unassigned slots, and blocked reduction with explicit error messaging when assigned attendees exceed target capacity.
  - Full cross-event isolation ensuring slots for one event never mutate another.
- **Card Designer Background Image Management**:
  - Selection, rendering, and Room persistence of background image URIs on badge templates.
  - Background image replacement and safe removal with null state safety.
  - Proportional aspect-ratio matching utility.
- **Multiple Badge Templates & Active Selection**:
  - Event-scoped template creation, renaming, and duplication (duplicating both template configuration and all associated elements).
  - Single active template enforcement per event, with active/inactive visual status badges.
  - Cascading deletion of template elements upon template removal.
- **Horizontal Drag Direction**:
  - Normalized coordinate system updates in `BadgeCanvas` guaranteeing that dragging right always increases X and dragging left always decreases X regardless of ambient layout direction (LTR & RTL).
- **PDF Multi-Card Layout Engine**:
  - Support for standard paper formats: A4 (210×297 mm), A5 (148×210 mm), US Letter (215.9×279.4 mm), A3 (297×420 mm), and Single Badge.
  - Orientation swapping (Portrait and Landscape) with automatic recalculation of effective paper dimensions and printable area.
  - Dynamic grid configuration (rows × columns) with configurable margins, "Zero Margins" quick-toggle, card spacing, and cut marks.
  - Printable area validation preventing layout overflow and cut-off badges.
  - Sequential pagination handling large attendee batches (e.g., 500 guests across 56 pages) with zero dropped or duplicate attendees.
- **Live PDF Page Layout Preview**:
  - Accurate preview sheet reflecting paper size, orientation, grid rows/cols, margins, spacing, card aspect ratio, and background color.
  - Real-time overflow detection banner warning users if configured grid exceeds printable page dimensions.
- **Full Localization Parity**:
  - Added all layout configuration, paper size, orientation, zero margins, and cut marks string keys in both English (`values/strings.xml`) and Arabic (`values-ar/strings.xml`).
- **Comprehensive Automated Test Suite**:
  - Created `Phase9ComprehensiveTest.kt` with 16 automated tests covering all Phase 9 domains.
  - 100% test pass rate across the full project test suite (281/281 tests passing green).

## [Phase 8] - 2026-09-18

### Release Candidate Acceptance & Localization Completeness
- **Full Localization Parity**: Achieved 100% string parity between English and Arabic resource dictionaries (470/470 keys translated), completing Arabic translations for the PDF Batch Generator screen (`pdf_*` resource bundle).
- **Release Candidate Audit**: Verified end-to-end operational workflows, asymmetric ECDSA P-256 signatures, SHA-256 HMAC integrity, V2.1 license canonicalization, non-destructive Room migrations (V1 -> V2 -> V3), and fail-closed security invariants.
- **Zero-Cloud / Offline Verification**: Verified complete absence of network permissions, cloud synchronization, and remote service calls. On-device ML Kit barcode analysis operates strictly locally.
- **Automated Regression Suite**: All 265 unit, Robolectric, and integration tests passing green with zero regressions.
- **Physical Device Status**: Documented `UNVERIFIED` for physical device deployment due to container environment hardware limits (`adb devices` list empty); local JVM and build verification fully passed.

## [Phase 7.8] - 2026-09-18

### Hardened & Verified
- **Unused Cloud Configuration Removal**: Safely removed the unnecessary `com.google.gms.google-services` plugin and unused Firebase dependencies (`firebase-bom`, `firebase-ai`, `firebase-appcheck-*`) from `app/build.gradle.kts`, aligning build configurations with Evento's strict 100% offline-first architecture.
- **Clean Build Pipeline**: Eliminated the missing `google-services.json` build warning and runtime `FirebaseApp initialization unsuccessful` log messages.
- **Zero Regressions Verified**: All 265 automated unit and Robolectric tests in the test suite pass green without defects or flakiness.

## [Phase 7.7] - 2026-09-17

### Added
- **Complete Offline Event License & Device Binding**:
  - **Room Database Migration V2 -> V3**: Non-destructive database migration adding `licenseId`, `licenseIssuedAt`, `licenseExpiresAt`, `licenseMaxGuests`, `licenseAllowedDeviceCount`, `licenseBoundDeviceId`, `licenseStatus`, and `licenseFormatVersion` to `imported_events`.
  - **Check-In Engine License Enforcement**: Real-time enforcement in `CheckInEngine` validating event validity dates, capacity limits, and terminal device identity bindings on every attendee badge scan.
  - **Terminal Device Identity Foundation**: Non-identifying random UUID generator in `CheckInDeviceIdentityManager` with terminal prefix `TERM-` without accessing any hardware or PII identifiers.
  - **Admin Package License Configuration**: Fully configured offline licensing UI in `EventPackageScreen` supporting duration selection, guest limits, device binding, and deterministic canonicalization signing.
- **Check-In License-Aware Package Verification Pipeline**: Integrated `license.json` extraction and SHA-256 integrity verification directly into `EventoPackageVerifier`.
- **EVENTO-CANONICAL-V2.1 Verification Binding**: Added canonicalization support for Version 2.1 packages binding `licenseJsonSha256` into the ECDSA signature verification payload alongside `event.json` and `guests.json`.
- **Fail-Closed License Validation Engine**: Integrated `EventLicenseValidator` within `EventoPackageVerifier` to enforce timestamp validity (`issuedAt`, `expiresAt`), guest count capacity bounds (`maxGuests`), and hardware device binding (`boundDeviceId` vs `localDeviceId`).
- **Complete Backwards Compatibility**: Preserved seamless verification for Version 1 legacy integrity packages and Version 2 unlicensed authenticated packages.
- **Dedicated Automated Verification Suite**: Created comprehensive test suites `CheckInLicensePackageVerificationTest` and `CheckInLicensePersistenceAndEnforcementTest` validating all cryptographic, tampering, persistence, and scan enforcement behaviors.

## [Phase 7.6] - 2026-09-15

### Added
- **Asymmetric Cryptographic Package Signing**: Implemented ECDSA P-256 (NIST P-256 / secp256r1 with SHA256withECDSA) for authenticated, tamper-proof Evento Event Packages.
- **AndroidKeyStore Admin Key Protection**: Non-exportable hardware-backed EC signing keys isolated within Android Keystore with dedicated alias `evento_package_signing_key` and keyId `evento-admin-p256-v1`.
- **Deterministic Package Canonicalization**: Standardized UTF-8 canonical byte generation (`EVENTO-CANONICAL-V2`) binding format version, package type, event attributes, attendee counts, QR payload format, and SHA-256 hashes of `event.json` and `guests.json`.
- **Decoupled Public-Key Trust Anchor Architecture**: `CheckInTrustAnchorRegistry` maintaining an isolated public-key-only trust model for Evento Check-In. Check-In holds zero access to Admin private signing keys or Keystore signing infrastructure.
- **Dual Package Compatibility**: Full verification support for Version 2 authenticated packages (`SIGNED_VERIFIED`) with graceful backward compatibility for Version 1 legacy packages (`LEGACY_INTEGRITY_ONLY`).
- **Fail-Closed Verification & Ingestion**: Packages with missing, untrusted, or tampered signatures or modified contents are rejected immediately; untrusted packages cannot modify the active Room database.
- **Security Verification UI**: Distinct visual badges and indicators across `EventPackageImportScreen`, `CheckInHomeScreen`, and `EventPackageScreen` displaying signature algorithm, trusted key ID, and authentication state.
- **Comprehensive Security Test Suite**: Robolectric test suite covering key generation, canonical byte stability, valid signature verification, tampering detection across all package components, missing file rejection, unknown key rejection, and fail-closed database isolation.

## [Phase 7.5] - 2026-09-14

### Added
- **Attendance Records Screen**: Comprehensive offline terminal record view with route `attendance_records`.
- **Search & Filters**: Multi-field search (guest name, organization, job title) with Arabic character normalization (alef variations, teh marbuta, diacritics) and date filtering (All, Today).
- **Attendance Detail View**: High-contrast modal dialog showing full attendee information and timestamp without leaking internal database IDs or UUIDs.
- **Privacy-Preserving Offline CSV Export**: Event-scoped CSV export using Android Storage Access Framework (`ACTION_CREATE_DOCUMENT`) with UTF-8 BOM (`\uFEFF`) for immediate Excel/Sheets compatibility and RFC 4180 escaping. Omits all UUIDs, internal IDs, and sensitive contact information.
- **Local Attendance Data Management**: Added "Clear attendance records" action in Settings with safety confirmation dialog; clears only check-in records while safely retaining imported event and guest rosters.
- **Home Screen Integration**: Quick action card for Attendance Records and "View All" link on the Recent Check-Ins card.
- **Comprehensive Test Suite**: Unit and Robolectric tests covering CSV generation, RFC 4180 escaping, Arabic normalization, search filtering, database queries, and Compose UI flows.
