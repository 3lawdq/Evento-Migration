// Top-level build file where you can add configuration options common to all sub-projects/modules.
import org.gradle.api.DefaultTask
import org.gradle.api.file.FileSystemOperations
import org.gradle.api.file.ProjectLayout
import org.gradle.api.tasks.TaskAction
import java.io.File
import javax.inject.Inject

plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.android.library) apply false
  alias(libs.plugins.kotlin.compose) apply false
  alias(libs.plugins.google.devtools.ksp) apply false
  alias(libs.plugins.roborazzi) apply false
  alias(libs.plugins.secrets) apply false
  alias(libs.plugins.google.services) apply false
}

abstract class PackageDistributionTask : DefaultTask() {
  @get:Inject
  abstract val layout: ProjectLayout

  @TaskAction
  fun execute() {
    val rootDir = layout.projectDirectory.asFile
    val adminApk = File(rootDir, "app/build/outputs/apk/debug/app-debug.apk")
    val checkinApk = File(rootDir, "checkin/build/outputs/apk/debug/checkin-debug.apk")

    val distAdminDir = File(rootDir, "distribution/admin")
    val distCheckinDir = File(rootDir, "distribution/checkin")
    distAdminDir.mkdirs()
    distCheckinDir.mkdirs()

    val pubDistAdminDir = File(rootDir, "public/distribution/admin")
    val pubDistCheckinDir = File(rootDir, "public/distribution/checkin")
    pubDistAdminDir.mkdirs()
    pubDistCheckinDir.mkdirs()

    val buildOutputsDir = File(rootDir, ".build-outputs")
    buildOutputsDir.mkdirs()

    if (adminApk.exists()) {
      adminApk.copyTo(File(distAdminDir, "Evento-Admin.apk"), overwrite = true)
      adminApk.copyTo(File(pubDistAdminDir, "Evento-Admin.apk"), overwrite = true)
      adminApk.copyTo(File(buildOutputsDir, "app-debug.apk"), overwrite = true)
      println("[DISTRIBUTION] Published Evento Admin: distribution/admin/Evento-Admin.apk")
    }

    if (checkinApk.exists()) {
      checkinApk.copyTo(File(distCheckinDir, "Evento-Check-In.apk"), overwrite = true)
      checkinApk.copyTo(File(pubDistCheckinDir, "Evento-Check-In.apk"), overwrite = true)
      checkinApk.copyTo(File(buildOutputsDir, "checkin-debug.apk"), overwrite = true)
      println("[DISTRIBUTION] Published Evento Check-In: distribution/checkin/Evento-Check-In.apk")
    }
  }
}

tasks.register<PackageDistributionTask>("packageDistribution") {
  group = "distribution"
  description = "Collects both Evento Admin and Evento Check-In APK artifacts into distribution/ and public/"
  dependsOn(":app:assembleDebug", ":checkin:assembleDebug")
}
