package com.evento.checkin

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.local.dao.CheckInDao
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.data.repository.CheckInRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class AttendanceRecordsDatabaseAndLifecycleTest {

  private lateinit var database: CheckInDatabase
  private lateinit var dao: CheckInDao
  private lateinit var repository: CheckInRepository

  @Before
  fun setUp() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, CheckInDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    dao = database.checkInDao()
    repository = CheckInRepository(dao)
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun testAttendanceRecordsRetrievedAndOrderedNewestFirst() = runBlocking {
    val event = ImportedEventEntity(
      eventId = 100L,
      name = "Tech Summit 2026",
      date = "2026-10-01",
      location = "Riyadh",
      organizer = "Evento Team",
      packageFormatVersion = 1,
      guestCount = 2,
      importedAt = System.currentTimeMillis(),
      verificationStatus = "VERIFIED",
    )
    dao.insertEvent(event)

    val guests = listOf(
      ImportedGuestEntity(
        uuid = "uuid-1",
        eventId = 100L,
        fullName = "Guest One",
        invitationStatus = "ACCEPTED",
        organization = "Org A",
        jobTitle = "Dev",
        checkInStatus = "NOT_CHECKED_IN",
      ),
      ImportedGuestEntity(
        uuid = "uuid-2",
        eventId = 100L,
        fullName = "Guest Two",
        invitationStatus = "ACCEPTED",
        organization = "Org B",
        jobTitle = "Manager",
        checkInStatus = "NOT_CHECKED_IN",
      ),
    )
    dao.insertGuests(guests)

    // Check-in guest 1 earlier, guest 2 later
    dao.insertAttendance(
      AttendanceRecordEntity(
        eventId = 100L,
        guestUuid = "uuid-1",
        checkedInAt = 1000L,
      ),
    )
    dao.insertAttendance(
      AttendanceRecordEntity(
        eventId = 100L,
        guestUuid = "uuid-2",
        checkedInAt = 2000L,
      ),
    )

    val items = repository.getAllAttendanceItems(100L)
    assertEquals(2, items.size)
    assertEquals("uuid-2", items[0].guestUuid)
    assertEquals("Guest Two", items[0].fullName)
    assertEquals(2000L, items[0].checkedInAt)

    assertEquals("uuid-1", items[1].guestUuid)
    assertEquals("Guest One", items[1].fullName)
    assertEquals(1000L, items[1].checkedInAt)
  }

  @Test
  fun testGetAttendanceItemDetail() = runBlocking {
    val event = ImportedEventEntity(
      eventId = 101L,
      name = "AI Forum",
      date = "2026-11-15",
      location = "Jeddah",
      organizer = "Evento",
      packageFormatVersion = 1,
      guestCount = 1,
      importedAt = System.currentTimeMillis(),
      verificationStatus = "VERIFIED",
    )
    dao.insertEvent(event)

    dao.insertGuests(
      listOf(
        ImportedGuestEntity(
          uuid = "guest-ai-1",
          eventId = 101L,
          fullName = "Dr. Layla",
          invitationStatus = "ACCEPTED",
          organization = "SDAIA",
          jobTitle = "Researcher",
          checkInStatus = "NOT_CHECKED_IN",
        ),
      ),
    )

    dao.insertAttendance(
      AttendanceRecordEntity(
        eventId = 101L,
        guestUuid = "guest-ai-1",
        checkedInAt = 1774000000000L,
      ),
    )

    val item = repository.getAttendanceItem(101L, "guest-ai-1")
    assertNotNull(item)
    assertEquals("Dr. Layla", item?.fullName)
    assertEquals("SDAIA", item?.organization)
    assertEquals("Researcher", item?.jobTitle)
    assertEquals(1774000000000L, item?.checkedInAt)

    val nonExistent = repository.getAttendanceItem(101L, "unknown-uuid")
    assertNull(nonExistent)
  }

  @Test
  fun testClearAttendancePreservesEventAndGuests() = runBlocking {
    val event = ImportedEventEntity(
      eventId = 200L,
      name = "CyberSecurity Conference",
      date = "2026-12-01",
      location = "Dammam",
      organizer = "Evento",
      packageFormatVersion = 1,
      guestCount = 1,
      importedAt = System.currentTimeMillis(),
      verificationStatus = "VERIFIED",
    )
    dao.insertEvent(event)

    val guests = listOf(
      ImportedGuestEntity(
        uuid = "sec-1",
        eventId = 200L,
        fullName = "Security Analyst",
        invitationStatus = "ACCEPTED",
        organization = "CyberSec",
        jobTitle = "Analyst",
        checkInStatus = "NOT_CHECKED_IN",
      ),
    )
    dao.insertGuests(guests)

    dao.insertAttendance(
      AttendanceRecordEntity(
        eventId = 200L,
        guestUuid = "sec-1",
        checkedInAt = System.currentTimeMillis(),
      ),
    )

    assertEquals(1, dao.getAttendanceCount(200L))
    assertEquals(1, dao.getGuestCountForEvent(200L))

    // Clear attendance for event
    repository.deleteAttendanceForEvent(200L)

    // Attendance is cleared
    assertEquals(0, dao.getAttendanceCount(200L))
    val remainingRecords = repository.getAllAttendanceItems(200L)
    assertTrue(remainingRecords.isEmpty())

    // Event and guests are still present intact
    assertNotNull(dao.getActiveEvent())
    assertEquals("CyberSecurity Conference", dao.getActiveEvent()?.name)
    assertEquals(1, dao.getGuestCountForEvent(200L))
    val retrievedGuest = dao.getGuestByEventAndUuid(200L, "sec-1")
    assertNotNull(retrievedGuest)
    assertEquals("Security Analyst", retrievedGuest?.fullName)
  }

  @Test
  fun testEventIsolationInAttendanceQueries() = runBlocking {
    val event1 = ImportedEventEntity(
      eventId = 301L,
      name = "Event One",
      date = "2026-01-01",
      location = "Riyadh",
      organizer = "Org 1",
      packageFormatVersion = 1,
      guestCount = 1,
      importedAt = System.currentTimeMillis(),
      verificationStatus = "VERIFIED",
    )
    val event2 = ImportedEventEntity(
      eventId = 302L,
      name = "Event Two",
      date = "2026-02-01",
      location = "Riyadh",
      organizer = "Org 2",
      packageFormatVersion = 1,
      guestCount = 1,
      importedAt = System.currentTimeMillis(),
      verificationStatus = "VERIFIED",
    )
    dao.insertEvent(event1)
    dao.insertEvent(event2)

    dao.insertGuests(
      listOf(
        ImportedGuestEntity(
          uuid = "u-e1",
          eventId = 301L,
          fullName = "Guest of Event 1",
          invitationStatus = "ACCEPTED",
          organization = "Org 1",
          jobTitle = "Title 1",
          checkInStatus = "NOT_CHECKED_IN",
        ),
        ImportedGuestEntity(
          uuid = "u-e2",
          eventId = 302L,
          fullName = "Guest of Event 2",
          invitationStatus = "ACCEPTED",
          organization = "Org 2",
          jobTitle = "Title 2",
          checkInStatus = "NOT_CHECKED_IN",
        ),
      ),
    )

    dao.insertAttendance(
      AttendanceRecordEntity(
        eventId = 301L,
        guestUuid = "u-e1",
        checkedInAt = 1000L,
      ),
    )
    dao.insertAttendance(
      AttendanceRecordEntity(
        eventId = 302L,
        guestUuid = "u-e2",
        checkedInAt = 2000L,
      ),
    )

    val itemsE1 = repository.getAllAttendanceItems(301L)
    assertEquals(1, itemsE1.size)
    assertEquals("Guest of Event 1", itemsE1[0].fullName)

    val itemsE2 = repository.getAllAttendanceItems(302L)
    assertEquals(1, itemsE2.size)
    assertEquals("Guest of Event 2", itemsE2[0].fullName)

    // Deleting attendance for 301 does not affect 302
    repository.deleteAttendanceForEvent(301L)
    assertEquals(0, repository.getAllAttendanceItems(301L).size)
    assertEquals(1, repository.getAllAttendanceItems(302L).size)
  }
}
