package com.evento.checkin

import android.app.Application
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.evento.checkin.data.local.dao.CheckInDao
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.RecentCheckInItem
import com.evento.checkin.ui.screens.records.AttendanceRecordsScreen
import com.evento.checkin.ui.screens.records.AttendanceRecordsViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AttendanceRecordsUiTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  private val testEvent = ImportedEvent(
    eventId = 1L,
    name = "Global AI Summit 2026",
    date = "2026-09-15",
    location = "Riyadh Front",
    organizer = "SDAIA",
    packageFormatVersion = 1,
    guestCount = 2,
    verificationStatus = "VERIFIED",
  )

  private val testRecord = RecentCheckInItem(
    guestUuid = "uuid-layla",
    fullName = "Layla Al-Harbi",
    organization = "National AI Center",
    jobTitle = "Principal Researcher",
    checkedInAt = 1770000000000L,
  )

  private lateinit var viewModel: AttendanceRecordsViewModel

  @Before
  fun setUp() {
    val application = ApplicationProvider.getApplicationContext<Application>()
    val fakeRepo = FakeAttendanceRecordsRepository(testEvent, listOf(testRecord))
    viewModel = AttendanceRecordsViewModel(application, fakeRepo)
  }

  @Test
  fun testScreenDisplaysRecordAndCount() {
    composeTestRule.setContent {
      AttendanceRecordsScreen(
        onNavigateBack = {},
        viewModel = viewModel,
      )
    }

    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("records_count_badge").assertIsDisplayed()
    composeTestRule.onNodeWithTag("attendance_item_uuid-layla", useUnmergedTree = true).assertIsDisplayed()
  }

  @Test
  fun testSearchFiltersOutNonMatchingRecords() {
    composeTestRule.setContent {
      AttendanceRecordsScreen(
        onNavigateBack = {},
        viewModel = viewModel,
      )
    }

    composeTestRule.waitForIdle()

    // Search for non-matching name
    composeTestRule.onNodeWithTag("records_search_field").performTextInput("Unknown Person")
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("empty_search_notice").assertIsDisplayed()
  }

  @Test
  fun testDetailDialogOpensAndCloses() {
    composeTestRule.setContent {
      AttendanceRecordsScreen(
        onNavigateBack = {},
        viewModel = viewModel,
      )
    }

    composeTestRule.waitForIdle()

    // Click attendee item using unmerged tree to open detail dialog
    composeTestRule.onNodeWithTag("attendance_item_uuid-layla", useUnmergedTree = true).performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("attendance_detail_dialog").assertIsDisplayed()
    composeTestRule.onNodeWithTag("detail_name").assertIsDisplayed().assertTextEquals("Layla Al-Harbi")
    composeTestRule.onNodeWithTag("detail_organization").assertIsDisplayed().assertTextEquals("National AI Center")

    // Dismiss dialog
    composeTestRule.onNodeWithTag("detail_close_button").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("attendance_detail_dialog").assertDoesNotExist()
  }

  private class FakeAttendanceRecordsRepository(
    private val event: ImportedEvent?,
    private val records: List<RecentCheckInItem>,
  ) : CheckInRepository(StubCheckInDao()) {
    override fun getActiveEventFlow(): Flow<ImportedEvent?> = flowOf(event)
    override suspend fun getActiveEvent(): ImportedEvent? = event
    override fun getAllAttendanceItemsFlow(eventId: Long): Flow<List<RecentCheckInItem>> = flowOf(records)
    override suspend fun getAllAttendanceItems(eventId: Long): List<RecentCheckInItem> = records
    override fun getGuestCountForEventFlow(eventId: Long): Flow<Int> = flowOf(records.size + 1)
  }

  private class StubCheckInDao : CheckInDao {
    override fun getActiveEventFlow(): Flow<ImportedEventEntity?> = flowOf(null)
    override suspend fun getActiveEvent(): ImportedEventEntity? = null
    override fun getGuestsForEventFlow(eventId: Long): Flow<List<ImportedGuestEntity>> = flowOf(emptyList())
    override fun getAllGuestsFlow(): Flow<List<ImportedGuestEntity>> = flowOf(emptyList())
    override fun getGuestCountFlow(): Flow<Int> = flowOf(0)
    override suspend fun getGuestCount(): Int = 0
    override fun getGuestCountForEventFlow(eventId: Long): Flow<Int> = flowOf(0)
    override suspend fun getGuestCountForEvent(eventId: Long): Int = 0
    override fun getRecentCheckInsFlow(eventId: Long, limit: Int): Flow<List<RecentCheckInItem>> = flowOf(emptyList())
    override suspend fun getRecentCheckIns(eventId: Long, limit: Int): List<RecentCheckInItem> = emptyList()
    override fun getAllAttendanceItemsFlow(eventId: Long): Flow<List<RecentCheckInItem>> = flowOf(emptyList())
    override suspend fun getAllAttendanceItems(eventId: Long): List<RecentCheckInItem> = emptyList()
    override suspend fun getAttendanceItem(eventId: Long, guestUuid: String): RecentCheckInItem? = null
    override suspend fun getGuestByUuid(uuid: String): ImportedGuestEntity? = null
    override suspend fun getGuestByEventAndUuid(eventId: Long, uuid: String): ImportedGuestEntity? = null
    override suspend fun insertEvent(event: ImportedEventEntity) {}
    override suspend fun insertGuests(guests: List<ImportedGuestEntity>) {}
    override suspend fun clearEvents() {}
    override suspend fun clearGuests() {}
    override suspend fun insertAttendance(attendance: AttendanceRecordEntity): Long = 1L
    override suspend fun getAttendance(eventId: Long, guestUuid: String): AttendanceRecordEntity? = null
    override fun getAttendanceForEventFlow(eventId: Long): Flow<List<AttendanceRecordEntity>> = flowOf(emptyList())
    override suspend fun getAttendanceForEvent(eventId: Long): List<AttendanceRecordEntity> = emptyList()
    override suspend fun getAttendanceCount(eventId: Long): Int = 0
    override fun getAttendanceCountFlow(eventId: Long): Flow<Int> = flowOf(0)
    override suspend fun getPendingGuestCount(eventId: Long): Int = 0
    override fun getPendingGuestCountFlow(eventId: Long): Flow<Int> = flowOf(0)
    override suspend fun deleteAttendanceForEvent(eventId: Long) {}
    override suspend fun clearAllAttendance() {}
  }
}
