package com.evento.checkin

import android.app.Application
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.ui.screens.settings.CheckInSettingsScreen
import com.evento.checkin.ui.screens.settings.CheckInSettingsViewModel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CheckInSettingsClearAttendanceRoboTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  private lateinit var database: CheckInDatabase
  private lateinit var repository: CheckInRepository
  private lateinit var viewModel: CheckInSettingsViewModel

  @Before
  fun setUp() {
    val application = ApplicationProvider.getApplicationContext<Application>()
    database = Room.inMemoryDatabaseBuilder(application, CheckInDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    repository = CheckInRepository(database.checkInDao())

    runBlocking {
      val event = ImportedEventEntity(
        eventId = 10L,
        name = "KSA Digital Summit",
        date = "2026-11-20",
        location = "Riyadh",
        organizer = "Digital Gov",
        packageFormatVersion = 1,
        guestCount = 1,
        importedAt = System.currentTimeMillis(),
        verificationStatus = "VERIFIED",
      )
      database.checkInDao().insertEvent(event)

      val guests = listOf(
        ImportedGuestEntity(
          uuid = "uuid-clear-1",
          eventId = 10L,
          fullName = "Tariq Mansour",
          invitationStatus = "ACCEPTED",
          organization = "Digital Authority",
          jobTitle = "Director",
          checkInStatus = "NOT_CHECKED_IN",
        ),
      )
      database.checkInDao().insertGuests(guests)

      database.checkInDao().insertAttendance(
        AttendanceRecordEntity(
          eventId = 10L,
          guestUuid = "uuid-clear-1",
          checkedInAt = System.currentTimeMillis(),
        ),
      )
    }

    viewModel = CheckInSettingsViewModel(application, repository)
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun testClearAttendanceCardAndConfirmationFlow() {
    composeTestRule.setContent {
      CheckInSettingsScreen(
        viewModel = viewModel,
        onNavigateBack = {},
      )
    }

    composeTestRule.waitForIdle()

    // Assert the clear attendance card is displayed
    composeTestRule.onNodeWithTag("settings_clear_attendance_card").assertIsDisplayed()

    // Click on clear attendance card
    composeTestRule.onNodeWithTag("settings_clear_attendance_card").performClick()
    composeTestRule.waitForIdle()

    // Confirmation dialog should be shown
    composeTestRule.onNodeWithTag("clear_attendance_confirm_dialog").assertIsDisplayed()

    // Click confirm button
    composeTestRule.onNodeWithTag("clear_attendance_confirm_button").performClick()
    composeTestRule.waitForIdle()

    // Verify attendance is cleared in DB, but event and guests remain intact
    runBlocking {
      assertEquals(0, database.checkInDao().getAttendanceCount(10L))
      assertNotNull(database.checkInDao().getActiveEvent())
      assertEquals("KSA Digital Summit", database.checkInDao().getActiveEvent()?.name)
      assertEquals(1, database.checkInDao().getGuestCountForEvent(10L))
    }
  }
}
