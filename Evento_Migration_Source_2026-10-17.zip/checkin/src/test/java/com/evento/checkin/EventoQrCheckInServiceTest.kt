package com.evento.checkin

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.engine.CheckInEngine
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.ImportedGuest
import com.evento.checkin.domain.qr.QrCheckInResult
import com.evento.checkin.domain.qr.QrCheckInService
import com.evento.checkin.domain.qr.QrPayloadParseResult
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * Integration test suite for Phase 7.3B: [QrCheckInService].
 *
 * Verifies end-to-end integration between:
 * QR Text -> QrPayloadParser -> CheckInEngine -> CheckInRepository -> Room DB.
 */
@RunWith(RobolectricTestRunner::class)
class EventoQrCheckInServiceTest {

  private lateinit var context: Context
  private lateinit var database: CheckInDatabase
  private lateinit var repository: CheckInRepository
  private lateinit var engine: CheckInEngine
  private lateinit var service: QrCheckInService

  private var simulatedTime: Long = 1700000000000L
  private var engineCallCount = 0

  private val sampleEvent = ImportedEvent(
    eventId = 5001L,
    name = "Global Annual Conference 2026",
    date = "2026-10-10",
    location = "Zurich Congress Center",
    organizer = "Swiss Technology Alliance",
    packageFormatVersion = 1,
    guestCount = 2,
  )

  private val guest1Uuid = "550e8400-e29b-41d4-a716-446655440001"
  private val guest2Uuid = "550e8400-e29b-41d4-a716-446655440002"

  private val sampleGuest1 = ImportedGuest(
    uuid = guest1Uuid,
    eventId = 5001L,
    fullName = "Clara Oswald",
    invitationStatus = "CONFIRMED",
    organization = "Oswald Tech",
    jobTitle = "Principal Software Engineer",
  )

  private val sampleGuest2 = ImportedGuest(
    uuid = guest2Uuid,
    eventId = 5001L,
    fullName = "Rory Williams",
    invitationStatus = "CONFIRMED",
    organization = "Williams Health",
    jobTitle = "Chief Technology Officer",
  )

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    database = CheckInDatabase.createInMemory(context)
    repository = CheckInRepository(database.checkInDao())
    simulatedTime = 1700000000000L
    engineCallCount = 0

    engine = TrackingCheckInEngine(repository) { simulatedTime }
    service = QrCheckInService(engine)
  }

  @After
  fun tearDown() {
    database.close()
  }

  private inner class TrackingCheckInEngine(
    repo: CheckInRepository,
    timeProvider: () -> Long,
  ) : CheckInEngine(repo, timeProvider) {
    override suspend fun checkIn(guestUuid: String): com.evento.checkin.domain.model.CheckInResult {
      engineCallCount++
      return super.checkIn(guestUuid)
    }
  }

  @Test
  fun test19_validQrForExistingGuestReturnsSuccess(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val qrText = "EVT1:$guest1Uuid"
    val result = service.checkInWithQr(qrText)

    assertTrue("Valid QR for existing attendee must yield Success", result is QrCheckInResult.Success)
    val success = result as QrCheckInResult.Success
    assertEquals("Clara Oswald", success.guest.fullName)
    assertEquals(guest1Uuid, success.guest.uuid)
    assertEquals(simulatedTime, success.checkedInAt)
  }

  @Test
  fun test20_sameValidQrScannedAgainReturnsAlreadyCheckedIn(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val qrText = "EVT1:$guest1Uuid"
    val initialResult = service.checkInWithQr(qrText)
    assertTrue(initialResult is QrCheckInResult.Success)

    // Advance simulated time
    simulatedTime += 120000L // 2 minutes later
    val duplicateResult = service.checkInWithQr(qrText)

    assertTrue("Repeated scan of same QR must yield AlreadyCheckedIn", duplicateResult is QrCheckInResult.AlreadyCheckedIn)
    val already = duplicateResult as QrCheckInResult.AlreadyCheckedIn
    assertEquals("Clara Oswald", already.guest.fullName)
    assertEquals(1700000000000L, already.checkedInAt)
  }

  @Test
  fun test21_validQrForUnknownUuidReturnsGuestNotFound(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val unknownValidUuid = "ffffffff-ffff-ffff-ffff-ffffffffffff"
    val qrText = "EVT1:$unknownValidUuid"
    val result = service.checkInWithQr(qrText)

    assertTrue("Valid QR with unlisted UUID must yield GuestNotFound", result is QrCheckInResult.GuestNotFound)
    assertEquals(0, repository.getAttendanceCount(5001L))
  }

  @Test
  fun test22_malformedQrYieldsParserFailureAndEngineIsNotCalled(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))
    engineCallCount = 0

    val malformedCases = listOf(
      "EVT1:not-a-valid-uuid",
      "EVT1:$guest1Uuid:extra",
      " EVT1:$guest1Uuid",
      "EVT1:$guest1Uuid\n",
      "EVT1:",
      "",
    )

    for (malformed in malformedCases) {
      val result = service.checkInWithQr(malformed)
      assertTrue("'$malformed' must yield InvalidQr", result is QrCheckInResult.InvalidQr)
    }

    assertEquals("CheckInEngine must NEVER be invoked for malformed QR payloads", 0, engineCallCount)
    assertEquals("No attendance records created", 0, repository.getAttendanceCount(5001L))
  }

  @Test
  fun test23_wrongPrefixYieldsParserFailureAndEngineIsNotCalled(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))
    engineCallCount = 0

    val wrongPrefixCases = listOf(
      "EVT2:$guest1Uuid",
      "EVENTO:$guest1Uuid",
      guest1Uuid, // missing prefix completely
      "SCAN:$guest1Uuid",
    )

    for (wrong in wrongPrefixCases) {
      val result = service.checkInWithQr(wrong)
      assertTrue("'$wrong' must yield InvalidQr", result is QrCheckInResult.InvalidQr)
      val invalid = result as QrCheckInResult.InvalidQr
      assertTrue("Parse error must be InvalidPrefix", invalid.parseError is QrPayloadParseResult.InvalidPrefix)
    }

    assertEquals("CheckInEngine must NOT be invoked when prefix is invalid", 0, engineCallCount)
  }

  @Test
  fun test24_validUuidBelongingToAnotherEventReturnsGuestNotFound(): Unit = runBlocking {
    // Current active event is 5001L with Clara & Rory
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1))

    // Directly insert another attendee record into the database belonging to another event (9999L)
    val otherEventGuestUuid = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    database.checkInDao().insertGuests(
      listOf(
        ImportedGuestEntity(
          uuid = otherEventGuestUuid,
          eventId = 9999L,
          fullName = "Foreign Attendee",
          invitationStatus = "CONFIRMED",
          organization = "Other Corp",
          jobTitle = "Visitor",
          checkInStatus = "NOT_CHECKED_IN",
        )
      )
    )

    val qrText = "EVT1:$otherEventGuestUuid"
    val result = service.checkInWithQr(qrText)

    assertTrue("Guest belonging to another event must return GuestNotFound for current event", result is QrCheckInResult.GuestNotFound)
    assertEquals(0, repository.getAttendanceCount(5001L))
  }

  @Test
  fun test25_noActiveImportedEventReturnsNoActiveEvent(): Unit = runBlocking {
    repository.clearActivePackage()

    val qrText = "EVT1:$guest1Uuid"
    val result = service.checkInWithQr(qrText)

    assertTrue("Check-in attempt without active event must return NoActiveEvent", result is QrCheckInResult.NoActiveEvent)
  }

  @Test
  fun test26_successfulQrCheckInCreatesExactlyOneAttendanceRecord(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val qrText = "EVT1:$guest1Uuid"
    val result = service.checkInWithQr(qrText)
    assertTrue(result is QrCheckInResult.Success)

    val count = repository.getAttendanceCount(5001L)
    assertEquals("Exactly one attendance record must exist in DB", 1, count)

    val record = repository.getAttendance(5001L, guest1Uuid)
    assertNotNull(record)
    assertEquals(5001L, record?.eventId)
    assertEquals(guest1Uuid, record?.guestUuid)
  }

  @Test
  fun test27_duplicateQrCheckInDoesNotCreateAnotherAttendanceRecord(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val qrText = "EVT1:$guest1Uuid"
    service.checkInWithQr(qrText)
    assertEquals(1, repository.getAttendanceCount(5001L))

    // Second scan
    service.checkInWithQr(qrText)
    assertEquals("Attendance count must remain strictly 1 after duplicate scan", 1, repository.getAttendanceCount(5001L))

    // Third scan
    service.checkInWithQr(qrText)
    assertEquals("Attendance count must still remain strictly 1", 1, repository.getAttendanceCount(5001L))
  }

  @Test
  fun test28_existingGuestUuidRemainsUnchanged(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val qrText = "EVT1:$guest1Uuid"
    service.checkInWithQr(qrText)

    val guestInDb = repository.getGuestByUuid(guest1Uuid)
    assertNotNull(guestInDb)
    assertEquals(guest1Uuid, guestInDb?.uuid)
    assertEquals("Clara Oswald", guestInDb?.fullName)
    assertEquals("CONFIRMED", guestInDb?.invitationStatus) // Invitation status remains immutable
  }

  @Test
  fun test29_checkInTimestampComesFromInjectableTimeProvider(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))
    val specificTimestamp = 1755555555000L
    simulatedTime = specificTimestamp

    val qrText = "EVT1:$guest2Uuid"
    val result = service.checkInWithQr(qrText)

    assertTrue(result is QrCheckInResult.Success)
    val success = result as QrCheckInResult.Success
    assertEquals(specificTimestamp, success.checkedInAt)

    val inDb = repository.getAttendance(5001L, guest2Uuid)
    assertEquals(specificTimestamp, inDb?.checkedInAt)
  }

  @Test
  fun test30_existingPackageReimportBehaviorRemainsIntact(): Unit = runBlocking {
    // 1. Initial event imported and attendee checked in via QR
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))
    val firstCheckIn = service.checkInWithQr("EVT1:$guest1Uuid")
    assertTrue(firstCheckIn is QrCheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(5001L))

    // 2. Re-import a new package
    val newEvent = ImportedEvent(
      eventId = 6002L,
      name = "AI Horizons 2027",
      date = "2027-04-12",
      location = "Berlin Tech Hub",
      organizer = "Horizon AI",
      packageFormatVersion = 1,
      guestCount = 1,
    )
    val newGuestUuid = "660e8400-e29b-41d4-a716-446655440009"
    val newGuest = ImportedGuest(
      uuid = newGuestUuid,
      eventId = 6002L,
      fullName = "Donna Noble",
      invitationStatus = "CONFIRMED",
    )
    repository.replaceActivePackage(newEvent, listOf(newGuest))

    // Old attendance count reset; old QR no longer checks in
    assertEquals(0, repository.getAttendanceCount(5001L))
    assertEquals(0, repository.getAttendanceCount(6002L))

    val oldQrScan = service.checkInWithQr("EVT1:$guest1Uuid")
    assertTrue("Old guest QR must yield GuestNotFound against new event", oldQrScan is QrCheckInResult.GuestNotFound)

    // New QR scan succeeds
    val newQrScan = service.checkInWithQr("EVT1:$newGuestUuid")
    assertTrue("New guest QR check-in must succeed", newQrScan is QrCheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(6002L))
  }
}
