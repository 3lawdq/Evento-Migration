package com.evento.checkin

import com.evento.checkin.domain.CheckInSecurityArchitecture
import com.evento.checkin.navigation.EventoCheckInDestination
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EventoCheckInNavigationTest {

  @Test
  fun testAllDestinationsCount() {
    val destinations = EventoCheckInDestination.allDestinations
    // Home, EventPackageImport, CheckIn, Statistics, Settings
    assertEquals(5, destinations.size)
  }

  @Test
  fun testNoDuplicateRoutes() {
    val routes = EventoCheckInDestination.allDestinations.map { it.route }
    val uniqueRoutes = routes.toSet()
    assertEquals("Every destination must have a unique route", routes.size, uniqueRoutes.size)
  }

  @Test
  fun testRequiredRoutesExist() {
    val routes = EventoCheckInDestination.allDestinations.map { it.route }.toSet()
    assertTrue("Home route must exist", routes.contains("home"))
    assertTrue("Event package route must exist", routes.contains("event_package_import"))
    assertTrue("Check-in route must exist", routes.contains("check_in"))
    assertTrue("Statistics route must exist", routes.contains("statistics"))
    assertTrue("Settings route must exist", routes.contains("settings"))
  }

  @Test
  fun testAllDestinationsHaveValidIconsAndLabels() {
    EventoCheckInDestination.allDestinations.forEach { dest ->
      assertNotNull("Destination ${dest.route} must have selected icon", dest.selectedIcon)
      assertNotNull("Destination ${dest.route} must have unselected icon", dest.unselectedIcon)
      assertTrue("Destination ${dest.route} must have a valid string resource label", dest.labelRes != 0)
      assertFalse("Destination route cannot be empty", dest.route.isBlank())
    }
  }

  @Test
  fun testFromRouteResolution() {
    assertEquals(EventoCheckInDestination.Home, EventoCheckInDestination.fromRoute("home"))
    assertEquals(EventoCheckInDestination.EventPackageImport, EventoCheckInDestination.fromRoute("event_package_import"))
    assertEquals(EventoCheckInDestination.CheckIn, EventoCheckInDestination.fromRoute("check_in"))
    assertEquals(EventoCheckInDestination.QrScanner, EventoCheckInDestination.fromRoute("qr_scanner"))
    assertEquals(EventoCheckInDestination.AttendanceRecords, EventoCheckInDestination.fromRoute("attendance_records"))
    assertEquals(EventoCheckInDestination.Statistics, EventoCheckInDestination.fromRoute("statistics"))
    assertEquals(EventoCheckInDestination.Settings, EventoCheckInDestination.fromRoute("settings"))
  }

  @Test
  fun testFromRouteFallbackToHomeForUnknownOrNull() {
    assertEquals(EventoCheckInDestination.Home, EventoCheckInDestination.fromRoute(null))
    assertEquals(EventoCheckInDestination.Home, EventoCheckInDestination.fromRoute(""))
    assertEquals(EventoCheckInDestination.Home, EventoCheckInDestination.fromRoute("unknown_route_xyz"))
  }

  @Test
  fun testSecurityArchitectureConstants() {
    assertEquals("EVT1:", CheckInSecurityArchitecture.EXPECTED_PAYLOAD_PREFIX)
    assertEquals(2, CheckInSecurityArchitecture.EXPECTED_PACKAGE_FORMAT_VERSION)
    assertEquals("EVENTO_EVENT", CheckInSecurityArchitecture.EXPECTED_PACKAGE_TYPE)
  }
}
