package com.evento.checkin

import com.evento.checkin.domain.model.RecentCheckInItem
import com.evento.checkin.ui.screens.records.AttendanceFilter
import com.evento.checkin.ui.screens.records.AttendanceRecordsViewModel
import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AttendanceRecordsFilterTest {

  private val now = System.currentTimeMillis()
  private val yesterday = now - 24 * 60 * 60 * 1000L

  private val item1 = RecentCheckInItem(
    guestUuid = "u1",
    fullName = "أحمد محمد علي",
    organization = "شركة التقنية المتقدمة",
    jobTitle = "مهندس برمجيات",
    checkedInAt = now,
  )

  private val item2 = RecentCheckInItem(
    guestUuid = "u2",
    fullName = "سارة أحمد",
    organization = "وزارة الصحة",
    jobTitle = "مديرة مشروع",
    checkedInAt = yesterday,
  )

  private val item3 = RecentCheckInItem(
    guestUuid = "u3",
    fullName = "John Smith",
    organization = "Global Tech Corp",
    jobTitle = "Vice President",
    checkedInAt = now,
  )

  private val allRecords = listOf(item1, item2, item3)

  @Test
  fun testArabicNormalization() {
    assertEquals("احمد", AttendanceRecordsViewModel.normalizeText("أحمد"))
    assertEquals("احمد", AttendanceRecordsViewModel.normalizeText("إحمد"))
    assertEquals("احمد", AttendanceRecordsViewModel.normalizeText("آحمد"))
    assertEquals("فاطمه", AttendanceRecordsViewModel.normalizeText("فاطمة"))
    assertEquals("علي", AttendanceRecordsViewModel.normalizeText("على"))
  }

  @Test
  fun testSearchByName() {
    val results = AttendanceRecordsViewModel.applyFilterAndSearch(
      allRecords,
      query = "احمد", // without hamza
      filter = AttendanceFilter.ALL,
      nowMillis = now,
    )
    assertEquals(2, results.size)
    assertTrue(results.contains(item1))
    assertTrue(results.contains(item2))
  }

  @Test
  fun testSearchByOrganization() {
    val results = AttendanceRecordsViewModel.applyFilterAndSearch(
      allRecords,
      query = "Global",
      filter = AttendanceFilter.ALL,
      nowMillis = now,
    )
    assertEquals(1, results.size)
    assertEquals("John Smith", results.first().fullName)
  }

  @Test
  fun testSearchByJobTitle() {
    val results = AttendanceRecordsViewModel.applyFilterAndSearch(
      allRecords,
      query = "مهندس",
      filter = AttendanceFilter.ALL,
      nowMillis = now,
    )
    assertEquals(1, results.size)
    assertEquals("أحمد محمد علي", results.first().fullName)
  }

  @Test
  fun testFilterToday() {
    val results = AttendanceRecordsViewModel.applyFilterAndSearch(
      allRecords,
      query = "",
      filter = AttendanceFilter.TODAY,
      nowMillis = now,
    )
    assertEquals(2, results.size)
    assertTrue(results.contains(item1))
    assertTrue(results.contains(item3))
    assertFalse(results.contains(item2))
  }

  @Test
  fun testCombinedFilterAndSearch() {
    val results = AttendanceRecordsViewModel.applyFilterAndSearch(
      allRecords,
      query = "احمد",
      filter = AttendanceFilter.TODAY,
      nowMillis = now,
    )
    assertEquals(1, results.size)
    assertEquals(item1, results.first())
  }

  @Test
  fun testEmptyQueryReturnsAll() {
    val results = AttendanceRecordsViewModel.applyFilterAndSearch(
      allRecords,
      query = "   ",
      filter = AttendanceFilter.ALL,
      nowMillis = now,
    )
    assertEquals(3, results.size)
  }
}
