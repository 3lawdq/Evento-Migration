package com.evento.checkin

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.engine.CheckInEngine
import com.evento.checkin.domain.model.AttendanceRecord
import com.evento.checkin.domain.model.CheckInResult
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.ImportedGuest
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.File

/**
 * Comprehensive test suite for Phase 7.3A:
 * Attendance database layer, unique constraint, Room migration 1 -> 2, and CheckInEngine.
 */
@RunWith(RobolectricTestRunner::class)
class EventoCheckInEngineTest {

  private lateinit var context: Context
  private lateinit var database: CheckInDatabase
  private lateinit var repository: CheckInRepository
  private lateinit var engine: CheckInEngine
  private var simulatedTime: Long = 1700000000000L

  private val sampleEvent = ImportedEvent(
    eventId = 1001L,
    name = "Global Tech Summit 2026",
    date = "2026-11-15",
    location = "Grand Arena",
    organizer = "Acme Events Ltd",
    packageFormatVersion = 1,
    guestCount = 2,
  )

  private val guest1Uuid = "11111111-1111-1111-1111-111111111111"
  private val guest2Uuid = "22222222-2222-2222-2222-222222222222"

  private val sampleGuest1 = ImportedGuest(
    uuid = guest1Uuid,
    eventId = 1001L,
    fullName = "Alice Smith",
    invitationStatus = "CONFIRMED",
    organization = "Alpha Tech",
    jobTitle = "Principal Architect",
  )

  private val sampleGuest2 = ImportedGuest(
    uuid = guest2Uuid,
    eventId = 1001L,
    fullName = "Bob Jones",
    invitationStatus = "CONFIRMED",
    organization = "Beta Labs",
    jobTitle = "Security Engineer",
  )

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    database = CheckInDatabase.createInMemory(context)
    repository = CheckInRepository(database.checkInDao())
    simulatedTime = 1700000000000L
    engine = CheckInEngine(repository, timeProvider = { simulatedTime })
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun test01_databaseMigrationV1ToV2PreservesImportedEvent(): Unit = runBlocking {
    val dbFile = File(context.filesDir, "test_migration_event.db")
    if (dbFile.exists()) dbFile.delete()

    // 1. Manually create V1 database
    val rawDb = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
    rawDb.version = 1
    rawDb.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `imported_events` (
        `eventId` INTEGER NOT NULL PRIMARY KEY,
        `name` TEXT NOT NULL,
        `date` TEXT NOT NULL,
        `location` TEXT NOT NULL,
        `organizer` TEXT NOT NULL,
        `packageFormatVersion` INTEGER NOT NULL,
        `guestCount` INTEGER NOT NULL,
        `importedAt` INTEGER NOT NULL,
        `verificationStatus` TEXT NOT NULL
      )
      """.trimIndent()
    )
    rawDb.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `imported_guests` (
        `uuid` TEXT NOT NULL PRIMARY KEY,
        `eventId` INTEGER NOT NULL,
        `fullName` TEXT NOT NULL,
        `invitationStatus` TEXT NOT NULL,
        `organization` TEXT NOT NULL,
        `jobTitle` TEXT NOT NULL,
        `checkInStatus` TEXT NOT NULL
      )
      """.trimIndent()
    )
    rawDb.execSQL(
      """
      INSERT INTO `imported_events` VALUES (
        555, 'Preserved V1 Conference', '2026-12-01', 'Hall A', 'Test Org', 1, 10, 1690000000, 'VERIFIED'
      )
      """.trimIndent()
    )
    rawDb.close()

    // 2. Open via Room with MIGRATION_1_2 and MIGRATION_2_3
    val migratedDb = Room.databaseBuilder(context, CheckInDatabase::class.java, dbFile.absolutePath)
      .addMigrations(CheckInDatabase.MIGRATION_1_2, CheckInDatabase.MIGRATION_2_3)
      .allowMainThreadQueries()
      .build()

    val event = migratedDb.checkInDao().getActiveEvent()
    assertNotNull("Imported event should survive migration intact", event)
    assertEquals(555L, event?.eventId)
    assertEquals("Preserved V1 Conference", event?.name)
    assertEquals("Hall A", event?.location)

    migratedDb.close()
    dbFile.delete()
    Unit
  }

  @Test
  fun test02_databaseMigrationV1ToV2PreservesImportedGuests(): Unit = runBlocking {
    val dbFile = File(context.filesDir, "test_migration_guests.db")
    if (dbFile.exists()) dbFile.delete()

    // 1. Manually create V1 database with guests
    val rawDb = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
    rawDb.version = 1
    rawDb.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `imported_events` (
        `eventId` INTEGER NOT NULL PRIMARY KEY,
        `name` TEXT NOT NULL,
        `date` TEXT NOT NULL,
        `location` TEXT NOT NULL,
        `organizer` TEXT NOT NULL,
        `packageFormatVersion` INTEGER NOT NULL,
        `guestCount` INTEGER NOT NULL,
        `importedAt` INTEGER NOT NULL,
        `verificationStatus` TEXT NOT NULL
      )
      """.trimIndent()
    )
    rawDb.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `imported_guests` (
        `uuid` TEXT NOT NULL PRIMARY KEY,
        `eventId` INTEGER NOT NULL,
        `fullName` TEXT NOT NULL,
        `invitationStatus` TEXT NOT NULL,
        `organization` TEXT NOT NULL,
        `jobTitle` TEXT NOT NULL,
        `checkInStatus` TEXT NOT NULL
      )
      """.trimIndent()
    )
    rawDb.execSQL(
      """
      INSERT INTO `imported_guests` VALUES (
        'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 777, 'V1 VIP Attendee', 'CONFIRMED', 'Security Corp', 'CISO', 'NOT_CHECKED_IN'
      )
      """.trimIndent()
    )
    rawDb.close()

    // 2. Open via Room with MIGRATION_1_2 and MIGRATION_2_3
    val migratedDb = Room.databaseBuilder(context, CheckInDatabase::class.java, dbFile.absolutePath)
      .addMigrations(CheckInDatabase.MIGRATION_1_2, CheckInDatabase.MIGRATION_2_3)
      .allowMainThreadQueries()
      .build()

    val guest = migratedDb.checkInDao().getGuestByUuid("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")
    assertNotNull("Imported guest should survive migration intact", guest)
    assertEquals("V1 VIP Attendee", guest?.fullName)
    assertEquals(777L, guest?.eventId)
    assertEquals("Security Corp", guest?.organization)

    migratedDb.close()
    dbFile.delete()
    Unit
  }

  @Test
  fun test03_attendanceRecordCanBeInserted(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val record = AttendanceRecord(
      eventId = 1001L,
      guestUuid = guest1Uuid,
      checkedInAt = 1700000050000L,
    )
    val rowId = repository.insertAttendance(record)
    assertTrue("Row ID must be positive", rowId > 0)

    val queried = repository.getAttendance(1001L, guest1Uuid)
    assertNotNull(queried)
    assertEquals(1001L, queried?.eventId)
    assertEquals(guest1Uuid, queried?.guestUuid)
    assertEquals(1700000050000L, queried?.checkedInAt)
  }

  @Test
  fun test04_successfulCheckInCreatesExactlyOneAttendanceRecord(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val result = engine.checkIn(guest1Uuid)
    assertTrue("Check-in should succeed", result is CheckInResult.Success)

    val count = repository.getAttendanceCount(1001L)
    assertEquals(1, count)

    val pendingCount = repository.getPendingGuestCount(1001L)
    assertEquals(1, pendingCount)
  }

  @Test
  fun test05_successfulCheckInReturnsTheCorrectGuest(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val result = engine.checkIn(guest1Uuid)
    assertTrue(result is CheckInResult.Success)
    val success = result as CheckInResult.Success
    assertEquals("Alice Smith", success.guest.fullName)
    assertEquals(guest1Uuid, success.guest.uuid)
    assertEquals("Alpha Tech", success.guest.organization)
  }

  @Test
  fun test06_checkedInAtIsPopulated(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))
    simulatedTime = 1712345678900L

    val result = engine.checkIn(guest1Uuid)
    assertTrue(result is CheckInResult.Success)
    val success = result as CheckInResult.Success
    assertEquals(1712345678900L, success.checkedInAt)
  }

  @Test
  fun test07_secondCheckInOfSameGuestReturnsAlreadyCheckedIn(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))
    simulatedTime = 1700000000000L

    val firstResult = engine.checkIn(guest1Uuid)
    assertTrue(firstResult is CheckInResult.Success)

    simulatedTime = 1700000060000L // 1 minute later
    val secondResult = engine.checkIn(guest1Uuid)
    assertTrue("Duplicate check-in should return AlreadyCheckedIn", secondResult is CheckInResult.AlreadyCheckedIn)
    val already = secondResult as CheckInResult.AlreadyCheckedIn
    assertEquals("Alice Smith", already.guest.fullName)
  }

  @Test
  fun test08_secondCheckInDoesNotCreateAnotherAttendanceRecord(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    engine.checkIn(guest1Uuid)
    val countAfterFirst = repository.getAttendanceCount(1001L)
    assertEquals(1, countAfterFirst)

    engine.checkIn(guest1Uuid)
    val countAfterSecond = repository.getAttendanceCount(1001L)
    assertEquals("Attendance count must remain exactly 1 after duplicate attempt", 1, countAfterSecond)
  }

  @Test
  fun test09_originalCheckedInAtIsPreserved(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))
    val initialTime = 1700000010000L
    simulatedTime = initialTime

    val first = engine.checkIn(guest1Uuid) as CheckInResult.Success
    assertEquals(initialTime, first.checkedInAt)

    // Advance clock by 3 hours
    simulatedTime = initialTime + (3 * 3600 * 1000L)
    val second = engine.checkIn(guest1Uuid) as CheckInResult.AlreadyCheckedIn
    assertEquals("Original timestamp must be preserved", initialTime, second.checkedInAt)
  }

  @Test
  fun test10_unknownUuidReturnsGuestNotFound(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val unknownValidUuid = "99999999-9999-9999-9999-999999999999"
    val result = engine.checkIn(unknownValidUuid)
    assertTrue("Unknown attendee must yield GuestNotFound", result is CheckInResult.GuestNotFound)

    val count = repository.getAttendanceCount(1001L)
    assertEquals(0, count)
  }

  @Test
  fun test11_malformedUuidReturnsInvalidGuestUuid(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    val malformedCases = listOf("not-a-uuid", "12345", "", "   ", "EVT1:11111111-1111-1111-1111-111111111111")
    for (invalid in malformedCases) {
      val result = engine.checkIn(invalid)
      assertTrue("'$invalid' should return InvalidGuestUuid", result is CheckInResult.InvalidGuestUuid)
    }
  }

  @Test
  fun test12_checkInWithoutImportedEventReturnsNoActiveEvent(): Unit = runBlocking {
    repository.clearActivePackage()

    val result = engine.checkIn(guest1Uuid)
    assertTrue("Check-in without event must return NoActiveEvent", result is CheckInResult.NoActiveEvent)
  }

  @Test
  fun test13_guestFromAnotherEventCannotBeCheckedInAgainstCurrentEvent(): Unit = runBlocking {
    // Current active event is 1001L with Guest 1
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1))

    // Directly insert a guest belonging to another event (e.g. 9999L)
    database.checkInDao().insertGuests(
      listOf(
        ImportedGuestEntity(
          uuid = "88888888-8888-8888-8888-888888888888",
          eventId = 9999L,
          fullName = "Other Event Attendee",
          invitationStatus = "CONFIRMED",
          organization = "Other Co",
          jobTitle = "Analyst",
          checkInStatus = "NOT_CHECKED_IN",
        )
      )
    )

    val result = engine.checkIn("88888888-8888-8888-8888-888888888888")
    assertTrue("Guest belonging to another event must return GuestNotFound", result is CheckInResult.GuestNotFound)
  }

  @Test
  fun test14_sameUuidCanIndependentlyCheckInUnderAnotherEvent(): Unit = runBlocking {
    val commonUuid = "44444444-4444-4444-4444-444444444444"

    // 1. Event A check-in
    val eventA = sampleEvent.copy(eventId = 2001L, name = "Event Alpha")
    val guestA = sampleGuest1.copy(uuid = commonUuid, eventId = 2001L)
    repository.replaceActivePackage(eventA, listOf(guestA))

    val resultA = engine.checkIn(commonUuid)
    assertTrue(resultA is CheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(2001L))

    // 2. Event B check-in (same attendee UUID attending another event)
    val eventB = sampleEvent.copy(eventId = 2002L, name = "Event Beta")
    val guestB = sampleGuest1.copy(uuid = commonUuid, eventId = 2002L)
    // Directly insert event and guest for 2002 without clearing eventA attendance to test DB uniqueness
    database.checkInDao().insertEvent(ImportedEventEntity.fromDomain(eventB))
    database.checkInDao().insertGuests(listOf(ImportedGuestEntity.fromDomain(guestB)))

    // Direct insert attendance for Event B to verify DB index allows same UUID under different eventId
    val recordB = AttendanceRecord(
      eventId = 2002L,
      guestUuid = commonUuid,
      checkedInAt = 1700000099000L,
    )
    val rowIdB = repository.insertAttendance(recordB)
    assertTrue("DB must allow same guest UUID under distinct eventId", rowIdB > 0)
    assertEquals(1, repository.getAttendanceCount(2002L))
    assertEquals(1, repository.getAttendanceCount(2001L))
  }

  @Test
  fun test15_databaseUniqueConstraintPreventsDuplicate(): Unit = runBlocking {
    val record1 = AttendanceRecordEntity(
      eventId = 3001L,
      guestUuid = guest1Uuid,
      checkedInAt = 1000L,
    )
    val record2 = AttendanceRecordEntity(
      eventId = 3001L,
      guestUuid = guest1Uuid,
      checkedInAt = 2000L,
    )

    database.checkInDao().insertAttendance(record1)

    try {
      database.checkInDao().insertAttendance(record2)
      fail("Inserting duplicate (eventId, guestUuid) must throw SQLiteConstraintException")
    } catch (e: Exception) {
      assertTrue("Exception must be constraint violation: ${e.message}", e.message?.contains("UNIQUE", ignoreCase = true) == true || e.javaClass.simpleName.contains("Constraint"))
    }
  }

  @Test
  fun test16_raceDuplicateInsertionHandledGracefully(): Unit = runBlocking {
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))

    // Insert attendance in DB beforehand (simulating concurrent insert after lookup)
    database.checkInDao().insertAttendance(
      AttendanceRecordEntity(
        eventId = 1001L,
        guestUuid = guest1Uuid,
        checkedInAt = 1700000042000L,
      )
    )

    // Call checkIn -> engine should catch constraint violation and return AlreadyCheckedIn gracefully
    val result = engine.checkIn(guest1Uuid)
    assertTrue("Race condition should gracefully return AlreadyCheckedIn", result is CheckInResult.AlreadyCheckedIn)
    val already = result as CheckInResult.AlreadyCheckedIn
    assertEquals(1700000042000L, already.checkedInAt)
    assertEquals("Alice Smith", already.guest.fullName)
  }

  @Test
  fun test17_attendanceSurvivesDatabaseCloseReopen(): Unit = runBlocking {
    val dbFile = File(context.filesDir, "test_persistence_attendance.db")
    if (dbFile.exists()) dbFile.delete()

    val diskDb1 = Room.databaseBuilder(context, CheckInDatabase::class.java, dbFile.absolutePath)
      .addMigrations(CheckInDatabase.MIGRATION_1_2)
      .allowMainThreadQueries()
      .build()
    val diskRepo1 = CheckInRepository(diskDb1.checkInDao())

    diskRepo1.replaceActivePackage(sampleEvent, listOf(sampleGuest1))
    diskRepo1.insertAttendance(
      AttendanceRecord(
        eventId = 1001L,
        guestUuid = guest1Uuid,
        checkedInAt = 1700000088888L,
      )
    )
    diskDb1.close()

    // Re-open in fresh Room instance
    val diskDb2 = Room.databaseBuilder(context, CheckInDatabase::class.java, dbFile.absolutePath)
      .addMigrations(CheckInDatabase.MIGRATION_1_2)
      .allowMainThreadQueries()
      .build()
    val diskRepo2 = CheckInRepository(diskDb2.checkInDao())

    val loadedAttendance = diskRepo2.getAttendance(1001L, guest1Uuid)
    assertNotNull("Attendance record must survive close and reopen", loadedAttendance)
    assertEquals(1001L, loadedAttendance?.eventId)
    assertEquals(guest1Uuid, loadedAttendance?.guestUuid)
    assertEquals(1700000088888L, loadedAttendance?.checkedInAt)

    diskDb2.close()
    dbFile.delete()
    Unit
  }

  @Test
  fun test18_packageReimportRemovesAttendanceBelongingToReplacedEvent(): Unit = runBlocking {
    // 1. Initial event imported and attendee checked in
    repository.replaceActivePackage(sampleEvent, listOf(sampleGuest1, sampleGuest2))
    val checkInResult = engine.checkIn(guest1Uuid)
    assertTrue(checkInResult is CheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(1001L))

    // 2. Re-import a new package (different event)
    val newEvent = ImportedEvent(
      eventId = 8008L,
      name = "Next Gen Developers Conference",
      date = "2027-01-20",
      location = "Convention Center",
      organizer = "NextGen Org",
      packageFormatVersion = 1,
      guestCount = 1,
    )
    val newGuest = ImportedGuest(
      uuid = "77777777-7777-7777-7777-777777777777",
      eventId = 8008L,
      fullName = "New Conference Attendee",
      invitationStatus = "CONFIRMED",
    )
    repository.replaceActivePackage(newEvent, listOf(newGuest))

    // Old event attendance must be cleared and not remain active
    assertEquals("Old event attendance count must be 0", 0, repository.getAttendanceCount(1001L))
    assertEquals("New event attendance count must start at 0", 0, repository.getAttendanceCount(8008L))
    assertNull("Old attendance record must be gone", repository.getAttendance(1001L, guest1Uuid))

    // Verify new attendee can check in
    val newCheckIn = engine.checkIn("77777777-7777-7777-7777-777777777777")
    assertTrue("New attendee can check in cleanly", newCheckIn is CheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(8008L))
  }
}
