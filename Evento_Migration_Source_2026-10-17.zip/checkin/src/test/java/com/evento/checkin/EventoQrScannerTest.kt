package com.evento.checkin

import android.app.Application
import android.graphics.Rect
import android.media.Image
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageInfo
import androidx.camera.core.ImageProxy
import com.evento.checkin.data.local.dao.CheckInDao
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.engine.CheckInEngine
import com.evento.checkin.domain.model.CheckInResult
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.ImportedGuest
import com.evento.checkin.domain.model.RecentCheckInItem
import com.evento.checkin.domain.qr.QrCheckInResult
import com.evento.checkin.domain.qr.QrCheckInService
import com.evento.checkin.domain.qr.QrPayloadParseResult
import com.evento.checkin.domain.qr.QrPayloadParser
import com.evento.checkin.scanner.QrCodeDecoder
import com.evento.checkin.scanner.QrDecodeResult
import com.evento.checkin.scanner.QrImageAnalyzer
import com.evento.checkin.ui.screens.scanner.QrScannerViewModel
import com.evento.checkin.ui.screens.scanner.ScannerUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class EventoQrScannerTest {

  private val testDispatcher = StandardTestDispatcher()
  private val testScope = TestScope(testDispatcher)

  private val sampleEvent = ImportedEvent(
    eventId = 1001L,
    name = "Saudi Global Tech Summit 2026",
    date = "2026-10-15 09:00",
    location = "Riyadh Exhibition Center",
    organizer = "Evento Operations",
    packageFormatVersion = 1,
    guestCount = 100,
  )

  private val validUuid1 = UUID.randomUUID().toString()
  private val validUuid2 = UUID.randomUUID().toString()

  private val sampleGuest1 = ImportedGuest(
    uuid = validUuid1,
    eventId = 1001L,
    fullName = "Tariq Al-Harbi",
    organization = "Ministry of Communications",
    jobTitle = "VIP Delegate",
    invitationStatus = "INVITED",
  )

  private val sampleGuest2 = ImportedGuest(
    uuid = validUuid2,
    eventId = 1001L,
    fullName = "Sarah Al-Ghamdi",
    organization = "Tech Saudi",
    jobTitle = "Speaker",
    invitationStatus = "INVITED",
  )

  @Before
  fun setUp() {
    Dispatchers.setMain(testDispatcher)
  }

  @After
  fun tearDown() {
    Dispatchers.resetMain()
  }

  // =========================================================================
  // Requirement 13, 14, 15, 16: Analyzer & ImageProxy Lifecycle Tests
  // =========================================================================

  @Test
  fun test13_analyzerClosesImageProxyAfterSuccessfulDetection() {
    var decodedQrText: String? = null
    val fakeProxy = FakeImageProxy()

    val decoder = object : QrCodeDecoder {
      override fun decode(imageProxy: ImageProxy): QrDecodeResult {
        return QrDecodeResult.Success("EVT1:$validUuid1")
      }
    }

    val analyzer = QrImageAnalyzer(
      decoder = decoder,
      onQrDecoded = { decodedQrText = it },
    )

    analyzer.analyze(fakeProxy)

    assertEquals("EVT1:$validUuid1", decodedQrText)
    assertTrue("ImageProxy MUST be closed after successful detection", fakeProxy.isClosed)
  }

  @Test
  fun test14_analyzerClosesImageProxyAfterInvalidDetection() {
    var decodedQrText: String? = null
    val fakeProxy = FakeImageProxy()

    val decoder = object : QrCodeDecoder {
      override fun decode(imageProxy: ImageProxy): QrDecodeResult {
        return QrDecodeResult.None
      }
    }

    val analyzer = QrImageAnalyzer(
      decoder = decoder,
      onQrDecoded = { decodedQrText = it },
    )

    analyzer.analyze(fakeProxy)

    assertEquals(null, decodedQrText)
    assertTrue("ImageProxy MUST be closed after empty/invalid detection", fakeProxy.isClosed)
  }

  @Test
  fun test15_analyzerClosesImageProxyAfterDecoderFailure() {
    var caughtError: Throwable? = null
    val fakeProxy = FakeImageProxy()

    val decoder = object : QrCodeDecoder {
      override fun decode(imageProxy: ImageProxy): QrDecodeResult {
        return QrDecodeResult.Failure(RuntimeException("Frame decoding failed"))
      }
    }

    val analyzer = QrImageAnalyzer(
      decoder = decoder,
      onQrDecoded = { },
      onDecodeError = { caughtError = it },
    )

    analyzer.analyze(fakeProxy)

    assertNotNull("Decoder error must be caught and reported", caughtError)
    assertTrue("ImageProxy MUST be closed after decoder failure", fakeProxy.isClosed)
  }

  @Test
  fun test16_analyzerClosesImageProxyAndReportsMultipleQrCodes() {
    var multipleDetected = false
    var checkInTriggered = false
    val fakeProxy = FakeImageProxy()

    val decoder = object : QrCodeDecoder {
      override fun decode(imageProxy: ImageProxy): QrDecodeResult {
        return QrDecodeResult.MultipleQrDetected
      }
    }

    val analyzer = QrImageAnalyzer(
      decoder = decoder,
      onQrDecoded = { checkInTriggered = true },
      onMultipleQrDetected = { multipleDetected = true },
    )

    analyzer.analyze(fakeProxy)

    assertTrue("Multiple QR flag must be raised", multipleDetected)
    assertFalse("Check-in must NOT be triggered when multiple QR codes are in frame", checkInTriggered)
    assertTrue("ImageProxy MUST be closed after multiple QR detection", fakeProxy.isClosed)
  }

  @Test
  fun testAnalyzerRespectsScanningGateWhileStillClosingProxy() {
    var decodedCalled = false
    val fakeProxy = FakeImageProxy()

    val decoder = object : QrCodeDecoder {
      override fun decode(imageProxy: ImageProxy): QrDecodeResult {
        return QrDecodeResult.Success("EVT1:$validUuid1")
      }
    }

    val analyzer = QrImageAnalyzer(
      decoder = decoder,
      isScanningActive = { false },
      onQrDecoded = { decodedCalled = true },
    )

    analyzer.analyze(fakeProxy)

    assertFalse("Callback must not be invoked when scanning is disabled", decodedCalled)
    assertTrue("ImageProxy MUST still be closed even if scanning is inactive", fakeProxy.isClosed)
  }

  // =========================================================================
  // Requirement 1 to 12: Scanner ViewModel Coordination & Check-In Tests
  // =========================================================================

  @Test
  fun test1_validDecodedEvt1PayloadReachesQrCheckInService() = testScope.runTest {
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.Success(sampleGuest1, 1700000000000L)
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()

    assertEquals("EVT1:$validUuid1", fakeService.lastReceivedPayload)
    val state = viewModel.uiState.value
    assertTrue("State should be Success", state is ScannerUiState.Success)
    assertEquals(sampleGuest1, (state as ScannerUiState.Success).guest)
    assertEquals(1700000000000L, state.checkedInAt)
  }

  @Test
  fun test2_invalidDecodedTextIsPassedToQrCheckInServiceAndRejectedThere() = testScope.runTest {
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.InvalidQr(QrPayloadParseResult.InvalidPrefix)
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onQrCodeScanned("INVALID_PREFIX_DATA")
    advanceUntilIdle()

    assertEquals("INVALID_PREFIX_DATA", fakeService.lastReceivedPayload)
    val state = viewModel.uiState.value
    assertTrue("State should be InvalidQr", state is ScannerUiState.InvalidQr)
    assertEquals("INVALID_PREFIX_DATA", (state as ScannerUiState.InvalidQr).rawPayload)
  }

  @Test
  fun test3_scannerDoesNotBypassQrPayloadParser() = testScope.runTest {
    var parserInvoked = false
    var lastParsed: String? = null
    val service = QrCheckInService(
      engine = FakeCheckInEngine(),
      parsePayload = {
        parserInvoked = true
        lastParsed = it
        QrPayloadParser.parse(it)
      }
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = service,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()

    assertTrue("QrPayloadParser MUST be invoked by the pipeline", parserInvoked)
    assertEquals("EVT1:$validUuid1", lastParsed)
  }

  @Test
  fun test4_scannerDoesNotCallRoomDirectly() = testScope.runTest {
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.Success(sampleGuest1, 1700000000000L)
    )

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()

    assertEquals("Direct repository insertAttendance must NOT be called by ViewModel", 0, fakeRepo.directInsertCount)
  }

  @Test
  fun test5_duplicateCameraFramesAreDebounced() = testScope.runTest {
    var currentTime = 1000L
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.Success(sampleGuest1, 1000L)
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
      timeProvider = { currentTime },
      debounceWindowMs = 2000L,
    )
    advanceUntilIdle()

    // First scan
    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()
    assertEquals(1, fakeService.callCount)

    // Put scanner back in scanning state
    viewModel.resumeScanning(clearDebounce = false)
    advanceUntilIdle()

    // Second scan with identical payload within debounce window (+500ms)
    currentTime = 1500L
    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()

    assertEquals("Duplicate frame within debounce window must be ignored", 1, fakeService.callCount)
  }

  @Test
  fun test6_differentQrPayloadsAreNotIncorrectlyTreatedAsDuplicates() = testScope.runTest {
    var currentTime = 1000L
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.Success(sampleGuest1, 1000L)
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
      timeProvider = { currentTime },
      debounceWindowMs = 2000L,
    )
    advanceUntilIdle()

    // Scan Guest 1
    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()
    assertEquals(1, fakeService.callCount)

    // Resume scanning
    viewModel.resumeScanning(clearDebounce = false)
    advanceUntilIdle()

    // Immediately scan Guest 2 (different payload) only 200ms later
    currentTime = 1200L
    fakeService.stubResult = QrCheckInResult.Success(sampleGuest2, 1200L)
    viewModel.onQrCodeScanned("EVT1:$validUuid2")
    advanceUntilIdle()

    assertEquals("Different payload must NOT be blocked by debounce", 2, fakeService.callCount)
    assertEquals("EVT1:$validUuid2", fakeService.lastReceivedPayload)
  }

  @Test
  fun test7_successfulResultReturnsScannerToScanningState() = testScope.runTest {
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.Success(sampleGuest1, 1700000000000L)
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()
    assertTrue(viewModel.uiState.value is ScannerUiState.Success)

    viewModel.resumeScanning()
    advanceUntilIdle()

    assertEquals(ScannerUiState.Scanning, viewModel.uiState.value)
    assertTrue(viewModel.isScanningActive)
  }

  @Test
  fun test8_alreadyCheckedInResultIsDisplayedCorrectly() = testScope.runTest {
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.AlreadyCheckedIn(sampleGuest1, 1699999000000L)
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()

    val state = viewModel.uiState.value
    assertTrue("State must be AlreadyCheckedIn", state is ScannerUiState.AlreadyCheckedIn)
    assertEquals(sampleGuest1, (state as ScannerUiState.AlreadyCheckedIn).guest)
    assertEquals(1699999000000L, state.firstCheckedInAt)
  }

  @Test
  fun test9_guestNotFoundResultIsHandled() = testScope.runTest {
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.GuestNotFound
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onQrCodeScanned("EVT1:$validUuid1")
    advanceUntilIdle()

    val state = viewModel.uiState.value
    assertTrue("State must be GuestNotFound", state is ScannerUiState.GuestNotFound)
    assertEquals(validUuid1, (state as ScannerUiState.GuestNotFound).guestUuid)
  }

  @Test
  fun test10_invalidQrResultIsHandled() = testScope.runTest {
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.InvalidQr(QrPayloadParseResult.InvalidFormat)
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onQrCodeScanned("MALFORMED_JSON_{}")
    advanceUntilIdle()

    val state = viewModel.uiState.value
    assertTrue("State must be InvalidQr", state is ScannerUiState.InvalidQr)
    assertEquals("MALFORMED_JSON_{}", (state as ScannerUiState.InvalidQr).rawPayload)
  }

  @Test
  fun test11_noActiveEventResultIsHandled() = testScope.runTest {
    val fakeRepo = FakeCheckInRepository(activeEvent = null)
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.NoActiveEvent
    )

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    assertEquals("Terminal must be in NoActiveEvent state", ScannerUiState.NoActiveEvent, viewModel.uiState.value)
    assertFalse("Scanning must not be active when no event is loaded", viewModel.isScanningActive)
  }

  @Test
  fun test12_cameraPermissionDeniedStateIsHandled() = testScope.runTest {
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)
    val fakeService = TrackingQrCheckInService(stubResult = QrCheckInResult.NoActiveEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onCameraPermissionResult(granted = false)
    advanceUntilIdle()

    assertEquals(ScannerUiState.CameraPermissionDenied, viewModel.uiState.value)
  }

  @Test
  fun test16_multipleQrCodesInAFrameDoNotTriggerCheckIn() = testScope.runTest {
    val fakeService = TrackingQrCheckInService(
      stubResult = QrCheckInResult.Success(sampleGuest1, 1000L)
    )
    val fakeRepo = FakeCheckInRepository(activeEvent = sampleEvent)

    val viewModel = QrScannerViewModel(
      application = Application(),
      qrCheckInService = fakeService,
      checkInRepository = fakeRepo,
    )
    advanceUntilIdle()

    viewModel.onMultipleQrDetected()
    advanceUntilIdle()

    assertEquals(ScannerUiState.MultipleQrDetected, viewModel.uiState.value)
    assertEquals("Check-in service must NEVER be called when multiple QRs are detected", 0, fakeService.callCount)
  }

  // =========================================================================
  // Test Doubles
  // =========================================================================

  private class FakeImageProxy : ImageProxy {
    var isClosed = false
      private set

    override fun close() {
      isClosed = true
    }

    override fun getCropRect(): Rect = Rect(0, 0, 100, 100)
    override fun setCropRect(rect: Rect?) {}
    override fun getFormat(): Int = 0
    override fun getHeight(): Int = 100
    override fun getWidth(): Int = 100
    override fun getPlanes(): Array<ImageProxy.PlaneProxy> = emptyArray()
    override fun getImageInfo(): ImageInfo = object : ImageInfo {
      override fun getTagBundle(): androidx.camera.core.impl.TagBundle = androidx.camera.core.impl.TagBundle.emptyBundle()
      override fun getTimestamp(): Long = 0L
      override fun getRotationDegrees(): Int = 0
      override fun populateExifData(builder: androidx.camera.core.impl.utils.ExifData.Builder) {}
    }

    @ExperimentalGetImage
    override fun getImage(): Image? = null
  }

  private class TrackingQrCheckInService(
    var stubResult: QrCheckInResult,
  ) : QrCheckInService(
    engine = FakeCheckInEngine(),
  ) {
    var callCount = 0
    var lastReceivedPayload: String? = null

    override suspend fun checkInWithQr(qrPayload: String?): QrCheckInResult {
      callCount++
      lastReceivedPayload = qrPayload
      return stubResult
    }
  }

  private class FakeCheckInEngine : CheckInEngine(
    repository = FakeCheckInRepository(activeEvent = null),
  ) {
    override suspend fun checkIn(guestUuid: String): CheckInResult {
      return CheckInResult.NoActiveEvent
    }
  }

  private class FakeCheckInRepository(
    private val activeEvent: ImportedEvent?,
  ) : CheckInRepository(FakeCheckInDao()) {
    var directInsertCount = 0

    override suspend fun getActiveEvent(): ImportedEvent? = activeEvent
    override fun getActiveEventFlow(): Flow<ImportedEvent?> = flowOf(activeEvent)
    override fun getGuestCountFlow(): Flow<Int> = flowOf(0)
  }

  private class FakeCheckInDao : CheckInDao {
    override fun getActiveEventFlow(): Flow<ImportedEventEntity?> = flowOf(null)
    override suspend fun getActiveEvent(): ImportedEventEntity? = null
    override fun getGuestsForEventFlow(eventId: Long): Flow<List<ImportedGuestEntity>> = flowOf(emptyList())
    override fun getAllGuestsFlow(): Flow<List<ImportedGuestEntity>> = flowOf(emptyList())
    override fun getGuestCountFlow(): Flow<Int> = flowOf(0)
    override suspend fun getGuestCount(): Int = 0
    override fun getGuestCountForEventFlow(eventId: Long): Flow<Int> = flowOf(0)
    override suspend fun getGuestCountForEvent(eventId: Long): Int = 0
    override fun getRecentCheckInsFlow(eventId: Long, limit: Int): Flow<List<RecentCheckInItem>> = flowOf(emptyList())
    override suspend fun getRecentCheckIns(eventId: Long, limit: Int): List<RecentCheckInItem> = emptyList()
    override fun getAllAttendanceItemsFlow(eventId: Long): Flow<List<RecentCheckInItem>> = flowOf(emptyList())
    override suspend fun getAllAttendanceItems(eventId: Long): List<RecentCheckInItem> = emptyList()
    override suspend fun getAttendanceItem(eventId: Long, guestUuid: String): RecentCheckInItem? = null
    override suspend fun getGuestByUuid(uuid: String): ImportedGuestEntity? = null
    override suspend fun getGuestByEventAndUuid(eventId: Long, uuid: String): ImportedGuestEntity? = null
    override suspend fun insertEvent(event: ImportedEventEntity) {}
    override suspend fun insertGuests(guests: List<ImportedGuestEntity>) {}
    override suspend fun clearEvents() {}
    override suspend fun clearGuests() {}
    override suspend fun insertAttendance(attendance: AttendanceRecordEntity): Long = 1L
    override suspend fun getAttendance(eventId: Long, guestUuid: String): AttendanceRecordEntity? = null
    override fun getAttendanceForEventFlow(eventId: Long): Flow<List<AttendanceRecordEntity>> = flowOf(emptyList())
    override suspend fun getAttendanceForEvent(eventId: Long): List<AttendanceRecordEntity> = emptyList()
    override suspend fun getAttendanceCount(eventId: Long): Int = 0
    override fun getAttendanceCountFlow(eventId: Long): Flow<Int> = flowOf(0)
    override suspend fun getPendingGuestCount(eventId: Long): Int = 0
    override fun getPendingGuestCountFlow(eventId: Long): Flow<Int> = flowOf(0)
    override suspend fun deleteAttendanceForEvent(eventId: Long) {}
    override suspend fun clearAllAttendance() {}
  }
}
