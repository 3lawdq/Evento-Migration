package com.evento.checkin

import com.evento.checkin.domain.export.AttendanceCsvExporter
import com.evento.checkin.domain.model.RecentCheckInItem
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AttendanceCsvExporterTest {

  @Test
  fun testCsvHeaderAndUtf8Bom() {
    val content = AttendanceCsvExporter.generateCsvContent(emptyList())
    assertTrue("CSV must start with UTF-8 BOM", content.startsWith(AttendanceCsvExporter.UTF8_BOM))
    val afterBom = content.removePrefix(AttendanceCsvExporter.UTF8_BOM)
    assertTrue(
      "CSV must have correct human-readable header",
      afterBom.startsWith("Full Name,Organization,Job Title,Check-In Date,Check-In Time\r\n"),
    )
  }

  @Test
  fun testNoUuidOrInternalIdExported() {
    val secretUuid = "3fa85f64-5717-4562-b3fc-2c963f66afa6"
    val records = listOf(
      RecentCheckInItem(
        guestUuid = secretUuid,
        fullName = "Omar Al-Khatib",
        organization = "Saudi Aramco",
        jobTitle = "Chief Architect",
        checkedInAt = 1773000000000L,
      ),
    )

    val content = AttendanceCsvExporter.generateCsvContent(records)

    assertFalse("Internal UUID must NOT appear in the exported CSV", content.contains(secretUuid))
    assertTrue("Full name must appear in the exported CSV", content.contains("Omar Al-Khatib"))
    assertTrue("Organization must appear in the exported CSV", content.contains("Saudi Aramco"))
    assertTrue("Job title must appear in the exported CSV", content.contains("Chief Architect"))
  }

  @Test
  fun testArabicTextAndSpecialCharactersPreserved() {
    val records = listOf(
      RecentCheckInItem(
        guestUuid = "dummy-uuid",
        fullName = "د. سارة المنصور",
        organization = "وزارة الاتصالات وتقنية المعلومات",
        jobTitle = "مدير عام",
        checkedInAt = 1773000000000L,
      ),
    )

    val content = AttendanceCsvExporter.generateCsvContent(records)

    assertTrue("Arabic name must be preserved in CSV", content.contains("د. سارة المنصور"))
    assertTrue("Arabic organization must be preserved in CSV", content.contains("وزارة الاتصالات وتقنية المعلومات"))
    assertTrue("Arabic job title must be preserved in CSV", content.contains("مدير عام"))
  }

  @Test
  fun testRfc4180CsvEscaping() {
    val records = listOf(
      RecentCheckInItem(
        guestUuid = "uuid-1",
        fullName = "Doe, John \"Johnny\"",
        organization = "Acme, Inc.",
        jobTitle = "Lead, Dept\nSpecialist",
        checkedInAt = 1773000000000L,
      ),
    )

    val content = AttendanceCsvExporter.generateCsvContent(records)

    assertTrue(content.contains("\"Doe, John \"\"Johnny\"\"\""))
    assertTrue(content.contains("\"Acme, Inc.\""))
    assertTrue(content.contains("\"Lead, Dept\nSpecialist\""))
  }

  @Test
  fun testWriteCsvToStream() {
    val records = listOf(
      RecentCheckInItem(
        guestUuid = "uuid-stream",
        fullName = "Fahad Khalid",
        organization = "STC",
        jobTitle = "Engineer",
        checkedInAt = 1773000000000L,
      ),
    )

    val outputStream = ByteArrayOutputStream()
    AttendanceCsvExporter.writeCsvToStream(records, outputStream)
    val exportedString = outputStream.toString("UTF-8")

    assertTrue(exportedString.startsWith(AttendanceCsvExporter.UTF8_BOM))
    assertTrue(exportedString.contains("Fahad Khalid"))
    assertTrue(exportedString.contains("STC"))
  }

  @Test
  fun testGenerateFileNamePattern() {
    val fixedTime = 1700000000000L // 2023-11-14
    val fileName = AttendanceCsvExporter.generateFileName("LEAP 2026 Riyadh", fixedTime)

    assertTrue(fileName.startsWith("Evento_Attendance_LEAP_2026_Riyadh_"))
    assertTrue(fileName.endsWith(".csv"))
  }

  @Test
  fun testGenerateFileNameArabicEvent() {
    val fixedTime = 1700000000000L
    val fileName = AttendanceCsvExporter.generateFileName("مؤتمر_الرياض", fixedTime)

    assertTrue(fileName.startsWith("Evento_Attendance_مؤتمر_الرياض_"))
    assertTrue(fileName.endsWith(".csv"))
  }
}
