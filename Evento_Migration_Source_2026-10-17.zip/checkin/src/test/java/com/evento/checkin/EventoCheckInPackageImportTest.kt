package com.evento.checkin

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.evento.checkin.R
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.CheckInSecurityArchitecture
import com.evento.checkin.domain.model.ImportedGuest
import com.evento.checkin.domain.model.PackageValidationResult
import com.evento.checkin.util.packageutil.CheckInPackageSecurity
import com.evento.checkin.util.packageutil.EventoPackageImporter
import com.evento.checkin.util.packageutil.EventoPackageVerifier
import com.evento.checkin.util.packageutil.PackageImportResult
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Phase 7.2 comprehensive verification and test suite for Evento Check-In package import.
 *
 * Covers:
 * 1. Valid package imports successfully
 * 2. Modified event.json fails integrity
 * 3. Modified guests.json fails integrity
 * 4. Missing signature.json fails
 * 5. Missing manifest.json fails
 * 6. Missing event.json fails
 * 7. Missing guests.json fails
 * 8. Unsupported packageFormatVersion fails
 * 9. Unsupported packageType fails
 * 10. Duplicate UUIDs fail
 * 11. Malformed UUID fails
 * 12. Empty guest list handling works as expected
 * 13. Path traversal attack in ZIP is rejected
 * 14. Re-import replaces previous event data
 * 15. Guest count mismatch fails
 * 16. PII is not stored (verify email/phone/notes are absent)
 */
@RunWith(RobolectricTestRunner::class)
class EventoCheckInPackageImportTest {

  private lateinit var database: CheckInDatabase
  private lateinit var repository: CheckInRepository
  private lateinit var verifier: EventoPackageVerifier
  private lateinit var importer: EventoPackageImporter

  @Before
  fun setup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = CheckInDatabase.createInMemory(context)
    repository = CheckInRepository(database.checkInDao())
    verifier = EventoPackageVerifier()
    importer = EventoPackageImporter(repository, verifier)
  }

  @After
  fun tearDown() {
    database.close()
  }

  // =========================================================================
  // HELPER: Build deterministic .evento ZIP archives in memory
  // =========================================================================

  private fun buildZip(entries: Map<String, ByteArray>): ByteArray {
    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      for ((name, data) in entries) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(data)
        zos.closeEntry()
      }
    }
    return baos.toByteArray()
  }

  private fun buildZipEntries(entries: List<Pair<String, ByteArray>>): ByteArray {
    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      for ((name, data) in entries) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(data)
        zos.closeEntry()
      }
    }
    return baos.toByteArray()
  }

  private fun createPackageBytes(
    eventId: Long = 1001L,
    eventName: String = "Annual Graduation Ceremony",
    date: String = "2026-11-20",
    location: String = "Grand Auditorium",
    organizer: String = "Evento University",
    packageFormatVersion: Int = 1,
    packageType: String = "EVENTO_EVENT",
    payloadFormat: String = "EVT1:<guest_uuid>",
    guestCountOverride: Int? = null,
    guests: List<Map<String, Any?>> = listOf(
      mapOf(
        "uuid" to "550e8400-e29b-41d4-a716-446655440000",
        "fullName" to "Amira Hassan",
        "invitationStatus" to "CONFIRMED",
        "organization" to "Tech Corp",
        "jobTitle" to "Senior Lead",
      ),
      mapOf(
        "uuid" to "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
        "fullName" to "Tariq Al-Mansoor",
        "invitationStatus" to "INVITED",
        "organization" to "Design Studio",
        "jobTitle" to "Art Director",
      ),
    ),
    tamperEventBytes: ((ByteArray) -> ByteArray)? = null,
    tamperGuestsBytes: ((ByteArray) -> ByteArray)? = null,
    omitEntries: Set<String> = emptySet(),
    extraEntries: Map<String, ByteArray> = emptyMap(),
  ): ByteArray {
    // 1. event.json
    val eventJson = JSONObject().apply {
      put("eventId", eventId)
      put("name", eventName)
      put("date", date)
      put("location", location)
      put("organizer", organizer)
      put("packageFormatVersion", packageFormatVersion)
    }.toString(2).toByteArray(Charsets.UTF_8)

    // 2. guests.json
    val guestsArray = JSONArray()
    for (g in guests) {
      val obj = JSONObject()
      g.forEach { (k, v) -> obj.put(k, v) }
      guestsArray.put(obj)
    }
    val guestsContainerJson = JSONObject().apply {
      put("guests", guestsArray)
    }.toString(2).toByteArray(Charsets.UTF_8)

    // Compute original SHA-256 digests
    val eventSha256 = CheckInPackageSecurity.sha256Hex(eventJson)
    val guestsSha256 = CheckInPackageSecurity.sha256Hex(guestsContainerJson)

    // 3. manifest.json
    val manifestJson = JSONObject().apply {
      put("packageFormatVersion", packageFormatVersion)
      put("packageType", packageType)
      put("eventId", eventId)
      put("eventName", eventName)
      put("guestCount", guestCountOverride ?: guests.size)
      put("guestScope", "ALL")
      put("payloadFormat", payloadFormat)
      put("hashAlgorithm", "SHA-256")
      put("createdAt", "2026-09-12T12:00:00Z")
    }.toString(2).toByteArray(Charsets.UTF_8)

    // 4. signature.json
    val signatureJson = JSONObject().apply {
      put("algorithm", "SHA-256")
      put("eventJsonSha256", eventSha256)
      put("guestsJsonSha256", guestsSha256)
    }.toString(2).toByteArray(Charsets.UTF_8)

    // Apply potential tampering
    val finalEventBytes = tamperEventBytes?.invoke(eventJson) ?: eventJson
    val finalGuestsBytes = tamperGuestsBytes?.invoke(guestsContainerJson) ?: guestsContainerJson

    val entries = mutableMapOf<String, ByteArray>()
    if ("manifest.json" !in omitEntries) entries["manifest.json"] = manifestJson
    if ("event.json" !in omitEntries) entries["event.json"] = finalEventBytes
    if ("guests.json" !in omitEntries) entries["guests.json"] = finalGuestsBytes
    if ("signature.json" !in omitEntries) entries["signature.json"] = signatureJson

    entries.putAll(extraEntries)
    return buildZip(entries)
  }

  // =========================================================================
  // TESTS
  // =========================================================================

  @Test
  fun test01_validPackageImportsSuccessfully() = runBlocking {
    val zipBytes = createPackageBytes()
    val validation = verifier.verifyPackage(zipBytes)

    assertTrue("Validation should succeed for a compliant package", validation is PackageValidationResult.Valid)
    val valid = validation as PackageValidationResult.Valid
    assertEquals(1001L, valid.event.eventId)
    assertEquals("Annual Graduation Ceremony", valid.event.name)
    assertEquals(2, valid.guests.size)
    assertEquals("LEGACY_INTEGRITY_ONLY", valid.event.verificationStatus)

    // Perform import into Room
    val importResult = importer.importFromStream(ByteArrayInputStream(zipBytes))
    assertTrue("Import should succeed", importResult is PackageImportResult.Success)
    val success = importResult as PackageImportResult.Success
    assertEquals(1001L, success.event.eventId)
    assertEquals(2, success.guestCount)

    // Verify stored active event and guests in database
    val storedEvent = repository.getActiveEvent()
    assertNotNull(storedEvent)
    assertEquals("Annual Graduation Ceremony", storedEvent?.name)
    assertEquals(2, storedEvent?.guestCount)

    val storedGuests = database.checkInDao().getGuestCount()
    assertEquals(2, storedGuests)

    val guest1 = database.checkInDao().getGuestByUuid("550e8400-e29b-41d4-a716-446655440000")
    assertNotNull(guest1)
    assertEquals("Amira Hassan", guest1?.fullName)
    assertEquals("CONFIRMED", guest1?.invitationStatus)
    assertEquals("Tech Corp", guest1?.organization)
    assertEquals("Senior Lead", guest1?.jobTitle)
  }

  @Test
  fun test02_modifiedEventJsonFailsIntegrity() {
    val zipBytes = createPackageBytes(
      tamperEventBytes = { originalBytes ->
        // Tamper with event data without updating signature
        val str = originalBytes.toString(Charsets.UTF_8)
        str.replace("Annual Graduation Ceremony", "Hacked Graduation Ceremony")
          .toByteArray(Charsets.UTF_8)
      }
    )

    val result = verifier.verifyPackage(zipBytes)
    assertTrue("Tampered event.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_integrity_failed, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("SHA-256"))
  }

  @Test
  fun test03_modifiedGuestsJsonFailsIntegrity() {
    val zipBytes = createPackageBytes(
      tamperGuestsBytes = { originalBytes ->
        // Tamper with guest roster without updating signature
        val str = originalBytes.toString(Charsets.UTF_8)
        str.replace("Amira Hassan", "Eve Attacker")
          .toByteArray(Charsets.UTF_8)
      }
    )

    val result = verifier.verifyPackage(zipBytes)
    assertTrue("Tampered guests.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_integrity_failed, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("SHA-256"))
  }

  @Test
  fun test04_missingSignatureJsonFails() {
    val zipBytes = createPackageBytes(omitEntries = setOf("signature.json"))
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Missing signature.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_missing_entries, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("signature.json"))
  }

  @Test
  fun test05_missingManifestJsonFails() {
    val zipBytes = createPackageBytes(omitEntries = setOf("manifest.json"))
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Missing manifest.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_missing_entries, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("manifest.json"))
  }

  @Test
  fun test06_missingEventJsonFails() {
    val zipBytes = createPackageBytes(omitEntries = setOf("event.json"))
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Missing event.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_missing_entries, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("event.json"))
  }

  @Test
  fun test07_missingGuestsJsonFails() {
    val zipBytes = createPackageBytes(omitEntries = setOf("guests.json"))
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Missing guests.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_missing_entries, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("guests.json"))
  }

  @Test
  fun test08_unsupportedPackageFormatVersionFails() {
    val zipBytes = createPackageBytes(packageFormatVersion = 99)
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Unsupported version must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_unsupported_version, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("packageFormatVersion"))
  }

  @Test
  fun test09_unsupportedPackageTypeFails() {
    val zipBytes = createPackageBytes(packageType = "EVENTO_UNKNOWN_TYPE")
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Unsupported packageType must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_unsupported_type, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("packageType"))
  }

  @Test
  fun test10_duplicateUuidsFail() {
    // Two guests sharing the same UUID (one uppercase, one lowercase)
    val zipBytes = createPackageBytes(
      guests = listOf(
        mapOf("uuid" to "550e8400-e29b-41d4-a716-446655440000", "fullName" to "Guest One", "invitationStatus" to "CONFIRMED"),
        mapOf("uuid" to "550E8400-E29B-41D4-A716-446655440000", "fullName" to "Guest Two", "invitationStatus" to "INVITED"),
      )
    )
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Duplicate UUIDs must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_duplicate_uuid, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("Duplicate guest UUID"))
  }

  @Test
  fun test11_malformedUuidFails() {
    val zipBytes = createPackageBytes(
      guests = listOf(
        mapOf("uuid" to "invalid-non-uuid-string", "fullName" to "Guest Broken", "invitationStatus" to "CONFIRMED"),
      )
    )
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Malformed UUID must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_invalid_uuid, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("invalid UUID"))
  }

  @Test
  fun test12_emptyGuestListHandlingWorksAsExpected() {
    val zipBytes = createPackageBytes(
      guests = emptyList()
    )
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Empty guest roster must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_empty_guests, invalid.userMessageRes)
  }

  @Test
  fun test13_pathTraversalAttackInZipIsRejected() {
    val zipBytes = createPackageBytes(
      extraEntries = mapOf(
        "../bad_actor.json" to "{}".toByteArray(Charsets.UTF_8)
      )
    )
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Path traversal entry must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_security_violation, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("Security violation"))
  }

  @Test
  fun test14_reimportReplacesPreviousEventData() = runBlocking {
    // 1. Import first event with 2 guests
    val zipBytes1 = createPackageBytes(
      eventId = 101L,
      eventName = "First Event",
      guests = listOf(
        mapOf("uuid" to "11111111-1111-1111-1111-111111111111", "fullName" to "User One", "invitationStatus" to "CONFIRMED"),
        mapOf("uuid" to "22222222-2222-2222-2222-222222222222", "fullName" to "User Two", "invitationStatus" to "INVITED"),
      )
    )
    val result1 = importer.importFromStream(ByteArrayInputStream(zipBytes1))
    assertTrue(result1 is PackageImportResult.Success)

    assertEquals("First Event", repository.getActiveEvent()?.name)
    assertEquals(2, database.checkInDao().getGuestCount())
    assertNotNull(database.checkInDao().getGuestByUuid("11111111-1111-1111-1111-111111111111"))

    // 2. Re-import second event with 1 different guest
    val zipBytes2 = createPackageBytes(
      eventId = 202L,
      eventName = "Second Replacement Event",
      guests = listOf(
        mapOf("uuid" to "33333333-3333-3333-3333-333333333333", "fullName" to "User Three", "invitationStatus" to "CONFIRMED"),
      )
    )
    val result2 = importer.importFromStream(ByteArrayInputStream(zipBytes2))
    assertTrue(result2 is PackageImportResult.Success)

    // Verify atomic replacement: previous event and previous guests are gone
    val currentEvent = repository.getActiveEvent()
    assertEquals(202L, currentEvent?.eventId)
    assertEquals("Second Replacement Event", currentEvent?.name)
    assertEquals(1, currentEvent?.guestCount)

    assertEquals(1, database.checkInDao().getGuestCount())
    // Old guests from event 101 must not exist
    assertNull(database.checkInDao().getGuestByUuid("11111111-1111-1111-1111-111111111111"))
    assertNull(database.checkInDao().getGuestByUuid("22222222-2222-2222-2222-222222222222"))
    // New guest must exist
    assertNotNull(database.checkInDao().getGuestByUuid("33333333-3333-3333-3333-333333333333"))
  }

  @Test
  fun test15_guestCountMismatchFails() {
    // Manifest declares guestCount = 10, but guests list only has 2
    val zipBytes = createPackageBytes(
      guestCountOverride = 10
    )
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Guest count mismatch must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_guest_count_mismatch, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("Guest count mismatch"))
  }

  @Test
  fun test16_piiIsNotStored() {
    // Check-In privacy architecture constraint:
    // Email, phone number, and organizer notes must NOT exist on Check-In attendee models.
    val guestFields = ImportedGuest::class.java.declaredFields.map { it.name }
    val entityFields = ImportedGuestEntity::class.java.declaredFields.map { it.name }

    assertFalse("ImportedGuest domain must NOT contain email", guestFields.contains("email"))
    assertFalse("ImportedGuest domain must NOT contain phone", guestFields.contains("phone"))
    assertFalse("ImportedGuest domain must NOT contain notes", guestFields.contains("notes"))

    assertFalse("ImportedGuestEntity must NOT store email", entityFields.contains("email"))
    assertFalse("ImportedGuestEntity must NOT store phone", entityFields.contains("phone"))
    assertFalse("ImportedGuestEntity must NOT store notes", entityFields.contains("notes"))

    // Confirm authorized fields are present
    assertTrue(guestFields.contains("uuid"))
    assertTrue(guestFields.contains("fullName"))
    assertTrue(guestFields.contains("invitationStatus"))
    assertTrue(guestFields.contains("organization"))
    assertTrue(guestFields.contains("jobTitle"))
    assertTrue(guestFields.contains("checkInStatus"))
  }

  @Test
  fun test17_guestReferencingDifferentEventFails() {
    // Guest object contains an eventId that does not match the package eventId (1001L)
    val zipBytes = createPackageBytes(
      eventId = 1001L,
      guests = listOf(
        mapOf(
          "uuid" to "550e8400-e29b-41d4-a716-446655440000",
          "fullName" to "Foreign Guest",
          "invitationStatus" to "CONFIRMED",
          "eventId" to 9999L,
        ),
      ),
    )
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Guest belonging to different event must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_invalid_guest, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("different event ID"))
  }

  @Test
  fun test18_malformedJsonInRequiredFileFails() {
    // Malformed JSON syntax in event.json
    val zipBytes = createPackageBytes(
      tamperEventBytes = {
        "{ \"eventId\": 1001, \"name\": \"Broken JSON...".toByteArray(Charsets.UTF_8)
      }
    )
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Malformed JSON must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_invalid_package, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("Malformed JSON payload"))
  }

  @Test
  fun test19_failedImportPreservesPreviousValidEvent(): Unit = runBlocking {
    // A. Import valid package
    val validZipBytes = createPackageBytes(
      eventId = 5001L,
      eventName = "Original Valid Event",
      guests = listOf(
        mapOf("uuid" to "11111111-1111-1111-1111-111111111111", "fullName" to "Original Guest", "invitationStatus" to "CONFIRMED")
      )
    )
    val import1 = importer.importFromStream(ByteArrayInputStream(validZipBytes))
    assertTrue("Initial valid import must succeed", import1 is PackageImportResult.Success)

    // B. Verify the event and guests exist in the Check-In database
    val originalEvent = repository.getActiveEvent()
    assertNotNull(originalEvent)
    assertEquals(5001L, originalEvent?.eventId)
    assertEquals("Original Valid Event", originalEvent?.name)
    assertEquals(1, database.checkInDao().getGuestCount())

    // C. Attempt to import a deliberately invalid/tampered package
    val invalidZipBytes = createPackageBytes(
      eventId = 6002L,
      eventName = "Tampered Malicious Event",
      tamperEventBytes = { "corrupted data".toByteArray(Charsets.UTF_8) }
    )
    val import2 = importer.importFromStream(ByteArrayInputStream(invalidZipBytes))

    // D. Verify the invalid import fails
    assertTrue("Tampered package import must fail", import2 is PackageImportResult.Error)

    // E. Verify the ORIGINAL valid event and guests are still present and unchanged
    val preservedEvent = repository.getActiveEvent()
    assertNotNull("Original event must be preserved", preservedEvent)
    assertEquals(5001L, preservedEvent?.eventId)
    assertEquals("Original Valid Event", preservedEvent?.name)
    assertEquals(1, preservedEvent?.guestCount)

    val preservedGuests = database.checkInDao().getGuestCount()
    assertEquals(1, preservedGuests)
    val preservedGuest = database.checkInDao().getGuestByUuid("11111111-1111-1111-1111-111111111111")
    assertNotNull(preservedGuest)
    assertEquals("Original Guest", preservedGuest?.fullName)
  }

  @Test
  fun test20_duplicateZipEntriesRejected() {
    val eventData = "{}".toByteArray(Charsets.UTF_8)
    val duplicateZipBytes = buildZipEntries(
      listOf(
        Pair("manifest.json", eventData),
        Pair("event.json", eventData),
        Pair("EVENT.JSON", eventData), // case-insensitive duplicate of event.json
        Pair("guests.json", eventData),
        Pair("signature.json", eventData),
      )
    )

    val result = verifier.verifyPackage(duplicateZipBytes)
    assertTrue("Duplicate ZIP entry must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(R.string.checkin_err_security_violation, invalid.userMessageRes)
    assertTrue(invalid.technicalReason.contains("Duplicate entry", ignoreCase = true))
  }

  @Test
  fun test21_databaseReloadAcrossProcessReopen(): Unit = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val testDbFile = File(context.filesDir, "test_checkin_persistence_reload.db")
    testDbFile.delete()

    val zipBytes = createPackageBytes(
      eventId = 7777L,
      eventName = "Persistent Across Restart Event",
      date = "2026-12-31",
      location = "Convention Center Hall A",
      organizer = "Global Events Org",
      guests = listOf(
        mapOf(
          "uuid" to "77777777-7777-7777-7777-777777777777",
          "fullName" to "Persistent Guest",
          "invitationStatus" to "CONFIRMED",
          "organization" to "Persistent Org",
          "jobTitle" to "Chief Architect",
        ),
      ),
    )

    // A. Import valid package into a file-backed Room database instance
    val diskDb1 = Room.databaseBuilder(context, CheckInDatabase::class.java, testDbFile.absolutePath)
      .allowMainThreadQueries()
      .build()
    val repo1 = CheckInRepository(diskDb1.checkInDao())
    val importer1 = EventoPackageImporter(repo1, verifier)

    val importResult = importer1.importFromStream(ByteArrayInputStream(zipBytes))
    assertTrue("Initial import must succeed", importResult is PackageImportResult.Success)

    // B. Close/release the database instance
    diskDb1.close()

    // C. Create/reopen a fresh database instance using the same database file
    val diskDb2 = Room.databaseBuilder(context, CheckInDatabase::class.java, testDbFile.absolutePath)
      .allowMainThreadQueries()
      .build()
    val repo2 = CheckInRepository(diskDb2.checkInDao())

    // D. Load the imported event and guests
    val reloadedEvent = repo2.getActiveEvent()
    val reloadedCount = diskDb2.checkInDao().getGuestCount()
    val reloadedGuest = diskDb2.checkInDao().getGuestByUuid("77777777-7777-7777-7777-777777777777")

    // E. Verify the data is still present and correct
    assertNotNull("Reloaded event must not be null", reloadedEvent)
    assertEquals(7777L, reloadedEvent?.eventId)
    assertEquals("Persistent Across Restart Event", reloadedEvent?.name)
    assertEquals("2026-12-31", reloadedEvent?.date)
    assertEquals("Convention Center Hall A", reloadedEvent?.location)
    assertEquals(1, reloadedCount)

    assertNotNull("Reloaded guest must not be null", reloadedGuest)
    assertEquals("Persistent Guest", reloadedGuest?.fullName)
    assertEquals("CONFIRMED", reloadedGuest?.invitationStatus)
    assertEquals("Persistent Org", reloadedGuest?.organization)
    assertEquals("Chief Architect", reloadedGuest?.jobTitle)

    diskDb2.close()
    testDbFile.delete()
    Unit
  }

  @Test
  fun test22_qrPayloadContractMatchesGuestUuid(): Unit = runBlocking {
    val guestUuid = "550e8400-e29b-41d4-a716-446655440000"
    val zipBytes = createPackageBytes(
      guests = listOf(
        mapOf(
          "uuid" to guestUuid,
          "fullName" to "Amira Hassan",
          "invitationStatus" to "CONFIRMED",
          "organization" to "Tech Corp",
          "jobTitle" to "Senior Lead",
        )
      )
    )
    val result = importer.importFromStream(ByteArrayInputStream(zipBytes))
    assertTrue("Import should succeed", result is PackageImportResult.Success)

    val guest = database.checkInDao().getGuestByUuid(guestUuid)
    assertNotNull("Imported guest must exist in database", guest)

    val rawUuid = guest!!.uuid
    val expectedQrPayload = "${CheckInSecurityArchitecture.EXPECTED_PAYLOAD_PREFIX}$rawUuid"

    // Verify exact contract
    assertEquals("EVT1:550e8400-e29b-41d4-a716-446655440000", expectedQrPayload)
    assertTrue("Must start with exact prefix EVT1:", expectedQrPayload.startsWith("EVT1:"))
    assertEquals("UUID must match exactly after prefix", rawUuid, expectedQrPayload.substring(5))

    // Verify strictly NO PII, name, email, phone, or extra ID in QR payload
    assertFalse("Payload must NOT contain full name", expectedQrPayload.contains(guest.fullName))
    assertFalse("Payload must NOT contain email symbol @", expectedQrPayload.contains("@"))
    assertFalse("Payload must NOT contain organization", expectedQrPayload.contains(guest.organization))
    assertFalse("Payload must NOT contain job title", expectedQrPayload.contains(guest.jobTitle))
    assertFalse("Payload must NOT contain additional QR ID", expectedQrPayload.contains("id="))

    // Verify UUID validity
    assertTrue("Payload UUID must be RFC-4122 compliant", CheckInPackageSecurity.isValidUuid(rawUuid))
  }
}
