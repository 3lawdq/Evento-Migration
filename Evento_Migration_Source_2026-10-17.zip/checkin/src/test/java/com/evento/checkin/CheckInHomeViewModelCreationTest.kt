package com.evento.checkin

import android.app.Application
import android.content.Context
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ApplicationProvider
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.ui.screens.home.CheckInHomeScreen
import com.evento.checkin.ui.screens.home.CheckInHomeViewModel
import com.evento.checkin.ui.screens.packageimport.PackageImportViewModel
import com.evento.checkin.ui.screens.records.AttendanceRecordsViewModel
import com.evento.checkin.ui.screens.scanner.QrScannerViewModel
import com.evento.checkin.ui.screens.settings.CheckInSettingsViewModel
import com.evento.checkin.ui.screens.statistics.StatisticsViewModel
import org.junit.After
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class CheckInHomeViewModelCreationTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  private lateinit var context: Context
  private lateinit var database: CheckInDatabase
  private lateinit var repository: CheckInRepository

  @Before
  fun setup() {
    context = ApplicationProvider.getApplicationContext<Context>()
    database = CheckInDatabase.createInMemory(context)
    repository = CheckInRepository(database.checkInDao())
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun testCheckInHomeViewModelFactoryWithRepository() {
    val factory = CheckInHomeViewModel.provideFactory(repository)
    val viewModel = factory.create(CheckInHomeViewModel::class.java)
    assertNotNull("ViewModel created from repository factory must not be null", viewModel)
    assertTrue("ViewModel must be instance of CheckInHomeViewModel", viewModel is CheckInHomeViewModel)
  }

  @Test
  fun testCheckInHomeViewModelFactoryWithContext() {
    val factory = CheckInHomeViewModel.provideFactory(context)
    val viewModel = factory.create(CheckInHomeViewModel::class.java)
    assertNotNull("ViewModel created from context factory must not be null", viewModel)
    assertTrue("ViewModel must be instance of CheckInHomeViewModel", viewModel is CheckInHomeViewModel)
  }

  @Test
  fun testCheckInHomeViewModelDirectConstructor() {
    val viewModel = CheckInHomeViewModel(repository)
    assertNotNull(viewModel)
    assertNotNull(viewModel.uiState.value)
  }

  @Test
  fun testCheckInHomeViewModelApplicationConstructor() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = CheckInHomeViewModel(app, repository)
    assertNotNull(viewModel)
    assertNotNull(viewModel.uiState.value)
  }

  @Test
  fun testAllCheckInViewModelsProvideFactory() {
    val statsVm = StatisticsViewModel.provideFactory(repository).create(StatisticsViewModel::class.java)
    assertNotNull(statsVm)

    val recordsVm = AttendanceRecordsViewModel.provideFactory(repository).create(AttendanceRecordsViewModel::class.java)
    assertNotNull(recordsVm)

    val settingsVm = CheckInSettingsViewModel.provideFactory(repository).create(CheckInSettingsViewModel::class.java)
    assertNotNull(settingsVm)

    val importVm = PackageImportViewModel.provideFactory(repository).create(PackageImportViewModel::class.java)
    assertNotNull(importVm)

    val scannerVm = QrScannerViewModel.provideFactory(repository).create(QrScannerViewModel::class.java)
    assertNotNull(scannerVm)
  }

  @Test
  fun testCheckInHomeScreenRendersWithoutCrash() {
    composeTestRule.setContent {
      val vm = CheckInHomeViewModel.provideFactory(repository).create(CheckInHomeViewModel::class.java)
      CheckInHomeScreen(
        viewModel = vm,
        onNavigateTo = {},
      )
    }

    // Verify it renders the home screen content without crashing
    composeTestRule.onNodeWithTag("checkin_header_card").assertExists()
  }
}
