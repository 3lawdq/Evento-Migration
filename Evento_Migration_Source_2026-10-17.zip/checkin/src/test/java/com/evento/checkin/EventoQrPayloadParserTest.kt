package com.evento.checkin

import com.evento.checkin.domain.qr.QrPayloadParseResult
import com.evento.checkin.domain.qr.QrPayloadParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit test suite for Phase 7.3B: [QrPayloadParser].
 *
 * Verifies strict offline parsing and validation rules for the `EVT1:<uuid>` badge grammar.
 */
class EventoQrPayloadParserTest {

  private val validUuid = "550e8400-e29b-41d4-a716-446655440000"
  private val validUppercaseUuid = "550E8400-E29B-41D4-A716-446655440000"

  @Test
  fun test01_validEvt1UuidIsAccepted() {
    val raw = "EVT1:$validUuid"
    val result = QrPayloadParser.parse(raw)

    assertTrue("Expected Valid parse result for $raw", result is QrPayloadParseResult.Valid)
    val valid = result as QrPayloadParseResult.Valid
    assertEquals(validUuid, valid.uuid)
    assertEquals(validUuid, valid.payload.uuid)
  }

  @Test
  fun test02_validUuidWithUppercaseHexCharactersIsHandledConsistently() {
    val raw = "EVT1:$validUppercaseUuid"
    val result = QrPayloadParser.parse(raw)

    assertTrue("Expected Valid parse result for uppercase UUID $raw", result is QrPayloadParseResult.Valid)
    val valid = result as QrPayloadParseResult.Valid
    assertEquals(validUppercaseUuid, valid.uuid)
  }

  @Test
  fun test03_emptyStringRejected() {
    val result = QrPayloadParser.parse("")
    assertTrue("Empty string must be rejected", result is QrPayloadParseResult.InvalidFormat)

    val nullResult = QrPayloadParser.parse(null)
    assertTrue("Null input must be rejected", nullResult is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test04_evt1WithNoUuidRejected() {
    val raw = "EVT1:"
    val result = QrPayloadParser.parse(raw)
    assertTrue("Prefix without UUID must be rejected", result is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test05_wrongPrefixEvt2Rejected() {
    val raw = "EVT2:$validUuid"
    val result = QrPayloadParser.parse(raw)
    assertTrue("Wrong prefix must yield InvalidPrefix", result is QrPayloadParseResult.InvalidPrefix)
  }

  @Test
  fun test06_missingPrefixRejected() {
    val raw = validUuid
    val result = QrPayloadParser.parse(raw)
    assertTrue("Raw UUID without EVT1: must yield InvalidPrefix", result is QrPayloadParseResult.InvalidPrefix)
  }

  @Test
  fun test07_malformedUuidRejected() {
    val raw = "EVT1:not-a-uuid"
    val result = QrPayloadParser.parse(raw)
    assertTrue("Malformed UUID string must yield InvalidUuid", result is QrPayloadParseResult.InvalidUuid)
  }

  @Test
  fun test08_leadingWhitespaceRejected() {
    val raw = " EVT1:$validUuid"
    val result = QrPayloadParser.parse(raw)
    assertTrue("Leading whitespace must yield InvalidFormat without trimming", result is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test09_trailingWhitespaceRejected() {
    val raw = "EVT1:$validUuid "
    val result = QrPayloadParser.parse(raw)
    assertTrue("Trailing whitespace must yield InvalidFormat without trimming", result is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test10_newlineRejected() {
    val rawNewline = "EVT1:$validUuid\n"
    val rawCarriageReturn = "EVT1:$validUuid\r"
    val rawCrLf = "EVT1:$validUuid\r\n"

    assertTrue("Newline must yield InvalidFormat", QrPayloadParser.parse(rawNewline) is QrPayloadParseResult.InvalidFormat)
    assertTrue("Carriage return must yield InvalidFormat", QrPayloadParser.parse(rawCarriageReturn) is QrPayloadParseResult.InvalidFormat)
    assertTrue("CRLF must yield InvalidFormat", QrPayloadParser.parse(rawCrLf) is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test11_extraDataAfterUuidRejected() {
    val raw = "EVT1:$validUuid:extra"
    val result = QrPayloadParser.parse(raw)
    assertTrue("Extra colon-delimited data must yield InvalidFormat", result is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test12_multipleFieldsRejected() {
    val rawComma = "EVT1:$validUuid,extra"
    val rawSemicolon = "EVT1:$validUuid;field2"
    val rawPipe = "EVT1:$validUuid|vip"

    assertTrue("Comma delimiter must yield InvalidFormat", QrPayloadParser.parse(rawComma) is QrPayloadParseResult.InvalidFormat)
    assertTrue("Semicolon delimiter must yield InvalidFormat", QrPayloadParser.parse(rawSemicolon) is QrPayloadParseResult.InvalidFormat)
    assertTrue("Pipe delimiter must yield InvalidFormat", QrPayloadParser.parse(rawPipe) is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test13_jsonPayloadRejected() {
    val rawJson = "{\"uuid\":\"$validUuid\"}"
    val rawPrefixedJson = "EVT1:{\"uuid\":\"$validUuid\"}"

    assertTrue("Raw JSON must be rejected", QrPayloadParser.parse(rawJson) !is QrPayloadParseResult.Valid)
    assertTrue("Prefixed JSON must yield InvalidFormat", QrPayloadParser.parse(rawPrefixedJson) is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test14_urlPayloadRejected() {
    val rawUrl = "https://evento.app/checkin/$validUuid"
    val rawPrefixedUrl = "EVT1:https://evento.app/checkin/$validUuid"

    assertTrue("Raw URL must be rejected", QrPayloadParser.parse(rawUrl) !is QrPayloadParseResult.Valid)
    assertTrue("Prefixed URL must yield InvalidFormat", QrPayloadParser.parse(rawPrefixedUrl) is QrPayloadParseResult.InvalidFormat)
  }

  @Test
  fun test15_payloadContainingGuestNameOrPiiRejected() {
    val rawWithName = "EVT1:Alice Smith"
    val rawWithEmail = "EVT1:alice@example.com"
    val rawPiiWithUuid = "EVT1:$validUuid Alice Smith"

    assertTrue("Guest name payload must be rejected", QrPayloadParser.parse(rawWithName) !is QrPayloadParseResult.Valid)
    assertTrue("Email payload must be rejected", QrPayloadParser.parse(rawWithEmail) !is QrPayloadParseResult.Valid)
    assertTrue("PII appended to UUID must be rejected", QrPayloadParser.parse(rawPiiWithUuid) !is QrPayloadParseResult.Valid)
  }

  @Test
  fun test16_randomTextRejected() {
    val raw = "Hello World"
    val result = QrPayloadParser.parse(raw)
    assertTrue("Random text must yield InvalidPrefix", result is QrPayloadParseResult.InvalidPrefix)
  }

  @Test
  fun test17_evt1ShortNumberRejected() {
    val raw = "EVT1:123"
    val result = QrPayloadParser.parse(raw)
    assertTrue("EVT1:123 must yield InvalidUuid", result is QrPayloadParseResult.InvalidUuid)
  }

  @Test
  fun test18_evt1UuidWithTrailingColonAndExtraRejected() {
    val raw = "EVT1:$validUuid:extra"
    val result = QrPayloadParser.parse(raw)
    assertTrue("EVT1:<uuid>:extra must be rejected as InvalidFormat", result is QrPayloadParseResult.InvalidFormat)
  }
}
