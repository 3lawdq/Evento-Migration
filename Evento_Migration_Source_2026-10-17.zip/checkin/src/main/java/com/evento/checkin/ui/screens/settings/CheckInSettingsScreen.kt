package com.evento.checkin.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.evento.checkin.R
import com.evento.checkin.ui.components.CheckInTopAppBar

@Composable
fun CheckInSettingsScreen(
  modifier: Modifier = Modifier,
  viewModel: CheckInSettingsViewModel = viewModel(
    factory = CheckInSettingsViewModel.provideFactory(LocalContext.current),
  ),
  onNavigateBack: () -> Unit,
) {
  val activeEvent by viewModel.activeEvent.collectAsStateWithLifecycle()
  val operationMessage by viewModel.message.collectAsStateWithLifecycle()
  val scrollState = rememberScrollState()
  val snackbarHostState = remember { SnackbarHostState() }

  var showClearConfirmDialog by remember { mutableStateOf(false) }
  var showClearAttendanceDialog by remember { mutableStateOf(false) }

  val successClearText = stringResource(R.string.checkin_settings_clear_success)
  val successClearAttendanceText = stringResource(R.string.checkin_settings_clear_attendance_success)
  LaunchedEffect(operationMessage) {
    if (operationMessage == "CLEARED") {
      snackbarHostState.showSnackbar(successClearText)
      viewModel.dismissMessage()
    } else if (operationMessage == "ATTENDANCE_CLEARED") {
      snackbarHostState.showSnackbar(successClearAttendanceText)
      viewModel.dismissMessage()
    }
  }

  Scaffold(
    topBar = {
      CheckInTopAppBar(
        title = stringResource(R.string.checkin_settings_title),
        onNavigateBack = onNavigateBack,
      )
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    modifier = modifier.testTag("checkin_settings_screen"),
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .verticalScroll(scrollState)
        .padding(paddingValues)
        .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // 1. Clear Active Event Action (Operational Reset)
      ClearEventActionCard(
        hasActiveEvent = activeEvent != null,
        eventName = activeEvent?.name,
        onClick = { showClearConfirmDialog = true },
      )

      // 2. Clear Attendance Records Only (Event and guests preserved)
      ClearAttendanceActionCard(
        hasActiveEvent = activeEvent != null,
        eventName = activeEvent?.name,
        onClick = { showClearAttendanceDialog = true },
      )

      // 3. Language & Region Settings
      SettingsInfoCard(
        title = stringResource(R.string.checkin_settings_lang_label),
        value = stringResource(R.string.checkin_settings_lang_value),
        icon = Icons.Default.Language,
        testTag = "settings_language_item",
      )

      // 3. Terminal Mode Status
      SettingsInfoCard(
        title = stringResource(R.string.checkin_settings_terminal_label),
        value = stringResource(R.string.checkin_settings_terminal_value),
        icon = Icons.Default.Lock,
        testTag = "settings_terminal_item",
      )

      // 4. App Version
      SettingsInfoCard(
        title = stringResource(R.string.app_version),
        value = stringResource(R.string.checkin_app_version),
        icon = Icons.Default.PhoneAndroid,
        testTag = "settings_version_item",
      )

      // 5. About Evento Check-In
      SettingsInfoCard(
        title = stringResource(R.string.checkin_settings_about_label),
        value = stringResource(R.string.checkin_settings_about_desc),
        icon = Icons.Default.Info,
        testTag = "settings_about_item",
      )

      Spacer(modifier = Modifier.height(16.dp))
    }
  }

  // Safe Confirmation Dialog for Clearing Active Event
  if (showClearConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showClearConfirmDialog = false },
      icon = {
        Icon(
          imageVector = Icons.Default.Warning,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.error,
          modifier = Modifier.size(32.dp),
        )
      },
      title = {
        Text(
          text = stringResource(R.string.checkin_settings_clear_dialog_title),
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
      },
      text = {
        Text(
          text = stringResource(R.string.checkin_settings_clear_dialog_message),
          style = MaterialTheme.typography.bodyMedium,
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            showClearConfirmDialog = false
            viewModel.clearImportedEvent()
          },
          colors = ButtonDefaults.textButtonColors(
            contentColor = MaterialTheme.colorScheme.error,
          ),
          modifier = Modifier.testTag("clear_event_confirm_button"),
        ) {
          Text(
            text = stringResource(R.string.checkin_settings_clear_confirm),
            fontWeight = FontWeight.Bold,
          )
        }
      },
      dismissButton = {
        TextButton(
          onClick = { showClearConfirmDialog = false },
          modifier = Modifier.testTag("clear_event_cancel_button"),
        ) {
          Text(text = stringResource(R.string.checkin_settings_clear_cancel))
        }
      },
      modifier = Modifier.testTag("clear_event_confirm_dialog"),
    )
  }

  // Safe Confirmation Dialog for Clearing Attendance Records Only
  if (showClearAttendanceDialog) {
    AlertDialog(
      onDismissRequest = { showClearAttendanceDialog = false },
      icon = {
        Icon(
          imageVector = Icons.Default.Warning,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.error,
          modifier = Modifier.size(32.dp),
        )
      },
      title = {
        Text(
          text = stringResource(R.string.checkin_settings_clear_attendance_dialog_title),
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
      },
      text = {
        Text(
          text = stringResource(R.string.checkin_settings_clear_attendance_dialog_message),
          style = MaterialTheme.typography.bodyMedium,
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            showClearAttendanceDialog = false
            viewModel.clearAttendanceRecords()
          },
          colors = ButtonDefaults.textButtonColors(
            contentColor = MaterialTheme.colorScheme.error,
          ),
          modifier = Modifier.testTag("clear_attendance_confirm_button"),
        ) {
          Text(
            text = stringResource(R.string.checkin_settings_clear_attendance_confirm),
            fontWeight = FontWeight.Bold,
          )
        }
      },
      dismissButton = {
        TextButton(
          onClick = { showClearAttendanceDialog = false },
          modifier = Modifier.testTag("clear_attendance_cancel_button"),
        ) {
          Text(text = stringResource(R.string.checkin_settings_clear_cancel))
        }
      },
      modifier = Modifier.testTag("clear_attendance_confirm_dialog"),
    )
  }
}

@Composable
private fun ClearAttendanceActionCard(
  hasActiveEvent: Boolean,
  eventName: String?,
  onClick: () -> Unit,
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (hasActiveEvent) {
        MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f)
      } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
      },
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("settings_clear_attendance_card")
      .clickable(enabled = hasActiveEvent, onClick = onClick),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(
            if (hasActiveEvent) {
              MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)
            } else {
              MaterialTheme.colorScheme.surfaceVariant
            }
          ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.DeleteForever,
          contentDescription = null,
          tint = if (hasActiveEvent) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.size(24.dp),
        )
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = stringResource(R.string.checkin_settings_clear_attendance_title),
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = if (hasActiveEvent) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
        )
        Text(
          text = stringResource(R.string.checkin_settings_clear_attendance_desc),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (hasActiveEvent) 0.8f else 0.5f),
        )
      }
    }
  }
}

@Composable
private fun ClearEventActionCard(
  hasActiveEvent: Boolean,
  eventName: String?,
  onClick: () -> Unit,
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (hasActiveEvent) {
        MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)
      } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
      },
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("settings_clear_event_card")
      .clickable(enabled = hasActiveEvent, onClick = onClick),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(
            if (hasActiveEvent) {
              MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
            } else {
              MaterialTheme.colorScheme.surfaceVariant
            }
          ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.DeleteForever,
          contentDescription = null,
          tint = if (hasActiveEvent) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.size(24.dp),
        )
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = stringResource(R.string.checkin_settings_clear_event_title),
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = if (hasActiveEvent) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
        )
        Text(
          text = if (hasActiveEvent && eventName != null) {
            eventName
          } else {
            stringResource(R.string.checkin_settings_clear_event_desc)
          },
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      if (hasActiveEvent) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.error,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}

@Composable
private fun SettingsInfoCard(
  title: String,
  value: String,
  icon: ImageVector,
  testTag: String,
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag(testTag),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(24.dp),
      )
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = value,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}
