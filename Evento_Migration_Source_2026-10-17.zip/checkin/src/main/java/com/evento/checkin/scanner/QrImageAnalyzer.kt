package com.evento.checkin.scanner

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy

/**
 * CameraX ImageAnalysis.Analyzer that delegates QR decoding to [QrCodeDecoder].
 *
 * Guarantees that [ImageProxy] is closed on every single code path
 * (success, multiple QR, empty, decode failure, or unhandled exception).
 */
class QrImageAnalyzer(
  private val decoder: QrCodeDecoder,
  private val isScanningActive: () -> Boolean = { true },
  private val onQrDecoded: (String) -> Unit,
  private val onMultipleQrDetected: () -> Unit = {},
  private val onDecodeError: (Throwable?) -> Unit = {},
) : ImageAnalysis.Analyzer {

  override fun analyze(imageProxy: ImageProxy) {
    try {
      if (!isScanningActive()) {
        return
      }

      when (val result = decoder.decode(imageProxy)) {
        is QrDecodeResult.Success -> {
          onQrDecoded(result.qrText)
        }
        is QrDecodeResult.MultipleQrDetected -> {
          onMultipleQrDetected()
        }
        is QrDecodeResult.None -> {
          // No QR code detected in this frame
        }
        is QrDecodeResult.Failure -> {
          onDecodeError(result.throwable)
        }
      }
    } catch (t: Throwable) {
      onDecodeError(t)
    } finally {
      imageProxy.close()
    }
  }
}
