package com.evento.checkin.scanner

/**
 * Result of offline QR decoding on a single image frame.
 */
sealed interface QrDecodeResult {
  /**
   * Exactly one valid QR code was detected in the frame.
   */
  data class Success(val qrText: String) : QrDecodeResult

  /**
   * Multiple QR codes were detected in the same frame.
   * Check-in is intentionally aborted to prevent ambiguity.
   */
  data object MultipleQrDetected : QrDecodeResult

  /**
   * No QR code was found in the frame.
   */
  data object None : QrDecodeResult

  /**
   * Hardware, parsing, or decoder runtime failure.
   */
  data class Failure(val throwable: Throwable?) : QrDecodeResult
}
