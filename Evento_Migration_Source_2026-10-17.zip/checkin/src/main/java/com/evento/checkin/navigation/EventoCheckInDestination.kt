package com.evento.checkin.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.evento.checkin.R

/**
 * Strongly typed navigation destinations for the Evento Check-In application.
 *
 * Distinct from Evento Admin destinations to ensure strict separation of concerns.
 */
sealed class EventoCheckInDestination(
  val route: String,
  @StringRes val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
) {
  data object Home : EventoCheckInDestination(
    route = "home",
    labelRes = R.string.checkin_nav_home,
    selectedIcon = Icons.Filled.Home,
    unselectedIcon = Icons.Outlined.Home,
  )

  data object EventPackageImport : EventoCheckInDestination(
    route = "event_package_import",
    labelRes = R.string.checkin_nav_package,
    selectedIcon = Icons.Filled.FileDownload,
    unselectedIcon = Icons.Outlined.FileDownload,
  )

  data object CheckIn : EventoCheckInDestination(
    route = "check_in",
    labelRes = R.string.checkin_nav_scan,
    selectedIcon = Icons.Filled.QrCodeScanner,
    unselectedIcon = Icons.Outlined.QrCodeScanner,
  )

  data object QrScanner : EventoCheckInDestination(
    route = "qr_scanner",
    labelRes = R.string.checkin_nav_scanner,
    selectedIcon = Icons.Filled.QrCodeScanner,
    unselectedIcon = Icons.Outlined.QrCodeScanner,
  )

  data object Statistics : EventoCheckInDestination(
    route = "statistics",
    labelRes = R.string.checkin_nav_statistics,
    selectedIcon = Icons.Filled.BarChart,
    unselectedIcon = Icons.Outlined.BarChart,
  )

  data object Settings : EventoCheckInDestination(
    route = "settings",
    labelRes = R.string.checkin_nav_settings,
    selectedIcon = Icons.Filled.Settings,
    unselectedIcon = Icons.Outlined.Settings,
  )

  data object AttendanceRecords : EventoCheckInDestination(
    route = "attendance_records",
    labelRes = R.string.checkin_nav_attendance_records,
    selectedIcon = Icons.Filled.Assignment,
    unselectedIcon = Icons.Outlined.Assignment,
  )

  companion object {
    val allDestinations: List<EventoCheckInDestination>
      get() = listOf(
        Home,
        EventPackageImport,
        CheckIn,
        Statistics,
        Settings,
      )

    fun fromRoute(route: String?): EventoCheckInDestination {
      return when (route) {
        QrScanner.route -> QrScanner
        AttendanceRecords.route -> AttendanceRecords
        else -> allDestinations.firstOrNull { it.route == route } ?: Home
      }
    }
  }
}
