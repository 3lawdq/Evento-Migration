package com.evento.checkin.ui.screens.settings

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.model.ImportedEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CheckInSettingsViewModel(
  private val repository: CheckInRepository,
) : ViewModel() {

  constructor(
    application: Application,
    repository: CheckInRepository = CheckInRepository(
      CheckInDatabase.getInstance(application).checkInDao()
    ),
  ) : this(repository)

  val activeEvent: StateFlow<ImportedEvent?> = repository.getActiveEventFlow()
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = null,
    )

  private val _message = MutableStateFlow<String?>(null)
  val message: StateFlow<String?> = _message.asStateFlow()

  fun clearImportedEvent(onCompleted: () -> Unit = {}) {
    viewModelScope.launch {
      repository.clearActivePackage()
      _message.value = "CLEARED"
      onCompleted()
    }
  }

  /**
   * Safely clears attendance records for the currently active event only.
   * Preserves imported event and guests intact.
   */
  fun clearAttendanceRecords(onCompleted: () -> Unit = {}) {
    val event = activeEvent.value ?: return
    viewModelScope.launch {
      repository.deleteAttendanceForEvent(event.eventId)
      _message.value = "ATTENDANCE_CLEARED"
      onCompleted()
    }
  }

  fun dismissMessage() {
    _message.value = null
  }

  companion object {
    fun provideFactory(
      repository: CheckInRepository,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return CheckInSettingsViewModel(repository) as T
      }
    }

    fun provideFactory(
      context: Context,
    ): ViewModelProvider.Factory = provideFactory(
      CheckInRepository(CheckInDatabase.getInstance(context.applicationContext).checkInDao())
    )
  }
}
