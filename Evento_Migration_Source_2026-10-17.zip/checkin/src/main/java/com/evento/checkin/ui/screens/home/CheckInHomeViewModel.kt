package com.evento.checkin.ui.screens.home

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.RecentCheckInItem
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

data class CheckInHomeUiState(
  val currentEvent: ImportedEvent? = null,
  val totalGuests: Int = 0,
  val checkedInCount: Int = 0,
  val remainingGuests: Int = 0,
  val attendancePercentage: Double = 0.0,
  val recentCheckIns: List<RecentCheckInItem> = emptyList(),
  val isLoading: Boolean = false,
  val importError: String? = null,
) {
  val hasActiveEvent: Boolean
    get() = currentEvent != null

  val formattedPercentage: String
    get() = String.format(java.util.Locale.US, "%.1f%%", attendancePercentage)
}

@OptIn(ExperimentalCoroutinesApi::class)
class CheckInHomeViewModel(
  private val repository: CheckInRepository,
) : ViewModel() {

  /**
   * Compatibility constructor for callers providing [Application].
   */
  constructor(
    application: Application,
    repository: CheckInRepository = CheckInRepository(
      CheckInDatabase.getInstance(application).checkInDao()
    ),
  ) : this(repository)

  val uiState: StateFlow<CheckInHomeUiState> = repository.getActiveEventFlow()
    .flatMapLatest { event ->
      if (event == null) {
        flowOf(
          CheckInHomeUiState(
            currentEvent = null,
            totalGuests = 0,
            checkedInCount = 0,
            remainingGuests = 0,
            attendancePercentage = 0.0,
            recentCheckIns = emptyList(),
            isLoading = false,
          )
        )
      } else {
        combine(
          repository.getGuestCountForEventFlow(event.eventId),
          repository.getAttendanceCountFlow(event.eventId),
          repository.getPendingGuestCountFlow(event.eventId),
          repository.getRecentCheckInsFlow(event.eventId, limit = 10),
        ) { totalGuests, checkedInCount, pendingCount, recentList ->
          val percentage = if (totalGuests > 0) {
            (checkedInCount.toDouble() / totalGuests.toDouble()) * 100.0
          } else {
            0.0
          }
          CheckInHomeUiState(
            currentEvent = event,
            totalGuests = totalGuests,
            checkedInCount = checkedInCount,
            remainingGuests = pendingCount,
            attendancePercentage = percentage,
            recentCheckIns = recentList,
            isLoading = false,
          )
        }
      }
    }
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = CheckInHomeUiState(isLoading = true),
    )

  companion object {
    fun provideFactory(
      repository: CheckInRepository,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return CheckInHomeViewModel(repository) as T
      }
    }

    fun provideFactory(
      context: Context,
    ): ViewModelProvider.Factory = provideFactory(
      CheckInRepository(CheckInDatabase.getInstance(context.applicationContext).checkInDao())
    )
  }
}
