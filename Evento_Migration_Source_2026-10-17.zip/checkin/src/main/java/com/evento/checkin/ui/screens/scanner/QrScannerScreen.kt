package com.evento.checkin.ui.screens.scanner

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PersonOff
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.evento.checkin.R
import com.evento.checkin.domain.model.ImportedGuest
import com.evento.checkin.scanner.MlKitQrCodeDecoder
import com.evento.checkin.scanner.QrCodeDecoder
import com.evento.checkin.scanner.QrImageAnalyzer
import com.evento.checkin.ui.components.CheckInTopAppBar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

@Composable
fun QrScannerScreen(
  modifier: Modifier = Modifier,
  viewModel: QrScannerViewModel = viewModel(
    factory = QrScannerViewModel.provideFactory(LocalContext.current),
  ),
  decoder: QrCodeDecoder = remember { MlKitQrCodeDecoder() },
  onNavigateBack: () -> Unit,
  onNavigateToImport: () -> Unit = {},
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  var hasCameraPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.CAMERA,
      ) == PackageManager.PERMISSION_GRANTED
    )
  }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission(),
  ) { isGranted ->
    hasCameraPermission = isGranted
    viewModel.onCameraPermissionResult(isGranted)
  }

  LaunchedEffect(Unit) {
    if (!hasCameraPermission) {
      permissionLauncher.launch(Manifest.permission.CAMERA)
    }
  }

  // Provide subtle haptic feedback on status change
  LaunchedEffect(uiState) {
    when (uiState) {
      is ScannerUiState.Success -> triggerHaptic(context, isSuccess = true)
      is ScannerUiState.AlreadyCheckedIn,
      is ScannerUiState.InvalidQr,
      is ScannerUiState.GuestNotFound,
      is ScannerUiState.MultipleQrDetected -> triggerHaptic(context, isSuccess = false)
      else -> Unit
    }
  }

  Scaffold(
    topBar = {
      CheckInTopAppBar(
        title = stringResource(R.string.checkin_scan_title),
        onNavigateBack = onNavigateBack,
      )
    },
    modifier = modifier.testTag("checkin_scanner_screen"),
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(paddingValues),
    ) {
      when {
        !hasCameraPermission -> {
          CameraPermissionContent(
            onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) },
          )
        }

        uiState is ScannerUiState.NoActiveEvent -> {
          NoActiveEventContent(
            onNavigateToImport = onNavigateToImport,
          )
        }

        else -> {
          // Camera scanner viewfinder and overlay
          CameraScannerContent(
            uiState = uiState,
            decoder = decoder,
            isScanningActive = { viewModel.isScanningActive },
            onQrCodeScanned = { payload -> viewModel.onQrCodeScanned(payload) },
            onMultipleQrDetected = { viewModel.onMultipleQrDetected() },
            onCameraError = { error -> viewModel.onCameraError(error) },
            onResumeScanning = { viewModel.resumeScanning() },
            onNavigateToImport = onNavigateToImport,
          )
        }
      }
    }
  }
}

@Composable
private fun CameraScannerContent(
  uiState: ScannerUiState,
  decoder: QrCodeDecoder,
  isScanningActive: () -> Boolean,
  onQrCodeScanned: (String) -> Unit,
  onMultipleQrDetected: () -> Unit,
  onCameraError: (Throwable?) -> Unit,
  onResumeScanning: () -> Unit,
  onNavigateToImport: () -> Unit,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val analysisExecutor = remember { Executors.newSingleThreadExecutor() }

  DisposableEffect(Unit) {
    onDispose {
      analysisExecutor.shutdown()
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    // Camera Preview Layer
    AndroidView(
      factory = { ctx ->
        val previewView = PreviewView(ctx).apply {
          scaleType = PreviewView.ScaleType.FILL_CENTER
        }

        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
        cameraProviderFuture.addListener({
          try {
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
              it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val imageAnalyzer = ImageAnalysis.Builder()
              .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
              .build()
              .also { analysis ->
                analysis.setAnalyzer(
                  analysisExecutor,
                  QrImageAnalyzer(
                    decoder = decoder,
                    isScanningActive = isScanningActive,
                    onQrDecoded = onQrCodeScanned,
                    onMultipleQrDetected = onMultipleQrDetected,
                    onDecodeError = onCameraError,
                  ),
                )
              }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
              lifecycleOwner,
              cameraSelector,
              preview,
              imageAnalyzer,
            )
          } catch (t: Throwable) {
            onCameraError(t)
          }
        }, ContextCompat.getMainExecutor(ctx))

        previewView
      },
      modifier = Modifier
        .fillMaxSize()
        .testTag("scanner_viewfinder"),
    )

    // Viewfinder Reticle Overlay
    ViewfinderReticleOverlay(
      isProcessing = uiState is ScannerUiState.Processing,
    )

    // Dynamic Status and Feedback Bottom Sheet/Card
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.BottomCenter)
        .padding(16.dp),
    ) {
      ScannerFeedbackCard(
        uiState = uiState,
        onResumeScanning = onResumeScanning,
        onNavigateToImport = onNavigateToImport,
      )
    }
  }
}

@Composable
private fun ViewfinderReticleOverlay(
  isProcessing: Boolean,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 32.dp, vertical = 24.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    // Instruction Banner
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
      shadowElevation = 4.dp,
      modifier = Modifier.padding(bottom = 24.dp),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Default.QrCodeScanner,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(20.dp),
        )
        Text(
          text = stringResource(R.string.checkin_scan_instruction),
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
          color = MaterialTheme.colorScheme.onSurface,
        )
      }
    }

    // High Contrast Frame Reticle
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .aspectRatio(1f)
        .clip(RoundedCornerShape(24.dp))
        .background(Color.Black.copy(alpha = 0.08f))
        .border(
          width = 3.dp,
          color = if (isProcessing) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.85f),
          shape = RoundedCornerShape(24.dp),
        )
        .testTag("scanner_frame_guide"),
      contentAlignment = Alignment.Center,
    ) {
      if (isProcessing) {
        CircularProgressIndicator(
          color = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(48.dp),
        )
      }
    }

    Spacer(modifier = Modifier.height(100.dp))
  }
}

@Composable
private fun ScannerFeedbackCard(
  uiState: ScannerUiState,
  onResumeScanning: () -> Unit,
  onNavigateToImport: () -> Unit,
) {
  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("scanner_result_card"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      when (uiState) {
        is ScannerUiState.Idle,
        is ScannerUiState.Scanning -> {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Icon(
              imageVector = Icons.Default.QrCodeScanner,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(28.dp),
            )
            Column {
              Text(
                text = stringResource(R.string.checkin_scan_title),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = stringResource(R.string.checkin_scan_status_scanning),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }

        is ScannerUiState.Processing -> {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(24.dp),
              strokeWidth = 2.5.dp,
              color = MaterialTheme.colorScheme.primary,
            )
            Text(
              text = stringResource(R.string.checkin_scan_status_processing),
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface,
            )
          }
        }

        is ScannerUiState.Success -> {
          FeedbackStatusRow(
            icon = Icons.Default.CheckCircle,
            iconTint = Color(0xFF2E7D32),
            title = stringResource(R.string.checkin_scan_success_title),
            titleColor = Color(0xFF2E7D32),
          )
          GuestDetailsSection(guest = uiState.guest, timestamp = uiState.checkedInAt)
          Button(
            onClick = onResumeScanning,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("scanner_btn_scan_next"),
            colors = ButtonDefaults.buttonColors(
              containerColor = Color(0xFF2E7D32),
            ),
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(stringResource(R.string.checkin_scan_btn_next))
          }
        }

        is ScannerUiState.AlreadyCheckedIn -> {
          FeedbackStatusRow(
            icon = Icons.Default.Warning,
            iconTint = Color(0xFFE65100),
            title = stringResource(R.string.checkin_scan_already_checked_in_title),
            titleColor = Color(0xFFE65100),
          )
          GuestDetailsSection(guest = uiState.guest, timestamp = uiState.firstCheckedInAt)
          Button(
            onClick = onResumeScanning,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("scanner_btn_scan_next"),
            colors = ButtonDefaults.buttonColors(
              containerColor = Color(0xFFE65100),
            ),
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(stringResource(R.string.checkin_scan_btn_next))
          }
        }

        is ScannerUiState.GuestNotFound -> {
          FeedbackStatusRow(
            icon = Icons.Default.PersonOff,
            iconTint = MaterialTheme.colorScheme.error,
            title = stringResource(R.string.checkin_scan_guest_not_found_title),
            titleColor = MaterialTheme.colorScheme.error,
          )
          Text(
            text = uiState.guestUuid,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
          )
          OutlinedButton(
            onClick = onResumeScanning,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("scanner_btn_scan_next"),
          ) {
            Text(stringResource(R.string.checkin_scan_btn_next))
          }
        }

        is ScannerUiState.InvalidQr -> {
          FeedbackStatusRow(
            icon = Icons.Default.Error,
            iconTint = MaterialTheme.colorScheme.error,
            title = stringResource(R.string.checkin_scan_invalid_qr_title),
            titleColor = MaterialTheme.colorScheme.error,
          )
          Text(
            text = stringResource(R.string.checkin_scan_invalid_qr_desc),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
          )
          OutlinedButton(
            onClick = onResumeScanning,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("scanner_btn_scan_next"),
          ) {
            Text(stringResource(R.string.checkin_scan_btn_next))
          }
        }

        is ScannerUiState.MultipleQrDetected -> {
          FeedbackStatusRow(
            icon = Icons.Default.Warning,
            iconTint = Color(0xFFE65100),
            title = stringResource(R.string.checkin_scan_multiple_qr_error),
            titleColor = Color(0xFFE65100),
          )
          Button(
            onClick = onResumeScanning,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("scanner_btn_scan_next"),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.primary,
            ),
          ) {
            Text(stringResource(R.string.checkin_scan_btn_next))
          }
        }

        is ScannerUiState.NoActiveEvent -> {
          FeedbackStatusRow(
            icon = Icons.Default.EventBusy,
            iconTint = MaterialTheme.colorScheme.error,
            title = stringResource(R.string.checkin_scan_no_active_event_title),
            titleColor = MaterialTheme.colorScheme.error,
          )
          Text(
            text = stringResource(R.string.checkin_scan_no_active_event_desc),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
          )
          Button(
            onClick = onNavigateToImport,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("scanner_btn_import_event"),
          ) {
            Icon(Icons.Default.FileDownload, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(stringResource(R.string.checkin_scan_btn_import_event))
          }
        }

        is ScannerUiState.CameraError -> {
          FeedbackStatusRow(
            icon = Icons.Default.Error,
            iconTint = MaterialTheme.colorScheme.error,
            title = stringResource(R.string.checkin_scan_camera_error),
            titleColor = MaterialTheme.colorScheme.error,
          )
          Button(
            onClick = onResumeScanning,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(stringResource(R.string.checkin_scan_btn_retry_camera))
          }
        }

        is ScannerUiState.CameraPermissionRequired,
        is ScannerUiState.CameraPermissionDenied -> {
          // Handled by top-level state check
        }
      }
    }
  }
}

@Composable
private fun FeedbackStatusRow(
  icon: ImageVector,
  iconTint: Color,
  title: String,
  titleColor: Color,
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = iconTint,
      modifier = Modifier.size(28.dp),
    )
    Text(
      text = title,
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
      color = titleColor,
      textAlign = TextAlign.Center,
    )
  }
}

@Composable
private fun GuestDetailsSection(
  guest: ImportedGuest,
  timestamp: Long,
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Text(
      text = guest.fullName,
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
      color = MaterialTheme.colorScheme.onSurface,
      textAlign = TextAlign.Center,
    )
    if (!guest.organization.isNullOrBlank()) {
      Text(
        text = guest.organization,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
      )
    }
    if (!guest.jobTitle.isNullOrBlank()) {
      Text(
        text = guest.jobTitle,
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.primary,
        textAlign = TextAlign.Center,
      )
    }
    Text(
      text = formatTimestamp(timestamp),
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
      textAlign = TextAlign.Center,
    )
  }
}

@Composable
private fun CameraPermissionContent(
  onRequestPermission: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    Box(
      modifier = Modifier
        .size(80.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.primaryContainer),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = Icons.Default.CameraAlt,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(40.dp),
      )
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = stringResource(R.string.checkin_scan_camera_error),
      style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      color = MaterialTheme.colorScheme.onBackground,
      textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(12.dp))

    Text(
      text = stringResource(R.string.checkin_scan_camera_permission_required),
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(28.dp))

    Button(
      onClick = onRequestPermission,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("scanner_btn_grant_permission"),
    ) {
      Text(stringResource(R.string.checkin_scan_btn_grant_permission))
    }
  }
}

@Composable
private fun NoActiveEventContent(
  onNavigateToImport: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    Box(
      modifier = Modifier
        .size(80.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.errorContainer),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = Icons.Default.EventBusy,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.error,
        modifier = Modifier.size(40.dp),
      )
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = stringResource(R.string.checkin_scan_no_active_event_title),
      style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      color = MaterialTheme.colorScheme.onBackground,
      textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(12.dp))

    Text(
      text = stringResource(R.string.checkin_scan_no_active_event_desc),
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(28.dp))

    Button(
      onClick = onNavigateToImport,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("scanner_btn_import_event"),
    ) {
      Icon(Icons.Default.FileDownload, contentDescription = null)
      Spacer(modifier = Modifier.width(8.dp))
      Text(stringResource(R.string.checkin_scan_btn_import_event))
    }
  }
}

private fun formatTimestamp(timestamp: Long): String {
  val date = Date(timestamp)
  val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
  return sdf.format(date)
}

private fun triggerHaptic(context: Context, isSuccess: Boolean) {
  try {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
      val vibrator = vibratorManager?.defaultVibrator
      if (isSuccess) {
        vibrator?.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 80, 80, 80), -1))
      }
    } else {
      @Suppress("DEPRECATION")
      val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
      if (isSuccess) {
        @Suppress("DEPRECATION")
        vibrator?.vibrate(80)
      } else {
        @Suppress("DEPRECATION")
        vibrator?.vibrate(longArrayOf(0, 80, 80, 80), -1)
      }
    }
  } catch (_: Throwable) {
    // Non-fatal if device lacks vibrator or permission
  }
}
