package com.evento.checkin.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/**
 * Reusable, Material 3-aligned empty state component for Evento Check-In.
 *
 * Supports context-specific icon, title, optional supporting description, optional header row
 * with badge, and optional primary action button with icon and test tag.
 */
@Composable
fun CheckInEmptyState(
  icon: ImageVector,
  title: String,
  modifier: Modifier = Modifier,
  description: String? = null,
  headerLabel: String? = null,
  badgeText: String? = null,
  actionLabel: String? = null,
  actionIcon: ImageVector? = null,
  onActionClick: (() -> Unit)? = null,
  actionTestTag: String? = null,
  actionModifier: Modifier = Modifier,
  cardContainer: Boolean = true,
  shape: Shape = RoundedCornerShape(20.dp),
  containerColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
  contentPadding: PaddingValues = PaddingValues(20.dp),
  testTag: String? = null,
) {
  val rootModifier = if (!testTag.isNullOrBlank()) modifier.testTag(testTag) else modifier

  val content: @Composable () -> Unit = {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(contentPadding),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      if (headerLabel != null || badgeText != null) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (headerLabel != null) {
            Text(
              text = headerLabel,
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          } else {
            Spacer(modifier = Modifier.width(1.dp))
          }

          if (badgeText != null) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant,
            ) {
              Text(
                text = badgeText,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }
        }
      }

      Box(
        modifier = Modifier
          .size(64.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          modifier = Modifier.size(32.dp),
          tint = MaterialTheme.colorScheme.primary,
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
      )

      if (!description.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = description,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center,
        )
      }

      if (actionLabel != null && onActionClick != null) {
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = onActionClick,
          shape = RoundedCornerShape(12.dp),
          modifier = actionModifier
            .heightIn(min = 48.dp)
            .then(if (actionTestTag != null) Modifier.testTag(actionTestTag) else Modifier),
        ) {
          if (actionIcon != null) {
            Icon(
              imageVector = actionIcon,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
          }
          Text(
            text = actionLabel,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
          )
        }
      }
    }
  }

  if (cardContainer) {
    Card(
      modifier = rootModifier.fillMaxWidth(),
      shape = shape,
      colors = CardDefaults.cardColors(
        containerColor = containerColor,
      ),
    ) {
      content()
    }
  } else {
    Box(
      modifier = rootModifier,
      contentAlignment = Alignment.Center,
    ) {
      content()
    }
  }
}
