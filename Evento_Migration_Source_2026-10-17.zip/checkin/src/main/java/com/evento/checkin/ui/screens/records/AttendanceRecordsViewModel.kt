package com.evento.checkin.ui.screens.records

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.export.AttendanceCsvExporter
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.RecentCheckInItem
import java.util.Calendar
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AttendanceFilter {
  ALL,
  TODAY,
}

data class AttendanceRecordsUiState(
  val isLoading: Boolean = false,
  val activeEvent: ImportedEvent? = null,
  val totalGuestsCount: Int = 0,
  val totalCheckedInCount: Int = 0,
  val records: List<RecentCheckInItem> = emptyList(),
  val filteredRecords: List<RecentCheckInItem> = emptyList(),
  val searchQuery: String = "",
  val activeFilter: AttendanceFilter = AttendanceFilter.ALL,
  val selectedRecord: RecentCheckInItem? = null,
  val exportMessage: String? = null,
  val exportSuccess: Boolean? = null,
)

open class AttendanceRecordsViewModel(
  private val repository: CheckInRepository,
) : ViewModel() {

  constructor(
    application: Application,
    repository: CheckInRepository = CheckInRepository(
      CheckInDatabase.getInstance(application).checkInDao()
    ),
  ) : this(repository)

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _activeFilter = MutableStateFlow(AttendanceFilter.ALL)
  val activeFilter: StateFlow<AttendanceFilter> = _activeFilter.asStateFlow()

  private val _selectedRecord = MutableStateFlow<RecentCheckInItem?>(null)
  val selectedRecord: StateFlow<RecentCheckInItem?> = _selectedRecord.asStateFlow()

  private val _exportMessage = MutableStateFlow<String?>(null)
  val exportMessage: StateFlow<String?> = _exportMessage.asStateFlow()

  private val _exportSuccess = MutableStateFlow<Boolean?>(null)
  val exportSuccess: StateFlow<Boolean?> = _exportSuccess.asStateFlow()

  private val activeEventFlow = repository.getActiveEventFlow()

  @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
  val uiState: StateFlow<AttendanceRecordsUiState> = activeEventFlow
    .flatMapLatest { event ->
      if (event == null) {
        flowOf(
          AttendanceRecordsUiState(
            isLoading = false,
            activeEvent = null,
            totalGuestsCount = 0,
            totalCheckedInCount = 0,
            records = emptyList(),
            filteredRecords = emptyList(),
          )
        )
      } else {
        combine(
          repository.getAllAttendanceItemsFlow(event.eventId),
          repository.getGuestCountForEventFlow(event.eventId),
          _searchQuery,
          _activeFilter,
          _selectedRecord,
          _exportMessage,
          _exportSuccess,
        ) { args: Array<Any?> ->
          @Suppress("UNCHECKED_CAST")
          val records = (args[0] as? List<RecentCheckInItem>) ?: emptyList()
          val guestsCount = (args[1] as? Int) ?: 0
          val query = (args[2] as? String) ?: ""
          val filter = (args[3] as? AttendanceFilter) ?: AttendanceFilter.ALL
          val selected = args[4] as? RecentCheckInItem
          val message = args[5] as? String
          val success = args[6] as? Boolean

          val filtered = applyFilterAndSearch(records, query, filter)

          AttendanceRecordsUiState(
            isLoading = false,
            activeEvent = event,
            totalGuestsCount = guestsCount,
            totalCheckedInCount = records.size,
            records = records,
            filteredRecords = filtered,
            searchQuery = query,
            activeFilter = filter,
            selectedRecord = selected,
            exportMessage = message,
            exportSuccess = success,
          )
        }
      }
    }
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = AttendanceRecordsUiState(isLoading = true),
    )

  fun onSearchQueryChanged(query: String) {
    _searchQuery.value = query
  }

  fun onFilterChanged(filter: AttendanceFilter) {
    _activeFilter.value = filter
  }

  fun onSelectRecord(record: RecentCheckInItem?) {
    _selectedRecord.value = record
  }

  fun dismissExportMessage() {
    _exportMessage.value = null
    _exportSuccess.value = null
  }

  fun exportAttendance(uri: Uri, contentResolver: ContentResolver) {
    val currentState = uiState.value
    val event = currentState.activeEvent
    val records = currentState.records

    if (event == null || records.isEmpty()) {
      _exportMessage.value = "EMPTY"
      _exportSuccess.value = false
      return
    }

    viewModelScope.launch {
      try {
        withContext(Dispatchers.IO) {
          contentResolver.openOutputStream(uri)?.use { outputStream ->
            AttendanceCsvExporter.writeCsvToStream(records, outputStream)
          } ?: throw IllegalStateException("Cannot open document output stream")
        }
        _exportMessage.value = "SUCCESS"
        _exportSuccess.value = true
      } catch (e: Exception) {
        _exportMessage.value = e.localizedMessage ?: "ERROR"
        _exportSuccess.value = false
      }
    }
  }

  companion object {
    /**
     * Filters attendance records by calendar date and text search.
     */
    fun applyFilterAndSearch(
      records: List<RecentCheckInItem>,
      query: String,
      filter: AttendanceFilter,
      nowMillis: Long = System.currentTimeMillis(),
    ): List<RecentCheckInItem> {
      return records.filter { record ->
        val matchesFilter = when (filter) {
          AttendanceFilter.ALL -> true
          AttendanceFilter.TODAY -> isSameDay(record.checkedInAt, nowMillis)
        }
        matchesFilter && matchesSearch(record, query)
      }
    }

    fun isSameDay(t1: Long, t2: Long): Boolean {
      val c1 = Calendar.getInstance().apply { timeInMillis = t1 }
      val c2 = Calendar.getInstance().apply { timeInMillis = t2 }
      return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) &&
        c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
    }

    fun matchesSearch(item: RecentCheckInItem, query: String): Boolean {
      if (query.isBlank()) return true
      val normQuery = normalizeText(query)
      val normName = normalizeText(item.fullName)
      val normOrg = normalizeText(item.organization ?: "")
      val normJob = normalizeText(item.jobTitle ?: "")

      return normName.contains(normQuery) ||
        normOrg.contains(normQuery) ||
        normJob.contains(normQuery)
    }

    fun normalizeText(text: String): String {
      return text
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "") // remove Arabic tashkeel
        .replace(Regex("[إأآا]"), "ا")
        .replace('ة', 'ه')
        .replace('ى', 'ي')
        .lowercase(Locale.getDefault())
        .trim()
    }

    fun provideFactory(
      repository: CheckInRepository,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AttendanceRecordsViewModel(repository) as T
      }
    }

    fun provideFactory(
      context: Context,
    ): ViewModelProvider.Factory = provideFactory(
      CheckInRepository(CheckInDatabase.getInstance(context.applicationContext).checkInDao())
    )
  }
}
