package com.evento.checkin

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.evento.checkin.R
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.navigation.EventoCheckInDestination
import com.evento.checkin.ui.components.CheckInTopAppBar
import com.evento.checkin.ui.screens.checkin.CheckInScreen
import com.evento.checkin.ui.screens.home.CheckInHomeScreen
import com.evento.checkin.ui.screens.home.CheckInHomeViewModel
import com.evento.checkin.ui.screens.packageimport.EventPackageImportScreen
import com.evento.checkin.ui.screens.packageimport.PackageImportViewModel
import com.evento.checkin.ui.screens.records.AttendanceRecordsScreen
import com.evento.checkin.ui.screens.records.AttendanceRecordsViewModel
import com.evento.checkin.ui.screens.scanner.QrScannerViewModel
import com.evento.checkin.ui.screens.settings.CheckInSettingsScreen
import com.evento.checkin.ui.screens.settings.CheckInSettingsViewModel
import com.evento.checkin.ui.screens.statistics.StatisticsScreen
import com.evento.checkin.ui.screens.statistics.StatisticsViewModel

@Composable
fun EventoCheckInApp(
  modifier: Modifier = Modifier,
  repository: CheckInRepository? = null,
) {
  val context = LocalContext.current
  val checkInRepository = remember(repository) {
    repository ?: CheckInRepository(
      CheckInDatabase.getInstance(context).checkInDao()
    )
  }

  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route
  val currentDestination = EventoCheckInDestination.fromRoute(currentRoute)

  Scaffold(
    topBar = {
      if (currentDestination == EventoCheckInDestination.Home) {
        CheckInTopAppBar(
          title = stringResource(R.string.checkin_app_name),
        )
      }
    },
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("checkin_bottom_navigation"),
      ) {
        EventoCheckInDestination.allDestinations.forEach { destination ->
          val selected = currentDestination == destination
          NavigationBarItem(
            selected = selected,
            onClick = {
              if (currentRoute != destination.route) {
                navController.navigate(destination.route) {
                  popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                  }
                  launchSingleTop = true
                  restoreState = true
                }
              }
            },
            icon = {
              Icon(
                imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                contentDescription = stringResource(destination.labelRes),
              )
            },
            label = {
              Text(
                text = stringResource(destination.labelRes),
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                ),
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.primary,
              selectedTextColor = MaterialTheme.colorScheme.primary,
              indicatorColor = MaterialTheme.colorScheme.primaryContainer,
              unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
              unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
            ),
            modifier = Modifier.testTag("nav_${destination.route}"),
          )
        }
      }
    },
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = EventoCheckInDestination.Home.route,
      modifier = Modifier.padding(innerPadding),
    ) {
      composable(EventoCheckInDestination.Home.route) {
        CheckInHomeScreen(
          viewModel = viewModel(
            factory = CheckInHomeViewModel.provideFactory(checkInRepository),
          ),
          onNavigateTo = { destination ->
            navController.navigate(destination.route) {
              launchSingleTop = true
            }
          },
        )
      }

      composable(EventoCheckInDestination.EventPackageImport.route) {
        EventPackageImportScreen(
          viewModel = viewModel(
            factory = PackageImportViewModel.provideFactory(checkInRepository),
          ),
          onNavigateBack = { navController.popBackStack() },
          onNavigateHome = {
            navController.navigate(EventoCheckInDestination.Home.route) {
              popUpTo(EventoCheckInDestination.Home.route) { inclusive = true }
              launchSingleTop = true
            }
          },
        )
      }

      composable(EventoCheckInDestination.CheckIn.route) {
        CheckInScreen(
          viewModel = viewModel(
            factory = QrScannerViewModel.provideFactory(checkInRepository),
          ),
          onNavigateBack = { navController.popBackStack() },
          onNavigateToImport = {
            navController.navigate(EventoCheckInDestination.EventPackageImport.route) {
              launchSingleTop = true
            }
          },
        )
      }

      composable(EventoCheckInDestination.QrScanner.route) {
        CheckInScreen(
          viewModel = viewModel(
            factory = QrScannerViewModel.provideFactory(checkInRepository),
          ),
          onNavigateBack = { navController.popBackStack() },
          onNavigateToImport = {
            navController.navigate(EventoCheckInDestination.EventPackageImport.route) {
              launchSingleTop = true
            }
          },
        )
      }

      composable(EventoCheckInDestination.Statistics.route) {
        StatisticsScreen(
          viewModel = viewModel(
            factory = StatisticsViewModel.provideFactory(checkInRepository),
          ),
          onNavigateBack = { navController.popBackStack() },
        )
      }

      composable(EventoCheckInDestination.AttendanceRecords.route) {
        AttendanceRecordsScreen(
          viewModel = viewModel(
            factory = AttendanceRecordsViewModel.provideFactory(checkInRepository),
          ),
          onNavigateBack = { navController.popBackStack() },
        )
      }

      composable(EventoCheckInDestination.Settings.route) {
        CheckInSettingsScreen(
          viewModel = viewModel(
            factory = CheckInSettingsViewModel.provideFactory(checkInRepository),
          ),
          onNavigateBack = { navController.popBackStack() },
        )
      }
    }
  }
}
