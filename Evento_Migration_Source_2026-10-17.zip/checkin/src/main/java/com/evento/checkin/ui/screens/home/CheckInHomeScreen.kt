package com.evento.checkin.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.evento.checkin.R
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.RecentCheckInItem
import com.evento.checkin.navigation.EventoCheckInDestination
import com.evento.checkin.ui.components.CheckInEmptyState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CheckInHomeScreen(
  modifier: Modifier = Modifier,
  viewModel: CheckInHomeViewModel = viewModel(
    factory = CheckInHomeViewModel.provideFactory(LocalContext.current),
  ),
  onNavigateTo: (EventoCheckInDestination) -> Unit,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .verticalScroll(scrollState)
      .padding(horizontal = 20.dp, vertical = 16.dp),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    // 1. Application Branding & Mode Header
    CheckInHeaderSection()

    // 2. Current Event Loaded Status Card (with Live Attendance Summary)
    CurrentEventStatusCard(
      uiState = uiState,
      onScanClick = { onNavigateTo(EventoCheckInDestination.CheckIn) },
      onImportClick = { onNavigateTo(EventoCheckInDestination.EventPackageImport) },
    )

    // 3. Operational Quick Actions List
    Text(
      text = stringResource(R.string.quick_actions_title),
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
      color = MaterialTheme.colorScheme.onBackground,
    )

    // Scan QR Action (Primary operational action if event loaded)
    CheckInActionCard(
      title = stringResource(R.string.checkin_home_action_scan_title),
      description = if (uiState.hasActiveEvent) {
        stringResource(R.string.checkin_home_action_scan_desc)
      } else {
        stringResource(R.string.checkin_home_state_no_event)
      },
      icon = Icons.Default.QrCodeScanner,
      testTag = "checkin_action_scan",
      enabled = uiState.hasActiveEvent,
      onClick = {
        if (uiState.hasActiveEvent) {
          onNavigateTo(EventoCheckInDestination.CheckIn)
        } else {
          onNavigateTo(EventoCheckInDestination.EventPackageImport)
        }
      },
    )

    // Attendance Records Action (Phase 7.5)
    CheckInActionCard(
      title = stringResource(R.string.checkin_home_action_records_title),
      description = stringResource(R.string.checkin_home_action_records_desc),
      icon = Icons.Default.Assignment,
      testTag = "checkin_action_records",
      enabled = true,
      onClick = { onNavigateTo(EventoCheckInDestination.AttendanceRecords) },
    )

    // Statistics Action
    CheckInActionCard(
      title = stringResource(R.string.checkin_home_action_stats_title),
      description = stringResource(R.string.checkin_home_action_stats_desc),
      icon = Icons.Default.BarChart,
      testTag = "checkin_action_stats",
      enabled = true,
      onClick = { onNavigateTo(EventoCheckInDestination.Statistics) },
    )

    // Import Event Package Action
    CheckInActionCard(
      title = if (uiState.hasActiveEvent) {
        stringResource(R.string.checkin_home_btn_reimport_package)
      } else {
        stringResource(R.string.checkin_home_action_import_title)
      },
      description = stringResource(R.string.checkin_home_action_import_desc),
      icon = Icons.Default.FileDownload,
      testTag = "checkin_action_import",
      enabled = true,
      onClick = { onNavigateTo(EventoCheckInDestination.EventPackageImport) },
    )

    // Settings Action
    CheckInActionCard(
      title = stringResource(R.string.checkin_home_action_settings_title),
      description = stringResource(R.string.checkin_home_action_settings_desc),
      icon = Icons.Default.Settings,
      testTag = "checkin_action_settings",
      enabled = true,
      onClick = { onNavigateTo(EventoCheckInDestination.Settings) },
    )

    // 4. Recent Check-In Activity Section (when event is loaded)
    if (uiState.hasActiveEvent) {
      RecentCheckInsCard(
        recentCheckIns = uiState.recentCheckIns,
        onViewAllClick = { onNavigateTo(EventoCheckInDestination.AttendanceRecords) },
      )
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}

@Composable
private fun CheckInHeaderSection() {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.primaryContainer,
    ),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("checkin_header_card"),
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text = stringResource(R.string.checkin_home_title),
          style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onPrimaryContainer,
        )

        // Security / Terminal Mode Badge
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.primary,
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.size(14.dp),
            )
            Text(
              text = stringResource(R.string.checkin_app_badge),
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onPrimary,
            )
          }
        }
      }

      Text(
        text = stringResource(R.string.checkin_home_subtitle),
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
      )
    }
  }
}

@Composable
private fun CurrentEventStatusCard(
  uiState: CheckInHomeUiState,
  onScanClick: () -> Unit,
  onImportClick: () -> Unit,
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("checkin_current_event_card"),
  ) {
    val currentEvent = uiState.currentEvent
    if (currentEvent == null) {
      // State A: No Event Loaded
      CheckInEmptyState(
        icon = Icons.Default.EventBusy,
        title = stringResource(R.string.checkin_home_state_no_event),
        description = stringResource(R.string.checkin_home_ready_import),
        headerLabel = stringResource(R.string.checkin_home_current_event_label),
        badgeText = stringResource(R.string.checkin_home_state_no_event),
        actionLabel = stringResource(R.string.checkin_home_btn_import_package),
        actionIcon = Icons.Default.FileDownload,
        onActionClick = onImportClick,
        actionTestTag = "checkin_empty_import_btn",
        actionModifier = Modifier.fillMaxWidth(),
        cardContainer = false,
      )
    } else {
      // State B: Event Loaded & Ready for Check-In
      Column(
        modifier = Modifier.padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        // Header Row: Label + Security & Ready Badges
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = stringResource(R.string.checkin_home_current_event_label),
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.primary,
          )

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            // Security Badge (Phase 7.6)
            when (currentEvent.verificationStatus) {
              "SIGNED_VERIFIED" -> {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.primaryContainer,
                  modifier = Modifier.testTag("event_security_badge_signed"),
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  ) {
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.size(14.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = stringResource(R.string.checkin_security_signed_verified),
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                  }
                }
              }
              "LEGACY_INTEGRITY_ONLY" -> {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.secondaryContainer,
                  modifier = Modifier.testTag("event_security_badge_legacy"),
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  ) {
                    Icon(
                      imageVector = Icons.Default.Info,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.secondary,
                      modifier = Modifier.size(14.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = stringResource(R.string.checkin_security_legacy_integrity),
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                  }
                }
              }
              else -> {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.errorContainer,
                  modifier = Modifier.testTag("event_security_badge_unverified"),
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  ) {
                    Icon(
                      imageVector = Icons.Default.ErrorOutline,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.error,
                      modifier = Modifier.size(14.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = stringResource(R.string.checkin_security_unverified),
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                  }
                }
              }
            }

            // Ready Status Badge
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.testTag("event_ready_badge"),
            ) {
              Text(
                text = stringResource(R.string.checkin_home_state_event_ready),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }
        }

        // Event Name
        Text(
          text = currentEvent.name,
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier.testTag("current_event_name"),
        )

        // Event Details (Date & Location)
        Column(
          verticalArrangement = Arrangement.spacedBy(6.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          if (currentEvent.date.isNotBlank()) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Default.CalendarToday,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp),
              )
              Text(
                text = currentEvent.date,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.testTag("current_event_date"),
              )
            }
          }

          if (currentEvent.location.isNotBlank()) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Default.Place,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp),
              )
              Text(
                text = currentEvent.location,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.testTag("current_event_location"),
              )
            }
          }
        }

        HorizontalDivider(color = DividerDefaults.color.copy(alpha = 0.5f))

        // Live Attendance Summary Row
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("home_attendance_summary_row"),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          SummaryStatItem(
            label = stringResource(R.string.checkin_stats_total_guests),
            value = uiState.totalGuests.toString(),
            testTag = "summary_total_guests",
          )
          SummaryStatItem(
            label = stringResource(R.string.checkin_stats_checked_in),
            value = uiState.checkedInCount.toString(),
            testTag = "summary_checked_in",
          )
          SummaryStatItem(
            label = stringResource(R.string.checkin_stats_remaining),
            value = uiState.remainingGuests.toString(),
            testTag = "summary_remaining",
          )
          SummaryStatItem(
            label = stringResource(R.string.checkin_stats_rate),
            value = uiState.formattedPercentage,
            testTag = "summary_rate",
          )
        }

        // Primary Action: Scan QR Button
        Button(
          onClick = onScanClick,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("checkin_primary_scan_btn"),
        ) {
          Icon(
            imageVector = Icons.Default.QrCodeScanner,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.checkin_home_btn_scan_qr),
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          )
        }

        // Secondary Action: Re-import / Switch Event Package Button
        OutlinedButton(
          onClick = onImportClick,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("checkin_reimport_button"),
        ) {
          Icon(
            imageVector = Icons.Default.FileDownload,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = stringResource(R.string.checkin_home_reimport_button))
        }
      }
    }
  }
}

@Composable
private fun SummaryStatItem(
  label: String,
  value: String,
  testTag: String,
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier.testTag(testTag),
  ) {
    Text(
      text = value,
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
      color = MaterialTheme.colorScheme.onSurface,
    )
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}

@Composable
private fun CheckInActionCard(
  title: String,
  description: String,
  icon: ImageVector,
  testTag: String,
  enabled: Boolean = true,
  onClick: () -> Unit,
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (enabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (enabled) 1.dp else 0.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag(testTag)
      .clickable(enabled = enabled, onClick = onClick),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(
            if (enabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
          ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(22.dp),
        )
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
        )
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = if (enabled) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        tint = if (enabled) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
        modifier = Modifier.size(18.dp),
      )
    }
  }
}

@Composable
private fun RecentCheckInsCard(
  recentCheckIns: List<RecentCheckInItem>,
  onViewAllClick: (() -> Unit)? = null,
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("checkin_recent_checkins_card"),
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = stringResource(R.string.checkin_home_recent_checkins),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
          )

          if (recentCheckIns.isNotEmpty()) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.secondaryContainer,
            ) {
              Text(
                text = "${recentCheckIns.size}",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
              )
            }
          }
        }

        if (recentCheckIns.isNotEmpty() && onViewAllClick != null) {
          androidx.compose.material3.TextButton(
            onClick = onViewAllClick,
            modifier = Modifier.testTag("view_all_records_button"),
          ) {
            Text(
              text = stringResource(R.string.checkin_home_view_all_records),
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.primary,
            )
          }
        }
      }

      if (recentCheckIns.isEmpty()) {
        Text(
          text = stringResource(R.string.checkin_home_no_recent_checkins),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.testTag("empty_recent_checkins_notice"),
        )
      } else {
        Column(
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          recentCheckIns.forEachIndexed { index, item ->
            RecentCheckInRow(item = item)
            if (index < recentCheckIns.lastIndex) {
              HorizontalDivider(color = DividerDefaults.color.copy(alpha = 0.4f))
            }
          }
        }
      }
    }
  }
}

@Composable
private fun RecentCheckInRow(
  item: RecentCheckInItem,
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(12.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("recent_checkin_item_${item.guestUuid}"),
  ) {
    Box(
      modifier = Modifier
        .size(36.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.primaryContainer),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = Icons.Default.CheckCircle,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(20.dp),
      )
    }

    Column(
      modifier = Modifier.weight(1f),
      verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
      Text(
        text = item.fullName,
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )

      val subtitle = listOfNotNull(item.organization, item.jobTitle)
        .filter { it.isNotBlank() }
        .joinToString(" • ")

      if (subtitle.isNotBlank()) {
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }

    // Localized check-in time formatting (e.g., 09:42:15)
    val timeFormatted = formatCheckInTime(item.checkedInAt)
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Icon(
        imageVector = Icons.Default.Schedule,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(12.dp),
      )
      Text(
        text = timeFormatted,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

private fun formatCheckInTime(epochMillis: Long): String {
  val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
  return sdf.format(Date(epochMillis))
}
