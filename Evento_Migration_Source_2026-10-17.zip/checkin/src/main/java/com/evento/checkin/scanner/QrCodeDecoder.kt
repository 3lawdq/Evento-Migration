package com.evento.checkin.scanner

import androidx.camera.core.ImageProxy

/**
 * Pluggable offline QR code decoder interface.
 *
 * Keeps CameraX frame handling and decoding logic cleanly decoupled
 * and enables deterministic JVM Robolectric testing without hardware.
 */
interface QrCodeDecoder {
  /**
   * Decodes QR code(s) from [imageProxy].
   *
   * Implementations MUST NOT close the [imageProxy]; the caller/analyzer
   * retains ownership of closing the frame buffer in all circumstances.
   */
  fun decode(imageProxy: ImageProxy): QrDecodeResult
}
