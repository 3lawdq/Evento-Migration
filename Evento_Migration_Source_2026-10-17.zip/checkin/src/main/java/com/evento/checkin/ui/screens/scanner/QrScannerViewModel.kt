package com.evento.checkin.ui.screens.scanner

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.qr.QrCheckInResult
import com.evento.checkin.domain.qr.QrCheckInService
import com.evento.checkin.domain.qr.QrPayloadParseResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel orchestrating the offline Camera QR Scanner state machine.
 *
 * Enforces:
 * 1. Offline security invariants (no network, local verification only).
 * 2. In-memory debounce to filter rapid duplicate frames for the same badge.
 * 3. Immediate throughput for different attendee badges.
 * 4. Delegation through [QrCheckInService] -> [CheckInEngine].
 * 5. Strict active event gating before permitting check-in.
 */
class QrScannerViewModel(
  private val qrCheckInService: QrCheckInService,
  private val checkInRepository: CheckInRepository,
  private val timeProvider: () -> Long = { System.currentTimeMillis() },
  private val debounceWindowMs: Long = 2000L,
) : ViewModel() {

  constructor(
    application: Application,
    qrCheckInService: QrCheckInService = QrCheckInService(
      repository = CheckInRepository(
        CheckInDatabase.getInstance(application).checkInDao()
      ),
    ),
    checkInRepository: CheckInRepository = CheckInRepository(
      CheckInDatabase.getInstance(application).checkInDao()
    ),
    timeProvider: () -> Long = { System.currentTimeMillis() },
    debounceWindowMs: Long = 2000L,
  ) : this(
    qrCheckInService = qrCheckInService,
    checkInRepository = checkInRepository,
    timeProvider = timeProvider,
    debounceWindowMs = debounceWindowMs,
  )

  private val _uiState = MutableStateFlow<ScannerUiState>(ScannerUiState.Idle)
  val uiState: StateFlow<ScannerUiState> = _uiState.asStateFlow()

  private var lastScannedPayload: String? = null
  private var lastScannedTimestamp: Long = 0L

  val isScanningActive: Boolean
    get() = _uiState.value is ScannerUiState.Scanning

  init {
    checkActiveEvent()
  }

  /**
   * Validates whether an active event is loaded before enabling the scanner.
   */
  fun checkActiveEvent() {
    viewModelScope.launch {
      val activeEvent = checkInRepository.getActiveEvent()
      if (activeEvent == null) {
        _uiState.value = ScannerUiState.NoActiveEvent
      } else if (_uiState.value is ScannerUiState.Idle || _uiState.value is ScannerUiState.NoActiveEvent) {
        _uiState.value = ScannerUiState.Scanning
      }
    }
  }

  /**
   * Responds to runtime camera permission results.
   */
  fun onCameraPermissionResult(granted: Boolean) {
    if (granted) {
      checkActiveEvent()
    } else {
      _uiState.value = ScannerUiState.CameraPermissionDenied
    }
  }

  /**
   * Handles CameraX hardware or lifecycle binding errors.
   */
  fun onCameraError(throwable: Throwable?) {
    val message = throwable?.localizedMessage ?: "Camera initialization error"
    _uiState.value = ScannerUiState.CameraError(message)
  }

  /**
   * Invoked when multiple QR codes are simultaneously detected in a single camera frame.
   */
  fun onMultipleQrDetected() {
    if (_uiState.value !is ScannerUiState.Scanning) return
    _uiState.value = ScannerUiState.MultipleQrDetected
  }

  /**
   * Processes a raw decoded QR payload string.
   */
  fun onQrCodeScanned(rawPayload: String) {
    // Only accept incoming scans if currently actively scanning
    if (_uiState.value !is ScannerUiState.Scanning) {
      return
    }

    val now = timeProvider()
    // Duplicate frame debounce check for identical payload
    if (rawPayload == lastScannedPayload && (now - lastScannedTimestamp) < debounceWindowMs) {
      // Rapid identical frame from camera feed - ignore
      return
    }

    lastScannedPayload = rawPayload
    lastScannedTimestamp = now

    _uiState.value = ScannerUiState.Processing

    viewModelScope.launch {
      when (val result = qrCheckInService.checkInWithQr(rawPayload)) {
        is QrCheckInResult.Success -> {
          _uiState.value = ScannerUiState.Success(
            guest = result.guest,
            checkedInAt = result.checkedInAt,
          )
        }
        is QrCheckInResult.AlreadyCheckedIn -> {
          _uiState.value = ScannerUiState.AlreadyCheckedIn(
            guest = result.guest,
            firstCheckedInAt = result.checkedInAt,
          )
        }
        is QrCheckInResult.GuestNotFound -> {
          val extractedUuid = rawPayload.removePrefix("EVT1:")
          _uiState.value = ScannerUiState.GuestNotFound(guestUuid = extractedUuid)
        }
        is QrCheckInResult.InvalidQr -> {
          val reason = when (result.parseError) {
            is QrPayloadParseResult.InvalidPrefix -> "Invalid badge prefix"
            is QrPayloadParseResult.InvalidUuid -> "Invalid attendee identifier"
            is QrPayloadParseResult.InvalidFormat -> "Invalid badge format"
            is QrPayloadParseResult.Valid -> "Invalid QR code"
          }
          _uiState.value = ScannerUiState.InvalidQr(
            rawPayload = rawPayload,
            message = reason,
          )
        }
        is QrCheckInResult.NoActiveEvent -> {
          _uiState.value = ScannerUiState.NoActiveEvent
        }
        is QrCheckInResult.LicenseExpired -> {
          _uiState.value = ScannerUiState.InvalidQr(rawPayload, result.reason)
        }
        is QrCheckInResult.LicenseNotYetValid -> {
          _uiState.value = ScannerUiState.InvalidQr(rawPayload, result.reason)
        }
        is QrCheckInResult.LicenseGuestLimitExceeded -> {
          _uiState.value = ScannerUiState.InvalidQr(rawPayload, result.reason)
        }
        is QrCheckInResult.LicenseDeviceMismatch -> {
          _uiState.value = ScannerUiState.InvalidQr(rawPayload, result.reason)
        }
        is QrCheckInResult.LicenseInvalid -> {
          _uiState.value = ScannerUiState.InvalidQr(rawPayload, result.reason)
        }
        is QrCheckInResult.LicenseMissing -> {
          _uiState.value = ScannerUiState.InvalidQr(rawPayload, result.reason)
        }
      }
    }
  }

  /**
   * Resets the UI state back to [ScannerUiState.Scanning] for the next attendee.
   */
  fun resumeScanning(clearDebounce: Boolean = true) {
    if (clearDebounce) {
      lastScannedPayload = null
      lastScannedTimestamp = 0L
    }
    viewModelScope.launch {
      val activeEvent = checkInRepository.getActiveEvent()
      if (activeEvent == null) {
        _uiState.value = ScannerUiState.NoActiveEvent
      } else {
        _uiState.value = ScannerUiState.Scanning
      }
    }
  }

  companion object {
    fun provideFactory(
      repository: CheckInRepository,
      qrCheckInService: QrCheckInService = QrCheckInService(repository),
      timeProvider: () -> Long = { System.currentTimeMillis() },
      debounceWindowMs: Long = 2000L,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return QrScannerViewModel(
          qrCheckInService = qrCheckInService,
          checkInRepository = repository,
          timeProvider = timeProvider,
          debounceWindowMs = debounceWindowMs,
        ) as T
      }
    }

    fun provideFactory(
      context: Context,
    ): ViewModelProvider.Factory {
      val appContext = context.applicationContext
      val identityManager = com.evento.checkin.security.CheckInDeviceIdentityManager(appContext)
      val repo = CheckInRepository(CheckInDatabase.getInstance(appContext).checkInDao())
      val service = QrCheckInService(
        repository = repo,
        deviceIdentityManager = identityManager,
      )
      return provideFactory(
        repository = repo,
        qrCheckInService = service,
      )
    }
  }
}
