package com.evento.checkin.ui.screens.statistics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.evento.checkin.R
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.RecentCheckInItem
import com.evento.checkin.ui.components.CheckInEmptyState
import com.evento.checkin.ui.components.CheckInTopAppBar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatisticsScreen(
  modifier: Modifier = Modifier,
  viewModel: StatisticsViewModel = viewModel(
    factory = StatisticsViewModel.provideFactory(LocalContext.current),
  ),
  onNavigateBack: () -> Unit,
  onNavigateToScanner: () -> Unit = {},
  onNavigateToImport: () -> Unit = {},
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val scrollState = rememberScrollState()

  Scaffold(
    topBar = {
      CheckInTopAppBar(
        title = stringResource(R.string.checkin_stats_title),
        onNavigateBack = onNavigateBack,
      )
    },
    modifier = modifier.testTag("checkin_statistics_screen"),
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .verticalScroll(scrollState)
        .padding(paddingValues)
        .padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      if (!uiState.hasActiveEvent) {
        // Empty State: No Event Loaded
        CheckInEmptyState(
          icon = Icons.Default.BarChart,
          title = stringResource(R.string.checkin_stats_title),
          description = stringResource(R.string.checkin_stats_empty_no_event),
          actionLabel = stringResource(R.string.checkin_home_btn_import_package),
          actionIcon = Icons.Default.FileDownload,
          onActionClick = onNavigateToImport,
          actionTestTag = "stats_import_button",
          testTag = "stats_no_event_notice",
          modifier = Modifier.fillMaxWidth(),
        )
      } else {
        // Event Loaded: Show Live Statistics
        val event = uiState.currentEvent!!

        // Event Header Summary Card
        EventStatisticsHeaderCard(
          event = event,
          attendanceRate = uiState.formattedPercentage,
        )

        // 4 Core Metric Cards (2x2 Grid)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          StatMetricCard(
            title = stringResource(R.string.checkin_stats_total_guests),
            value = uiState.totalGuests.toString(),
            icon = Icons.Default.People,
            testTag = "stat_total_guests",
            modifier = Modifier.weight(1f),
          )
          StatMetricCard(
            title = stringResource(R.string.checkin_stats_checked_in),
            value = uiState.checkedInCount.toString(),
            icon = Icons.Default.CheckCircle,
            testTag = "stat_checked_in",
            modifier = Modifier.weight(1f),
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          StatMetricCard(
            title = stringResource(R.string.checkin_stats_remaining),
            value = uiState.remainingGuests.toString(),
            icon = Icons.Default.HourglassEmpty,
            testTag = "stat_remaining",
            modifier = Modifier.weight(1f),
          )
          StatMetricCard(
            title = stringResource(R.string.checkin_stats_rate),
            value = uiState.formattedPercentage,
            icon = Icons.Default.Percent,
            testTag = "stat_rate",
            modifier = Modifier.weight(1f),
          )
        }

        // Attendance Progress Bar Card
        AttendanceProgressBarCard(
          checkedInCount = uiState.checkedInCount,
          totalGuests = uiState.totalGuests,
          percentage = uiState.attendancePercentage,
        )

        // Notice states for edge cases
        if (uiState.totalGuests == 0) {
          NoticeCard(
            text = stringResource(R.string.checkin_stats_empty_zero_guests),
            testTag = "stats_zero_guests_notice",
          )
        } else if (uiState.checkedInCount == 0) {
          NoticeCard(
            text = stringResource(R.string.checkin_stats_empty_zero_attendance),
            testTag = "stats_zero_attendance_notice",
          )
        }

        // Quick Scan Action Button
        Button(
          onClick = onNavigateToScanner,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("stats_scan_button"),
        ) {
          Icon(
            imageVector = Icons.Default.QrCodeScanner,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.checkin_home_btn_scan_qr),
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          )
        }

        // Recent Check-In Activity List
        RecentCheckInsSection(recentCheckIns = uiState.recentCheckIns)
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun EventStatisticsHeaderCard(
  event: ImportedEvent,
  attendanceRate: String,
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.primaryContainer,
    ),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("stats_event_header_card"),
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text = event.name,
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier
            .weight(1f)
            .testTag("current_event_name"),
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.primary,
        ) {
          Text(
            text = attendanceRate,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
          )
        }
      }

      if (event.date.isNotBlank()) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = Icons.Default.CalendarToday,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = event.date,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
          )
        }
      }

      if (event.location.isNotBlank()) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = Icons.Default.Place,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = event.location,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
          )
        }
      }
    }
  }
}

@Composable
private fun AttendanceProgressBarCard(
  checkedInCount: Int,
  totalGuests: Int,
  percentage: Double,
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("stats_progress_card"),
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.checkin_stats_rate),
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = "$checkedInCount / $totalGuests",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.primary,
        )
      }

      val progressFraction = if (totalGuests > 0) {
        (percentage / 100.0).toFloat().coerceIn(0f, 1f)
      } else {
        0f
      }

      LinearProgressIndicator(
        progress = { progressFraction },
        modifier = Modifier
          .fillMaxWidth()
          .height(10.dp)
          .clip(RoundedCornerShape(5.dp)),
        color = MaterialTheme.colorScheme.primary,
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
        strokeCap = StrokeCap.Round,
      )
    }
  }
}

@Composable
private fun StatMetricCard(
  title: String,
  value: String,
  icon: ImageVector,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = modifier.testTag(testTag),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(18.dp),
        )
      }

      Text(
        text = value,
        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
      )
    }
  }
}

@Composable
private fun NoticeCard(
  text: String,
  testTag: String,
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
    ),
    modifier = Modifier
      .fillMaxWidth()
      .testTag(testTag),
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(
        imageVector = Icons.Default.Info,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(20.dp),
      )
      Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun RecentCheckInsSection(
  recentCheckIns: List<RecentCheckInItem>,
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("stats_recent_checkins"),
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text = stringResource(R.string.checkin_home_recent_checkins),
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )

        if (recentCheckIns.isNotEmpty()) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.secondaryContainer,
          ) {
            Text(
              text = "${recentCheckIns.size}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSecondaryContainer,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            )
          }
        }
      }

      if (recentCheckIns.isEmpty()) {
        Text(
          text = stringResource(R.string.checkin_home_no_recent_checkins),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      } else {
        Column(
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          recentCheckIns.forEachIndexed { index, item ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("stats_checkin_item_${item.guestUuid}"),
            ) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(20.dp),
                )
              }

              Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
              ) {
                Text(
                  text = item.fullName,
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )

                val subtitle = listOfNotNull(item.organization, item.jobTitle)
                  .filter { it.isNotBlank() }
                  .joinToString(" • ")

                if (subtitle.isNotBlank()) {
                  Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              }

              val timeFormatted = formatCheckInTime(item.checkedInAt)
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                Icon(
                  imageVector = Icons.Default.Schedule,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(12.dp),
                )
                Text(
                  text = timeFormatted,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }

            if (index < recentCheckIns.lastIndex) {
              HorizontalDivider(color = DividerDefaults.color.copy(alpha = 0.4f))
            }
          }
        }
      }
    }
  }
}

private fun formatCheckInTime(epochMillis: Long): String {
  val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
  return sdf.format(Date(epochMillis))
}
