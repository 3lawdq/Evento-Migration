package com.evento.checkin.ui.screens.scanner

import com.evento.checkin.domain.model.ImportedGuest

/**
 * UI State representation for the Check-In QR Scanner.
 */
sealed interface ScannerUiState {
  /**
   * Initial idle state before camera initialization.
   */
  data object Idle : ScannerUiState

  /**
   * Terminal is actively analyzing camera frames for QR codes.
   */
  data object Scanning : ScannerUiState

  /**
   * A QR code was captured and is currently undergoing offline validation and engine check-in.
   */
  data object Processing : ScannerUiState

  /**
   * Attendee successfully checked in.
   */
  data class Success(
    val guest: ImportedGuest,
    val checkedInAt: Long,
  ) : ScannerUiState

  /**
   * Attendee was already recorded as checked in previously.
   */
  data class AlreadyCheckedIn(
    val guest: ImportedGuest,
    val firstCheckedInAt: Long,
  ) : ScannerUiState

  /**
   * QR payload format was valid EVT1:<uuid>, but the UUID was not found in the active event roster.
   */
  data class GuestNotFound(
    val guestUuid: String,
  ) : ScannerUiState

  /**
   * Scanned text was malformed, had an invalid prefix, bad UUID, or was not an Evento badge.
   */
  data class InvalidQr(
    val rawPayload: String,
    val message: String,
  ) : ScannerUiState

  /**
   * Multiple QR codes were detected in the same camera frame simultaneously.
   */
  data object MultipleQrDetected : ScannerUiState

  /**
   * No active .evento package is loaded into the terminal.
   */
  data object NoActiveEvent : ScannerUiState

  /**
   * Camera permission has not yet been requested or granted.
   */
  data object CameraPermissionRequired : ScannerUiState

  /**
   * Camera permission was explicitly denied by the user.
   */
  data object CameraPermissionDenied : ScannerUiState

  /**
   * Hardware, CameraX lifecycle, or sensor initialization failure.
   */
  data class CameraError(
    val message: String,
  ) : ScannerUiState
}
