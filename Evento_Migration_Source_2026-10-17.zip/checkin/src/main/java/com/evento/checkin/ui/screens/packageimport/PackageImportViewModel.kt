package com.evento.checkin.ui.screens.packageimport

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.evento.checkin.R
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.PackageSecurityError
import com.evento.checkin.domain.model.PackageSecurityStatus
import com.evento.checkin.util.packageutil.EventoPackageImporter
import com.evento.checkin.util.packageutil.EventoPackageVerifier
import com.evento.checkin.util.packageutil.ImportStep
import com.evento.checkin.util.packageutil.PackageImportResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface PackageImportUiState {
  data object Idle : PackageImportUiState
  data class Reading(@StringRes val messageRes: Int = R.string.checkin_import_reading_step) : PackageImportUiState
  data class Verifying(@StringRes val messageRes: Int = R.string.checkin_import_verifying_step) : PackageImportUiState
  data class Saving(@StringRes val messageRes: Int = R.string.checkin_import_saving_step) : PackageImportUiState
  data class Success(
    val event: ImportedEvent,
    val guestCount: Int,
    val securityStatus: PackageSecurityStatus = PackageSecurityStatus.SIGNED_VERIFIED,
    val keyId: String? = null,
  ) : PackageImportUiState
  data class Error(
    @StringRes val userMessageRes: Int,
    val technicalDetails: String,
    val errorCategory: PackageSecurityError? = null,
  ) : PackageImportUiState
}

class PackageImportViewModel(
  private val repository: CheckInRepository,
  private val importer: EventoPackageImporter = EventoPackageImporter(repository),
  private val localDeviceIdProvider: (() -> String?)? = null,
) : ViewModel() {

  constructor(
    application: Application,
    repository: CheckInRepository = CheckInRepository(
      CheckInDatabase.getInstance(application).checkInDao()
    ),
    importer: EventoPackageImporter = EventoPackageImporter(repository),
  ) : this(
    repository = repository,
    importer = importer,
    localDeviceIdProvider = {
      com.evento.checkin.security.CheckInDeviceIdentityManager(application).getOrCreateDeviceId()
    },
  )

  private val _uiState = MutableStateFlow<PackageImportUiState>(PackageImportUiState.Idle)
  val uiState: StateFlow<PackageImportUiState> = _uiState.asStateFlow()

  fun importPackage(uri: Uri, contentResolver: ContentResolver) {
    viewModelScope.launch {
      val result = importer.importFromUri(
        uri = uri,
        contentResolver = contentResolver,
        localDeviceId = localDeviceIdProvider?.invoke(),
        onStepChange = { step ->
          _uiState.value = when (step) {
            ImportStep.READING -> PackageImportUiState.Reading()
            ImportStep.VERIFYING -> PackageImportUiState.Verifying()
            ImportStep.SAVING -> PackageImportUiState.Saving()
          }
        },
      )

      _uiState.value = when (result) {
        is PackageImportResult.Success -> {
          PackageImportUiState.Success(
            event = result.event,
            guestCount = result.guestCount,
            securityStatus = result.securityStatus,
            keyId = result.keyId,
          )
        }
        is PackageImportResult.Error -> {
          PackageImportUiState.Error(
            userMessageRes = result.userMessageRes,
            technicalDetails = result.technicalDetails,
            errorCategory = result.errorCategory,
          )
        }
      }
    }
  }

  fun resetState() {
    _uiState.value = PackageImportUiState.Idle
  }

  companion object {
    fun provideFactory(
      repository: CheckInRepository,
      importer: EventoPackageImporter = EventoPackageImporter(repository),
      localDeviceIdProvider: (() -> String?)? = null,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return PackageImportViewModel(repository, importer, localDeviceIdProvider) as T
      }
    }

    fun provideFactory(
      context: Context,
    ): ViewModelProvider.Factory {
      val appContext = context.applicationContext
      val devIdManager = com.evento.checkin.security.CheckInDeviceIdentityManager(appContext)
      val verifier = EventoPackageVerifier(deviceIdentityManager = devIdManager)
      val importer = EventoPackageImporter(
        repository = CheckInRepository(CheckInDatabase.getInstance(appContext).checkInDao()),
        verifier = verifier,
      )
      return provideFactory(
        repository = CheckInRepository(CheckInDatabase.getInstance(appContext).checkInDao()),
        importer = importer,
        localDeviceIdProvider = { devIdManager.getOrCreateDeviceId() },
      )
    }
  }
}
