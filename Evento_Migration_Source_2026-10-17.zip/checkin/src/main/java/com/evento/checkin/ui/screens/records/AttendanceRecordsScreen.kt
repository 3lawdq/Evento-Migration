package com.evento.checkin.ui.screens.records

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.outlined.AssignmentLate
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.evento.checkin.domain.export.AttendanceCsvExporter
import com.evento.checkin.domain.model.RecentCheckInItem
import com.evento.checkin.ui.components.CheckInEmptyState
import com.evento.checkin.ui.components.CheckInTopAppBar
import com.evento.checkin.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceRecordsScreen(
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier,
  viewModel: AttendanceRecordsViewModel = viewModel(
    factory = AttendanceRecordsViewModel.provideFactory(LocalContext.current),
  ),
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val snackbarHostState = remember { SnackbarHostState() }

  val exportLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("text/csv"),
  ) { uri ->
    if (uri != null) {
      viewModel.exportAttendance(uri, context.contentResolver)
    }
  }

  val exportSuccessMsg = stringResource(R.string.checkin_records_export_success)
  val exportErrorMsg = stringResource(R.string.checkin_records_export_error)
  val exportNoDataMsg = stringResource(R.string.checkin_records_export_no_data)

  LaunchedEffect(uiState.exportMessage) {
    val message = uiState.exportMessage ?: return@LaunchedEffect
    when (message) {
      "SUCCESS" -> snackbarHostState.showSnackbar(exportSuccessMsg)
      "EMPTY" -> snackbarHostState.showSnackbar(exportNoDataMsg)
      else -> snackbarHostState.showSnackbar(exportErrorMsg)
    }
    viewModel.dismissExportMessage()
  }

  Scaffold(
    topBar = {
      CheckInTopAppBar(
        title = stringResource(R.string.checkin_records_title),
        onNavigateBack = onNavigateBack,
        actions = {
          IconButton(
            onClick = {
              val event = uiState.activeEvent
              if (event == null || uiState.records.isEmpty()) {
                Toast.makeText(context, exportNoDataMsg, Toast.LENGTH_SHORT).show()
              } else {
                val fileName = AttendanceCsvExporter.generateFileName(event.name)
                exportLauncher.launch(fileName)
              }
            },
            enabled = uiState.activeEvent != null && uiState.records.isNotEmpty(),
            modifier = Modifier.testTag("records_export_button"),
          ) {
            Icon(
              imageVector = Icons.Default.FileDownload,
              contentDescription = stringResource(R.string.checkin_records_action_export),
              tint = if (uiState.activeEvent != null && uiState.records.isNotEmpty()) {
                MaterialTheme.colorScheme.primary
              } else {
                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.38f)
              },
            )
          }
        },
      )
    },
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    modifier = modifier.fillMaxSize(),
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues),
    ) {
      if (uiState.isLoading) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center,
        ) {
          CircularProgressIndicator()
        }
      } else if (uiState.activeEvent == null) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
          contentAlignment = Alignment.Center,
        ) {
          CheckInEmptyState(
            icon = Icons.Outlined.AssignmentLate,
            title = stringResource(R.string.checkin_records_empty_no_event),
            testTag = "records_no_event_notice",
          )
        }
      } else {
        // Event Header & Count
        Card(
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("records_header_card"),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = uiState.activeEvent?.name ?: "",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = stringResource(
                  R.string.checkin_records_count_badge,
                  uiState.totalCheckedInCount,
                  uiState.totalGuestsCount,
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("records_count_badge"),
              )
            }
          }
        }

        // Search Field
        OutlinedTextField(
          value = uiState.searchQuery,
          onValueChange = { viewModel.onSearchQueryChanged(it) },
          placeholder = {
            Text(
              text = stringResource(R.string.checkin_records_search_hint),
              style = MaterialTheme.typography.bodyMedium,
            )
          },
          leadingIcon = {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          },
          trailingIcon = {
            if (uiState.searchQuery.isNotEmpty()) {
              IconButton(
                onClick = { viewModel.onSearchQueryChanged("") },
                modifier = Modifier.testTag("records_search_clear_button"),
              ) {
                Icon(
                  imageVector = Icons.Default.Clear,
                  contentDescription = stringResource(R.string.checkin_records_clear_search),
                )
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag("records_search_field"),
        )

        // Filter Chips Row
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          FilterChip(
            selected = uiState.activeFilter == AttendanceFilter.ALL,
            onClick = { viewModel.onFilterChanged(AttendanceFilter.ALL) },
            label = { Text(stringResource(R.string.checkin_records_filter_all)) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
              selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
            ),
            modifier = Modifier.testTag("filter_all"),
          )

          FilterChip(
            selected = uiState.activeFilter == AttendanceFilter.TODAY,
            onClick = { viewModel.onFilterChanged(AttendanceFilter.TODAY) },
            label = { Text(stringResource(R.string.checkin_records_filter_today)) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
              selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
            ),
            modifier = Modifier.testTag("filter_today"),
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Records List or Empty State
        if (uiState.records.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(16.dp),
            contentAlignment = Alignment.Center,
          ) {
            CheckInEmptyState(
              icon = Icons.Outlined.AssignmentLate,
              title = stringResource(R.string.checkin_records_empty_no_records),
              testTag = "empty_records_notice",
            )
          }
        } else if (uiState.filteredRecords.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(16.dp),
            contentAlignment = Alignment.Center,
          ) {
            CheckInEmptyState(
              icon = Icons.Outlined.SearchOff,
              title = stringResource(R.string.checkin_records_empty_search),
              testTag = "empty_search_notice",
            )
          }
        } else {
          LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
              .fillMaxSize()
              .testTag("records_list"),
          ) {
            items(
              items = uiState.filteredRecords,
              key = { it.guestUuid },
            ) { record ->
              AttendanceRecordRow(
                record = record,
                onClick = { viewModel.onSelectRecord(record) },
              )
            }
          }
        }
      }
    }
  }

  // Attendance Detail Dialog
  val selectedRecord = uiState.selectedRecord
  if (selectedRecord != null) {
    AttendanceDetailDialog(
      record = selectedRecord,
      onDismiss = { viewModel.onSelectRecord(null) },
    )
  }
}

@Composable
private fun AttendanceRecordRow(
  record: RecentCheckInItem,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }
  val formattedTime = remember(record.checkedInAt) { dateFormat.format(Date(record.checkedInAt)) }

  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("attendance_item_${record.guestUuid}"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = record.fullName,
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(start = 8.dp),
        ) {
          Icon(
            imageVector = Icons.Default.AccessTime,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(14.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = formattedTime,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
          )
        }
      }

      val secondaryInfo = buildString {
        if (!record.organization.isNullOrBlank()) {
          append(record.organization)
        }
        if (!record.jobTitle.isNullOrBlank()) {
          if (isNotEmpty()) append(" • ")
          append(record.jobTitle)
        }
      }

      if (secondaryInfo.isNotBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = secondaryInfo,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
private fun AttendanceDetailDialog(
  record: RecentCheckInItem,
  onDismiss: () -> Unit,
) {
  val dateOnlyFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
  val timeOnlyFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
  val checkInDate = remember(record.checkedInAt) { dateOnlyFormat.format(Date(record.checkedInAt)) }
  val checkInTime = remember(record.checkedInAt) { timeOnlyFormat.format(Date(record.checkedInAt)) }
  val unspecified = stringResource(R.string.checkin_records_unspecified)

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = stringResource(R.string.checkin_records_detail_title),
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        DetailItemRow(
          icon = Icons.Default.Person,
          label = stringResource(R.string.checkin_records_detail_name),
          value = record.fullName,
          testTag = "detail_name",
        )

        DetailItemRow(
          icon = Icons.Default.Business,
          label = stringResource(R.string.checkin_records_detail_org),
          value = record.organization?.ifBlank { null } ?: unspecified,
          testTag = "detail_organization",
        )

        DetailItemRow(
          icon = Icons.Default.Work,
          label = stringResource(R.string.checkin_records_detail_job),
          value = record.jobTitle?.ifBlank { null } ?: unspecified,
          testTag = "detail_job_title",
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

        DetailItemRow(
          icon = Icons.Default.CalendarToday,
          label = stringResource(R.string.checkin_records_detail_date),
          value = checkInDate,
          testTag = "detail_date",
        )

        DetailItemRow(
          icon = Icons.Default.AccessTime,
          label = stringResource(R.string.checkin_records_detail_time),
          value = checkInTime,
          testTag = "detail_time",
        )
      }
    },
    confirmButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("detail_close_button"),
      ) {
        Text(stringResource(R.string.checkin_records_detail_close))
      }
    },
    modifier = Modifier.testTag("attendance_detail_dialog"),
  )
}

@Composable
private fun DetailItemRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  value: String,
  testTag: String,
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier.size(20.dp),
    )
    Spacer(modifier = Modifier.width(12.dp))
    Column {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.testTag(testTag),
      )
    }
  }
}
