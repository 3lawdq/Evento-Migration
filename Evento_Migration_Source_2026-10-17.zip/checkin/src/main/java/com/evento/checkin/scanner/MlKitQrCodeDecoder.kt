package com.evento.checkin.scanner

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

/**
 * On-device, 100% offline QR code decoder using ML Kit Barcode Scanning.
 *
 * Configured strictly for [Barcode.FORMAT_QR_CODE].
 * Operates entirely on-device with zero network, cloud, or remote dependencies.
 */
class MlKitQrCodeDecoder(
  options: BarcodeScannerOptions = BarcodeScannerOptions.Builder()
    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
    .build(),
) : QrCodeDecoder {

  private val scanner = BarcodeScanning.getClient(options)

  @OptIn(ExperimentalGetImage::class)
  override fun decode(imageProxy: ImageProxy): QrDecodeResult {
    val mediaImage = imageProxy.image ?: return QrDecodeResult.None
    val rotationDegrees = imageProxy.imageInfo.rotationDegrees

    return try {
      val inputImage = InputImage.fromMediaImage(mediaImage, rotationDegrees)
      val barcodes = Tasks.await(scanner.process(inputImage))

      when {
        barcodes.isNullOrEmpty() -> QrDecodeResult.None
        barcodes.size == 1 -> {
          val rawValue = barcodes[0].rawValue ?: barcodes[0].displayValue
          if (!rawValue.isNullOrBlank()) {
            QrDecodeResult.Success(rawValue)
          } else {
            QrDecodeResult.None
          }
        }
        else -> QrDecodeResult.MultipleQrDetected
      }
    } catch (t: Throwable) {
      QrDecodeResult.Failure(t)
    }
  }
}
