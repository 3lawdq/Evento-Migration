package com.evento.checkin.ui.theme

import androidx.compose.ui.graphics.Color

// Evento Signature Commercial Palette (Royal Blue #1D4ED8 & Restrained Copper #C56A4A)
val EventoPrimaryLight = Color(0xFF1D4ED8) // Royal Blue
val EventoOnPrimaryLight = Color(0xFFFFFFFF)
val EventoPrimaryContainerLight = Color(0xFFEFF6FF) // Crisp Light Blue Tint
val EventoOnPrimaryContainerLight = Color(0xFF1E40AF)

val EventoSecondaryLight = Color(0xFFC56A4A) // Restrained Copper Accent (used sparingly)
val EventoOnSecondaryLight = Color(0xFFFFFFFF)
val EventoSecondaryContainerLight = Color(0xFFFCEEE8) // Soft copper tint
val EventoOnSecondaryContainerLight = Color(0xFF7C2D12)

val EventoTertiaryLight = Color(0xFFC56A4A) // Copper Accent
val EventoOnTertiaryLight = Color(0xFFFFFFFF)
val EventoTertiaryContainerLight = Color(0xFFFCEEE8)
val EventoOnTertiaryContainerLight = Color(0xFF7C2D12)

val EventoBackgroundLight = Color(0xFFF8FAFC) // Light Background
val EventoOnBackgroundLight = Color(0xFF172033) // Light Primary Text (WCAG AAA)
val EventoSurfaceLight = Color(0xFFFFFFFF) // Light Surface
val EventoOnSurfaceLight = Color(0xFF172033) // Light Primary Text
val EventoSurfaceVariantLight = Color(0xFFF1F5F9) // Clean slate tint
val EventoOnSurfaceVariantLight = Color(0xFF64748B) // Light Secondary Text
val EventoOutlineLight = Color(0xFFE2E8F0) // Light Outline
val EventoOutlineVariantLight = Color(0xFFE2E8F0) // Light Outline Variant

// Dark Theme Palette: Deep #0B1220 Background & #111C2E Surface, WCAG AAA compliant
val EventoPrimaryDark = Color(0xFF8AB4FF) // Proposed Dark Primary
val EventoOnPrimaryDark = Color(0xFF0B1220)
val EventoPrimaryContainerDark = Color(0xFF1E3A8A)
val EventoOnPrimaryContainerDark = Color(0xFFDBEAFE)

val EventoSecondaryDark = Color(0xFFE7B89B) // Proposed Dark Copper Accent (used sparingly)
val EventoOnSecondaryDark = Color(0xFF0B1220)
val EventoSecondaryContainerDark = Color(0xFF5C2818)
val EventoOnSecondaryContainerDark = Color(0xFFFCEEE8)

val EventoTertiaryDark = Color(0xFFE7B89B)
val EventoOnTertiaryDark = Color(0xFF0B1220)
val EventoTertiaryContainerDark = Color(0xFF5C2818)
val EventoOnTertiaryContainerDark = Color(0xFFFCEEE8)

val EventoBackgroundDark = Color(0xFF0B1220) // Deep Dark Background
val EventoOnBackgroundDark = Color(0xFFF1F5F9) // Dark Primary Text (WCAG AAA)
val EventoSurfaceDark = Color(0xFF111C2E) // Deep Dark Surface
val EventoOnSurfaceDark = Color(0xFFF1F5F9) // Dark Primary Text
val EventoSurfaceVariantDark = Color(0xFF1E293B)
val EventoOnSurfaceVariantDark = Color(0xFFA8B3C7) // Dark Secondary Text
val EventoOutlineDark = Color(0xFF28364A) // Dark Outline
val EventoOutlineVariantDark = Color(0xFF28364A) // Dark Outline Variant

// Semantic status colors
val EventoSuccess = Color(0xFF16A34A)
val EventoWarning = Color(0xFFD97706)
val EventoError = Color(0xFFDC2626)

// Legacy aliases mapped to Signature palette for complete backward compatibility
val Emerald80 = EventoPrimaryDark
val EmeraldGrey80 = EventoOutlineVariantDark
val Mint80 = EventoSecondaryDark
val Emerald40 = EventoPrimaryLight
val EmeraldDark = EventoOnPrimaryContainerLight
val EmeraldDeep = EventoOnPrimaryDark
val Mint40 = EventoSecondaryLight

// High-contrast Neutrals & Surfaces mapped to Signature
val Slate900 = EventoBackgroundDark
val Slate800 = EventoSurfaceDark
val Slate700 = EventoSurfaceVariantDark
val Slate600 = EventoOutlineDark
val Slate100 = EventoSurfaceVariantLight
val Slate50 = EventoBackgroundLight

// Terminal Status Colors
val StatusReady = Color(0xFF16A34A)
val StatusWarning = Color(0xFFD97706)
val StatusInfo = Color(0xFF1D4ED8)
val StatusOffline = Color(0xFF64748B)
