package com.evento.checkin.ui.screens.checkin

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.evento.checkin.ui.screens.scanner.QrScannerScreen
import com.evento.checkin.ui.screens.scanner.QrScannerViewModel

@Composable
fun CheckInScreen(
  modifier: Modifier = Modifier,
  viewModel: QrScannerViewModel = viewModel(
    factory = QrScannerViewModel.provideFactory(LocalContext.current),
  ),
  onNavigateBack: () -> Unit,
  onNavigateToImport: () -> Unit = {},
) {
  QrScannerScreen(
    modifier = modifier,
    viewModel = viewModel,
    onNavigateBack = onNavigateBack,
    onNavigateToImport = onNavigateToImport,
  )
}


