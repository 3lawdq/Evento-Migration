package com.evento.checkin.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = EventoPrimaryDark,
    onPrimary = EventoOnPrimaryDark,
    primaryContainer = EventoPrimaryContainerDark,
    onPrimaryContainer = EventoOnPrimaryContainerDark,
    secondary = EventoSecondaryDark,
    onSecondary = EventoOnSecondaryDark,
    secondaryContainer = EventoSecondaryContainerDark,
    onSecondaryContainer = EventoOnSecondaryContainerDark,
    tertiary = EventoTertiaryDark,
    onTertiary = EventoOnTertiaryDark,
    tertiaryContainer = EventoTertiaryContainerDark,
    onTertiaryContainer = EventoOnTertiaryContainerDark,
    background = EventoBackgroundDark,
    onBackground = EventoOnBackgroundDark,
    surface = EventoSurfaceDark,
    onSurface = EventoOnSurfaceDark,
    surfaceVariant = EventoSurfaceVariantDark,
    onSurfaceVariant = EventoOnSurfaceVariantDark,
    outline = EventoOutlineDark,
    outlineVariant = EventoOutlineVariantDark,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = EventoPrimaryLight,
    onPrimary = EventoOnPrimaryLight,
    primaryContainer = EventoPrimaryContainerLight,
    onPrimaryContainer = EventoOnPrimaryContainerLight,
    secondary = EventoSecondaryLight,
    onSecondary = EventoOnSecondaryLight,
    secondaryContainer = EventoSecondaryContainerLight,
    onSecondaryContainer = EventoOnSecondaryContainerLight,
    tertiary = EventoTertiaryLight,
    onTertiary = EventoOnTertiaryLight,
    tertiaryContainer = EventoTertiaryContainerLight,
    onTertiaryContainer = EventoOnTertiaryContainerLight,
    background = EventoBackgroundLight,
    onBackground = EventoOnBackgroundLight,
    surface = EventoSurfaceLight,
    onSurface = EventoOnSurfaceLight,
    surfaceVariant = EventoSurfaceVariantLight,
    onSurfaceVariant = EventoOnSurfaceVariantLight,
    outline = EventoOutlineLight,
    outlineVariant = EventoOutlineVariantLight,
  )

@Composable
fun EventoCheckInTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use intentional corporate branding by default
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content,
  )
}

