package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.local.EventDatabase
import com.example.data.local.dao.BadgeDao
import com.example.data.local.dao.EventDao
import com.example.data.local.dao.GuestDao
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import com.example.data.model.DataQualityFilter
import com.example.data.model.EventDataQualitySummary
import com.example.data.model.EventStatus
import com.example.data.model.GuestDataQualityEvaluator
import com.example.data.model.GuestQualityField
import com.example.data.model.GuestSortOption
import com.example.ui.screens.guests.GuestsViewModel
import com.example.ui.screens.guests.GuestsUiState
import com.example.data.model.InvitationStatus
import com.example.data.model.ProductionReadinessEvaluator
import com.example.data.model.ReadinessSeverity
import com.example.data.repository.BadgeTemplateRepository
import com.example.data.repository.BadgeTemplateRepositoryImpl
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepository
import com.example.data.repository.GuestRepositoryImpl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(AndroidJUnit4::class)
@Config(sdk = [36])
class Phase10ComprehensiveTest {

  private val testDispatcher = UnconfinedTestDispatcher()
  private lateinit var context: Context
  private lateinit var database: EventDatabase
  private lateinit var eventDao: EventDao
  private lateinit var guestDao: GuestDao
  private lateinit var badgeDao: BadgeDao
  private lateinit var eventRepository: EventRepository
  private lateinit var guestRepository: GuestRepository
  private lateinit var badgeRepository: BadgeTemplateRepository

  @Before
  fun setUp() = runBlocking {
    Dispatchers.setMain(testDispatcher)
    context = ApplicationProvider.getApplicationContext()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()

    eventDao = database.eventDao()
    guestDao = database.guestDao()
    badgeDao = database.badgeDao()

    eventRepository = EventRepositoryImpl(eventDao, database)
    guestRepository = GuestRepositoryImpl(guestDao, database)
    badgeRepository = BadgeTemplateRepositoryImpl(badgeDao)
  }

  @After
  fun tearDown() {
    database.close()
    Dispatchers.resetMain()
  }

  // ==========================================
  // SECTION A: Event Duplication
  // ==========================================

  @Test
  fun duplicateEvent_createsNewEventWithDistinctIdAndFreshTimestamps(): Unit = runBlocking {
    val sourceId = eventRepository.createEvent(
      name = "Global Summit 2026",
      description = "Annual Tech Summit",
      date = "2026-10-15",
      location = "Convention Center Hall A",
      organizer = "Tech Corp",
      status = EventStatus.ACTIVE,
      guestCapacity = 500,
      autoCreateSlots = false,
    )

    val duplicatedId = eventRepository.duplicateEvent(
      sourceEventId = sourceId,
      newName = "Global Summit 2027",
      copyGuests = false,
    )

    assertNotEquals(sourceId, duplicatedId)
    assertTrue(duplicatedId > 0)

    val sourceEvent = eventRepository.getEventByIdSync(sourceId)
    val duplicatedEvent = eventRepository.getEventByIdSync(duplicatedId)

    assertNotNull(sourceEvent)
    assertNotNull(duplicatedEvent)
    assertEquals("Global Summit 2026", sourceEvent!!.name)
    assertEquals("Global Summit 2027", duplicatedEvent!!.name)
    assertEquals(sourceEvent.description, duplicatedEvent.description)
    assertEquals(sourceEvent.date, duplicatedEvent.date)
    assertEquals(sourceEvent.location, duplicatedEvent.location)
    assertEquals(sourceEvent.organizer, duplicatedEvent.organizer)
    assertEquals(sourceEvent.guestCapacity, duplicatedEvent.guestCapacity)
    assertEquals(EventStatus.ACTIVE, duplicatedEvent.status)
  }

  @Test
  fun duplicateEvent_withoutCopyGuests_doesNotCopyGuests(): Unit = runBlocking {
    val sourceId = eventRepository.createEvent(
      name = "Source Event",
      description = "Desc",
      date = "2026-11-01",
      location = "Room 101",
      organizer = "Organizer",
      guestCapacity = 100,
    )

    // Add 3 guests to source event
    guestRepository.createGuest(sourceId, "Alice Smith", "alice@example.com", "555-111", "Acme", "Lead", InvitationStatus.CONFIRMED)
    guestRepository.createGuest(sourceId, "Bob Jones", "bob@example.com", "555-222", "Acme", "Dev", InvitationStatus.CHECKED_IN)
    guestRepository.createGuest(sourceId, "Charlie Brown", "charlie@example.com", "555-333", "Acme", "Designer", InvitationStatus.CHECKED_IN)

    val sourceGuests = guestRepository.getGuestsForEvent(sourceId).first()
    assertEquals(3, sourceGuests.size)

    val duplicatedId = eventRepository.duplicateEvent(sourceId, "Copied Event (No Guests)", copyGuests = false)

    val duplicatedGuests = guestRepository.getGuestsForEvent(duplicatedId).first()
    assertEquals(0, duplicatedGuests.size)
  }

  @Test
  fun duplicateEvent_withCopyGuests_generatesFreshUuidsAndResetsStatus(): Unit = runBlocking {
    val sourceId = eventRepository.createEvent(
      name = "Source Event With Guests",
      description = "Desc",
      date = "2026-11-01",
      location = "Room 101",
      organizer = "Organizer",
      guestCapacity = 100,
    )

    val originalUuid1 = UUID.randomUUID().toString()
    val originalUuid2 = UUID.randomUUID().toString()

    guestDao.insertGuest(
      GuestEntity(
        id = 0L,
        eventId = sourceId,
        uuid = originalUuid1,
        fullName = "Alice Smith",
        email = "alice@example.com",
        phone = "555-111",
        organization = "Acme",
        jobTitle = "Lead",
        invitationStatus = InvitationStatus.CHECKED_IN, // CHECKED_IN status in source
      )
    )
    guestDao.insertGuest(
      GuestEntity(
        id = 0L,
        eventId = sourceId,
        uuid = originalUuid2,
        fullName = "Bob Jones",
        email = "bob@example.com",
        phone = "555-222",
        organization = "Beta Inc",
        jobTitle = "Dev",
        invitationStatus = InvitationStatus.CONFIRMED,
      )
    )

    val duplicatedId = eventRepository.duplicateEvent(sourceId, "Duplicated Event With Guests", copyGuests = true)

    val copiedGuests = guestRepository.getGuestsForEvent(duplicatedId).first()
    assertEquals(2, copiedGuests.size)

    val copiedGuest1 = copiedGuests.find { it.fullName == "Alice Smith" }
    val copiedGuest2 = copiedGuests.find { it.fullName == "Bob Jones" }

    assertNotNull(copiedGuest1)
    assertNotNull(copiedGuest2)

    // Verify FRESH UUIDs - never reused!
    assertNotEquals(originalUuid1, copiedGuest1!!.uuid)
    assertNotEquals(originalUuid2, copiedGuest2!!.uuid)
    assertTrue(copiedGuest1.uuid.isNotBlank())
    assertTrue(copiedGuest2.uuid.isNotBlank())
    assertNotEquals(copiedGuest1.uuid, copiedGuest2.uuid)

    // Verify invitation status is reset to INVITED (never carry forward CHECKED_IN or CONFIRMED)
    assertEquals(InvitationStatus.INVITED, copiedGuest1.invitationStatus)
    assertEquals(InvitationStatus.INVITED, copiedGuest2.invitationStatus)

    // Verify profile data was copied faithfully
    assertEquals("alice@example.com", copiedGuest1.email)
    assertEquals("555-111", copiedGuest1.phone)
    assertEquals("Acme", copiedGuest1.organization)
    assertEquals("Lead", copiedGuest1.jobTitle)

    // Verify event ID binding
    assertEquals(duplicatedId, copiedGuest1.eventId)
    assertEquals(duplicatedId, copiedGuest2.eventId)
  }

  @Test
  fun duplicateEvent_duplicatesBadgeTemplateAndElements(): Unit = runBlocking {
    val sourceId = eventRepository.createEvent("Event With Badge", "Desc", "2026-11-01", "Loc", "Org")

    // Create a custom template for source
    val sourceTpl = BadgeTemplateEntity(
      eventId = sourceId,
      name = "VIP Template",
      widthMm = 85f,
      heightMm = 55f,
      orientation = BadgeOrientation.LANDSCAPE,
      backgroundColor = "#123456",
      isActive = true,
    )
    val elements = listOf(
      BadgeElementEntity(
        templateId = 0L,
        type = BadgeElementType.ATTENDEE_NAME,
        x = 10f, y = 10f, width = 60f, height = 15f,
      ),
      BadgeElementEntity(
        templateId = 0L,
        type = BadgeElementType.QR,
        x = 10f, y = 30f, width = 20f, height = 20f,
      ),
    )
    badgeDao.saveTemplateWithElements(sourceTpl, elements)

    val duplicatedId = eventRepository.duplicateEvent(sourceId, "Duplicated Badge Event", copyGuests = false)

    val duplicatedTemplates = badgeDao.getTemplatesForEventSync(duplicatedId)
    assertEquals(1, duplicatedTemplates.size)

    val dupTpl = duplicatedTemplates.first()
    assertEquals(duplicatedId, dupTpl.eventId)
    assertEquals("VIP Template", dupTpl.name)
    assertEquals("#123456", dupTpl.backgroundColor)

    val dupElements = badgeDao.getElementsForTemplateSync(dupTpl.id)
    assertEquals(2, dupElements.size)
    assertTrue(dupElements.any { it.type == BadgeElementType.ATTENDEE_NAME })
    assertTrue(dupElements.any { it.type.isQr })
    assertTrue(dupElements.all { it.templateId == dupTpl.id })
  }

  // ==========================================
  // SECTION B: Bulk Guest Operations
  // ==========================================

  @Test
  fun bulkUpdateStatus_updatesOnlySpecifiedGuestsInEvent(): Unit = runBlocking {
    val eventId = eventRepository.createEvent("Event Bulk Status", "Desc", "2026-11-01", "Loc", "Org")

    val id1 = guestRepository.createGuest(eventId, "G1", "g1@test.com", "111", "Org", "Role", InvitationStatus.INVITED)
    val id2 = guestRepository.createGuest(eventId, "G2", "g2@test.com", "222", "Org", "Role", InvitationStatus.INVITED)
    val id3 = guestRepository.createGuest(eventId, "G3", "g3@test.com", "333", "Org", "Role", InvitationStatus.INVITED)

    // Update only id1 and id2 to CONFIRMED
    val affected = guestRepository.bulkUpdateStatus(eventId, listOf(id1, id2), InvitationStatus.CONFIRMED)
    assertEquals(2, affected)

    val g1 = guestDao.getGuestByIdSync(id1)
    val g2 = guestDao.getGuestByIdSync(id2)
    val g3 = guestDao.getGuestByIdSync(id3)

    assertEquals(InvitationStatus.CONFIRMED, g1?.invitationStatus)
    assertEquals(InvitationStatus.CONFIRMED, g2?.invitationStatus)
    assertEquals(InvitationStatus.INVITED, g3?.invitationStatus) // Untouched!
  }

  @Test
  fun bulkUpdateOrganization_updatesMultipleGuestsAndTrims(): Unit = runBlocking {
    val eventId = eventRepository.createEvent("Event Bulk Org", "Desc", "2026-11-01", "Loc", "Org")

    val id1 = guestRepository.createGuest(eventId, "G1", "g1@test.com", "111", "Old Org", "Role")
    val id2 = guestRepository.createGuest(eventId, "G2", "g2@test.com", "222", "Old Org", "Role")
    val id3 = guestRepository.createGuest(eventId, "G3", "g3@test.com", "333", "Other Org", "Role")

    val affected = guestRepository.bulkUpdateOrganization(eventId, listOf(id1, id2), "  New Enterprise Inc.  ")
    assertEquals(2, affected)

    val g1 = guestDao.getGuestByIdSync(id1)
    val g2 = guestDao.getGuestByIdSync(id2)
    val g3 = guestDao.getGuestByIdSync(id3)

    assertEquals("New Enterprise Inc.", g1?.organization)
    assertEquals("New Enterprise Inc.", g2?.organization)
    assertEquals("Other Org", g3?.organization)
  }

  @Test
  fun bulkUpdateJobTitle_updatesMultipleGuestsAndTrims(): Unit = runBlocking {
    val eventId = eventRepository.createEvent("Event Bulk Title", "Desc", "2026-11-01", "Loc", "Org")

    val id1 = guestRepository.createGuest(eventId, "G1", "g1@test.com", "111", "Org", "Junior")
    val id2 = guestRepository.createGuest(eventId, "G2", "g2@test.com", "222", "Org", "Mid")

    val affected = guestRepository.bulkUpdateJobTitle(eventId, listOf(id1, id2), " Senior VP ")
    assertEquals(2, affected)

    val g1 = guestDao.getGuestByIdSync(id1)
    val g2 = guestDao.getGuestByIdSync(id2)

    assertEquals("Senior VP", g1?.jobTitle)
    assertEquals("Senior VP", g2?.jobTitle)
  }

  @Test
  fun bulkDeleteGuests_removesOnlySelectedGuests(): Unit = runBlocking {
    val eventId = eventRepository.createEvent("Event Bulk Delete", "Desc", "2026-11-01", "Loc", "Org")

    val id1 = guestRepository.createGuest(eventId, "G1", "g1@test.com", "111", "Org", "Role")
    val id2 = guestRepository.createGuest(eventId, "G2", "g2@test.com", "222", "Org", "Role")
    val id3 = guestRepository.createGuest(eventId, "G3", "g3@test.com", "333", "Org", "Role")

    val affected = guestRepository.bulkDeleteGuests(eventId, listOf(id1, id3))
    assertEquals(2, affected)

    val remaining = guestRepository.getGuestsForEvent(eventId).first()
    assertEquals(1, remaining.size)
    assertEquals(id2, remaining.first().id)
  }

  @Test
  fun bulkOperations_respectEventScoping(): Unit = runBlocking {
    val event1 = eventRepository.createEvent("Event 1", "Desc", "2026-11-01", "Loc", "Org")
    val event2 = eventRepository.createEvent("Event 2", "Desc", "2026-11-01", "Loc", "Org")

    val g1 = guestRepository.createGuest(event1, "Guest E1", "e1@test.com", "111", "Org1", "Role1", InvitationStatus.INVITED)
    val g2 = guestRepository.createGuest(event2, "Guest E2", "e2@test.com", "222", "Org2", "Role2", InvitationStatus.INVITED)

    // Attempt to update g2 using event1 scope -> must NOT update g2!
    val affected = guestRepository.bulkUpdateStatus(event1, listOf(g2), InvitationStatus.CONFIRMED)
    assertEquals(0, affected)

    val g2Check = guestDao.getGuestByIdSync(g2)
    assertEquals(InvitationStatus.INVITED, g2Check?.invitationStatus)
  }

  @Test
  fun bulkOperations_withEmptyList_safelyReturnsZero(): Unit = runBlocking {
    val eventId = eventRepository.createEvent("Event Empty Bulk", "Desc", "2026-11-01", "Loc", "Org")

    val r1 = guestRepository.bulkUpdateStatus(eventId, emptyList(), InvitationStatus.CONFIRMED)
    val r2 = guestRepository.bulkUpdateOrganization(eventId, emptyList(), "Org")
    val r3 = guestRepository.bulkUpdateJobTitle(eventId, emptyList(), "Title")
    val r4 = guestRepository.bulkDeleteGuests(eventId, emptyList())

    assertEquals(0, r1)
    assertEquals(0, r2)
    assertEquals(0, r3)
    assertEquals(0, r4)
  }

  // ==========================================
  // SECTION C: Data Quality Evaluation
  // ==========================================

  @Test
  fun guestQualityEvaluator_evaluatesCompleteAndIncompleteProfiles(): Unit = runBlocking {
    val completeGuest = GuestEntity(
      id = 0L,
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "John Doe",
      email = "john@example.com",
      phone = "1234567890",
      organization = "Tech Labs",
      jobTitle = "Architect",
    )

    val incompleteGuest = GuestEntity(
      id = 0L,
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Jane Smith",
      email = "", // Missing email
      phone = "", // Missing phone
      organization = "Tech Labs",
      jobTitle = "", // Missing title
    )

    val emptySlot = GuestEntity(
      id = 0L,
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "",
      email = "",
      phone = "",
      organization = "",
      jobTitle = "",
    )

    val evalComplete = GuestDataQualityEvaluator.evaluateGuest(completeGuest)
    val evalIncomplete = GuestDataQualityEvaluator.evaluateGuest(incompleteGuest)
    val evalSlot = GuestDataQualityEvaluator.evaluateGuest(emptySlot)

    assertTrue(evalComplete.isComplete)
    assertFalse(evalComplete.isEmptySlot)
    assertTrue(evalComplete.missingFields.isEmpty())

    assertFalse(evalIncomplete.isComplete)
    assertFalse(evalIncomplete.isEmptySlot)
    assertTrue(evalIncomplete.missingFields.contains(GuestQualityField.EMAIL))
    assertTrue(evalIncomplete.missingFields.contains(GuestQualityField.PHONE))
    assertTrue(evalIncomplete.missingFields.contains(GuestQualityField.JOB_TITLE))

    assertTrue(evalSlot.isEmptySlot)
    assertFalse(evalSlot.isComplete)
    assertTrue(evalSlot.missingFields.contains(GuestQualityField.FULL_NAME))
  }

  @Test
  fun guestQualityEvaluator_summarizesGuestList(): Unit = runBlocking {
    val g1 = GuestEntity(
      id = 0L,
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Complete User",
      email = "user1@test.com",
      phone = "111",
      organization = "Org",
      jobTitle = "Role",
    )
    val g2 = GuestEntity(
      id = 0L,
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Incomplete User",
      email = "",
      phone = "222",
      organization = "Org",
      jobTitle = "Role",
    )
    val g3 = GuestEntity(
      id = 0L,
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "",
      email = "",
      phone = "",
      organization = "",
      jobTitle = "",
    )

    val summary = GuestDataQualityEvaluator.summarize(listOf(g1, g2, g3))

    assertEquals(3, summary.totalRecords)
    assertEquals(1, summary.emptySlotsCount)
    assertEquals(2, summary.registeredGuestsCount)
    assertEquals(1, summary.completeGuestsCount)
    assertEquals(1, summary.incompleteGuestsCount)
    assertEquals(50, summary.completenessPercentage)
  }

  @Test
  fun guestsViewModel_dataQualityFiltering_filtersCorrectSubsets(): Unit = runBlocking {
    val eventId = eventRepository.createEvent("Quality Filter Event", "Desc", "2026-11-01", "Loc", "Org")

    guestRepository.createGuest(eventId, "A Complete", "a@test.com", "111", "Org", "Dev")
    guestRepository.createGuest(eventId, "B NoEmail", "", "222", "Org", "Dev")
    guestRepository.createGuest(eventId, "C NoPhone", "c@test.com", "", "Org", "Dev")
    guestDao.insertGuest(
      GuestEntity(
        id = 0L,
        eventId = eventId,
        uuid = UUID.randomUUID().toString(),
        fullName = "",
        email = "",
        phone = "",
        organization = "",
        jobTitle = "",
      )
    )

    val viewModel = GuestsViewModel(guestRepository, eventRepository)
    viewModel.selectEvent(eventId)

    // ALL
    viewModel.setQualityFilter(DataQualityFilter.ALL)
    val stateAll = viewModel.uiState.first {
      it is GuestsUiState.Success && it.selectedEvent?.id == eventId && it.selectedQualityFilter == DataQualityFilter.ALL
    } as GuestsUiState.Success
    assertEquals(4, stateAll.guests.size)

    // COMPLETE_ONLY
    viewModel.setQualityFilter(DataQualityFilter.COMPLETE_ONLY)
    val stateComplete = viewModel.uiState.first {
      it is GuestsUiState.Success && it.selectedEvent?.id == eventId && it.selectedQualityFilter == DataQualityFilter.COMPLETE_ONLY
    } as GuestsUiState.Success
    assertEquals(1, stateComplete.guests.size)
    assertEquals("A Complete", stateComplete.guests.first().fullName)

    // INCOMPLETE_ONLY
    viewModel.setQualityFilter(DataQualityFilter.INCOMPLETE_ONLY)
    val stateIncomplete = viewModel.uiState.first {
      it is GuestsUiState.Success && it.selectedEvent?.id == eventId && it.selectedQualityFilter == DataQualityFilter.INCOMPLETE_ONLY
    } as GuestsUiState.Success
    assertEquals(2, stateIncomplete.guests.size)

    // EMPTY_SLOTS_ONLY
    viewModel.setQualityFilter(DataQualityFilter.EMPTY_SLOTS_ONLY)
    val stateEmpty = viewModel.uiState.first {
      it is GuestsUiState.Success && it.selectedEvent?.id == eventId && it.selectedQualityFilter == DataQualityFilter.EMPTY_SLOTS_ONLY
    } as GuestsUiState.Success
    assertEquals(1, stateEmpty.guests.size)
    assertTrue(stateEmpty.guests.first().fullName.isBlank())
  }

  @Test
  fun guestsViewModel_guestSorting_sortsCorrectly(): Unit = runBlocking {
    val eventId = eventRepository.createEvent("Sort Event", "Desc", "2026-11-01", "Loc", "Org")

    guestRepository.createGuest(eventId, "Charlie", "c@test.com", "111", "Beta", "Dev")
    guestRepository.createGuest(eventId, "Alice", "a@test.com", "222", "Alpha", "Lead")
    guestRepository.createGuest(eventId, "Bob", "b@test.com", "333", "Gamma", "VP")

    val viewModel = GuestsViewModel(guestRepository, eventRepository)
    viewModel.selectEvent(eventId)

    // NAME_ASC
    viewModel.setSortOption(GuestSortOption.NAME_ASC)
    val stateNameAsc = viewModel.uiState.first {
      it is GuestsUiState.Success && it.selectedEvent?.id == eventId && it.selectedSortOption == GuestSortOption.NAME_ASC
    } as GuestsUiState.Success
    assertEquals("Alice", stateNameAsc.guests[0].fullName)
    assertEquals("Bob", stateNameAsc.guests[1].fullName)
    assertEquals("Charlie", stateNameAsc.guests[2].fullName)

    // NAME_DESC
    viewModel.setSortOption(GuestSortOption.NAME_DESC)
    val stateNameDesc = viewModel.uiState.first {
      it is GuestsUiState.Success && it.selectedEvent?.id == eventId && it.selectedSortOption == GuestSortOption.NAME_DESC
    } as GuestsUiState.Success
    assertEquals("Charlie", stateNameDesc.guests[0].fullName)
    assertEquals("Bob", stateNameDesc.guests[1].fullName)
    assertEquals("Alice", stateNameDesc.guests[2].fullName)

    // ORG_ASC
    viewModel.setSortOption(GuestSortOption.ORG_ASC)
    val stateOrgAsc = viewModel.uiState.first {
      it is GuestsUiState.Success && it.selectedEvent?.id == eventId && it.selectedSortOption == GuestSortOption.ORG_ASC
    } as GuestsUiState.Success
    assertEquals("Alpha", stateOrgAsc.guests[0].organization)
    assertEquals("Beta", stateOrgAsc.guests[1].organization)
    assertEquals("Gamma", stateOrgAsc.guests[2].organization)
  }

  // ==========================================
  // SECTION D: Production Readiness Evaluation
  // ==========================================

  @Test
  fun productionReadiness_evaluatesReadyEventCorrectly(): Unit = runBlocking {
    val event = EventEntity(
      id = 1L,
      name = "Annual Conference",
      description = "Full Description",
      date = "2026-12-01",
      location = "Main Auditorium",
      organizer = "Company",
      status = EventStatus.ACTIVE,
      guestCapacity = 100,
    )

    val guests = listOf(
      GuestEntity(
        id = 0L,
        eventId = 1L,
        uuid = UUID.randomUUID().toString(),
        fullName = "Alice",
        email = "alice@test.com",
        phone = "111",
        organization = "Org",
        jobTitle = "Role",
      ),
      GuestEntity(
        id = 0L,
        eventId = 1L,
        uuid = UUID.randomUUID().toString(),
        fullName = "Bob",
        email = "bob@test.com",
        phone = "222",
        organization = "Org",
        jobTitle = "Role",
      ),
    )

    val template = BadgeTemplateEntity(
      id = 1L,
      eventId = 1L,
      name = "Badge",
      widthMm = 85f,
      heightMm = 55f,
      orientation = BadgeOrientation.LANDSCAPE,
      isActive = true,
    )

    val report = ProductionReadinessEvaluator.evaluate(
      event = event,
      guests = guests,
      activeBadgeTemplate = template,
      pdfFitsOnPage = true,
    )

    assertTrue(report.scorePercentage >= 80)
    assertTrue(report.isProductionReady)
    assertEquals(0, report.criticalCount)
    assertTrue(report.checks.any { it.id == "event_name" && it.severity == ReadinessSeverity.PASSED })
    assertTrue(report.checks.any { it.id == "event_date" && it.severity == ReadinessSeverity.PASSED })
    assertTrue(report.checks.any { it.id == "badge_template" && it.severity == ReadinessSeverity.PASSED })
  }

  @Test
  fun productionReadiness_flagsMissingTemplateAndExceededCapacity(): Unit = runBlocking {
    val event = EventEntity(
      id = 1L,
      name = "Overbooked Event",
      description = "Desc",
      date = "2026-12-01",
      location = "Loc",
      organizer = "Org",
      status = EventStatus.ACTIVE,
      guestCapacity = 1, // Capacity is 1
    )

    val guests = listOf(
      GuestEntity(
        id = 0L,
        eventId = 1L,
        uuid = UUID.randomUUID().toString(),
        fullName = "Alice",
        email = "alice@test.com",
        phone = "111",
        organization = "Org",
        jobTitle = "Role",
      ),
      GuestEntity(
        id = 0L,
        eventId = 1L,
        uuid = UUID.randomUUID().toString(),
        fullName = "Bob",
        email = "bob@test.com",
        phone = "222",
        organization = "Org",
        jobTitle = "Role",
      ), // 2 guests registered > 1
    )

    val report = ProductionReadinessEvaluator.evaluate(
      event = event,
      guests = guests,
      activeBadgeTemplate = null, // Missing template!
      pdfFitsOnPage = true,
    )

    assertFalse(report.isProductionReady)
    assertTrue(report.criticalCount > 0)
    assertTrue(report.checks.any { it.id == "badge_template" && it.severity == ReadinessSeverity.CRITICAL })
    assertTrue(report.checks.any { it.id == "guest_capacity" && it.severity == ReadinessSeverity.WARNING })
  }

  @Test
  fun productionReadiness_handlesNullEventGracefully(): Unit = runBlocking {
    val report = ProductionReadinessEvaluator.evaluate(
      event = null,
      guests = emptyList(),
      activeBadgeTemplate = null,
    )

    assertFalse(report.isProductionReady)
    assertEquals(0, report.scorePercentage)
    assertEquals(0, report.checks.size)
  }
}
