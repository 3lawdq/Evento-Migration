package com.example

import com.example.ui.navigation.EventoDestination
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class EventoDestinationTest {

  @Test
  fun `verify all required destinations exist`() {
    val destinations = EventoDestination.allDestinations
    assertEquals(8, destinations.size)

    val routes = destinations.map { it.route }.toSet()
    assert(routes.contains("dashboard"))
    assert(routes.contains("events"))
    assert(routes.contains("guests"))
    assert(routes.contains("card_designer"))
    assert(routes.contains("pdf_generator"))
    assert(routes.contains("event_package"))
    assert(routes.contains("reports"))
    assert(routes.contains("settings"))
  }

  @Test
  fun `verify route resolution falls back to dashboard`() {
    assertEquals(EventoDestination.Dashboard, EventoDestination.fromRoute(null))
    assertEquals(EventoDestination.Dashboard, EventoDestination.fromRoute("unknown_route"))
    assertEquals(EventoDestination.Events, EventoDestination.fromRoute("events"))
    assertEquals(EventoDestination.Guests, EventoDestination.fromRoute("guests"))
    assertEquals(EventoDestination.EventPackage, EventoDestination.fromRoute("event_package"))
  }
}
