package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.local.EventDatabase
import com.example.data.local.dao.EventDao
import com.example.data.local.entity.EventEntity
import com.example.data.model.EventStatus
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EventRoomPersistenceTest {

  private lateinit var database: EventDatabase
  private lateinit var eventDao: EventDao
  private lateinit var repository: EventRepository

  @Before
  fun createDb() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    eventDao = database.eventDao()
    repository = EventRepositoryImpl(eventDao)
  }

  @After
  fun closeDb() {
    database.close()
  }

  @Test
  fun `insert event and read back via repository`() = runBlocking {
    val id = repository.createEvent(
      name = "Global AI Summit 2026",
      description = "Annual enterprise summit on AI architectures",
      date = "2026-11-20 10:00 AM",
      location = "Riyadh Front Exhibition Center",
      organizer = "Evento Tech Operations",
      status = EventStatus.ACTIVE,
    )

    assertTrue(id > 0)

    val event = repository.getEventByIdSync(id)
    assertNotNull(event)
    assertEquals("Global AI Summit 2026", event?.name)
    assertEquals("Annual enterprise summit on AI architectures", event?.description)
    assertEquals("2026-11-20 10:00 AM", event?.date)
    assertEquals("Riyadh Front Exhibition Center", event?.location)
    assertEquals("Evento Tech Operations", event?.organizer)
    assertEquals(EventStatus.ACTIVE, event?.status)
    assertTrue(event!!.createdAt > 0)
    assertTrue(event.updatedAt >= event.createdAt)

    val allEvents = repository.getAllEvents().first()
    assertEquals(1, allEvents.size)
    assertEquals(id, allEvents.first().id)
  }

  @Test
  fun `update existing event details and verify persistence`() = runBlocking {
    val id = repository.createEvent(
      name = "Draft Meeting",
      description = "Initial notes",
      date = "2026-10-01",
      location = "Room A",
      organizer = "Draft Host",
      status = EventStatus.DRAFT,
    )

    val original = repository.getEventByIdSync(id)!!
    val modified = original.copy(
      name = "Strategic Planning Board",
      description = "Updated high-priority agenda",
      location = "Executive Boardroom",
      status = EventStatus.ACTIVE,
    )

    repository.updateEvent(modified)

    val updated = repository.getEventByIdSync(id)!!
    assertEquals("Strategic Planning Board", updated.name)
    assertEquals("Updated high-priority agenda", updated.description)
    assertEquals("Executive Boardroom", updated.location)
    assertEquals(EventStatus.ACTIVE, updated.status)
    assertTrue(updated.updatedAt >= original.updatedAt)
  }

  @Test
  fun `archive event status updates properly`() = runBlocking {
    val id = repository.createEvent(
      name = "Completed Seminar",
      description = "Closed session",
      date = "2026-08-15",
      location = "Hall B",
      organizer = "Operations",
      status = EventStatus.ACTIVE,
    )

    repository.updateEventStatus(id, EventStatus.ARCHIVED)

    val archived = repository.getEventByIdSync(id)!!
    assertEquals(EventStatus.ARCHIVED, archived.status)

    val archivedList = repository.getEventsByStatus(EventStatus.ARCHIVED).first()
    assertEquals(1, archivedList.size)
    assertEquals(id, archivedList.first().id)

    val activeCount = repository.getActiveEventsCount().first()
    assertEquals(0, activeCount)
  }

  @Test
  fun `delete event removes it from Room database`() = runBlocking {
    val id = repository.createEvent(
      name = "Temporary Test Event",
      description = "To be deleted",
      date = "2026-09-12",
      location = "Virtual",
      organizer = "Admin",
      status = EventStatus.DRAFT,
    )

    assertNotNull(repository.getEventByIdSync(id))
    repository.deleteEvent(id)
    assertNull(repository.getEventByIdSync(id))

    val allEvents = repository.getAllEvents().first()
    assertTrue(allEvents.isEmpty())
  }
}
