package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.importer.ExcelGuestParser
import com.example.data.local.EventDatabase
import com.example.data.local.dao.EventDao
import com.example.data.local.dao.GuestDao
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepository
import com.example.data.repository.GuestRepositoryImpl
import com.example.util.excel.ExcelGuestExporter
import com.example.util.excel.XlsxParser
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.io.FileInputStream
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class ExcelGuestExportTest {

  private lateinit var context: Context
  private lateinit var database: EventDatabase
  private lateinit var eventDao: EventDao
  private lateinit var guestDao: GuestDao
  private lateinit var eventRepository: EventRepository
  private lateinit var guestRepository: GuestRepository

  private var eventAId: Long = 0L
  private var eventBId: Long = 0L

  @Before
  fun setUp() = runBlocking {
    context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()

    eventDao = database.eventDao()
    guestDao = database.guestDao()
    eventRepository = EventRepositoryImpl(eventDao)
    guestRepository = GuestRepositoryImpl(guestDao, database)

    eventAId = eventRepository.createEvent(
      name = "Annual Technology Forum 2026",
      description = "Flagship conference",
      date = "2026-11-20",
      location = "Riyadh Front",
      organizer = "Global Events Authority",
      status = EventStatus.ACTIVE,
    )

    eventBId = eventRepository.createEvent(
      name = "Global Medical Symposium",
      description = "Medical summit",
      date = "2026-12-05",
      location = "Jeddah Dome",
      organizer = "Ministry of Health",
      status = EventStatus.ACTIVE,
    )
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun testExportEmptyGuestList() {
    val file = ExcelGuestExporter.exportGuestsToXlsx(
      context = context,
      eventName = "Empty Event",
      guests = emptyList(),
    )

    assertTrue(file.exists())
    assertTrue(file.length() > 0)

    val rows = XlsxParser.parse(FileInputStream(file))
    assertEquals(1, rows.size) // Only header row
    assertEquals("Name", rows[0][0])
    assertEquals("Organization", rows[0][1])
    assertEquals("Job Title", rows[0][2])
    assertEquals("Email", rows[0][3])
    assertEquals("Phone", rows[0][4])
    assertEquals("Status", rows[0][5])
    assertEquals("UUID", rows[0][6])
    assertEquals("Notes", rows[0][7])

    file.delete()
  }

  @Test
  fun testExportSingleGuestWithAllFields() {
    val guestUuid = UUID.randomUUID().toString()
    val guest = GuestEntity(
      id = 1L,
      eventId = eventAId,
      uuid = guestUuid,
      fullName = "John Doe",
      email = "john.doe@example.com",
      phone = "+14155552671",
      organization = "Acme Corp",
      jobTitle = "Chief Executive Officer",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "VIP front row seating",
      createdAt = 1000L,
    )

    val file = ExcelGuestExporter.exportGuestsToXlsx(
      context = context,
      eventName = "Leadership Summit",
      guests = listOf(guest),
    )

    assertTrue(file.exists())

    val rows = XlsxParser.parse(FileInputStream(file))
    assertEquals(2, rows.size) // Header + 1 guest

    val dataRow = rows[1]
    assertEquals("John Doe", dataRow[0])
    assertEquals("Acme Corp", dataRow[1])
    assertEquals("Chief Executive Officer", dataRow[2])
    assertEquals("john.doe@example.com", dataRow[3])
    assertEquals("+14155552671", dataRow[4])
    assertEquals("CONFIRMED", dataRow[5])
    assertEquals(guestUuid, dataRow[6])
    assertEquals("VIP front row seating", dataRow[7])

    file.delete()
  }

  @Test
  fun testExportArabicAndMixedGuestData() {
    val guest1 = GuestEntity(
      id = 1L,
      eventId = eventAId,
      uuid = "uuid-ar-001",
      fullName = "أحمد محمد المنصور",
      email = "ahmed.almansoor@example.sa",
      phone = "+966501234567",
      organization = "هيئة الحكومة الرقمية",
      jobTitle = "مدير عام الابتكار",
      invitationStatus = InvitationStatus.CHECKED_IN,
      notes = "متحدث رئيسي في الجلسة الافتتاحية",
      createdAt = 1000L,
    )

    val guest2 = GuestEntity(
      id = 2L,
      eventId = eventAId,
      uuid = "uuid-mix-002",
      fullName = "Dr. Sara Al-Ghamdi د. سارة الغامدي",
      email = "sara.g@health.gov.sa",
      phone = "+966559876543",
      organization = "BioTech Lab مختبرات حيوية",
      jobTitle = "Senior Researcher باحث أول",
      invitationStatus = InvitationStatus.INVITED,
      notes = "Requires translation headset & special assistance",
      createdAt = 2000L,
    )

    val file = ExcelGuestExporter.exportGuestsToXlsx(
      context = context,
      eventName = "مؤتمر الذكاء الاصطناعي",
      guests = listOf(guest1, guest2),
    )

    assertTrue(file.exists())

    val rows = XlsxParser.parse(FileInputStream(file))
    assertEquals(3, rows.size)

    assertEquals("أحمد محمد المنصور", rows[1][0])
    assertEquals("هيئة الحكومة الرقمية", rows[1][1])
    assertEquals("مدير عام الابتكار", rows[1][2])
    assertEquals("CHECKED_IN", rows[1][5])

    assertEquals("Dr. Sara Al-Ghamdi د. سارة الغامدي", rows[2][0])
    assertEquals("BioTech Lab مختبرات حيوية", rows[2][1])
    assertEquals("Senior Researcher باحث أول", rows[2][2])
    assertEquals("INVITED", rows[2][5])

    file.delete()
  }

  @Test
  fun testExportXmlSpecialCharactersInFields() {
    val guest = GuestEntity(
      id = 1L,
      eventId = eventAId,
      uuid = "uuid-spec-chars",
      fullName = "John & Jane <VIP> \"The Best\" 'Speakers'",
      email = "john+jane@test.org",
      phone = "+10000000",
      organization = "R&D <Advanced> & \"Innovation\"",
      jobTitle = "Director of 'Strategy' & Growth",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "Line 1\nLine 2 with <tag> & \"quotes\" and 'apostrophe'",
      createdAt = 1000L,
    )

    val file = ExcelGuestExporter.exportGuestsToXlsx(
      context = context,
      eventName = "Special & Characters <Test>",
      guests = listOf(guest),
    )

    assertTrue(file.exists())

    val rows = XlsxParser.parse(FileInputStream(file))
    assertEquals(2, rows.size)

    val dataRow = rows[1]
    assertEquals("John & Jane <VIP> \"The Best\" 'Speakers'", dataRow[0])
    assertEquals("R&D <Advanced> & \"Innovation\"", dataRow[1])
    assertEquals("Director of 'Strategy' & Growth", dataRow[2])
    assertEquals("CONFIRMED", dataRow[5])
    assertTrue(dataRow[7].contains("Line 1"))
    assertTrue(dataRow[7].contains("<tag>"))
    assertTrue(dataRow[7].contains("&"))

    file.delete()
  }

  @Test
  fun testExportEmptyOptionalFieldsProduceEmptyCells() {
    val guest = GuestEntity(
      id = 1L,
      eventId = eventAId,
      uuid = "uuid-minimal-001",
      fullName = "Minimal Guest",
      email = "",
      phone = "",
      organization = "",
      jobTitle = "",
      invitationStatus = InvitationStatus.INVITED,
      notes = "",
      createdAt = 1000L,
    )

    val file = ExcelGuestExporter.exportGuestsToXlsx(
      context = context,
      eventName = "Minimal Roster",
      guests = listOf(guest),
    )

    val rows = XlsxParser.parse(FileInputStream(file))
    val dataRow = rows[1]

    assertEquals("Minimal Guest", dataRow[0])
    assertEquals("", dataRow[1])
    assertEquals("", dataRow[2])
    assertEquals("", dataRow[3])
    assertEquals("", dataRow[4])
    assertFalse(dataRow[1].contains("null", ignoreCase = true))
    assertFalse(dataRow[7].contains("null", ignoreCase = true))

    file.delete()
  }

  @Test
  fun testStrictCrossEventIsolation() {
    runBlocking {
      // Event A has 3 guests
      guestRepository.createGuest(eventId = eventAId, fullName = "Event A Guest 1")
      guestRepository.createGuest(eventId = eventAId, fullName = "Event A Guest 2")
      guestRepository.createGuest(eventId = eventAId, fullName = "Event A Guest 3")

      // Event B has 2 guests
      guestRepository.createGuest(eventId = eventBId, fullName = "Event B Guest 1")
      guestRepository.createGuest(eventId = eventBId, fullName = "Event B Guest 2")

      val eventAGuests = guestRepository.getGuestsForEventSync(eventAId)
      val eventBGuests = guestRepository.getGuestsForEventSync(eventBId)

      assertEquals(3, eventAGuests.size)
      assertEquals(2, eventBGuests.size)

      // Export Event A only
      val fileA = ExcelGuestExporter.exportGuestsToXlsx(
        context = context,
        eventName = "Event A Roster",
        guests = eventAGuests,
      )

      val rowsA = XlsxParser.parse(FileInputStream(fileA))
      assertEquals(4, rowsA.size) // Header + 3 guests

      val exportedNames = rowsA.drop(1).map { it[0] }.toSet()
      assertTrue(exportedNames.contains("Event A Guest 1"))
      assertTrue(exportedNames.contains("Event A Guest 2"))
      assertTrue(exportedNames.contains("Event A Guest 3"))
      assertFalse(exportedNames.contains("Event B Guest 1"))
      assertFalse(exportedNames.contains("Event B Guest 2"))

      // Ensure database was not modified
      assertEquals(3, guestRepository.getGuestsForEventSync(eventAId).size)
      assertEquals(2, guestRepository.getGuestsForEventSync(eventBId).size)

      fileA.delete()
    }
  }

  @Test
  fun testUuidIntegrityDuringExport() {
    val specificUuid = "custom-fixed-uuid-12345-67890"
    val guest = GuestEntity(
      id = 42L,
      eventId = eventAId,
      uuid = specificUuid,
      fullName = "UUID Integrity Test",
      invitationStatus = InvitationStatus.CONFIRMED,
    )

    val file = ExcelGuestExporter.exportGuestsToXlsx(
      context = context,
      eventName = "Integrity Check",
      guests = listOf(guest),
    )

    val rows = XlsxParser.parse(FileInputStream(file))
    val exportedUuid = rows[1][6]

    assertEquals(specificUuid, exportedUuid)
    file.delete()
  }

  @Test
  fun testFilenameSanitizationWithArabicAndInvalidCharacters() {
    val file = ExcelGuestExporter.exportGuestsToXlsx(
      context = context,
      eventName = "مؤتمر/الذكاء*الاصطناعي:2026?|<>",
      guests = emptyList(),
    )

    assertTrue(file.name.startsWith("Evento_"))
    assertTrue(file.name.endsWith(".xlsx"))
    assertFalse(file.name.contains("/"))
    assertFalse(file.name.contains("\\"))
    assertFalse(file.name.contains(":"))
    assertFalse(file.name.contains("*"))
    assertFalse(file.name.contains("?"))
    assertFalse(file.name.contains("<"))
    assertFalse(file.name.contains(">"))
    assertFalse(file.name.contains("|"))
    assertTrue(file.exists())

    file.delete()
  }

  @Test
  fun testLargeGuestRosterExportPerformance() {
    val largeGuestList = (1..1000).map { i ->
      GuestEntity(
        id = i.toLong(),
        eventId = eventAId,
        uuid = UUID.randomUUID().toString(),
        fullName = "Guest Number $i",
        email = "guest$i@largecorp.test",
        phone = "+96650000${i.toString().padStart(4, '0')}",
        organization = "Organization ${(i % 20) + 1}",
        jobTitle = "Role ${(i % 10) + 1}",
        invitationStatus = when (i % 4) {
          0 -> InvitationStatus.INVITED
          1 -> InvitationStatus.CONFIRMED
          2 -> InvitationStatus.CHECKED_IN
          else -> InvitationStatus.DECLINED
        },
        notes = "Auto generated test record #$i",
      )
    }

    val startTime = System.currentTimeMillis()
    val file = ExcelGuestExporter.exportGuestsToXlsx(
      context = context,
      eventName = "High Volume Roster",
      guests = largeGuestList,
    )
    val duration = System.currentTimeMillis() - startTime

    assertTrue("Large roster export took under 5 seconds", duration < 5000)
    assertTrue(file.exists())
    assertTrue(file.length() > 50000) // Expect valid zip size

    val rows = XlsxParser.parse(FileInputStream(file))
    assertEquals(1001, rows.size)

    file.delete()
  }

  @Test
  fun testExportImportRoundTripCompatibility() {
    runBlocking {
      val originalGuests = listOf(
        GuestEntity(
          id = 1L,
          eventId = eventAId,
          uuid = "uuid-roundtrip-1",
          fullName = "Eng. Khalid Al-Fassi",
          email = "khalid@alfassi.com",
          phone = "+966541112233",
          organization = "Energy Innovations",
          jobTitle = "Chief Technology Officer",
          invitationStatus = InvitationStatus.CONFIRMED,
          notes = "VIP Speaker",
        ),
        GuestEntity(
          id = 2L,
          eventId = eventAId,
          uuid = "uuid-roundtrip-2",
          fullName = "Layla Al-Obeid",
          email = "layla@obeid.org",
          phone = "+966567778899",
          organization = "Future Foundation",
          jobTitle = "Program Director",
          invitationStatus = InvitationStatus.DECLINED,
          notes = "Requested conference recordings",
        ),
        GuestEntity(
          id = 3L,
          eventId = eventAId,
          uuid = "uuid-roundtrip-3",
          fullName = "Tariq Hassan",
          email = "tariq@hassan.test",
          phone = "+966598889900",
          organization = "Global Logistics",
          jobTitle = "Supply Chain Lead",
          invitationStatus = InvitationStatus.CHECKED_IN,
          notes = "Attended morning keynote",
        ),
      )

      val file = ExcelGuestExporter.exportGuestsToXlsx(
        context = context,
        eventName = "RoundTrip Test",
        guests = originalGuests,
      )

      // Parse the exported file using the frozen ExcelGuestParser
      val preview = ExcelGuestParser.parse(
        inputStream = FileInputStream(file),
        fileName = file.name,
        existingGuests = emptyList(), // Simulate importing into fresh event
      )

      assertEquals(3, preview.validRows.size)
      assertEquals(0, preview.invalidRows.size)
      assertEquals(0, preview.duplicateRows.size)

      val row1 = preview.validRows[0]
      assertEquals("Eng. Khalid Al-Fassi", row1.fullName)
      assertEquals("Energy Innovations", row1.organization)
      assertEquals("Chief Technology Officer", row1.jobTitle)
      assertEquals("khalid@alfassi.com", row1.email)
      assertEquals("+966541112233", row1.phone)
      assertEquals(InvitationStatus.CONFIRMED, row1.invitationStatus)
      assertEquals("uuid-roundtrip-1", row1.existingUuid)
      assertEquals("VIP Speaker", row1.notes)

      val row2 = preview.validRows[1]
      assertEquals("Layla Al-Obeid", row2.fullName)
      assertEquals(InvitationStatus.DECLINED, row2.invitationStatus)
      assertEquals("uuid-roundtrip-2", row2.existingUuid)

      val row3 = preview.validRows[2]
      assertEquals("Tariq Hassan", row3.fullName)
      assertEquals(InvitationStatus.CHECKED_IN, row3.invitationStatus)
      assertEquals("uuid-roundtrip-3", row3.existingUuid)

      file.delete()
    }
  }
}
