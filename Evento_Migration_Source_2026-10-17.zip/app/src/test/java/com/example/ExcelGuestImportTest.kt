package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.importer.ExcelGuestParser
import com.example.data.local.EventDatabase
import com.example.data.local.dao.EventDao
import com.example.data.local.dao.GuestDao
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepository
import com.example.data.repository.GuestRepositoryImpl
import com.example.util.excel.XlsxParser
import com.example.util.excel.XlsxWriter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayInputStream

@RunWith(AndroidJUnit4::class)
class ExcelGuestImportTest {

  private lateinit var database: EventDatabase
  private lateinit var eventDao: EventDao
  private lateinit var guestDao: GuestDao
  private lateinit var eventRepository: EventRepository
  private lateinit var guestRepository: GuestRepository
  private var eventId: Long = 0L

  @Before
  fun setUp() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()

    eventDao = database.eventDao()
    guestDao = database.guestDao()
    eventRepository = EventRepositoryImpl(eventDao)
    guestRepository = GuestRepositoryImpl(guestDao, database)

    eventId = eventRepository.createEvent(
      name = "Tech Innovation Summit 2026",
      description = "Flagship conference",
      date = "2026-11-20",
      location = "Riyadh Front Exhibition Center",
      organizer = "Global Events Authority",
      status = EventStatus.ACTIVE,
    )
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun testXlsxWriterAndParserRoundTrip() {
    val testRows = listOf(
      listOf("Full Name", "Email", "Phone", "Organization", "Job Title", "Status", "Notes"),
      listOf("Dr. Tariq Al-Mansoor", "tariq@example.com", "+966501234567", "Innovate Corp", "CTO", "Confirmed", "VIP speaker"),
      listOf("Sara Jenkins", "sara.j@example.org", "+14155551234", "Summit Labs", "VP Engineering", "Invited", "Requires translation headset"),
    )

    val xlsxBytes = XlsxWriter.createXlsx(testRows)
    val parsedRows = XlsxParser.parse(ByteArrayInputStream(xlsxBytes))

    assertEquals(3, parsedRows.size)
    assertEquals("Full Name", parsedRows[0][0])
    assertEquals("Dr. Tariq Al-Mansoor", parsedRows[1][0])
    assertEquals("tariq@example.com", parsedRows[1][1])
    assertEquals("Sara Jenkins", parsedRows[2][0])
  }

  @Test
  fun testEnglishHeadersParsingAndDeduplication() = runBlocking {
    // 1. Create one existing guest in the database
    guestRepository.createGuest(
      eventId = eventId,
      fullName = "Existing Attendee",
      email = "duplicate@company.com",
      phone = "+966500000000",
    )

    val rows = listOf(
      listOf("Full Name", "Email", "Phone", "Organization", "Job Title", "Status", "Notes"),
      listOf("Fahad Al-Otaibi", "fahad@alotaibi.sa", "+966555112233", "Tech SA", "Lead Architect", "Confirmed", "Keynote"),
      listOf("", "invalid@emptyname.com", "+966555998877", "No Name Org", "Consultant", "Invited", "Invalid row"),
      listOf("Duplicate Person", "duplicate@company.com", "+966555000111", "Same Org", "Manager", "Invited", "Should be flagged duplicate"),
    )

    val bytes = XlsxWriter.createXlsx(rows)
    val existingGuests = guestRepository.getGuestsForEventSync(eventId)
    val preview = ExcelGuestParser.parse(ByteArrayInputStream(bytes), "attendees.xlsx", existingGuests)

    assertEquals("attendees.xlsx", preview.fileName)
    assertEquals(3, preview.totalRows)
    assertEquals(1, preview.invalidRows.size)
    assertEquals("Full Name is missing or empty", preview.invalidRows[0].invalidReason)
    assertEquals(1, preview.duplicateRows.size)
    assertEquals("Duplicate Email: duplicate@company.com", preview.duplicateRows[0].duplicateReason)
    assertEquals(1, preview.willBeImportedCount)

    // Execute bulk import transaction
    val result = guestRepository.importGuestsTransaction(
      eventId = eventId,
      validRows = preview.validRows.filter { !it.isDuplicate && it.isValid },
    )

    assertEquals(1, result.importedCount)

    // Verify database state
    val allGuests = guestRepository.getGuestsForEvent(eventId).first()
    assertEquals(2, allGuests.size) // 1 existing + 1 newly imported
    val imported = allGuests.find { it.fullName == "Fahad Al-Otaibi" }
    assertNotNull(imported)
    assertEquals("Tech SA", imported?.organization)
    assertEquals(InvitationStatus.CONFIRMED, imported?.invitationStatus)
    assertNotNull(imported?.uuid)
    assertTrue(imported!!.uuid.isNotEmpty())
  }

  @Test
  fun testArabicHeadersParsingAndStatusMapping() = runBlocking {
    val rows = listOf(
      listOf("الاسم الكامل", "البريد الإلكتروني", "رقم الجوال", "الجهة", "المسمى الوظيفي", "حالة الدعوة", "ملاحظات"),
      listOf("م. ريم الشمري", "reem@saudi-ai.sa", "+966511223344", "الذكاء الاصطناعي", "مديرة مشاريع", "مؤكد", "جلسة حوارية"),
      listOf("د. خالد القحطاني", "khaled@univ.edu.sa", "+966599887766", "جامعة الملك سعود", "أستاذ باحث", "اعتذار", "تضارب مواعيد"),
      listOf("نورة السبيعي", "noura@events.sa", "+966544332211", "هيئة الفعاليات", "منسقة مراسم", "تم الحضور", "طاقم التنظيم"),
    )

    val bytes = XlsxWriter.createXlsx(rows)
    val existingGuests = guestRepository.getGuestsForEventSync(eventId)
    val preview = ExcelGuestParser.parse(ByteArrayInputStream(bytes), "arabic_guests.xlsx", existingGuests)

    assertEquals(3, preview.totalRows)
    assertEquals(0, preview.invalidRows.size)
    assertEquals(0, preview.duplicateRows.size)
    assertEquals(3, preview.willBeImportedCount)

    assertEquals(InvitationStatus.CONFIRMED, preview.validRows[0].invitationStatus)
    assertEquals(InvitationStatus.DECLINED, preview.validRows[1].invitationStatus)
    assertEquals(InvitationStatus.CHECKED_IN, preview.validRows[2].invitationStatus)

    // Commit import
    val importResult = guestRepository.importGuestsTransaction(
      eventId = eventId,
      validRows = preview.validRows,
    )

    assertEquals(3, importResult.importedCount)
    val guestsInDb = guestRepository.getGuestsForEvent(eventId).first()
    assertEquals(3, guestsInDb.size)
  }

  @Test
  fun testUuidPreservationAndGeneration() = runBlocking {
    val customUuid = "550e8400-e29b-41d4-a716-446655440000"
    val rows = listOf(
      listOf("Full Name", "Email", "UUID"),
      listOf("Guest With Pre-generated UUID", "pregen@test.com", customUuid),
      listOf("Guest With Generated UUID", "auto@test.com", ""),
    )

    val bytes = XlsxWriter.createXlsx(rows)
    val preview = ExcelGuestParser.parse(ByteArrayInputStream(bytes), "uuids.xlsx", emptyList())
    assertEquals(2, preview.willBeImportedCount)

    guestRepository.importGuestsTransaction(eventId, preview.validRows)
    val guests = guestRepository.getGuestsForEvent(eventId).first()

    val pregenGuest = guests.find { it.fullName == "Guest With Pre-generated UUID" }
    val autoGuest = guests.find { it.fullName == "Guest With Generated UUID" }

    assertNotNull(pregenGuest)
    assertEquals(customUuid, pregenGuest?.uuid)

    assertNotNull(autoGuest)
    assertNotNull(autoGuest?.uuid)
    assertTrue(autoGuest!!.uuid.isNotEmpty())
    assertFalse(autoGuest.uuid == customUuid)
  }
}
