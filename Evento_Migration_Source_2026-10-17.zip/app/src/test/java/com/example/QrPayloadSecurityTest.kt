package com.example

import com.example.ui.navigation.EventoDestination
import com.example.util.qr.QrCodeGeneratorImpl
import com.example.util.qr.QrPayload
import java.util.UUID
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class QrPayloadSecurityTest {

  @Test
  fun `qr payload format strictly adheres to EVT1 with guest uuid`() {
    val sampleUuid = UUID.randomUUID().toString()
    val payload = QrPayload.buildPayload(sampleUuid)

    // Must start with EVT1:
    assertTrue(payload.startsWith("EVT1:"))
    assertEquals("EVT1:$sampleUuid", payload)

    // Parse back
    val parseResult = QrPayload.parse(payload)
    assertTrue(parseResult is QrPayload.ParseResult.Success)
    assertEquals(sampleUuid, (parseResult as QrPayload.ParseResult.Success).guestUuid)
  }

  @Test
  fun `qr payload rejects personal information and malicious content`() {
    // Rejects email addresses
    val emailResult = QrPayload.parse("EVT1:alawdq4@gmail.com")
    assertTrue(emailResult is QrPayload.ParseResult.Invalid)

    // Rejects raw personal data / vCard
    val vcardResult = QrPayload.parse("BEGIN:VCARD\nFN:John Doe\nEND:VCARD")
    assertTrue(vcardResult is QrPayload.ParseResult.Invalid)

    // Rejects JSON payload with personal fields
    val jsonResult = QrPayload.parse("{\"name\": \"John Doe\", \"email\": \"john@example.com\"}")
    assertTrue(jsonResult is QrPayload.ParseResult.Invalid)

    // Rejects spaces or additional parameters
    val malformedWithParams = QrPayload.parse("EVT1:${UUID.randomUUID()} name=John")
    assertTrue(malformedWithParams is QrPayload.ParseResult.Invalid)
  }

  @Test
  fun `qr generator compiles and builds bitmap from valid EVT1 payload`() {
    val sampleUuid = "12345678-1234-1234-1234-123456789abc"
    val generator = QrCodeGeneratorImpl()

    val bitmap = generator.generateQrBitmap(sampleUuid, sizePixels = 256)
    assertNotNull(bitmap)
    assertEquals(256, bitmap!!.width)
    assertEquals(256, bitmap.height)
  }

  @Test
  fun `navigation destinations are non-null and safely initialized`() {
    val destinations = EventoDestination.allDestinations
    assertEquals(8, destinations.size)
    destinations.forEach { destination ->
      assertNotNull("Destination must not be null", destination)
      assertNotNull("Route must not be null", destination.route)
      assertNotNull("Section must not be null", destination.section)
      assertNotNull("Selected icon must not be null", destination.selectedIcon)
      assertNotNull("Unselected icon must not be null", destination.unselectedIcon)
    }
  }
}
