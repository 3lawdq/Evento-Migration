package com.example.ui.screens.reports

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.model.AttendanceRecord
import com.example.data.local.EventDatabase
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepository
import com.example.data.repository.GuestRepositoryImpl
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
class AnalyticsViewModelTest {

  private lateinit var context: Context
  private lateinit var eventDatabase: EventDatabase
  private lateinit var checkInDatabase: CheckInDatabase
  private lateinit var eventRepo: EventRepository
  private lateinit var guestRepo: GuestRepository
  private lateinit var checkInRepo: CheckInRepository

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    eventDatabase = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()

    checkInDatabase = Room.inMemoryDatabaseBuilder(context, CheckInDatabase::class.java)
      .allowMainThreadQueries()
      .build()

    eventRepo = EventRepositoryImpl(eventDatabase.eventDao(), eventDatabase)
    guestRepo = GuestRepositoryImpl(eventDatabase.guestDao(), eventDatabase)
    checkInRepo = CheckInRepository(checkInDatabase.checkInDao())
  }

  @After
  fun tearDown() {
    eventDatabase.close()
    checkInDatabase.close()
  }

  private fun createViewModel(testScope: TestScope): AnalyticsViewModel {
    return AnalyticsViewModel(
      eventRepository = eventRepo,
      guestRepository = guestRepo,
      checkInRepository = checkInRepo,
      coroutineScope = testScope.backgroundScope,
    )
  }

  @Test
  fun `empty database produces empty state with no selected event`() = runTest {
    val viewModel = createViewModel(this)

    val state = viewModel.uiState.first { !it.isLoading }
    assertTrue(state.events.isEmpty())
    assertNull(state.selectedEvent)
    assertEquals(0, state.attendanceSummary.totalGuests)
    assertEquals(0, state.attendanceSummary.checkedInGuests)
    assertTrue(state.timeline.isEmpty())
  }

  @Test
  fun `calculates attendance and cross-analysis accurately`() = runTest {
    val eventId = eventRepo.createEvent(
      name = "Annual Tech Summit",
      description = "Tech conference",
      date = "2026-10-15",
      location = "Convention Center",
      organizer = "TechCorp",
      status = EventStatus.ACTIVE,
    )

    // Guest 1: Invited and Checked In via checkin database
    val uuid1 = UUID.randomUUID().toString()
    guestRepo.createGuest(
      eventId = eventId,
      fullName = "Alice Smith",
      email = "alice@tech.org",
      phone = "123456",
      organization = "TechCorp",
      jobTitle = "Lead Architect",
      invitationStatus = InvitationStatus.INVITED,
    )
    // Update guest's UUID in DB to match
    val guests = guestRepo.getGuestsForEventSync(eventId)
    val guest1 = guests.first()
    checkInRepo.insertAttendance(
      AttendanceRecord(eventId = eventId, guestUuid = guest1.uuid, checkedInAt = 1690000000000L)
    )

    // Guest 2: Confirmed and Checked In directly in guest roster
    guestRepo.createGuest(
      eventId = eventId,
      fullName = "Bob Johnson",
      email = "bob@tech.org",
      phone = "234567",
      organization = "TechCorp",
      jobTitle = "Senior Developer",
      invitationStatus = InvitationStatus.CHECKED_IN,
    )

    // Guest 3: Confirmed but Not Checked In
    guestRepo.createGuest(
      eventId = eventId,
      fullName = "Charlie Davis",
      email = "charlie@acme.com",
      phone = "345678",
      organization = "Acme Inc",
      jobTitle = "Product Manager",
      invitationStatus = InvitationStatus.CONFIRMED,
    )

    // Guest 4: Declined
    guestRepo.createGuest(
      eventId = eventId,
      fullName = "Dana Evans",
      email = "dana@acme.com",
      phone = "456789",
      organization = "Acme Inc",
      jobTitle = "Product Manager",
      invitationStatus = InvitationStatus.DECLINED,
    )

    val viewModel = createViewModel(this)

    val state = viewModel.uiState.first { it.selectedEvent != null && it.attendanceSummary.totalGuests == 4 }

    assertEquals("Annual Tech Summit", state.selectedEvent?.name)
    assertEquals(4, state.attendanceSummary.totalGuests)
    assertEquals(2, state.attendanceSummary.checkedInGuests)
    assertEquals(2, state.attendanceSummary.remainingGuests)
    assertEquals(50.0, state.attendanceSummary.attendancePercentage, 0.01)

    // Cross-analysis validation
    assertEquals(1, state.crossAnalysis.confirmedAndCheckedIn)
    assertEquals(1, state.crossAnalysis.confirmedNotCheckedIn)
    assertEquals(1, state.crossAnalysis.declined)
    assertEquals(2, state.crossAnalysis.totalCheckedIn)

    // Organization summary validation
    val techCorp = state.organizationSummaries.find { it.organization == "TechCorp" }
    assertNotNull(techCorp)
    assertEquals(2, techCorp?.totalGuests)
    assertEquals(2, techCorp?.checkedInGuests)
    assertEquals(100.0, techCorp?.attendancePercentage ?: 0.0, 0.01)

    val acme = state.organizationSummaries.find { it.organization == "Acme Inc" }
    assertNotNull(acme)
    assertEquals(2, acme?.totalGuests)
    assertEquals(0, acme?.checkedInGuests)

    // Job title summary validation
    val pm = state.jobTitleSummaries.find { it.jobTitle == "Product Manager" }
    assertNotNull(pm)
    assertEquals(2, pm?.totalGuests)

    // Data quality summary validation
    assertEquals(4, state.dataQualitySummary.totalRecords)
    assertEquals(4, state.dataQualitySummary.completeGuestsCount)
    assertEquals(0, state.dataQualitySummary.incompleteGuestsCount)
    assertEquals(100, state.dataQualitySummary.completenessPercentage)
  }

  @Test
  fun `calculates timeline and peak window accurately`() = runTest {
    val eventId = eventRepo.createEvent(
      name = "Conference 2026",
      description = "Tech conference",
      date = "2026-11-20",
      location = "Auditorium",
      organizer = "TechCorp",
      status = EventStatus.ARCHIVED,
    )

    val g1Uuid = UUID.randomUUID().toString()
    val g2Uuid = UUID.randomUUID().toString()
    val g3Uuid = UUID.randomUUID().toString()

    guestRepo.createGuest(eventId = eventId, fullName = "User 1")
    guestRepo.createGuest(eventId = eventId, fullName = "User 2")
    guestRepo.createGuest(eventId = eventId, fullName = "User 3")

    val baseHourMs = 1700000000000L // arbitrary fixed time
    // Two check-ins in the same hour window
    checkInRepo.insertAttendance(AttendanceRecord(eventId = eventId, guestUuid = g1Uuid, checkedInAt = baseHourMs + 60000L))
    checkInRepo.insertAttendance(AttendanceRecord(eventId = eventId, guestUuid = g2Uuid, checkedInAt = baseHourMs + 120000L))
    // One check-in in the subsequent hour
    checkInRepo.insertAttendance(AttendanceRecord(eventId = eventId, guestUuid = g3Uuid, checkedInAt = baseHourMs + 3700000L))

    val viewModel = createViewModel(this)

    val state = viewModel.uiState.first { it.selectedEvent != null && it.timeline.size == 2 }

    assertEquals(2, state.timeline.size)
    assertNotNull(state.peakCheckIn)
    assertEquals(2, state.peakCheckIn?.checkInCount)
  }
}
