package com.example.ui.screens.dashboard

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.EventDatabase
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.ExportedPackageEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.data.repository.BadgeTemplateRepository
import com.example.data.repository.BadgeTemplateRepositoryImpl
import com.example.data.repository.EventPackageRepository
import com.example.data.repository.EventPackageRepositoryImpl
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepository
import com.example.data.repository.GuestRepositoryImpl
import com.example.util.packageexport.EventoPackageWriter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
class DashboardMetricsTest {

  private lateinit var context: Context
  private lateinit var database: EventDatabase
  private lateinit var eventRepo: EventRepository
  private lateinit var guestRepo: GuestRepository
  private lateinit var badgeRepo: BadgeTemplateRepository
  private lateinit var packageRepo: EventPackageRepository
  private lateinit var dashboardViewModel: DashboardViewModel

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()

    eventRepo = EventRepositoryImpl(database.eventDao(), database)
    guestRepo = GuestRepositoryImpl(database.guestDao(), database)
    badgeRepo = BadgeTemplateRepositoryImpl(database.badgeDao())
    val writer = EventoPackageWriter(context)
    packageRepo = EventPackageRepositoryImpl(writer, database.exportedPackageDao())
  }

  @After
  fun tearDown() {
    database.close()
  }

  private fun createViewModel(scope: kotlinx.coroutines.CoroutineScope): DashboardViewModel {
    return DashboardViewModel(
      eventRepository = eventRepo,
      guestRepository = guestRepo,
      badgeTemplateRepository = badgeRepo,
      packageRepository = packageRepo,
      coroutineScope = scope,
    )
  }

  @Test
  fun testEmptyDatabase_allMetricsAreZero() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val state = dashboardViewModel.uiState.first { !it.isLoading }
    assertEquals(0, state.totalEvents)
    assertEquals(0, state.activeEvents)
    assertEquals(0, state.totalGuests)
    assertEquals(0, state.designedBadges)
    assertEquals(0, state.preparedPackages)
    assertTrue(state.recentEvents.isEmpty())
  }

  @Test
  fun testEventCreation_updatesTotalEvents() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    eventRepo.createEvent(
      name = "Tech Summit 2026",
      description = "Annual summit",
      date = "2026-10-15",
      location = "Convention Hall",
      organizer = "Tech Corp",
      status = EventStatus.DRAFT,
    )

    val state = dashboardViewModel.uiState.first { it.totalEvents == 1 }
    assertEquals(1, state.totalEvents)
    assertEquals(0, state.activeEvents)
  }

  @Test
  fun testActiveEventStatus_updatesActiveEvents() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val eventId = eventRepo.createEvent(
      name = "Tech Summit 2026",
      description = "Annual summit",
      date = "2026-10-15",
      location = "Convention Hall",
      organizer = "Tech Corp",
      status = EventStatus.DRAFT,
    )

    eventRepo.updateEventStatus(eventId, EventStatus.ACTIVE)

    val state = dashboardViewModel.uiState.first { it.activeEvents == 1 }
    assertEquals(1, state.totalEvents)
    assertEquals(1, state.activeEvents)
  }

  @Test
  fun testGuestInsertion_updatesTotalGuests() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val eventId = eventRepo.createEvent(
      name = "Expo 2026",
      description = "Expo",
      date = "2026-11-20",
      location = "Center Hall",
      organizer = "Org",
    )

    guestRepo.createGuest(
      eventId = eventId,
      fullName = "Alice Smith",
      email = "alice@example.com",
    )

    guestRepo.createGuest(
      eventId = eventId,
      fullName = "Bob Johnson",
      email = "bob@example.com",
    )

    val state = dashboardViewModel.uiState.first { it.totalGuests == 2 }
    assertEquals(2, state.totalGuests)
  }

  @Test
  fun testGuestDeletion_updatesTotalGuests() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val eventId = eventRepo.createEvent(
      name = "Expo 2026",
      description = "Expo",
      date = "2026-11-20",
      location = "Center",
      organizer = "Org",
    )

    val guestId = guestRepo.createGuest(
      eventId = eventId,
      fullName = "Alice Smith",
      email = "alice@example.com",
    )

    dashboardViewModel.uiState.first { it.totalGuests == 1 }

    guestRepo.deleteGuest(guestId)

    val state = dashboardViewModel.uiState.first { it.totalGuests == 0 }
    assertEquals(0, state.totalGuests)
  }

  @Test
  fun testBadgeTemplateCreation_updatesDesignedBadges() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val eventId = eventRepo.createEvent(
      name = "Expo 2026",
      description = "Expo",
      date = "2026-11-20",
      location = "Center",
      organizer = "Org",
    )

    badgeRepo.createTemplate(
      eventId = eventId,
      name = "VIP Badge",
      orientation = BadgeOrientation.LANDSCAPE,
    )

    val state = dashboardViewModel.uiState.first { it.designedBadges == 1 }
    assertEquals(1, state.designedBadges)
  }

  @Test
  fun testBadgeTemplateDeletion_updatesDesignedBadges() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val eventId = eventRepo.createEvent(
      name = "Expo 2026",
      description = "Expo",
      date = "2026-11-20",
      location = "Center",
      organizer = "Org",
    )

    val templateId = badgeRepo.createTemplate(
      eventId = eventId,
      name = "VIP Badge",
    )

    dashboardViewModel.uiState.first { it.designedBadges == 1 }

    badgeRepo.deleteTemplate(templateId)

    val state = dashboardViewModel.uiState.first { it.designedBadges == 0 }
    assertEquals(0, state.designedBadges)
  }

  @Test
  fun testPreparedPackageInsertion_updatesPreparedPackages() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val eventId = eventRepo.createEvent(
      name = "Conference 2026",
      description = "Conf",
      date = "2026-12-01",
      location = "Main Hall",
      organizer = "Conf Inc",
    )

    val packageEntity = ExportedPackageEntity(
      eventId = eventId,
      fileName = "conference_2026.evento",
      guestCount = 150,
      fileSizeBytes = 20480L,
      isLicensed = true,
      exportedAt = System.currentTimeMillis(),
    )

    database.exportedPackageDao().insertExportedPackage(packageEntity)

    val state = dashboardViewModel.uiState.first { it.preparedPackages == 1 }
    assertEquals(1, state.preparedPackages)
  }

  @Test
  fun testEventDeletion_cascadesPreparedPackagesAndDependentMetrics() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val eventId = eventRepo.createEvent(
      name = "Summit 2026",
      description = "Summit",
      date = "2026-12-05",
      location = "Hall B",
      organizer = "Summit Org",
    )

    guestRepo.createGuest(eventId = eventId, fullName = "John Doe")
    badgeRepo.createTemplate(eventId = eventId, name = "Badge 1")
    database.exportedPackageDao().insertExportedPackage(
      ExportedPackageEntity(
        eventId = eventId,
        fileName = "summit_2026.evento",
        guestCount = 1,
        fileSizeBytes = 5000L,
        isLicensed = false,
        exportedAt = System.currentTimeMillis(),
      )
    )

    val beforeDelete = dashboardViewModel.uiState.first { it.preparedPackages == 1 }
    assertEquals(1, beforeDelete.totalEvents)
    assertEquals(1, beforeDelete.totalGuests)
    assertEquals(1, beforeDelete.designedBadges)
    assertEquals(1, beforeDelete.preparedPackages)

    // Delete event
    eventRepo.deleteEvent(eventId)

    val afterDelete = dashboardViewModel.uiState.first { it.totalEvents == 0 }
    assertEquals(0, afterDelete.totalEvents)
    assertEquals(0, afterDelete.totalGuests)
    assertEquals(0, afterDelete.designedBadges)
    assertEquals(0, afterDelete.preparedPackages)
  }

  @Test
  fun testMultipleEventsAndReExport_aggregateCorrectly() = runTest {
    val dashboardViewModel = createViewModel(backgroundScope)
    val event1 = eventRepo.createEvent(name = "Event 1", description = "", date = "2026-01-01", location = "Loc 1", organizer = "Org")
    val event2 = eventRepo.createEvent(name = "Event 2", description = "", date = "2026-02-01", location = "Loc 2", organizer = "Org")

    guestRepo.createGuest(eventId = event1, fullName = "Guest 1")
    guestRepo.createGuest(eventId = event1, fullName = "Guest 2")
    guestRepo.createGuest(eventId = event2, fullName = "Guest 3")

    badgeRepo.createTemplate(eventId = event1, name = "T1")
    badgeRepo.createTemplate(eventId = event2, name = "T2")
    badgeRepo.createTemplate(eventId = event2, name = "T3")

    // Event 1 exported twice (re-export records are preserved)
    database.exportedPackageDao().insertExportedPackage(
      ExportedPackageEntity(eventId = event1, fileName = "evt1_v1.evento", guestCount = 2, fileSizeBytes = 1000L, isLicensed = false, exportedAt = 1000L)
    )
    database.exportedPackageDao().insertExportedPackage(
      ExportedPackageEntity(eventId = event1, fileName = "evt1_v2.evento", guestCount = 2, fileSizeBytes = 1100L, isLicensed = false, exportedAt = 2000L)
    )

    // Event 2 exported once
    database.exportedPackageDao().insertExportedPackage(
      ExportedPackageEntity(eventId = event2, fileName = "evt2_v1.evento", guestCount = 1, fileSizeBytes = 900L, isLicensed = true, exportedAt = 3000L)
    )

    val state = dashboardViewModel.uiState.first { it.preparedPackages == 3 }
    assertEquals(2, state.totalEvents)
    assertEquals(3, state.totalGuests)
    assertEquals(3, state.designedBadges)
    assertEquals(3, state.preparedPackages)
  }

  @Test
  fun testRoomMigration4To5_succeedsAndPreservesData() = runTest {
    // Verify exported_packages table exists and supports queries
    val count = database.exportedPackageDao().getExportedPackagesCountSync()
    assertEquals(0, count)

    val eventId = eventRepo.createEvent(
      name = "Migration Test Event",
      description = "Description",
      date = "2026-09-23",
      location = "Lab",
      organizer = "Test",
    )

    val pkg = ExportedPackageEntity(
      eventId = eventId,
      fileName = "test_mig.evento",
      guestCount = 10,
      fileSizeBytes = 4096L,
      isLicensed = true,
      exportedAt = 123456789L,
    )
    val insertedId = database.exportedPackageDao().insertExportedPackage(pkg)
    assertTrue(insertedId > 0)

    val packagesForEvent = database.exportedPackageDao().getPackagesForEvent(eventId).first()
    assertEquals(1, packagesForEvent.size)
    assertEquals("test_mig.evento", packagesForEvent[0].fileName)
    assertEquals(10, packagesForEvent[0].guestCount)
    assertEquals(4096L, packagesForEvent[0].fileSizeBytes)
    assertTrue(packagesForEvent[0].isLicensed)
    assertEquals(123456789L, packagesForEvent[0].exportedAt)
  }
}
