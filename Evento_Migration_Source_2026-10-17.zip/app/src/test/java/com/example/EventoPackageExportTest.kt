package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.util.packageexport.EVENTO_HASH_ALGORITHM
import com.example.util.packageexport.EVENTO_SIGNATURE_ALGORITHM
import com.example.util.packageexport.EVENTO_PACKAGE_FORMAT_VERSION
import com.example.util.packageexport.EVENTO_PACKAGE_TYPE
import com.example.util.packageexport.EVENTO_QR_PAYLOAD_FORMAT
import com.example.util.packageexport.EventPackageExportRequest
import com.example.util.packageexport.EventPackageExportResult
import com.example.util.packageexport.EventoPackageBuilder
import com.example.util.packageexport.EventoPackageHash
import com.example.util.packageexport.EventoPackageReader
import com.example.util.packageexport.EventoPackageValidator
import com.example.util.packageexport.EventoPackageWriter
import com.example.util.packageexport.PackageGuestScope
import com.example.util.packageexport.PackageValidationResult
import com.example.util.packageexport.ReadPackageResult
import com.example.util.packageexport.VerifiedPackageResult
import com.example.data.importer.ExcelImportResult
import com.example.data.importer.ParsedGuestRow
import com.example.data.repository.CapacityUpdateResult
import com.example.data.repository.EventPackageRepository
import com.example.data.repository.EventRepository
import com.example.data.repository.GuestRepository
import com.example.ui.screens.packageexport.EventPackageViewModel
import com.example.util.packageexport.EventoPackageCanonicalizer
import com.example.util.packageexport.EventoPackageLicense
import com.example.util.packageexport.EventoPackageManifest
import com.example.util.packageexport.EventoPackageSignature
import com.example.util.qr.QrPayload
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
class EventoPackageExportTest {

  @get:Rule
  val tempFolder = TemporaryFolder()

  private lateinit var context: Context
  private lateinit var builder: EventoPackageBuilder
  private lateinit var reader: EventoPackageReader
  private lateinit var validator: EventoPackageValidator
  private lateinit var writer: EventoPackageWriter

  private val sampleEvent = EventEntity(
    id = 42L,
    name = "Global Tech Summit 2026",
    date = "2026-10-15",
    location = "Convention Center Hall A",
    organizer = "Acme Corp Events",
    status = EventStatus.ACTIVE,
  )

  private val guestUuid1 = "11111111-1111-1111-1111-111111111111"
  private val guestUuid2 = "22222222-2222-2222-2222-222222222222"
  private val guestUuid3 = "33333333-3333-3333-3333-333333333333"

  private val sampleGuests = listOf(
    GuestEntity(
      id = 101L,
      eventId = 42L,
      fullName = "Alice Smith",
      email = "alice@example.com",
      phone = "+1234567890",
      organization = "Tech Labs Inc",
      jobTitle = "Chief Architect",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "VIP speaker with dietary requirements",
      uuid = guestUuid1,
    ),
    GuestEntity(
      id = 102L,
      eventId = 42L,
      fullName = "Bob Johnson",
      email = "bob@example.com",
      phone = "+9876543210",
      organization = "Dev Innovations",
      jobTitle = "Engineering Lead",
      invitationStatus = InvitationStatus.INVITED,
      notes = "Arriving late on day 1",
      uuid = guestUuid2,
    ),
    GuestEntity(
      id = 103L,
      eventId = 42L,
      fullName = "Charlie Brown",
      email = "charlie@example.com",
      phone = "+1122334455",
      organization = "Cloud Systems",
      jobTitle = "Principal Engineer",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "Requires wheelchair access",
      uuid = guestUuid3,
    ),
  )

  private val sampleLicense = EventoPackageLicense(
    licenseId = "LIC-TEST-2026-ABCD",
    eventId = 42L,
    issuedAt = 1760000000000L,
    expiresAt = 1762592000000L,
    maxGuests = 100,
    allowedDeviceCount = 2,
    boundDeviceId = "TERM-HALL-A-01",
    licenseFormatVersion = 1,
  )

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    builder = EventoPackageBuilder()
    reader = EventoPackageReader()
    validator = EventoPackageValidator(reader)
    writer = EventoPackageWriter(context, builder)
  }

  @Test
  fun `1 - package creation succeeds for valid event and guests`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )

    val result = writer.writePackage(request, outputDirectory = tempFolder.root)
    assertTrue("Export result should be Success: $result", result is EventPackageExportResult.Success)

    val success = result as EventPackageExportResult.Success
    assertTrue("Target file must exist", success.file.exists())
    assertTrue("Target file must have non-zero size", success.fileSizeInBytes > 0)
    assertEquals(3, success.guestCount)
    assertEquals(42L, success.manifest.eventId)
  }

  @Test
  fun `2 - output is a valid ZIP archive`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success

    ZipFile(result.file).use { zip ->
      assertNotNull("ZipFile should open cleanly", zip)
      assertTrue("Zip must contain entries", zip.size() > 0)
    }
  }

  @Test
  fun `3 - ZIP contains exactly the required core entries`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success

    val entryNames = mutableSetOf<String>()
    ZipFile(result.file).use { zip ->
      val entries = zip.entries()
      while (entries.hasMoreElements()) {
        entryNames.add(entries.nextElement().name)
      }
    }

    assertEquals(4, entryNames.size)
    assertTrue("manifest.json must exist", entryNames.contains("manifest.json"))
    assertTrue("event.json must exist", entryNames.contains("event.json"))
    assertTrue("guests.json must exist", entryNames.contains("guests.json"))
    assertTrue("signature.json must exist", entryNames.contains("signature.json"))
  }

  @Test
  fun `4 - packageFormatVersion is 2 and packageType is EVENTO_EVENT`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success

    val readResult = reader.readPackage(result.file) as ReadPackageResult.Success
    assertEquals(2, readResult.manifest.packageFormatVersion)
    assertEquals("EVENTO_EVENT", readResult.manifest.packageType)
    assertEquals(EVENTO_PACKAGE_FORMAT_VERSION, readResult.manifest.packageFormatVersion)
    assertEquals(EVENTO_PACKAGE_TYPE, readResult.manifest.packageType)
  }

  @Test
  fun `5 - event data is correctly serialized`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success
    val readResult = reader.readPackage(result.file) as ReadPackageResult.Success

    val event = readResult.event
    assertEquals(42L, event.eventId)
    assertEquals("Global Tech Summit 2026", event.name)
    assertEquals("2026-10-15", event.date)
    assertEquals("Convention Center Hall A", event.location)
    assertEquals("Acme Corp Events", event.organizer)
    assertEquals(EVENTO_PACKAGE_FORMAT_VERSION, event.packageFormatVersion)
  }

  @Test
  fun `6 - guest data is correctly serialized with uuid, fullName, invitationStatus, organization, and jobTitle`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success
    val readResult = reader.readPackage(result.file) as ReadPackageResult.Success

    val guests = readResult.guests
    assertEquals(3, guests.size)

    val alice = guests.first { it.uuid == guestUuid1 }
    assertEquals("Alice Smith", alice.fullName)
    assertEquals(InvitationStatus.CONFIRMED.name, alice.invitationStatus)
    assertEquals("Tech Labs Inc", alice.organization)
    assertEquals("Chief Architect", alice.jobTitle)
  }

  @Test
  fun `7 - PII exclusion - email, phone, and notes are NOT present in package guest JSON`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success
    val readResult = reader.readPackage(result.file) as ReadPackageResult.Success

    val guestsJsonString = String(readResult.rawGuestsBytes, Charsets.UTF_8)

    assertFalse("Email key must not be in guests JSON", guestsJsonString.contains("\"email\""))
    assertFalse("Phone key must not be in guests JSON", guestsJsonString.contains("\"phoneNumber\""))
    assertFalse("Phone key must not be in guests JSON", guestsJsonString.contains("\"phone\""))
    assertFalse("Notes key must not be in guests JSON", guestsJsonString.contains("\"notes\""))
    assertFalse("Alice's email must not be in guests JSON", guestsJsonString.contains("alice@example.com"))
    assertFalse("Alice's phone must not be in guests JSON", guestsJsonString.contains("+1234567890"))
    assertFalse("Notes content must not be in guests JSON", guestsJsonString.contains("VIP speaker"))
  }

  @Test
  fun `8 - uuid remains existing GuestEntity uuid and no secondary QR ID exists`() = runTest {
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, sampleGuests, PackageGuestScope.ALL)
    )

    assertEquals(sampleGuests.size, payload.guests.size)
    val expectedUuids = sampleGuests.map { it.uuid }.toSet()
    val actualUuids = payload.guests.map { it.uuid }.toSet()
    assertEquals(expectedUuids, actualUuids)
  }

  @Test
  fun `9 - QR payload format remains exactly EVT1 guest_uuid`() {
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, sampleGuests, PackageGuestScope.ALL)
    )

    assertEquals("EVT1:<guest_uuid>", payload.manifest.payloadFormat)
    assertEquals(EVENTO_QR_PAYLOAD_FORMAT, payload.manifest.payloadFormat)

    // Verify format matches existing QrPayload contract
    val testUuid = UUID.randomUUID().toString()
    val formatted = QrPayload.buildPayload(testUuid)
    assertEquals("EVT1:$testUuid", formatted)
  }

  @Test
  fun `10 - ALL scope exports all valid guests`() {
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, sampleGuests, PackageGuestScope.ALL)
    )
    assertEquals(3, payload.manifest.guestCount)
    assertEquals(3, payload.guests.size)
    assertEquals("ALL", payload.manifest.guestScope)
  }

  @Test
  fun `11 - CONFIRMED scope exports only confirmed guests`() {
    val confirmedGuests = sampleGuests.filter { it.invitationStatus == InvitationStatus.CONFIRMED }
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, confirmedGuests, PackageGuestScope.CONFIRMED)
    )

    assertEquals(2, payload.manifest.guestCount)
    assertEquals(2, payload.guests.size)
    assertEquals("CONFIRMED", payload.manifest.guestScope)
    assertTrue(payload.guests.all { it.invitationStatus == InvitationStatus.CONFIRMED.name })
  }

  @Test
  fun `12 - CUSTOM scope exports exactly selected guests`() {
    val customSelection = listOf(sampleGuests[1]) // Bob only
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, customSelection, PackageGuestScope.CUSTOM)
    )

    assertEquals(1, payload.manifest.guestCount)
    assertEquals(1, payload.guests.size)
    assertEquals("CUSTOM", payload.manifest.guestScope)
    assertEquals(guestUuid2, payload.guests[0].uuid)
    assertEquals("Bob Johnson", payload.guests[0].fullName)
  }

  @Test
  fun `13 - manifest guestCount and guestScope are accurately recorded`() {
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, sampleGuests, PackageGuestScope.ALL)
    )
    assertEquals(3, payload.manifest.guestCount)
    assertEquals("ALL", payload.manifest.guestScope)
    assertEquals(42L, payload.manifest.eventId)
    assertEquals("Global Tech Summit 2026", payload.manifest.eventName)
  }

  @Test
  fun `14 - guest ordering is deterministic by UUID ascending`() {
    // Pass guests with out-of-order UUIDs
    val disorderedGuests = listOf(
      sampleGuests[2], // UUID 3333...
      sampleGuests[0], // UUID 1111...
      sampleGuests[1], // UUID 2222...
    )

    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, disorderedGuests, PackageGuestScope.ALL)
    )

    assertEquals(guestUuid1, payload.guests[0].uuid)
    assertEquals(guestUuid2, payload.guests[1].uuid)
    assertEquals(guestUuid3, payload.guests[2].uuid)
  }

  @Test
  fun `15 - same logical input produces deterministic guest ordering and hashes`() {
    val fixedDate = "2026-10-15T12:00:00Z"

    val disordered1 = listOf(sampleGuests[2], sampleGuests[0], sampleGuests[1])
    val disordered2 = listOf(sampleGuests[1], sampleGuests[2], sampleGuests[0])

    val payload1 = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, disordered1, PackageGuestScope.ALL),
      fixedIsoDate = fixedDate,
    )
    val payload2 = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, disordered2, PackageGuestScope.ALL),
      fixedIsoDate = fixedDate,
    )

    assertEquals(payload1.guestsJson, payload2.guestsJson)
    assertEquals(payload1.eventJson, payload2.eventJson)
    assertEquals(payload1.manifestJson, payload2.manifestJson)
    assertEquals(payload1.signatureDto.guestsJsonSha256, payload2.signatureDto.guestsJsonSha256)
    assertEquals(payload1.signatureDto.eventJsonSha256, payload2.signatureDto.eventJsonSha256)
    assertEquals(payload1.signatureDto.algorithm, payload2.signatureDto.algorithm)
    assertEquals(payload1.signatureDto.keyId, payload2.signatureDto.keyId)
  }

  @Test
  fun `16 - SHA-256 integrity information is generated in signature json`() {
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, sampleGuests, PackageGuestScope.ALL)
    )

    assertEquals("SHA256withECDSA", payload.signatureDto.algorithm)
    assertEquals(EVENTO_SIGNATURE_ALGORITHM, payload.signatureDto.algorithm)

    val expectedEventHash = EventoPackageHash.sha256(payload.eventJson.toByteArray(Charsets.UTF_8))
    val expectedGuestsHash = EventoPackageHash.sha256(payload.guestsJson.toByteArray(Charsets.UTF_8))

    assertEquals(expectedEventHash, payload.signatureDto.eventJsonSha256)
    assertEquals(expectedGuestsHash, payload.signatureDto.guestsJsonSha256)
  }

  @Test
  fun `17 - valid package passes reader and validator verification`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success

    val verifiedResult = validator.validateFile(result.file)
    assertTrue("Package should be verified as valid", verifiedResult is VerifiedPackageResult.Valid)

    val valid = verifiedResult as VerifiedPackageResult.Valid
    assertEquals(3, valid.guests.size)
    assertEquals(42L, valid.event.eventId)
    assertEquals(3, valid.manifest.guestCount)
  }

  @Test
  fun `18 - tampered event json in package fails verification`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success
    val originalFile = result.file

    // Read original entries
    val readOriginal = reader.readPackage(originalFile) as ReadPackageResult.Success
    val tamperedEventJson = readOriginal.eventAdapterModifyName("Tampered Event Name")

    // Create a new tampered ZIP file
    val tamperedFile = File(tempFolder.root, "tampered_event.evento")
    createZipWithEntries(
      targetFile = tamperedFile,
      manifestJson = String(readOriginal.rawManifestBytes, Charsets.UTF_8),
      eventJson = tamperedEventJson,
      guestsJson = String(readOriginal.rawGuestsBytes, Charsets.UTF_8),
      signatureJson = String(readOriginal.rawSignatureBytes, Charsets.UTF_8),
    )

    val verifiedResult = validator.validateFile(tamperedFile)
    assertTrue("Tampered package must be Invalid", verifiedResult is VerifiedPackageResult.Invalid)
    val invalid = verifiedResult as VerifiedPackageResult.Invalid
    assertTrue("Error reason must mention Tamper or mismatch: ${invalid.reason}", invalid.reason.contains("Tamper detected"))
  }

  @Test
  fun `19 - tampered guests json in package fails verification`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success
    val originalFile = result.file

    val readOriginal = reader.readPackage(originalFile) as ReadPackageResult.Success
    val tamperedGuestsJson = String(readOriginal.rawGuestsBytes, Charsets.UTF_8)
      .replace("Alice Smith", "Mallory Imposter")

    val tamperedFile = File(tempFolder.root, "tampered_guests.evento")
    createZipWithEntries(
      targetFile = tamperedFile,
      manifestJson = String(readOriginal.rawManifestBytes, Charsets.UTF_8),
      eventJson = String(readOriginal.rawEventBytes, Charsets.UTF_8),
      guestsJson = tamperedGuestsJson,
      signatureJson = String(readOriginal.rawSignatureBytes, Charsets.UTF_8),
    )

    val verifiedResult = validator.validateFile(tamperedFile)
    assertTrue("Tampered package must be Invalid", verifiedResult is VerifiedPackageResult.Invalid)
    val invalid = verifiedResult as VerifiedPackageResult.Invalid
    assertTrue("Error reason must mention Tamper: ${invalid.reason}", invalid.reason.contains("Tamper detected"))
  }

  @Test
  fun `20 - missing required ZIP entry fails validation`() {
    val missingSignatureFile = File(tempFolder.root, "missing_signature.evento")
    ZipOutputStream(FileOutputStream(missingSignatureFile)).use { zos ->
      val entry = ZipEntry("manifest.json")
      zos.putNextEntry(entry)
      zos.write("{}".toByteArray(Charsets.UTF_8))
      zos.closeEntry()
    }

    val verifiedResult = validator.validateFile(missingSignatureFile)
    assertTrue("Package missing entries must be Invalid", verifiedResult is VerifiedPackageResult.Invalid)
    val invalid = verifiedResult as VerifiedPackageResult.Invalid
    assertTrue("Error must mention missing entry: ${invalid.reason}", invalid.reason.contains("Missing"))
  }

  @Test
  fun `21 - invalid package type or package format version fails validation`() = runTest {
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(sampleEvent, sampleGuests, PackageGuestScope.ALL)
    )

    // Tamper manifest packageType
    val tamperedManifest = payload.manifestJson.replace("EVENTO_EVENT", "UNKNOWN_FORMAT")
    val invalidTypeFile = File(tempFolder.root, "invalid_type.evento")
    createZipWithEntries(
      targetFile = invalidTypeFile,
      manifestJson = tamperedManifest,
      eventJson = payload.eventJson,
      guestsJson = payload.guestsJson,
      signatureJson = payload.signatureJson,
    )

    val verifiedResult = validator.validateFile(invalidTypeFile)
    assertTrue("Invalid package type must be rejected", verifiedResult is VerifiedPackageResult.Invalid)
    val invalid = verifiedResult as VerifiedPackageResult.Invalid
    assertTrue("Reason should state unsupported package type: ${invalid.reason}", invalid.reason.contains("Unsupported package type"))
  }

  @Test
  fun `22 - invalid guest UUID format is rejected during validation`() {
    val guestsWithBadUuid = listOf(
      sampleGuests[0].copy(uuid = "not-a-valid-uuid")
    )

    val validation = builder.validateRequest(
      EventPackageExportRequest(sampleEvent, guestsWithBadUuid, PackageGuestScope.ALL)
    )
    assertTrue("Malformed UUID must be rejected", validation is PackageValidationResult.Invalid)
    val invalid = validation as PackageValidationResult.Invalid
    assertTrue("Reason should mention UUID: ${invalid.reason}", invalid.reason.contains("UUID"))
  }

  @Test
  fun `23 - duplicate guest UUIDs are rejected during validation`() {
    val guestsWithDuplicateUuid = listOf(
      sampleGuests[0],
      sampleGuests[1].copy(uuid = sampleGuests[0].uuid), // Duplicate UUID
    )

    val validation = builder.validateRequest(
      EventPackageExportRequest(sampleEvent, guestsWithDuplicateUuid, PackageGuestScope.ALL)
    )
    assertTrue("Duplicate UUID must be rejected", validation is PackageValidationResult.Invalid)
    val invalid = validation as PackageValidationResult.Invalid
    assertTrue("Reason should mention duplicate UUIDs: ${invalid.reason}", invalid.reason.contains("Duplicate guest UUID"))
  }

  @Test
  fun `24 - guest belonging to another event is rejected`() {
    val foreignGuests = listOf(
      sampleGuests[0],
      sampleGuests[1].copy(eventId = 9999L), // Belongs to a different event
    )

    val validation = builder.validateRequest(
      EventPackageExportRequest(sampleEvent, foreignGuests, PackageGuestScope.ALL)
    )
    assertTrue("Foreign guest must be rejected", validation is PackageValidationResult.Invalid)
    val invalid = validation as PackageValidationResult.Invalid
    assertTrue("Reason should state guest does not belong: ${invalid.reason}", invalid.reason.contains("do not belong to event"))
  }

  @Test
  fun `25 - nonexistent or invalid event is rejected`() {
    val invalidIdEvent = sampleEvent.copy(id = 0L)
    val validation1 = builder.validateRequest(
      EventPackageExportRequest(invalidIdEvent, sampleGuests, PackageGuestScope.ALL)
    )
    assertTrue("Invalid event ID must be rejected", validation1 is PackageValidationResult.Invalid)

    val blankNameEvent = sampleEvent.copy(name = "   ")
    val validation2 = builder.validateRequest(
      EventPackageExportRequest(blankNameEvent, sampleGuests, PackageGuestScope.ALL)
    )
    assertTrue("Blank event name must be rejected", validation2 is PackageValidationResult.Invalid)
  }

  @Test
  fun `26 - empty guest list is rejected`() {
    val validation = builder.validateRequest(
      EventPackageExportRequest(sampleEvent, emptyList(), PackageGuestScope.ALL)
    )
    assertTrue("Empty guests list must be rejected", validation is PackageValidationResult.Invalid)
    val invalid = validation as PackageValidationResult.Invalid
    assertTrue("Reason should mention at least one guest: ${invalid.reason}", invalid.reason.contains("At least one guest is required"))
  }

  @Test
  fun `27 - package can be reopened and verified cleanly`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
    )
    val result = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success

    // Reopen via reader
    val read = reader.readPackage(result.file)
    assertTrue("Package must be read successfully", read is ReadPackageResult.Success)

    // Verify via validator
    val verified = validator.validateFile(result.file)
    assertTrue("Package must be verified successfully", verified is VerifiedPackageResult.Valid)
    val valid = verified as VerifiedPackageResult.Valid
    assertEquals(sampleGuests.size, valid.guests.size)
    assertEquals(sampleEvent.name, valid.event.name)
  }

  @Test
  fun `28 - existing QR security behavior remains intact`() {
    // Check valid EVT1 prefix and RFC4122 UUID
    val validPayload = "EVT1:$guestUuid1"
    val parsed = QrPayload.parse(validPayload)
    assertTrue("Valid EVT1 QR payload must parse as Success", parsed is QrPayload.ParseResult.Success)
    assertEquals(guestUuid1, (parsed as QrPayload.ParseResult.Success).guestUuid)

    // Check invalid prefix is rejected
    val invalidPrefixPayload = "BAD1:$guestUuid1"
    assertTrue("Invalid prefix must fail parsing", QrPayload.parse(invalidPrefixPayload) is QrPayload.ParseResult.Invalid)

    // Check raw UUID without prefix is rejected
    assertTrue("Raw UUID without prefix must fail parsing", QrPayload.parse(guestUuid1) is QrPayload.ParseResult.Invalid)

    // Check EVT1 with malformed UUID is rejected
    assertTrue("Malformed UUID must fail parsing", QrPayload.parse("EVT1:not-a-uuid") is QrPayload.ParseResult.Invalid)
  }

  // ==================================================
  // TEST GROUP 1 — VALID LICENSED PACKAGE
  // ==================================================

  @Test
  fun `29 - valid licensed package export produces non-null license json, V2_1 canonicalization, and verified 5-file zip`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense,
    )

    val result = writer.writePackage(request, outputDirectory = tempFolder.root)
    assertTrue("Export result should be Success: $result", result is EventPackageExportResult.Success)

    val success = result as EventPackageExportResult.Success
    assertTrue("Target file must exist", success.file.exists())
    assertTrue("isLicensed must be true on export success result", success.isLicensed)
    assertNotNull("license DTO must be non-null on export success result", success.license)

    // 1. Verify ZIP contains exactly 5 entries including license.json
    ZipFile(success.file).use { zip ->
      val entries = zip.entries().toList().map { it.name }.toSet()
      assertEquals(5, entries.size)
      assertTrue("manifest.json must exist in ZIP", entries.contains("manifest.json"))
      assertTrue("event.json must exist in ZIP", entries.contains("event.json"))
      assertTrue("guests.json must exist in ZIP", entries.contains("guests.json"))
      assertTrue("signature.json must exist in ZIP", entries.contains("signature.json"))
      assertTrue("license.json must exist in ZIP", entries.contains("license.json"))
    }

    // 2. Read package via EventoPackageReader and verify license fields preserved
    val readResult = reader.readPackage(success.file)
    assertTrue("Read package must succeed: $readResult", readResult is ReadPackageResult.Success)
    val read = readResult as ReadPackageResult.Success

    assertNotNull("signature.licenseJsonSha256 must be present in signature.json", read.signature.licenseJsonSha256)
    assertEquals(
      "Signed content descriptor must be EVENTO-CANONICAL-V2.1",
      EventoPackageCanonicalizer.DESCRIPTOR_V2_1,
      read.signature.signedContentDescriptor,
    )

    val lic = read.license
    assertNotNull("license.json must parse into EventoPackageLicense", lic)
    assertEquals(sampleLicense.licenseId, lic!!.licenseId)
    assertEquals(sampleEvent.id, lic.eventId)
    assertEquals(sampleLicense.issuedAt, lic.issuedAt)
    assertEquals(sampleLicense.expiresAt, lic.expiresAt)
    assertEquals(sampleLicense.maxGuests, lic.maxGuests)
    assertEquals(sampleLicense.allowedDeviceCount, lic.allowedDeviceCount)
    assertEquals(sampleLicense.boundDeviceId, lic.boundDeviceId)
    assertEquals(sampleLicense.licenseFormatVersion, lic.licenseFormatVersion)

    // 3. Pre-export validation verification succeeds
    val verification = validator.validateFile(success.file)
    assertTrue("Valid licensed package must verify as Valid: $verification", verification is VerifiedPackageResult.Valid)
  }

  // ==================================================
  // TEST GROUP 2 — VALID UNLICENSED PACKAGE
  // ==================================================

  @Test
  fun `30 - valid unlicensed package export preserves Phase 6 four-file structure and V2 signature`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = null,
    )

    val result = writer.writePackage(request, outputDirectory = tempFolder.root)
    assertTrue("Export result should be Success: $result", result is EventPackageExportResult.Success)

    val success = result as EventPackageExportResult.Success
    assertFalse("isLicensed must be false for unlicensed export", success.isLicensed)
    assertNull("license DTO must be null for unlicensed export", success.license)

    // 1. Verify ZIP contains exactly 4 entries and NO license.json
    ZipFile(success.file).use { zip ->
      val entries = zip.entries().toList().map { it.name }.toSet()
      assertEquals(4, entries.size)
      assertTrue("manifest.json must exist in ZIP", entries.contains("manifest.json"))
      assertTrue("event.json must exist in ZIP", entries.contains("event.json"))
      assertTrue("guests.json must exist in ZIP", entries.contains("guests.json"))
      assertTrue("signature.json must exist in ZIP", entries.contains("signature.json"))
      assertFalse("license.json must NOT exist in unlicensed ZIP", entries.contains("license.json"))
    }

    // 2. Read package via EventoPackageReader
    val readResult = reader.readPackage(success.file)
    assertTrue("Read package must succeed: $readResult", readResult is ReadPackageResult.Success)
    val read = readResult as ReadPackageResult.Success

    assertNull("license DTO must be null in read result", read.license)
    assertNull("rawLicenseBytes must be null in read result", read.rawLicenseBytes)
    assertNull("signature.licenseJsonSha256 must be null", read.signature.licenseJsonSha256)
    assertEquals(
      "Signed content descriptor must be EVENTO-CANONICAL-V2",
      EventoPackageCanonicalizer.DESCRIPTOR_V2,
      read.signature.signedContentDescriptor,
    )

    // 3. Package verification succeeds
    val verification = validator.validateFile(success.file)
    assertTrue("Valid unlicensed package must verify as Valid: $verification", verification is VerifiedPackageResult.Valid)
  }

  // ==================================================
  // TEST GROUP 3 — INVALID LICENSE CONFIGURATION
  // ==================================================

  @Test
  fun `31 - builder pre-export validation rejects empty or blank license ID`() {
    val baseRequest = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense,
    )

    val emptyIdResult = builder.validateRequest(
      baseRequest.copy(license = sampleLicense.copy(licenseId = ""))
    )
    assertTrue("Empty license ID must be Invalid", emptyIdResult is PackageValidationResult.Invalid)
    assertTrue(
      (emptyIdResult as PackageValidationResult.Invalid).reason.contains("License identifier cannot be blank")
    )

    val blankIdResult = builder.validateRequest(
      baseRequest.copy(license = sampleLicense.copy(licenseId = "   \t  "))
    )
    assertTrue("Blank whitespace license ID must be Invalid", blankIdResult is PackageValidationResult.Invalid)
    assertTrue(
      (blankIdResult as PackageValidationResult.Invalid).reason.contains("License identifier cannot be blank")
    )
  }

  @Test
  fun `32 - builder pre-export validation rejects invalid temporal license configurations`() {
    val baseRequest = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense,
    )

    // expiresAt <= issuedAt
    val equalTimesResult = builder.validateRequest(
      baseRequest.copy(license = sampleLicense.copy(issuedAt = 10000L, expiresAt = 10000L))
    )
    assertTrue("expiresAt == issuedAt must be Invalid", equalTimesResult is PackageValidationResult.Invalid)
    assertTrue(
      (equalTimesResult as PackageValidationResult.Invalid).reason.contains("License expiresAt must be after issuedAt")
    )

    val invertedTimesResult = builder.validateRequest(
      baseRequest.copy(license = sampleLicense.copy(issuedAt = 20000L, expiresAt = 10000L))
    )
    assertTrue("expiresAt < issuedAt must be Invalid", invertedTimesResult is PackageValidationResult.Invalid)
    assertTrue(
      (invertedTimesResult as PackageValidationResult.Invalid).reason.contains("License expiresAt must be after issuedAt")
    )

    // Non-positive timestamps
    val zeroIssuedResult = builder.validateRequest(
      baseRequest.copy(license = sampleLicense.copy(issuedAt = 0L, expiresAt = 10000L))
    )
    assertTrue("issuedAt == 0 must be Invalid", zeroIssuedResult is PackageValidationResult.Invalid)
    assertTrue(
      (zeroIssuedResult as PackageValidationResult.Invalid).reason.contains("License timestamps must be positive")
    )

    val negativeExpiresResult = builder.validateRequest(
      baseRequest.copy(license = sampleLicense.copy(issuedAt = 1000L, expiresAt = -500L))
    )
    assertTrue("expiresAt < 0 must be Invalid", negativeExpiresResult is PackageValidationResult.Invalid)
    assertTrue(
      (negativeExpiresResult as PackageValidationResult.Invalid).reason.contains("License timestamps must be positive")
    )
  }

  @Test
  fun `33 - builder pre-export validation rejects maxGuests below exported guest count`() {
    // sampleGuests has 3 guests
    val baseRequest = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense.copy(maxGuests = 2),
    )

    val result = builder.validateRequest(baseRequest)
    assertTrue("maxGuests below guest count must be Invalid", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertTrue(
      "Reason must indicate guest count exceeds maxGuests: ${invalid.reason}",
      invalid.reason.contains("exceeds license maxGuests (2)"),
    )
  }

  @Test
  fun `34 - builder pre-export validation rejects zero or negative maxGuests`() {
    val baseRequest = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense,
    )

    val zeroResult = builder.validateRequest(baseRequest.copy(license = sampleLicense.copy(maxGuests = 0)))
    assertTrue("maxGuests == 0 must be Invalid", zeroResult is PackageValidationResult.Invalid)
    assertTrue((zeroResult as PackageValidationResult.Invalid).reason.contains("License maxGuests must be positive"))

    val negativeResult = builder.validateRequest(baseRequest.copy(license = sampleLicense.copy(maxGuests = -5)))
    assertTrue("maxGuests < 0 must be Invalid", negativeResult is PackageValidationResult.Invalid)
    assertTrue((negativeResult as PackageValidationResult.Invalid).reason.contains("License maxGuests must be positive"))
  }

  @Test
  fun `35 - builder pre-export validation rejects zero or negative allowedDeviceCount`() {
    val baseRequest = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense,
    )

    val zeroResult = builder.validateRequest(baseRequest.copy(license = sampleLicense.copy(allowedDeviceCount = 0)))
    assertTrue("allowedDeviceCount == 0 must be Invalid", zeroResult is PackageValidationResult.Invalid)
    assertTrue((zeroResult as PackageValidationResult.Invalid).reason.contains("License allowedDeviceCount must be positive"))

    val negativeResult = builder.validateRequest(baseRequest.copy(license = sampleLicense.copy(allowedDeviceCount = -1)))
    assertTrue("allowedDeviceCount < 0 must be Invalid", negativeResult is PackageValidationResult.Invalid)
    assertTrue((negativeResult as PackageValidationResult.Invalid).reason.contains("License allowedDeviceCount must be positive"))
  }

  @Test
  fun `36 - builder pre-export validation rejects event ID mismatch between license and event`() {
    val baseRequest = EventPackageExportRequest(
      event = sampleEvent, // id = 42L
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense.copy(eventId = 9999L),
    )

    val result = builder.validateRequest(baseRequest)
    assertTrue("Event ID mismatch must be Invalid", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertTrue(
      "Reason must state eventId mismatch: ${invalid.reason}",
      invalid.reason.contains("does not match event ID (42)"),
    )
  }

  @Test
  fun `37 - viewModel pre-export validation rejects blank device ID when device binding is enabled`() = runTest {
    val fakeEventRepo = FakeEventRepository(listOf(sampleEvent))
    val fakeGuestRepo = FakeGuestRepository(sampleGuests)
    val fakePackageRepo = FakePackageRepository()

    val viewModel = EventPackageViewModel(
      eventRepository = fakeEventRepo,
      guestRepository = fakeGuestRepo,
      packageRepository = fakePackageRepo,
    )
    testScheduler.advanceUntilIdle()
    viewModel.selectEvent(sampleEvent)
    testScheduler.advanceUntilIdle()

    // Enable licensing and set device binding with blank device ID
    viewModel.setLicenseEnabled(true)
    viewModel.setDeviceBindingEnabled(true)
    viewModel.setBoundDeviceId("   ")

    viewModel.exportPackage()
    testScheduler.advanceUntilIdle()

    val state = viewModel.uiState.value
    assertNotNull("validationError must be set when device binding has blank ID", state.validationError)
    assertTrue(
      "Error must describe bound device identifier requirement: ${state.validationError}",
      state.validationError!!.contains("bound device identifier cannot be blank"),
    )
    assertNull("Package repository must NOT be called when validation fails", fakePackageRepo.lastRequest)
  }

  @Test
  fun `38 - viewModel pre-export validation rejects capacity below guest count and non-positive device counts`() = runTest {
    val fakeEventRepo = FakeEventRepository(listOf(sampleEvent))
    val fakeGuestRepo = FakeGuestRepository(sampleGuests)
    val fakePackageRepo = FakePackageRepository()

    val viewModel = EventPackageViewModel(
      eventRepository = fakeEventRepo,
      guestRepository = fakeGuestRepo,
      packageRepository = fakePackageRepo,
    )
    testScheduler.advanceUntilIdle()
    viewModel.selectEvent(sampleEvent)
    testScheduler.advanceUntilIdle()

    // 1. Capacity below guest count
    viewModel.setLicenseEnabled(true)
    viewModel.setMaxGuestsInput("1") // 3 guests exported
    viewModel.exportPackage()
    testScheduler.advanceUntilIdle()

    var state = viewModel.uiState.value
    assertNotNull("validationError must be set when capacity is below exported count", state.validationError)
    assertTrue(
      "Error must mention capacity below guest count: ${state.validationError}",
      state.validationError!!.contains("Maximum guests (1) cannot be below package guest count (3)"),
    )

    // 2. Allowed device count <= 0
    viewModel.setMaxGuestsInput("10")
    viewModel.setAllowedDeviceCountInput("0")
    viewModel.exportPackage()
    testScheduler.advanceUntilIdle()

    state = viewModel.uiState.value
    assertNotNull("validationError must be set when allowedDeviceCount is 0", state.validationError)
    assertTrue(
      "Error must describe invalid allowed device count: ${state.validationError}",
      state.validationError!!.contains("Invalid allowed device count"),
    )
  }

  // ==================================================
  // TEST GROUP 4 — LICENSE HASH / FORMAT RELATION
  // ==================================================

  @Test
  fun `39 - license SHA-256 hash strictly matches license json bytes and detects tampering`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense,
    )

    val exportResult = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success
    val read = reader.readPackage(exportResult.file) as ReadPackageResult.Success

    // 1. Verify licenseJsonSha256 strictly matches SHA-256 of raw license.json bytes
    val rawLicenseBytes = read.rawLicenseBytes
    assertNotNull("rawLicenseBytes must be present", rawLicenseBytes)
    val expectedHash = EventoPackageHash.sha256(rawLicenseBytes!!)
    assertEquals(expectedHash, read.signature.licenseJsonSha256)
    assertEquals(EventoPackageCanonicalizer.DESCRIPTOR_V2_1, read.signature.signedContentDescriptor)

    // 2. Tamper with license.json inside the ZIP
    val tamperedZipFile = File(tempFolder.root, "tampered_license.evento")
    val tamperedLicenseJson = String(rawLicenseBytes, Charsets.UTF_8).replace(
      "\"maxGuests\": 100",
      "\"maxGuests\": 9999",
    )
    assertTrue("tamperedLicenseJson must differ from rawLicenseBytes", tamperedLicenseJson != String(rawLicenseBytes, Charsets.UTF_8))

    createZipWithEntries(
      targetFile = tamperedZipFile,
      manifestJson = String(read.rawManifestBytes, Charsets.UTF_8),
      eventJson = String(read.rawEventBytes, Charsets.UTF_8),
      guestsJson = String(read.rawGuestsBytes, Charsets.UTF_8),
      signatureJson = String(read.rawSignatureBytes, Charsets.UTF_8),
      licenseJson = tamperedLicenseJson,
    )

    val tamperVerification = validator.validateFile(tamperedZipFile)
    assertTrue("Tampered license package must be Invalid: $tamperVerification", tamperVerification is VerifiedPackageResult.Invalid)
    val invalid = tamperVerification as VerifiedPackageResult.Invalid
    assertTrue(
      "Reason must report checksum mismatch: ${invalid.reason}",
      invalid.reason.contains("license.json SHA-256 checksum mismatch"),
    )
  }

  @Test
  fun `40 - package validator rejects signature and license file presence mismatches`() = runTest {
    val request = EventPackageExportRequest(
      event = sampleEvent,
      guests = sampleGuests,
      scope = PackageGuestScope.ALL,
      license = sampleLicense,
    )

    val exportResult = writer.writePackage(request, outputDirectory = tempFolder.root) as EventPackageExportResult.Success
    val read = reader.readPackage(exportResult.file) as ReadPackageResult.Success

    // Mismatch 1: Package has license.json, but signature.json does NOT declare licenseJsonSha256
    val signatureWithoutLicenseHash = read.signature.copy(licenseJsonSha256 = null)
    val moshi = com.squareup.moshi.Moshi.Builder().addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory()).build()
    val sigAdapter = moshi.adapter(EventoPackageSignature::class.java)

    val mismatchZip1 = File(tempFolder.root, "mismatch_sig_no_hash.evento")
    createZipWithEntries(
      targetFile = mismatchZip1,
      manifestJson = String(read.rawManifestBytes, Charsets.UTF_8),
      eventJson = String(read.rawEventBytes, Charsets.UTF_8),
      guestsJson = String(read.rawGuestsBytes, Charsets.UTF_8),
      signatureJson = sigAdapter.toJson(signatureWithoutLicenseHash),
      licenseJson = String(read.rawLicenseBytes!!, Charsets.UTF_8),
    )

    val res1 = validator.validateFile(mismatchZip1)
    assertTrue("Missing licenseJsonSha256 with present license.json must be Invalid", res1 is VerifiedPackageResult.Invalid)
    assertTrue(
      (res1 as VerifiedPackageResult.Invalid).reason.contains("does not declare licenseJsonSha256"),
    )

    // Mismatch 2: Signature declares licenseJsonSha256, but license.json is omitted from ZIP
    val mismatchZip2 = File(tempFolder.root, "mismatch_missing_license_file.evento")
    createZipWithEntries(
      targetFile = mismatchZip2,
      manifestJson = String(read.rawManifestBytes, Charsets.UTF_8),
      eventJson = String(read.rawEventBytes, Charsets.UTF_8),
      guestsJson = String(read.rawGuestsBytes, Charsets.UTF_8),
      signatureJson = String(read.rawSignatureBytes, Charsets.UTF_8),
      licenseJson = null,
    )

    val res2 = validator.validateFile(mismatchZip2)
    assertTrue("Declared licenseJsonSha256 with missing license.json must be Invalid", res2 is VerifiedPackageResult.Invalid)
    assertTrue(
      (res2 as VerifiedPackageResult.Invalid).reason.contains("license.json is missing"),
    )
  }

  // ==================================================
  // TEST GROUP 5 — LICENSE ID REGENERATION
  // ==================================================

  @Test
  fun `41 - viewModel license ID regeneration generates new unique ID while preserving config`() = runTest {
    val fakeEventRepo = FakeEventRepository(listOf(sampleEvent))
    val fakeGuestRepo = FakeGuestRepository(sampleGuests)
    val fakePackageRepo = FakePackageRepository()

    val viewModel = EventPackageViewModel(
      eventRepository = fakeEventRepo,
      guestRepository = fakeGuestRepo,
      packageRepository = fakePackageRepo,
    )
    testScheduler.advanceUntilIdle()

    // 1. Enable licensing and check initialized ID
    viewModel.setLicenseEnabled(true)
    val initialConfig = viewModel.uiState.value.licenseConfig
    assertTrue("isLicenseEnabled must be true", initialConfig.isLicenseEnabled)
    assertTrue("Initial licenseId must not be blank", initialConfig.licenseId.isNotBlank())

    // 2. Customize configuration fields
    viewModel.setMaxGuestsInput("250")
    viewModel.setAllowedDeviceCountInput("4")
    viewModel.setDurationDays(90)
    viewModel.setDeviceBindingEnabled(true)
    viewModel.setBoundDeviceId("STATION-NORTH-01")

    val beforeRegen = viewModel.uiState.value.licenseConfig
    assertEquals("250", beforeRegen.maxGuestsInput)
    assertEquals("4", beforeRegen.allowedDeviceCountInput)
    assertEquals(90, beforeRegen.durationDays)
    assertTrue(beforeRegen.isDeviceBindingEnabled)
    assertEquals("STATION-NORTH-01", beforeRegen.boundDeviceId)

    // 3. Trigger regeneration
    viewModel.regenerateLicenseId()
    val afterRegen = viewModel.uiState.value.licenseConfig

    // 4. Assert new non-blank ID generated and differs from previous
    assertTrue("Regenerated licenseId must not be blank", afterRegen.licenseId.isNotBlank())
    assertFalse("Regenerated licenseId must differ from previous ID", afterRegen.licenseId == beforeRegen.licenseId)

    // 5. Assert other configuration values were not cleared
    assertEquals("250", afterRegen.maxGuestsInput)
    assertEquals("4", afterRegen.allowedDeviceCountInput)
    assertEquals(90, afterRegen.durationDays)
    assertTrue(afterRegen.isDeviceBindingEnabled)
    assertEquals("STATION-NORTH-01", afterRegen.boundDeviceId)
    assertEquals(beforeRegen.issuedAt, afterRegen.issuedAt)
    assertEquals(beforeRegen.expiresAt, afterRegen.expiresAt)
  }

  // ==================================================
  // TEST GROUP 6 — DEFAULT LICENSE BEHAVIOR
  // ==================================================

  @Test
  fun `42 - default export configuration is unlicensed and enabling license initializes safe defaults`() = runTest {
    val fakeEventRepo = FakeEventRepository(listOf(sampleEvent))
    val fakeGuestRepo = FakeGuestRepository(sampleGuests)
    val fakePackageRepo = FakePackageRepository(
      exportResult = EventPackageExportResult.Success(
        file = File(tempFolder.root, "test.evento"),
        uri = android.net.Uri.parse("file://test.evento"),
        guestCount = sampleGuests.size,
        fileSizeInBytes = 1024L,
        manifest = EventoPackageManifest(eventId = 42L, eventName = "Test", createdAt = "2026-10-15T00:00:00Z", guestCount = 3, guestScope = PackageGuestScope.ALL.name),
        isLicensed = false,
        license = null,
      )
    )

    val viewModel = EventPackageViewModel(
      eventRepository = fakeEventRepo,
      guestRepository = fakeGuestRepo,
      packageRepository = fakePackageRepo,
    )
    testScheduler.advanceUntilIdle()
    viewModel.selectEvent(sampleEvent)
    testScheduler.advanceUntilIdle()

    // 1. Verify default initial state has isLicenseEnabled == false
    val defaultState = viewModel.uiState.value
    assertFalse("New export configuration must default to unlicensed", defaultState.licenseConfig.isLicenseEnabled)

    // When exporting while unlicensed, request.license must be null
    viewModel.exportPackage()
    testScheduler.advanceUntilIdle()

    assertNotNull("Export request must be submitted", fakePackageRepo.lastRequest)
    assertNull("Unlicensed export request must have null license", fakePackageRepo.lastRequest!!.license)

    // 2. When licensing is explicitly enabled, safe defaults are initialized
    viewModel.setLicenseEnabled(true)
    val enabledConfig = viewModel.uiState.value.licenseConfig

    assertTrue("isLicenseEnabled must be true", enabledConfig.isLicenseEnabled)
    assertTrue("Default licenseId must be non-blank UUID", enabledConfig.licenseId.isNotBlank())
    assertEquals("Default duration must be 30 days", 30, enabledConfig.durationDays)
    assertEquals("Default maxGuests must match exported guest count", "3", enabledConfig.maxGuestsInput)
    assertTrue("issuedAt must be positive", enabledConfig.issuedAt > 0L)
    assertTrue("expiresAt must be after issuedAt", enabledConfig.expiresAt > enabledConfig.issuedAt)
    assertEquals("allowedDeviceCount must default to 1", "1", enabledConfig.allowedDeviceCountInput)
    assertFalse("Device binding must be disabled by default", enabledConfig.isDeviceBindingEnabled)
    assertEquals("", enabledConfig.boundDeviceId)

    // 3. Enabling license allows valid export with license populated
    fakePackageRepo.exportResult = EventPackageExportResult.Success(
      file = File(tempFolder.root, "test_licensed.evento"),
      uri = android.net.Uri.parse("file://test_licensed.evento"),
      guestCount = sampleGuests.size,
      fileSizeInBytes = 2048L,
      manifest = EventoPackageManifest(eventId = 42L, eventName = "Test", createdAt = "2026-10-15T00:00:00Z", guestCount = 3, guestScope = PackageGuestScope.ALL.name),
      isLicensed = true,
      license = sampleLicense,
    )

    viewModel.exportPackage()
    testScheduler.advanceUntilIdle()

    val licensedRequest = fakePackageRepo.lastRequest
    assertNotNull("Licensed export request must be submitted", licensedRequest)
    assertNotNull("Licensed export request must contain non-null license", licensedRequest!!.license)
    assertEquals(sampleEvent.id, licensedRequest.license!!.eventId)
    assertEquals(enabledConfig.licenseId, licensedRequest.license!!.licenseId)
    assertTrue(licensedRequest.license!!.expiresAt > licensedRequest.license!!.issuedAt)
  }

  private fun createZipWithEntries(
    targetFile: File,
    manifestJson: String,
    eventJson: String,
    guestsJson: String,
    signatureJson: String,
    licenseJson: String? = null,
  ) {
    ZipOutputStream(FileOutputStream(targetFile)).use { zos ->
      writeZipEntry(zos, "manifest.json", manifestJson)
      writeZipEntry(zos, "event.json", eventJson)
      writeZipEntry(zos, "guests.json", guestsJson)
      licenseJson?.let { writeZipEntry(zos, "license.json", it) }
      writeZipEntry(zos, "signature.json", signatureJson)
    }
  }

  private fun writeZipEntry(zos: ZipOutputStream, entryName: String, content: String) {
    val bytes = content.toByteArray(Charsets.UTF_8)
    val entry = ZipEntry(entryName)
    zos.putNextEntry(entry)
    zos.write(bytes)
    zos.closeEntry()
  }

  private fun ReadPackageResult.Success.eventAdapterModifyName(newName: String): String {
    val original = String(rawEventBytes, Charsets.UTF_8)
    return original.replace("Global Tech Summit 2026", newName)
  }

  private class FakeEventRepository(private val events: List<EventEntity> = emptyList()) : EventRepository {
    override fun getAllEvents(): Flow<List<EventEntity>> = flowOf(events)
    override fun getEventsByStatus(status: EventStatus): Flow<List<EventEntity>> = flowOf(events.filter { it.status == status })
    override fun getEventById(id: Long): Flow<EventEntity?> = flowOf(events.find { it.id == id })
    override suspend fun getEventByIdSync(id: Long): EventEntity? = events.find { it.id == id }
    override fun getEventsCount(): Flow<Int> = flowOf(events.size)
    override fun getActiveEventsCount(): Flow<Int> = flowOf(events.count { it.status == EventStatus.ACTIVE })
    override suspend fun createEvent(
      name: String,
      description: String,
      date: String,
      location: String,
      organizer: String,
      status: EventStatus,
      guestCapacity: Int,
      autoCreateSlots: Boolean,
      slotNameFormat: String?,
    ): Long = 0L
    override suspend fun updateEvent(event: EventEntity) {}
    override suspend fun updateEventStatus(id: Long, status: EventStatus) {}
    override suspend fun updateEventCapacity(eventId: Long, newCapacity: Int): CapacityUpdateResult = CapacityUpdateResult.Success
    override suspend fun createGuestSlots(eventId: Long, count: Int): Int = count
    override suspend fun duplicateEvent(sourceEventId: Long, newName: String?, copyGuests: Boolean): Long = 0L
    override suspend fun deleteEvent(id: Long) {}
  }

  private class FakeGuestRepository(private val guests: List<GuestEntity> = emptyList()) : GuestRepository {
    override fun getGuestsForEvent(eventId: Long): Flow<List<GuestEntity>> = flowOf(guests.filter { it.eventId == eventId })
    override suspend fun getGuestsForEventSync(eventId: Long): List<GuestEntity> = guests.filter { it.eventId == eventId }
    override fun getGuestsForEventByStatus(eventId: Long, status: InvitationStatus): Flow<List<GuestEntity>> =
      flowOf(guests.filter { it.eventId == eventId && it.invitationStatus == status })
    override fun getGuestById(id: Long): Flow<GuestEntity?> = flowOf(guests.find { it.id == id })
    override suspend fun getGuestByIdSync(id: Long): GuestEntity? = guests.find { it.id == id }
    override suspend fun getGuestByUuid(uuid: String): GuestEntity? = guests.find { it.uuid == uuid }
    override fun getTotalGuestsCount(): Flow<Int> = flowOf(guests.size)
    override fun getGuestsCountForEvent(eventId: Long): Flow<Int> = flowOf(guests.size)
    override fun getGuestsCountByStatus(eventId: Long, status: InvitationStatus): Flow<Int> = flowOf(guests.count { it.invitationStatus == status })
    override fun searchGuests(eventId: Long, query: String): Flow<List<GuestEntity>> = flowOf(guests)
    override suspend fun createGuest(
      eventId: Long,
      fullName: String,
      email: String,
      phone: String,
      organization: String,
      jobTitle: String,
      invitationStatus: InvitationStatus,
      notes: String,
    ): Long = 0L
    override suspend fun importGuestsTransaction(eventId: Long, validRows: List<ParsedGuestRow>): ExcelImportResult =
      ExcelImportResult(importedCount = validRows.size, skippedCount = 0, invalidCount = 0, duplicateCount = 0)
    override suspend fun updateGuest(guest: GuestEntity) {}
    override suspend fun deleteGuest(id: Long) {}
    override suspend fun bulkUpdateStatus(eventId: Long, guestIds: List<Long>, status: InvitationStatus): Int = guestIds.size
    override suspend fun bulkUpdateOrganization(eventId: Long, guestIds: List<Long>, organization: String): Int = guestIds.size
    override suspend fun bulkUpdateJobTitle(eventId: Long, guestIds: List<Long>, jobTitle: String): Int = guestIds.size
    override suspend fun bulkDeleteGuests(eventId: Long, guestIds: List<Long>): Int = guestIds.size
    override fun getOrganizationStatsForEvent(eventId: Long): Flow<List<com.example.data.model.OrganizationStatsProjection>> = flowOf(emptyList())
    override fun getJobTitleStatsForEvent(eventId: Long): Flow<List<com.example.data.model.JobTitleStatsProjection>> = flowOf(emptyList())
  }

  private class FakePackageRepository(
    var exportResult: EventPackageExportResult = EventPackageExportResult.Error("Not configured"),
  ) : EventPackageRepository {
    var lastRequest: EventPackageExportRequest? = null
    override fun getExportedPackagesCount(): Flow<Int> = flowOf(0)
    override fun getPackagesForEvent(eventId: Long): Flow<List<com.example.data.local.entity.ExportedPackageEntity>> = flowOf(emptyList())
    override suspend fun exportEventPackage(request: EventPackageExportRequest): EventPackageExportResult {
      lastRequest = request
      return exportResult
    }
  }
}
