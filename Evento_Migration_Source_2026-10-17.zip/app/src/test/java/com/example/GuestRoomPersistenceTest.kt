package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.local.EventDatabase
import com.example.data.local.dao.EventDao
import com.example.data.local.dao.GuestDao
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepository
import com.example.data.repository.GuestRepositoryImpl
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class GuestRoomPersistenceTest {

  private lateinit var database: EventDatabase
  private lateinit var eventDao: EventDao
  private lateinit var guestDao: GuestDao
  private lateinit var eventRepository: EventRepository
  private lateinit var guestRepository: GuestRepository

  private var eventAId: Long = 0L
  private var eventBId: Long = 0L

  @Before
  fun createDb() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    eventDao = database.eventDao()
    guestDao = database.guestDao()
    eventRepository = EventRepositoryImpl(eventDao)
    guestRepository = GuestRepositoryImpl(guestDao)

    // Pre-create two distinct events for relational scoping verification
    eventAId = eventRepository.createEvent(
      name = "Global AI Summit 2026",
      description = "Enterprise Summit",
      date = "2026-11-20",
      location = "Riyadh Front",
      organizer = "Evento Tech",
      status = EventStatus.ACTIVE,
    )

    eventBId = eventRepository.createEvent(
      name = "CyberSecurity Forum 2026",
      description = "SecOps Meeting",
      date = "2026-12-10",
      location = "King Fahd Cultural Center",
      organizer = "Security Dept",
      status = EventStatus.ACTIVE,
    )
  }

  @After
  fun closeDb() {
    database.close()
  }

  @Test
  fun `1 creating and persisting a guest under an event`() = runBlocking {
    val guestId = guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Dr. Tariq Al-Mansoor",
      email = "tariq@example.com",
      phone = "+966 50 123 4567",
      organization = "AI Research Center",
      jobTitle = "Chief Scientist",
      invitationStatus = InvitationStatus.INVITED,
      notes = "VIP Keynote speaker",
    )

    assertTrue("Guest ID should be auto-generated > 0", guestId > 0)

    val guest = guestRepository.getGuestByIdSync(guestId)
    assertNotNull(guest)
    assertEquals(eventAId, guest?.eventId)
    assertEquals("Dr. Tariq Al-Mansoor", guest?.fullName)
    assertEquals("tariq@example.com", guest?.email)
    assertEquals("+966 50 123 4567", guest?.phone)
    assertEquals("AI Research Center", guest?.organization)
    assertEquals("Chief Scientist", guest?.jobTitle)
    assertEquals(InvitationStatus.INVITED, guest?.invitationStatus)
    assertEquals("VIP Keynote speaker", guest?.notes)

    // Verify UUID is cryptographically populated and non-blank
    assertNotNull(guest?.uuid)
    assertTrue(guest?.uuid?.isNotBlank() == true)
    assertEquals(36, guest?.uuid?.length) // Standard UUID length 8-4-4-4-12
  }

  @Test
  fun `2 reading guests by eventId`() = runBlocking {
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Sarah Jenkins",
      email = "sarah@tech.org",
    )
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Omar Khalid",
      email = "omar@cloud.com",
    )

    val eventAGuests = guestRepository.getGuestsForEvent(eventAId).first()
    assertEquals(2, eventAGuests.size)

    val names = eventAGuests.map { it.fullName }
    assertTrue(names.contains("Sarah Jenkins"))
    assertTrue(names.contains("Omar Khalid"))
  }

  @Test
  fun `3 updating a guest and verifying UUID remains permanently unchanged`() = runBlocking {
    val guestId = guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Fahad Al-Otaibi",
      email = "fahad@domain.com",
      organization = "Fintech Group",
      invitationStatus = InvitationStatus.INVITED,
    )

    val original = guestRepository.getGuestByIdSync(guestId)!!
    val originalUuid = original.uuid
    val originalCreatedAt = original.createdAt

    // Modify attendee details and update
    val updatedData = original.copy(
      fullName = "Fahad M. Al-Otaibi",
      jobTitle = "VP of Infrastructure",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "Dietary preference: Halal vegetarian",
    )
    guestRepository.updateGuest(updatedData)

    val reloaded = guestRepository.getGuestByIdSync(guestId)!!
    assertEquals("Fahad M. Al-Otaibi", reloaded.fullName)
    assertEquals("VP of Infrastructure", reloaded.jobTitle)
    assertEquals(InvitationStatus.CONFIRMED, reloaded.invitationStatus)
    assertEquals("Dietary preference: Halal vegetarian", reloaded.notes)

    // CRITICAL: UUID must be immutable across edits
    assertEquals("UUID must remain unchanged across edits", originalUuid, reloaded.uuid)
    assertEquals("Creation timestamp must remain original", originalCreatedAt, reloaded.createdAt)
    assertTrue("Updated timestamp should advance", reloaded.updatedAt >= original.updatedAt)
  }

  @Test
  fun `4 deleting a guest removes it from database`() = runBlocking {
    val guestId = guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Temporary Guest",
      email = "temp@temp.com",
    )

    assertNotNull(guestRepository.getGuestByIdSync(guestId))
    guestRepository.deleteGuest(guestId)
    assertNull(guestRepository.getGuestByIdSync(guestId))

    val eventGuests = guestRepository.getGuestsForEvent(eventAId).first()
    assertTrue(eventGuests.isEmpty())
  }

  @Test
  fun `5 guests from Event A do not appear under Event B`() = runBlocking {
    // Insert 2 guests into Event A
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Event A Guest 1",
      email = "a1@test.com",
    )
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Event A Guest 2",
      email = "a2@test.com",
    )

    // Insert 1 guest into Event B
    guestRepository.createGuest(
      eventId = eventBId,
      fullName = "Event B Exclusive Attendee",
      email = "b1@test.com",
    )

    val guestsA = guestRepository.getGuestsForEvent(eventAId).first()
    val guestsB = guestRepository.getGuestsForEvent(eventBId).first()

    assertEquals(2, guestsA.size)
    assertEquals(1, guestsB.size)

    assertEquals("Event B Exclusive Attendee", guestsB.first().fullName)

    // Event B guest must NOT appear in Event A
    assertTrue(guestsA.none { it.fullName == "Event B Exclusive Attendee" })
    assertTrue(guestsB.none { it.fullName.startsWith("Event A") })

    val countA = guestRepository.getGuestsCountForEvent(eventAId).first()
    val countB = guestRepository.getGuestsCountForEvent(eventBId).first()
    assertEquals(2, countA)
    assertEquals(1, countB)
  }

  @Test
  fun `6 search and filter behavior by status, name, and organization`() = runBlocking {
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Noura Al-Hassan",
      email = "noura@health.gov.sa",
      organization = "Ministry of Health",
      invitationStatus = InvitationStatus.CONFIRMED,
    )
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Khalid Bin Sultan",
      email = "khalid@finance.com",
      organization = "Global Capital",
      invitationStatus = InvitationStatus.INVITED,
    )
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Zayd Mansour",
      email = "zayd@health.gov.sa",
      organization = "Ministry of Health",
      invitationStatus = InvitationStatus.DECLINED,
    )

    // Search query "Ministry"
    val orgResults = guestRepository.searchGuests(eventAId, "Ministry").first()
    assertEquals(2, orgResults.size)
    assertTrue(orgResults.any { it.fullName == "Noura Al-Hassan" })
    assertTrue(orgResults.any { it.fullName == "Zayd Mansour" })

    // Search query by email domain "finance.com"
    val emailResults = guestRepository.searchGuests(eventAId, "finance").first()
    assertEquals(1, emailResults.size)
    assertEquals("Khalid Bin Sultan", emailResults.first().fullName)

    // Filter by CONFIRMED status
    val confirmedGuests = guestRepository.getGuestsForEventByStatus(eventAId, InvitationStatus.CONFIRMED).first()
    assertEquals(1, confirmedGuests.size)
    assertEquals("Noura Al-Hassan", confirmedGuests.first().fullName)

    // Filter by DECLINED status
    val declinedGuests = guestRepository.getGuestsForEventByStatus(eventAId, InvitationStatus.DECLINED).first()
    assertEquals(1, declinedGuests.size)
    assertEquals("Zayd Mansour", declinedGuests.first().fullName)
  }

  @Test
  fun `7 deleting parent event cascades and deletes all associated guests`() = runBlocking {
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Attendee 1",
      email = "att1@test.com",
    )
    guestRepository.createGuest(
      eventId = eventAId,
      fullName = "Attendee 2",
      email = "att2@test.com",
    )

    assertEquals(2, guestRepository.getGuestsCountForEvent(eventAId).first())

    // Delete Event A
    eventRepository.deleteEvent(eventAId)

    // CASCADE foreign key check
    val remainingGuests = guestRepository.getGuestsForEvent(eventAId).first()
    assertTrue("All guests belonging to deleted event should be cascaded", remainingGuests.isEmpty())
  }
}
