package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.local.EventDatabase
import com.example.data.local.dao.BadgeDao
import com.example.data.local.dao.EventDao
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.EventEntity
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.data.repository.BadgeTemplateRepository
import com.example.data.repository.BadgeTemplateRepositoryImpl
import com.example.ui.screens.designer.model.PreviewGuest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BadgeTemplatePersistenceTest {

  private lateinit var database: EventDatabase
  private lateinit var eventDao: EventDao
  private lateinit var badgeDao: BadgeDao
  private lateinit var badgeRepository: BadgeTemplateRepository

  private var testEventId: Long = 0L

  @Before
  fun createDb() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    eventDao = database.eventDao()
    badgeDao = database.badgeDao()
    badgeRepository = BadgeTemplateRepositoryImpl(badgeDao)

    testEventId = eventDao.insertEvent(
      EventEntity(
        name = "Tech Innovators 2026",
        description = "Conference on cutting-edge technologies",
        status = EventStatus.ACTIVE,
      ),
    )
  }

  @After
  fun closeDb() {
    database.close()
  }

  @Test
  fun `create and read default badge template with elements`() = runBlocking {
    val templateId = badgeRepository.createDefaultTemplate(testEventId, "Tech Innovators 2026")
    assertTrue(templateId > 0)

    val templateWithElements = badgeRepository.getTemplateWithElements(testEventId).first()
    assertNotNull(templateWithElements)

    val template = templateWithElements!!.template
    assertEquals(testEventId, template.eventId)
    assertEquals(90f, template.widthMm)
    assertEquals(60f, template.heightMm)
    assertEquals(BadgeOrientation.LANDSCAPE, template.orientation)

    val elements = templateWithElements.elements
    assertEquals(6, elements.size)

    // Verify all 6 required badge elements are present
    val elementTypes = elements.map { it.type }.toSet()
    assertTrue(elementTypes.contains(BadgeElementType.ATTENDEE_NAME))
    assertTrue(elementTypes.contains(BadgeElementType.JOB_TITLE))
    assertTrue(elementTypes.contains(BadgeElementType.ORGANIZATION))
    assertTrue(elementTypes.contains(BadgeElementType.EVENT_NAME))
    assertTrue(elementTypes.contains(BadgeElementType.LOGO))
    assertTrue(elementTypes.contains(BadgeElementType.QR_PLACEHOLDER))

    // Verify coordinates are normalized (0.0 to 1.0)
    elements.forEach { el ->
      assertTrue("Element ${el.type} x out of bounds: ${el.x}", el.x in 0.0f..1.0f)
      assertTrue("Element ${el.type} y out of bounds: ${el.y}", el.y in 0.0f..1.0f)
      assertTrue("Element ${el.type} width out of bounds: ${el.width}", el.width in 0.05f..1.0f)
      assertTrue("Element ${el.type} height out of bounds: ${el.height}", el.height in 0.05f..1.0f)
      assertTrue("Element ${el.type} x+width out of bounds", (el.x + el.width) <= 1.01f)
      assertTrue("Element ${el.type} y+height out of bounds", (el.y + el.height) <= 1.01f)
    }

    // Verify QR placeholder is purely a visual placeholder
    val qrElement = elements.first { it.type == BadgeElementType.QR_PLACEHOLDER }
    assertEquals("QR — Reserved", qrElement.text)
  }

  @Test
  fun `save updated template dimensions and modified elements`() = runBlocking {
    val templateId = badgeRepository.createDefaultTemplate(testEventId, "Tech Innovators 2026")
    val initial = badgeRepository.getTemplateWithElements(testEventId).first()!!

    val updatedTemplate = initial.template.copy(
      widthMm = 100f,
      heightMm = 70f,
      orientation = BadgeOrientation.PORTRAIT,
      backgroundColor = "#F1F5F9",
    )

    val updatedElements = initial.elements.map { el ->
      if (el.type == BadgeElementType.ATTENDEE_NAME) {
        el.copy(fontSize = 24f, textColor = "#0284C7", alignment = BadgeAlignment.START)
      } else {
        el
      }
    }

    badgeRepository.saveTemplate(updatedTemplate, updatedElements)

    val retrieved = badgeRepository.getTemplateWithElements(testEventId).first()!!
    assertEquals(100f, retrieved.template.widthMm)
    assertEquals(70f, retrieved.template.heightMm)
    assertEquals(BadgeOrientation.PORTRAIT, retrieved.template.orientation)
    assertEquals("#F1F5F9", retrieved.template.backgroundColor)

    val retrievedName = retrieved.elements.first { it.type == BadgeElementType.ATTENDEE_NAME }
    assertEquals(24f, retrievedName.fontSize)
    assertEquals("#0284C7", retrievedName.textColor)
    assertEquals(BadgeAlignment.START, retrievedName.alignment)
  }

  @Test
  fun `deleting template removes template and elements`() = runBlocking {
    val templateId = badgeRepository.createDefaultTemplate(testEventId, "Tech Innovators 2026")
    val before = badgeRepository.getTemplateWithElements(testEventId).first()
    assertNotNull(before)

    badgeRepository.deleteTemplate(templateId)

    val after = badgeRepository.getTemplateWithElements(testEventId).first()
    assertNull(after)
  }

  @Test
  fun `deleting event cascades to delete badge template and elements`() = runBlocking {
    badgeRepository.createDefaultTemplate(testEventId, "Tech Innovators 2026")
    assertNotNull(badgeRepository.getTemplateWithElements(testEventId).first())

    val event = eventDao.getEventById(testEventId).first()!!
    eventDao.deleteEvent(event)

    val templateAfterEventDelete = badgeRepository.getTemplateWithElements(testEventId).first()
    assertNull(templateAfterEventDelete)
  }

  @Test
  fun `preview guest remains strictly in-memory and is never persisted into Room`() = runBlocking {
    val previewGuest = PreviewGuest()
    assertEquals("Ahmed Mohammed", previewGuest.fullName)
    assertEquals("Event Manager", previewGuest.jobTitle)
    assertEquals("Evento Organization", previewGuest.organization)

    // Ensure database contains 0 guests for this event
    val guestsInDb = database.guestDao().getGuestsForEvent(testEventId).first()
    assertEquals(0, guestsInDb.size)
  }
}
