package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.EventDatabase
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.data.repository.BadgeTemplateRepositoryImpl
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepositoryImpl
import com.example.ui.screens.designer.CardDesignerViewModel
import com.example.util.qr.InMemoryQrCodeCache
import com.example.util.qr.QrCodeGeneratorImpl
import com.example.util.qr.QrPayload
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CardDesignerQrIntegrationTest {

  private val testDispatcher = StandardTestDispatcher()
  private lateinit var database: EventDatabase
  private lateinit var qrCache: InMemoryQrCodeCache
  private lateinit var qrGenerator: QrCodeGeneratorImpl

  @Before
  fun setUp() {
    Dispatchers.setMain(testDispatcher)
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    qrCache = InMemoryQrCodeCache(maxEntries = 20)
    qrGenerator = QrCodeGeneratorImpl(cache = qrCache)
  }

  @After
  fun tearDown() {
    database.close()
    Dispatchers.resetMain()
  }

  @Test
  fun `selected guest UUID becomes exact EVT1 payload`() {
    val guestUuid = UUID.randomUUID().toString()
    val guest = GuestEntity(
      eventId = 1L,
      fullName = "Alice Cooper",
      email = "alice@example.org",
      organization = "Acme Corp",
      jobTitle = "Lead Architect",
      uuid = guestUuid,
    )

    val payload = QrPayload.buildPayload(guest.uuid)

    assertEquals("EVT1:$guestUuid", payload)
    assertTrue(payload.startsWith("EVT1:"))
    assertFalse(payload.contains(guest.fullName))
    assertFalse(payload.contains(guest.email))
    assertFalse(payload.contains(guest.organization))
    assertFalse(payload.contains(guest.jobTitle))
  }

  @Test
  fun `actual QR bitmap is generated and square with high resolution`() {
    val guestUuid = UUID.randomUUID().toString()

    val bitmap = qrGenerator.generateQrBitmap(guestUuid, sizePixels = 512)

    assertNotNull("QR bitmap must be generated", bitmap)
    assertEquals(512, bitmap!!.width)
    assertEquals(512, bitmap.height)
    assertFalse("Bitmap should not be recycled", bitmap.isRecycled)
  }

  @Test
  fun `different guest UUIDs produce different QR payloads and unique QR outputs`() {
    val guestUuid1 = UUID.randomUUID().toString()
    val guestUuid2 = UUID.randomUUID().toString()

    val payload1 = QrPayload.buildPayload(guestUuid1)
    val payload2 = QrPayload.buildPayload(guestUuid2)

    assertNotEquals(payload1, payload2)

    val parse1 = QrPayload.parse(payload1)
    val parse2 = QrPayload.parse(payload2)

    assertTrue(parse1 is QrPayload.ParseResult.Success)
    assertTrue(parse2 is QrPayload.ParseResult.Success)
    assertEquals(guestUuid1, (parse1 as QrPayload.ParseResult.Success).guestUuid)
    assertEquals(guestUuid2, (parse2 as QrPayload.ParseResult.Success).guestUuid)
  }

  @Test
  fun `no personal information enters the QR payload under any circumstances`() {
    val guestUuid = UUID.randomUUID().toString()
    val personalGuest = GuestEntity(
      eventId = 10L,
      uuid = guestUuid,
      fullName = "Sarah Connor",
      email = "s.connor@cyberdyne.com",
      phone = "+1-555-0199",
      organization = "Cyberdyne Systems",
      jobTitle = "Security Officer",
      notes = "VIP badge required",
    )

    val payload = QrPayload.buildPayload(personalGuest.uuid)

    // Verify EVT1:<uuid> strict isolation
    assertEquals("EVT1:${personalGuest.uuid}", payload)
    assertFalse(payload.contains("Sarah"))
    assertFalse(payload.contains("s.connor@cyberdyne.com"))
    assertFalse(payload.contains("+1-555-0199"))
    assertFalse(payload.contains("Cyberdyne"))
    assertFalse(payload.contains("Security"))
    assertFalse(payload.contains("VIP"))

    // Verify rejection of payloads trying to inject PII
    val emailAttack = QrPayload.parse("EVT1:s.connor@cyberdyne.com")
    assertTrue(emailAttack is QrPayload.ParseResult.Invalid)

    val jsonAttack = QrPayload.parse("{\"uuid\":\"${personalGuest.uuid}\",\"name\":\"Sarah\"}")
    assertTrue(jsonAttack is QrPayload.ParseResult.Invalid)
  }

  @Test
  fun `no selected guest results in null QR bitmap and placeholder state`() = runTest {
    val badgeRepo = BadgeTemplateRepositoryImpl(database.badgeDao())
    val eventRepo = EventRepositoryImpl(database.eventDao())
    val guestRepo = GuestRepositoryImpl(database.guestDao())

    val viewModel = CardDesignerViewModel(
      badgeRepository = badgeRepo,
      eventRepository = eventRepo,
      guestRepository = guestRepo,
      qrCodeGenerator = qrGenerator,
      ioDispatcher = testDispatcher,
    )

    // Initial state: no preview guest selected
    assertNull(viewModel.selectedPreviewGuest.value)
    assertNull(viewModel.previewQrBitmap.value)

    // Select a guest
    val guest = GuestEntity(
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "John Doe",
      email = "john@example.com",
    )
    viewModel.selectPreviewGuest(guest)
    advanceUntilIdle()

    assertNotNull(viewModel.selectedPreviewGuest.value)
    assertNotNull(viewModel.previewQrBitmap.value)

    // Clear guest back to null
    viewModel.selectPreviewGuest(null)
    advanceUntilIdle()

    // Must return to null placeholder state
    assertNull(viewModel.selectedPreviewGuest.value)
    assertNull(viewModel.previewQrBitmap.value)
  }

  @Test
  fun `changing selected guest immediately updates the QR bitmap`() = runTest {
    val badgeRepo = BadgeTemplateRepositoryImpl(database.badgeDao())
    val eventRepo = EventRepositoryImpl(database.eventDao())
    val guestRepo = GuestRepositoryImpl(database.guestDao())

    val viewModel = CardDesignerViewModel(
      badgeRepository = badgeRepo,
      eventRepository = eventRepo,
      guestRepository = guestRepo,
      qrCodeGenerator = qrGenerator,
      ioDispatcher = testDispatcher,
    )

    val guest1 = GuestEntity(
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Guest One",
      email = "g1@example.com",
    )
    val guest2 = GuestEntity(
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Guest Two",
      email = "g2@example.com",
    )

    viewModel.selectPreviewGuest(guest1)
    advanceUntilIdle()
    val bitmap1 = viewModel.previewQrBitmap.value
    assertNotNull(bitmap1)

    viewModel.selectPreviewGuest(guest2)
    advanceUntilIdle()
    val bitmap2 = viewModel.previewQrBitmap.value
    assertNotNull(bitmap2)

    // Both guests have different UUIDs so both generated bitmaps are distinct
    assertNotEquals(guest1.uuid, guest2.uuid)
  }

  @Test
  fun `qr element dimensions remain strictly clamped to minimum size`() = runTest {
    val badgeRepo = BadgeTemplateRepositoryImpl(database.badgeDao())
    val eventRepo = EventRepositoryImpl(database.eventDao())
    val guestRepo = GuestRepositoryImpl(database.guestDao())

    val viewModel = CardDesignerViewModel(
      badgeRepository = badgeRepo,
      eventRepository = eventRepo,
      guestRepository = guestRepo,
      qrCodeGenerator = qrGenerator,
      ioDispatcher = testDispatcher,
    )

    // Add a QR element
    viewModel.addElement(BadgeElementType.QR)
    val qrElement = viewModel.currentElements.value.first { it.type == BadgeElementType.QR }

    // Try shrinking width and height to near zero
    viewModel.updateElementSize(qrElement.id, deltaNormalizedWidth = -0.9f, deltaNormalizedHeight = -0.9f)

    val updatedElement = viewModel.currentElements.value.first { it.id == qrElement.id }
    // Clamping rule requires at least 0.15f for QR code scannability
    assertTrue("QR width must be >= 0.15f, actual: ${updatedElement.width}", updatedElement.width >= 0.15f)
    assertTrue("QR height must be >= 0.15f, actual: ${updatedElement.height}", updatedElement.height >= 0.15f)
  }

  @Test
  fun `qr generation is deterministic and reuses cache for same guest`() {
    val guestUuid = UUID.randomUUID().toString()

    val bitmap1 = qrGenerator.generateQrBitmap(guestUuid, sizePixels = 256)
    val bitmap2 = qrGenerator.generateQrBitmap(guestUuid, sizePixels = 256)

    assertNotNull(bitmap1)
    assertNotNull(bitmap2)
    assertSame("Cached bitmap instance should be returned for same UUID", bitmap1, bitmap2)
    assertEquals(1, qrCache.size())
  }
}
