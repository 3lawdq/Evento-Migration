package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.BadgeTemplateWithElements
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.util.pdf.AndroidPdfGenerator
import com.example.util.pdf.PdfGenerationRequest
import com.example.util.pdf.PdfGenerationResult
import com.example.util.pdf.PdfPageDimensions
import com.example.util.pdf.PdfValidationResult
import com.example.util.qr.InMemoryQrCodeCache
import com.example.util.qr.QrCodeGenerator
import com.example.util.qr.QrCodeGeneratorImpl
import com.example.util.qr.QrPayload
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import java.io.OutputStream
import java.util.UUID

@Implements(PdfDocument::class)
class TestShadowPdfDocument {
  private val pages = mutableListOf<PdfDocument.PageInfo>()
  private var isClosed = false

  @Implementation
  fun __constructor__() {
    isClosed = false
  }

  @Implementation
  fun startPage(pageInfo: PdfDocument.PageInfo): PdfDocument.Page {
    if (isClosed) throw IllegalStateException("document is closed!")
    val bitmap = Bitmap.createBitmap(pageInfo.pageWidth, pageInfo.pageHeight, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val constructor = PdfDocument.Page::class.java.getDeclaredConstructor(
      Canvas::class.java,
      PdfDocument.PageInfo::class.java,
    )
    constructor.isAccessible = true
    return constructor.newInstance(canvas, pageInfo)
  }

  @Implementation
  fun finishPage(page: PdfDocument.Page) {
    if (isClosed) throw IllegalStateException("document is closed!")
    pages.add(page.info)
  }

  @Implementation
  fun writeTo(out: OutputStream) {
    if (isClosed) throw IllegalStateException("document is closed!")
    out.write("%PDF-1.4\n%Evento Badges\n".toByteArray(Charsets.UTF_8))
    out.flush()
  }

  @Implementation
  fun close() {
    isClosed = true
  }

  @Implementation
  fun getPages(): List<PdfDocument.PageInfo> = pages
}

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36], shadows = [TestShadowPdfDocument::class])
class PdfGeneratorTest {

  private lateinit var context: Context
  private lateinit var qrGenerator: QrCodeGenerator
  private lateinit var pdfGenerator: AndroidPdfGenerator

  private val testEvent = EventEntity(
    id = 100L,
    name = "Global Tech Summit 2026 / مؤتمر التقنية الدولي",
    description = "Annual Technology and AI Exhibition",
    date = "2026-10-15",
    location = "Riyadh Convention Center",
    organizer = "Evento Corp",
    status = EventStatus.ACTIVE,
  )

  private val testTemplate = BadgeTemplateEntity(
    id = 1L,
    eventId = 100L,
    name = "Standard Conference Badge",
    widthMm = 90f,
    heightMm = 60f,
    orientation = BadgeOrientation.LANDSCAPE,
    backgroundColor = "#FFFFFF",
  )

  private val testElements = listOf(
    BadgeElementEntity(
      id = 1L,
      templateId = 1L,
      type = BadgeElementType.ATTENDEE_NAME,
      x = 0.08f,
      y = 0.20f,
      width = 0.84f,
      height = 0.18f,
      fontSize = 18f,
      fontWeight = "BOLD",
      alignment = BadgeAlignment.CENTER,
      textColor = "#0F172A",
    ),
    BadgeElementEntity(
      id = 2L,
      templateId = 1L,
      type = BadgeElementType.JOB_TITLE,
      x = 0.08f,
      y = 0.40f,
      width = 0.84f,
      height = 0.12f,
      fontSize = 12f,
      alignment = BadgeAlignment.CENTER,
      textColor = "#475569",
    ),
    BadgeElementEntity(
      id = 3L,
      templateId = 1L,
      type = BadgeElementType.ORGANIZATION,
      x = 0.08f,
      y = 0.52f,
      width = 0.84f,
      height = 0.12f,
      fontSize = 12f,
      alignment = BadgeAlignment.CENTER,
      textColor = "#2563EB",
    ),
    BadgeElementEntity(
      id = 4L,
      templateId = 1L,
      type = BadgeElementType.QR,
      x = 0.35f,
      y = 0.66f,
      width = 0.30f,
      height = 0.30f,
    ),
  )

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    qrGenerator = QrCodeGeneratorImpl(InMemoryQrCodeCache())
    pdfGenerator = AndroidPdfGenerator(context, qrGenerator)
  }

  @Test
  fun testPdfPageDimensions_landscapeConversion() {
    val landscapeTemplate = testTemplate.copy(widthMm = 90f, heightMm = 60f, orientation = BadgeOrientation.LANDSCAPE)
    val dimensions = PdfPageDimensions.fromTemplate(landscapeTemplate)

    // 90mm * 72 / 25.4 ≈ 255 points, 60mm * 72 / 25.4 ≈ 170 points
    assertEquals(90f, dimensions.widthMm, 0.1f)
    assertEquals(60f, dimensions.heightMm, 0.1f)
    assertEquals(255, dimensions.widthPoints)
    assertEquals(170, dimensions.heightPoints)
  }

  @Test
  fun testPdfPageDimensions_portraitConversion() {
    val portraitTemplate = testTemplate.copy(widthMm = 90f, heightMm = 60f, orientation = BadgeOrientation.PORTRAIT)
    val dimensions = PdfPageDimensions.fromTemplate(portraitTemplate)

    // Portrait ensures width < height: 60mm width, 90mm height
    assertEquals(60f, dimensions.widthMm, 0.1f)
    assertEquals(90f, dimensions.heightMm, 0.1f)
    assertEquals(170, dimensions.widthPoints)
    assertEquals(255, dimensions.heightPoints)
  }

  @Test
  fun testValidation_validRequest() {
    val guest = GuestEntity(
      id = 1L,
      eventId = 100L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Dr. Tariq Al-Mansoor",
    )
    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, testElements),
      guests = listOf(guest),
    )

    val validation = pdfGenerator.validate(request)
    assertTrue("Validation should pass for valid request", validation is PdfValidationResult.Valid)
  }

  @Test
  fun testValidation_catchesInvalidGuestEventOwnership() {
    val foreignGuest = GuestEntity(
      id = 2L,
      eventId = 999L, // Different event!
      uuid = UUID.randomUUID().toString(),
      fullName = "Foreign Attendee",
    )
    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, testElements),
      guests = listOf(foreignGuest),
    )

    val validation = pdfGenerator.validate(request)
    assertTrue(validation is PdfValidationResult.Invalid)
    val reason = (validation as PdfValidationResult.Invalid).reason
    assertTrue(reason.contains("do not belong to event"))
  }

  @Test
  fun testValidation_catchesEmptyGuests() {
    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, testElements),
      guests = emptyList(),
    )

    val validation = pdfGenerator.validate(request)
    assertTrue(validation is PdfValidationResult.Invalid)
    val reason = (validation as PdfValidationResult.Invalid).reason
    assertTrue(reason.contains("No guests selected"))
  }

  @Test
  fun testValidation_catchesInvalidTemplateDimensions() {
    val invalidTemplate = testTemplate.copy(widthMm = 5f, heightMm = 5f)
    val guest = GuestEntity(
      id = 1L,
      eventId = 100L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Valid Guest",
    )
    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(invalidTemplate, testElements),
      guests = listOf(guest),
    )

    val validation = pdfGenerator.validate(request)
    assertTrue(validation is PdfValidationResult.Invalid)
    val reason = (validation as PdfValidationResult.Invalid).reason
    assertTrue(reason.contains("dimensions") && reason.contains("invalid"))
  }

  @Test
  fun testValidation_catchesTooSmallQrElement() {
    val tinyQrElements = listOf(
      BadgeElementEntity(
        id = 10L,
        templateId = 1L,
        type = BadgeElementType.QR,
        x = 0.1f,
        y = 0.1f,
        width = 0.05f, // Less than 0.10f minimum
        height = 0.05f,
      ),
    )
    val guest = GuestEntity(
      id = 1L,
      eventId = 100L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Valid Guest",
    )
    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, tinyQrElements),
      guests = listOf(guest),
    )

    val validation = pdfGenerator.validate(request)
    assertTrue(validation is PdfValidationResult.Invalid)
    val reason = (validation as PdfValidationResult.Invalid).reason
    assertTrue(reason.contains("QR code element is too small"))
  }

  @Test
  fun testGenerateBadges_singleGuest_success() = runTest {
    val guestUuid = UUID.randomUUID().toString()
    val guest = GuestEntity(
      id = 1L,
      eventId = 100L,
      uuid = guestUuid,
      fullName = "Jane Doe",
      jobTitle = "Lead Architect",
      organization = "Acme Cloud",
      invitationStatus = InvitationStatus.CONFIRMED,
    )

    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, testElements),
      guests = listOf(guest),
    )

    var progressCalls = 0
    val result = pdfGenerator.generateBadges(request) { curr, total ->
      progressCalls++
      assertEquals(1, curr)
      assertEquals(1, total)
    }

    if (result is PdfGenerationResult.Error) {
      result.cause?.printStackTrace()
    }
    assertTrue("Result should be Success but was: $result", result is PdfGenerationResult.Success)
    val success = result as PdfGenerationResult.Success
    assertEquals(1, success.pageCount)
    assertTrue(success.file.exists())
    assertTrue(success.fileSizeInBytes > 0)
    assertTrue(progressCalls > 0)
  }

  @Test
  fun testGenerateBadges_multipleGuests_matchesPageCount() = runTest {
    val guestCount = 5
    val guests = (1..guestCount).map { i ->
      GuestEntity(
        id = i.toLong(),
        eventId = 100L,
        uuid = UUID.randomUUID().toString(),
        fullName = "Guest Number $i",
        organization = "Org $i",
      )
    }

    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, testElements),
      guests = guests,
    )

    var reportedTotal = 0
    val result = pdfGenerator.generateBadges(request) { curr, total ->
      reportedTotal = total
    }

    assertTrue(result is PdfGenerationResult.Success)
    val success = result as PdfGenerationResult.Success
    assertEquals(guestCount, success.pageCount)
    assertEquals(guestCount, reportedTotal)
    assertTrue(success.file.exists())
    assertTrue(success.fileSizeInBytes > 0)
  }

  @Test
  fun testGenerateBadges_arabicAndBilingualText_doesNotCrash() = runTest {
    val arabicGuest = GuestEntity(
      id = 77L,
      eventId = 100L,
      uuid = UUID.randomUUID().toString(),
      fullName = "م. سارة إبراهيم القحطاني",
      jobTitle = "مديرة التحول الرقمي والتطوير",
      organization = "هيئة التقنية والأمن السيبراني",
      invitationStatus = InvitationStatus.CONFIRMED,
    )

    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, testElements),
      guests = listOf(arabicGuest),
    )

    val result = pdfGenerator.generateBadges(request)
    assertTrue("Arabic badges must generate cleanly without crashing", result is PdfGenerationResult.Success)
    val success = result as PdfGenerationResult.Success
    assertEquals(1, success.pageCount)
  }

  @Test
  fun testGenerateBadges_missingAndNullFields_handledSafelyWithoutNpe() = runTest {
    val sparseGuest = GuestEntity(
      id = 88L,
      eventId = 100L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Minimal Guest",
      jobTitle = "",
      organization = "",
      notes = "",
    )

    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, testElements),
      guests = listOf(sparseGuest),
    )

    val result = pdfGenerator.generateBadges(request)
    assertTrue("Missing fields must be handled safely without NPE", result is PdfGenerationResult.Success)
  }

  @Test
  fun testQrCodeGenerator_deterministicEvt1PayloadUsedInPdf() = runTest {
    val guestUuid = UUID.randomUUID().toString()
    val guest = GuestEntity(
      id = 99L,
      eventId = 100L,
      uuid = guestUuid,
      fullName = "QR Test Guest",
    )

    var recordedPayload: String? = null
    val recordingQrGenerator = object : QrCodeGenerator {
      override fun generateQrBitmap(guestUuid: String, sizePixels: Int): Bitmap? {
        recordedPayload = QrPayload.buildPayload(guestUuid)
        return Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
      }
    }

    val customPdfGen = AndroidPdfGenerator(context, recordingQrGenerator)
    val request = PdfGenerationRequest(
      event = testEvent,
      templateWithElements = BadgeTemplateWithElements(testTemplate, testElements),
      guests = listOf(guest),
    )

    val result = customPdfGen.generateBadges(request)
    assertTrue(result is PdfGenerationResult.Success)

    assertNotNull("QR Generator must have been invoked", recordedPayload)
    assertEquals("EVT1:$guestUuid", recordedPayload)
    assertTrue("QR payload must not contain PII", !recordedPayload!!.contains("QR Test Guest"))
  }
}
