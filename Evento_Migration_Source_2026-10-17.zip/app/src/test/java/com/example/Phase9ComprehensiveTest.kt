package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.local.EventDatabase
import com.example.data.local.dao.BadgeDao
import com.example.data.local.dao.EventDao
import com.example.data.local.dao.GuestDao
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.BadgeTemplateWithElements
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.data.repository.BadgeTemplateRepository
import com.example.data.repository.BadgeTemplateRepositoryImpl
import com.example.data.repository.CapacityUpdateResult
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.util.pdf.AndroidPdfGenerator
import com.example.util.pdf.PdfGenerationRequest
import com.example.util.pdf.PdfGenerationResult
import com.example.util.pdf.PdfLayoutConfig
import com.example.util.pdf.PdfPageDimensions
import com.example.util.pdf.PdfPaperSize
import com.example.util.pdf.PdfValidationResult
import com.example.util.qr.QrPayload
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.util.UUID
import kotlin.math.ceil

@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36], shadows = [TestShadowPdfDocument::class])
class Phase9ComprehensiveTest {

  private lateinit var context: Context
  private lateinit var database: EventDatabase
  private lateinit var eventDao: EventDao
  private lateinit var guestDao: GuestDao
  private lateinit var badgeDao: BadgeDao
  private lateinit var eventRepository: EventRepository
  private lateinit var badgeRepository: BadgeTemplateRepository

  private lateinit var pdfGenerator: AndroidPdfGenerator

  @Before
  fun setUp() = runBlocking {
    context = ApplicationProvider.getApplicationContext()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()

    eventDao = database.eventDao()
    guestDao = database.guestDao()
    badgeDao = database.badgeDao()

    eventRepository = EventRepositoryImpl(eventDao, database)
    badgeRepository = BadgeTemplateRepositoryImpl(badgeDao)

    pdfGenerator = AndroidPdfGenerator(context)
  }

  @After
  fun tearDown() {
    database.close()
  }

  // =========================================================================
  // Area A: GUEST CAPACITY & EMPTY SLOTS
  // =========================================================================

  @Test
  fun testGuestCapacity_defaultsToZero() = runBlocking {
    val id = eventRepository.createEvent(
      name = "Default Capacity Event",
      description = "Test Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
    )
    val saved = eventRepository.getEventById(id).first()

    assertNotNull(saved)
    assertEquals("Default capacity should be 0", 0, saved!!.guestCapacity)
  }

  @Test
  fun testGuestCapacity_slotCreation_createsExactSlotsWithUniqueUuids() = runBlocking {
    val targetCapacity = 25
    val eventId = eventRepository.createEvent(
      name = "Capacity Event",
      description = "Test Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
      guestCapacity = targetCapacity,
      autoCreateSlots = true,
    )

    val guests = guestDao.getGuestsForEvent(eventId).first()
    assertEquals(targetCapacity, guests.size)

    val uuids = guests.map { it.uuid }
    assertEquals("All UUIDs must be unique", targetCapacity, uuids.distinct().size)

    for (guest in guests) {
      assertTrue("Must be empty slot", guest.isEmptySlot)
      assertTrue("Must have valid cryptographic UUID", QrPayload.isValidUuid(guest.uuid))
      assertEquals(eventId, guest.eventId)
      assertEquals("", guest.fullName)
      assertEquals(InvitationStatus.INVITED, guest.invitationStatus)
    }
  }

  @Test
  fun testGuestCapacity_emptyGuestSlotState() {
    val emptyGuest = GuestEntity(
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "   ",
    )
    assertTrue("Guest with blank name is an empty slot", emptyGuest.isEmptySlot)

    val filledGuest = GuestEntity(
      eventId = 1L,
      uuid = UUID.randomUUID().toString(),
      fullName = "Dr. Alice Smith",
    )
    assertFalse("Guest with non-blank name is not an empty slot", filledGuest.isEmptySlot)
  }

  @Test
  fun testGuestCapacity_capacityIncrease_appendsNewEmptySlots() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Scalable Event",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
      guestCapacity = 5,
      autoCreateSlots = true,
    )
    assertEquals(5, guestDao.getGuestsForEvent(eventId).first().size)

    val result = eventRepository.updateEventCapacity(eventId, 12)
    assertTrue(result is CapacityUpdateResult.Success)

    val updatedGuests = guestDao.getGuestsForEvent(eventId).first()
    assertEquals(12, updatedGuests.size)
    assertEquals(12, updatedGuests.map { it.uuid }.distinct().size)

    val updatedEvent = eventRepository.getEventById(eventId).first()
    assertEquals(12, updatedEvent!!.guestCapacity)
  }

  @Test
  fun testGuestCapacity_capacityReductionSafePath_removesOnlyEmptySlots() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Reduction Event",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
      guestCapacity = 6,
      autoCreateSlots = true,
    )
    val originalGuests = guestDao.getGuestsForEvent(eventId).first()

    // Populate first 2 guests
    val g1 = originalGuests[0].copy(fullName = "Attendee One", email = "one@test.com")
    val g2 = originalGuests[1].copy(fullName = "Attendee Two", email = "two@test.com")
    guestDao.updateGuest(g1)
    guestDao.updateGuest(g2)

    // Reduce capacity from 6 to 3 (safe, because filled guests = 2 <= 3)
    val result = eventRepository.updateEventCapacity(eventId, 3)
    assertTrue(result is CapacityUpdateResult.Success)

    val remainingGuests = guestDao.getGuestsForEvent(eventId).first()
    assertEquals(3, remainingGuests.size)

    // Populated guests must be preserved with exact UUIDs and details
    val foundG1 = remainingGuests.find { it.id == g1.id }
    val foundG2 = remainingGuests.find { it.id == g2.id }
    assertNotNull(foundG1)
    assertNotNull(foundG2)
    assertEquals(g1.uuid, foundG1!!.uuid)
    assertEquals("Attendee One", foundG1.fullName)
    assertEquals(g2.uuid, foundG2!!.uuid)
    assertEquals("Attendee Two", foundG2.fullName)
  }

  @Test
  fun testGuestCapacity_capacityReductionBlockedPath_rejectsWhenPopulatedExceedsNewCapacity() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Blocked Reduction Event",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
      guestCapacity = 5,
      autoCreateSlots = true,
    )
    val originalGuests = guestDao.getGuestsForEvent(eventId).first()

    // Populate 4 guests
    for (i in 0 until 4) {
      guestDao.updateGuest(originalGuests[i].copy(fullName = "Attendee $i"))
    }

    // Attempt to reduce capacity to 2 (must be blocked because 4 guests are populated)
    val result = eventRepository.updateEventCapacity(eventId, 2)
    assertTrue("Reduction must be blocked", result is CapacityUpdateResult.Blocked)
    val blocked = result as CapacityUpdateResult.Blocked
    assertEquals(4, blocked.filledCount)
    assertEquals(2, blocked.requestedCapacity)

    // State must be unmodified
    val afterGuests = guestDao.getGuestsForEvent(eventId).first()
    assertEquals(5, afterGuests.size)
    val eventAfter = eventRepository.getEventById(eventId).first()
    assertEquals(5, eventAfter!!.guestCapacity)
  }

  @Test
  fun testGuestCapacity_crossEventCapacityIsolation() = runBlocking {
    val eventA = eventRepository.createEvent(
      name = "Event A",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
      guestCapacity = 10,
      autoCreateSlots = true,
    )
    val eventB = eventRepository.createEvent(
      name = "Event B",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall B",
      organizer = "Org",
      guestCapacity = 5,
      autoCreateSlots = true,
    )

    // Update Event A capacity
    eventRepository.updateEventCapacity(eventA, 20)

    val guestsA = guestDao.getGuestsForEvent(eventA).first()
    val guestsB = guestDao.getGuestsForEvent(eventB).first()

    assertEquals(20, guestsA.size)
    assertEquals(5, guestsB.size)
    assertTrue(guestsA.none { it.eventId == eventB })
    assertTrue(guestsB.none { it.eventId == eventA })
  }

  // =========================================================================
  // Area B & C & D: CARD DESIGNER, BACKGROUNDS, MULTIPLE TEMPLATES & DRAG
  // =========================================================================

  @Test
  fun testCardDesigner_backgroundImagePersistence_replacementAndRemoval() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Badge Event",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
    )
    val template = BadgeTemplateEntity(
      eventId = eventId,
      name = "Main Template",
      widthMm = 85.6f,
      heightMm = 53.98f,
      backgroundImageUri = "content://media/external/images/bg1.png",
      isActive = true,
    )
    val templateId = badgeRepository.saveTemplate(template, emptyList())

    val fetched = badgeRepository.getTemplateWithElementsById(templateId).first()
    assertNotNull(fetched)
    assertEquals("content://media/external/images/bg1.png", fetched!!.template.backgroundImageUri)

    // Replace background
    val replaced = fetched.template.copy(backgroundImageUri = "content://media/external/images/bg2.png")
    badgeRepository.saveTemplate(replaced, emptyList())
    val fetchedReplaced = badgeRepository.getTemplateWithElementsById(templateId).first()
    assertEquals("content://media/external/images/bg2.png", fetchedReplaced!!.template.backgroundImageUri)

    // Remove background
    val removed = fetchedReplaced.template.copy(backgroundImageUri = null)
    badgeRepository.saveTemplate(removed, emptyList())
    val fetchedRemoved = badgeRepository.getTemplateWithElementsById(templateId).first()
    assertNull(fetchedRemoved!!.template.backgroundImageUri)
  }

  @Test
  fun testCardDesigner_multipleTemplates_creationDuplicationActiveSelectionAndDeletion() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Multi Template Event",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
    )

    // 1. Create first template
    val t1Id = badgeRepository.createTemplate(eventId = eventId, name = "Template 1", setActive = true)

    // 2. Create second template
    val t2Id = badgeRepository.createTemplate(eventId = eventId, name = "Template 2", setActive = false)

    val templates = badgeRepository.getTemplatesForEvent(eventId).first()
    assertEquals(2, templates.size)

    // 3. Active selection: Set Template 2 as active
    badgeRepository.setActiveTemplate(eventId, t2Id)
    val activeTemplatesAfter = badgeRepository.getTemplatesForEvent(eventId).first()
    val active = activeTemplatesAfter.find { it.isActive }
    assertNotNull(active)
    assertEquals(t2Id, active!!.id)
    assertFalse(activeTemplatesAfter.find { it.id == t1Id }!!.isActive)

    // 4. Duplicate Template 2
    val dupId = badgeRepository.duplicateTemplate(t2Id, "Template 2 Copy")
    assertTrue(dupId > 0)
    val templatesAfterDup = badgeRepository.getTemplatesForEvent(eventId).first()
    assertEquals(3, templatesAfterDup.size)

    // 5. Delete Template 1
    badgeRepository.deleteTemplate(t1Id)
    val templatesAfterDelete = badgeRepository.getTemplatesForEvent(eventId).first()
    assertEquals(2, templatesAfterDelete.size)
    assertNull(templatesAfterDelete.find { it.id == t1Id })
  }

  @Test
  fun testCardDesigner_horizontalDragDirection_independentOfAmbientRtl() {
    // Verifies the math of deltaNormalizedX calculation:
    // With LTR coordinates, deltaX > 0 increases X (moves RIGHT), deltaX < 0 decreases X (moves LEFT).
    val startX = 0.5f
    val elementWidth = 0.2f

    val deltaRight = 0.1f
    val newXRight = (startX + deltaRight).coerceIn(0f, 1f - elementWidth)
    assertEquals(0.6f, newXRight, 0.001f)
    assertTrue("Positive delta moves element right", newXRight > startX)

    val deltaLeft = -0.1f
    val newXLeft = (startX + deltaLeft).coerceIn(0f, 1f - elementWidth)
    assertEquals(0.4f, newXLeft, 0.001f)
    assertTrue("Negative delta moves element left", newXLeft < startX)
  }

  // =========================================================================
  // Area E & F & G: PDF MULTI-CARD ENGINE, PAPER SIZES, ORIENTATIONS & PAGINATION
  // =========================================================================

  @Test
  fun testPdfMultiCard_paperSizeDimensions_A4_A5_Letter() {
    // A4: 210 × 297 mm
    assertEquals(210f, PdfPaperSize.A4.widthMm, 0.1f)
    assertEquals(297f, PdfPaperSize.A4.heightMm, 0.1f)

    // A5: 148 × 210 mm
    assertEquals(148f, PdfPaperSize.A5.widthMm, 0.1f)
    assertEquals(210f, PdfPaperSize.A5.heightMm, 0.1f)

    // US Letter: 215.9 × 279.4 mm
    assertEquals(215.9f, PdfPaperSize.US_LETTER.widthMm, 0.1f)
    assertEquals(279.4f, PdfPaperSize.US_LETTER.heightMm, 0.1f)
  }

  @Test
  fun testPdfMultiCard_paperOrientation_swapsWidthAndHeightProperly() {
    val portraitA4 = PdfLayoutConfig(paperSize = PdfPaperSize.A4, orientation = BadgeOrientation.PORTRAIT)
    assertEquals(210f, portraitA4.effectivePaperWidthMm(), 0.1f)
    assertEquals(297f, portraitA4.effectivePaperHeightMm(), 0.1f)

    val landscapeA4 = PdfLayoutConfig(paperSize = PdfPaperSize.A4, orientation = BadgeOrientation.LANDSCAPE)
    assertEquals(297f, landscapeA4.effectivePaperWidthMm(), 0.1f)
    assertEquals(210f, landscapeA4.effectivePaperHeightMm(), 0.1f)

    val portraitDim = PdfPageDimensions.fromPaperSize(PdfPaperSize.A4, BadgeOrientation.PORTRAIT)
    val landscapeDim = PdfPageDimensions.fromPaperSize(PdfPaperSize.A4, BadgeOrientation.LANDSCAPE)
    assertTrue(portraitDim.heightPoints > portraitDim.widthPoints)
    assertTrue(landscapeDim.widthPoints > landscapeDim.heightPoints)
  }

  @Test
  fun testPdfMultiCard_paginationAndSequentialOrder_500Guests3x3Grid() = runBlocking {
    val event = EventEntity(
      id = 500L,
      name = "Mega Summit 500",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
    )
    val template = BadgeTemplateEntity(
      id = 1L,
      eventId = 500L,
      name = "Badge",
      widthMm = 60f,
      heightMm = 40f,
      orientation = BadgeOrientation.LANDSCAPE,
    )
    val elements = listOf(
      BadgeElementEntity(
        id = 1L,
        templateId = 1L,
        type = BadgeElementType.ATTENDEE_NAME,
        x = 0.05f,
        y = 0.1f,
        width = 0.6f,
        height = 0.3f,
      ),
      BadgeElementEntity(
        id = 2L,
        templateId = 1L,
        type = BadgeElementType.QR,
        x = 0.7f,
        y = 0.1f,
        width = 0.25f,
        height = 0.25f,
      ),
    )

    val totalGuests = 500
    val guests = (1..totalGuests).map { i ->
      GuestEntity(
        id = i.toLong(),
        eventId = 500L,
        uuid = UUID.randomUUID().toString(),
        fullName = "Guest #$i",
      )
    }

    // 3 cols × 3 rows = 9 cards/page on A3 landscape
    val layout = PdfLayoutConfig(
      paperSize = PdfPaperSize.A3,
      orientation = BadgeOrientation.LANDSCAPE,
      columns = 3,
      rows = 3,
      marginTopMm = 10f,
      marginBottomMm = 10f,
      marginLeftMm = 10f,
      marginRightMm = 10f,
      spacingHorizontalMm = 5f,
      spacingVerticalMm = 5f,
    )
    assertEquals(9, layout.badgesPerPage)

    // 500 / 9 = 55.55 -> 56 pages
    val expectedPages = ceil(500f / 9f).toInt()
    assertEquals(56, expectedPages)

    val request = PdfGenerationRequest(
      event = event,
      templateWithElements = BadgeTemplateWithElements(template, elements),
      guests = guests,
      layoutConfig = layout,
    )

    val validation = pdfGenerator.validate(request)
    assertEquals(PdfValidationResult.Valid, validation)

    var processedCount = 0
    val result = pdfGenerator.generateBadges(request) { curr, _ ->
      processedCount = curr
    }

    assertTrue(result is PdfGenerationResult.Success)
    val success = result as PdfGenerationResult.Success
    assertEquals(56, success.pageCount)
    assertEquals(500, processedCount)
  }

  @Test
  fun testPdfMultiCard_zeroMarginsOption() {
    val zeroLayout = PdfLayoutConfig(
      paperSize = PdfPaperSize.A4,
      columns = 2,
      rows = 4,
      marginTopMm = 0f,
      marginBottomMm = 0f,
      marginLeftMm = 0f,
      marginRightMm = 0f,
      spacingHorizontalMm = 0f,
      spacingVerticalMm = 0f,
    )

    // With 2 cols × 4 rows and zero margins:
    // Total width = 2 × 85.6mm = 171.2mm <= 210mm (fits)
    // Total height = 4 × 53.98mm = 215.92mm <= 297mm (fits)
    assertTrue("Zero margins grid must fit", zeroLayout.fitsOnPage(85.6f, 53.98f))
  }

  @Test
  fun testPdfMultiCard_overflowDetection_rejectsWhenGridExceedsPaper() {
    val hugeLayout = PdfLayoutConfig(
      paperSize = PdfPaperSize.A5, // 148 × 210 mm
      columns = 4,
      rows = 6,
      marginTopMm = 10f,
      marginBottomMm = 10f,
      marginLeftMm = 10f,
      marginRightMm = 10f,
      spacingHorizontalMm = 5f,
      spacingVerticalMm = 5f,
    )

    // 4 cols of 85.6mm card = 342.4mm, which exceeds A5 width (148mm)
    assertFalse("Grid exceeds A5 dimensions", hugeLayout.fitsOnPage(85.6f, 53.98f))

    val event = EventEntity(
      id = 1L,
      name = "Overflow Event",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
    )
    val template = BadgeTemplateEntity(eventId = 1L, name = "Standard", widthMm = 85.6f, heightMm = 53.98f)
    val guest = GuestEntity(eventId = 1L, uuid = UUID.randomUUID().toString(), fullName = "John")

    val request = PdfGenerationRequest(
      event = event,
      templateWithElements = BadgeTemplateWithElements(template, emptyList()),
      guests = listOf(guest),
      layoutConfig = hugeLayout,
    )

    val validation = pdfGenerator.validate(request)
    assertTrue("Validation must report grid exceeds page dimensions", validation is PdfValidationResult.Invalid)
  }

  @Test
  fun testPdfMultiCard_a4_a5_letter_allGenerateSuccessfully() = runBlocking {
    val event = EventEntity(
      id = 200L,
      name = "Multi Paper Event",
      description = "Desc",
      date = "2026-09-20",
      location = "Hall A",
      organizer = "Org",
    )
    val template = BadgeTemplateEntity(id = 1L, eventId = 200L, widthMm = 85.6f, heightMm = 53.98f)
    val guests = listOf(
      GuestEntity(id = 1L, eventId = 200L, uuid = UUID.randomUUID().toString(), fullName = "Guest 1"),
      GuestEntity(id = 2L, eventId = 200L, uuid = UUID.randomUUID().toString(), fullName = "Guest 2"),
    )

    val papers = listOf(PdfPaperSize.A4, PdfPaperSize.A5, PdfPaperSize.US_LETTER)

    for (paper in papers) {
      val layout = PdfLayoutConfig(
        paperSize = paper,
        columns = 1,
        rows = 2,
        marginTopMm = 10f,
        marginBottomMm = 10f,
        marginLeftMm = 10f,
        marginRightMm = 10f,
      )

      val request = PdfGenerationRequest(
        event = event,
        templateWithElements = BadgeTemplateWithElements(template, emptyList()),
        guests = guests,
        layoutConfig = layout,
      )

      val result = pdfGenerator.generateBadges(request)
      assertTrue("Generation must succeed for paper size ${paper.displayName}", result is PdfGenerationResult.Success)
      val success = result as PdfGenerationResult.Success
      assertEquals("2 badges in 1x2 grid should take 1 page", 1, success.pageCount)
    }
  }
}
