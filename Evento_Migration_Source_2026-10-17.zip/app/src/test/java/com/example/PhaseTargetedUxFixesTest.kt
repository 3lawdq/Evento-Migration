package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.local.EventDatabase
import com.example.data.local.dao.EventDao
import com.example.data.local.dao.GuestDao
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.data.model.GuestDataQualityEvaluator
import com.example.data.model.GuestQualityField
import com.example.data.model.InvitationStatus
import com.example.data.repository.CapacityUpdateResult
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepository
import com.example.data.repository.GuestRepositoryImpl
import com.example.ui.screens.events.EventFormMode
import com.example.ui.screens.events.EventFormState
import com.example.ui.screens.events.EventsViewModel
import com.example.ui.screens.guests.GuestFormData
import com.example.ui.screens.guests.GuestsViewModel
import com.example.util.pdf.PdfLayoutConfig
import com.example.util.pdf.PdfPaperSize
import com.example.util.qr.QrPayload
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(AndroidJUnit4::class)
@Config(sdk = [34])
class PhaseTargetedUxFixesTest {

  private lateinit var context: Context
  private lateinit var database: EventDatabase
  private lateinit var eventDao: EventDao
  private lateinit var guestDao: GuestDao
  private lateinit var eventRepository: EventRepository
  private lateinit var guestRepository: GuestRepository

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    database = Room.inMemoryDatabaseBuilder(context, EventDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    eventDao = database.eventDao()
    guestDao = database.guestDao()
    eventRepository = EventRepositoryImpl(eventDao, database, context)
    guestRepository = GuestRepositoryImpl(guestDao, database)
  }

  @After
  fun tearDown() {
    database.close()
  }

  // =========================================================================
  // FIX 1 — Event Guest Capacity Pre-creates Guest Slots & Expands on Extra Guest
  // =========================================================================

  @Test
  fun testCreateEvent_withCapacity500_preCreates500EmptySlotsWithUniqueUuidsAndArabicFormat() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Grand Gala",
      description = "Annual gala dinner",
      date = "2026-10-15",
      location = "Riyadh Exhibition Center",
      organizer = "Evento Team",
      status = EventStatus.ACTIVE,
      guestCapacity = 500,
      autoCreateSlots = true,
      slotNameFormat = "ضيف %03d",
    )

    val guests = guestDao.getGuestsForEvent(eventId).first()
    assertEquals("Must pre-create exactly 500 guest slots", 500, guests.size)

    val uuids = guests.map { it.uuid }
    assertEquals("All 500 slots must have globally unique UUIDs", 500, uuids.distinct().size)

    for (guest in guests) {
      assertTrue("UUID must be a valid cryptographic UUID", QrPayload.isValidUuid(guest.uuid))
      assertEquals(eventId, guest.eventId)
      assertTrue("Guest must be evaluated as an empty slot", guest.isEmptySlot)

      val quality = GuestDataQualityEvaluator.evaluateGuest(guest)
      assertTrue("Quality evaluator must flag placeholder as empty slot", quality.isEmptySlot)
      assertFalse("Placeholder slot must not be marked complete", quality.isComplete)
      assertTrue("Placeholder name must not count as completed full name", quality.missingFields.contains(GuestQualityField.FULL_NAME))
    }

    // Check localized placeholder naming sequence
    val sortedGuests = guests.sortedBy { it.id }
    assertEquals("ضيف 001", sortedGuests[0].fullName)
    assertEquals("ضيف 002", sortedGuests[1].fullName)
    assertEquals("ضيف 500", sortedGuests[499].fullName)
  }

  @Test
  fun testCreateEvent_withCapacity_preCreatesSlotsWithEnglishFormat() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Tech Summit",
      description = "Keynote & Networking",
      date = "2026-11-20",
      location = "Main Auditorium",
      organizer = "Summit Org",
      status = EventStatus.ACTIVE,
      guestCapacity = 10,
      autoCreateSlots = true,
      slotNameFormat = "Guest %03d",
    )

    val guests = guestDao.getGuestsForEvent(eventId).first().sortedBy { it.id }
    assertEquals(10, guests.size)
    assertEquals("Guest 001", guests[0].fullName)
    assertEquals("Guest 010", guests[9].fullName)
    for (guest in guests) {
      assertTrue(guest.isEmptySlot)
      val eval = GuestDataQualityEvaluator.evaluateGuest(guest)
      assertTrue(eval.isEmptySlot)
    }
  }

  @Test
  fun testPlaceholderSlot_convertsInPlaceWhenEditedWithRealData_preservingUuid() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Exclusive Dinner",
      description = "VIP Dinner",
      date = "2026-12-01",
      location = "VIP Hall",
      organizer = "Organizer",
      guestCapacity = 5,
      autoCreateSlots = true,
      slotNameFormat = "ضيف %03d",
    )

    val initialSlots = guestDao.getGuestsForEvent(eventId).first().sortedBy { it.id }
    val slotToEdit = initialSlots[0]
    val originalUuid = slotToEdit.uuid

    // User edits ضيف 001 into Ahmed Ali
    val updatedGuest = slotToEdit.copy(
      fullName = "Ahmed Ali",
      email = "ahmed.ali@example.com",
      phone = "+966500000001",
      organization = "Ministry of Events",
      jobTitle = "Director General",
      invitationStatus = InvitationStatus.CONFIRMED,
    )
    guestRepository.updateGuest(updatedGuest)

    val fetched = guestRepository.getGuestByIdSync(slotToEdit.id)
    assertNotNull(fetched)
    assertEquals("UUID must remain identical and preserved across edits", originalUuid, fetched!!.uuid)
    assertEquals("Ahmed Ali", fetched.fullName)
    assertFalse("Completed guest must no longer be an empty slot", fetched.isEmptySlot)

    val eval = GuestDataQualityEvaluator.evaluateGuest(fetched)
    assertFalse("Must not be flagged as empty slot", eval.isEmptySlot)
    assertTrue("Must be marked complete when all fields provided", eval.isComplete)
    assertTrue(eval.missingFields.isEmpty())

    // Verify summary: 1 completed, 4 empty slots
    val allGuests = guestDao.getGuestsForEvent(eventId).first()
    val summary = GuestDataQualityEvaluator.summarize(allGuests)
    assertEquals(5, summary.totalRecords)
    assertEquals(4, summary.emptySlotsCount)
    assertEquals(1, summary.registeredGuestsCount)
    assertEquals(1, summary.completeGuestsCount)
    assertEquals(0, summary.incompleteGuestsCount)
  }

  @Test
  fun testAddGuest_beyondInitialCapacity_incrementsEventCapacitySafely() = runBlocking {
    val eventId = eventRepository.createEvent(
      name = "Capped Conference",
      description = "Conference",
      date = "2026-10-30",
      location = "Hall B",
      organizer = "Organizer",
      guestCapacity = 3,
      autoCreateSlots = true,
      slotNameFormat = "Guest %03d",
    )

    var event = eventRepository.getEventByIdSync(eventId)
    assertNotNull(event)
    assertEquals(3, event!!.guestCapacity)
    var guests = guestDao.getGuestsForEvent(eventId).first()
    assertEquals(3, guests.size)

    // Add an extra guest beyond capacity (3 -> 4)
    val extraGuestId = guestRepository.createGuest(
      eventId = eventId,
      fullName = "Extra Guest 4",
      email = "extra4@test.com",
      phone = "123456",
      organization = "Extra Org",
      jobTitle = "Specialist",
    )
    assertTrue("Extra guest ID must be valid", extraGuestId > 0)

    val updatedGuests = guestDao.getGuestsForEvent(eventId).first()
    assertEquals("Total guests should now be 4", 4, updatedGuests.size)

    event = eventRepository.getEventByIdSync(eventId)
    assertNotNull(event)
    assertEquals("Event capacity must automatically increase to accommodate extra guest", 4, event!!.guestCapacity)
  }

  // =========================================================================
  // FIX 3 — Unified Page Margin Control & Engine Preservation
  // =========================================================================

  @Test
  fun testPdfMargins_zeroMarginStateAndEngineCompatibility() {
    val defaultConfig = PdfLayoutConfig(
      paperSize = PdfPaperSize.A4,
      orientation = BadgeOrientation.PORTRAIT,
      columns = 2,
      rows = 4,
      marginTopMm = 10f,
      marginBottomMm = 10f,
      marginLeftMm = 10f,
      marginRightMm = 10f,
      spacingHorizontalMm = 5f,
      spacingVerticalMm = 5f,
    )

    // Standard card: 85.6mm x 53.98mm
    val fitsWithStandardMargins = defaultConfig.fitsOnPage(85.6f, 53.98f)
    assertTrue("Should fit with 10mm margins", fitsWithStandardMargins)

    // Zero-margin state
    val zeroMarginConfig = defaultConfig.copy(
      marginTopMm = 0f,
      marginBottomMm = 0f,
      marginLeftMm = 0f,
      marginRightMm = 0f,
      spacingHorizontalMm = 0f,
      spacingVerticalMm = 0f,
    )

    assertEquals(0f, zeroMarginConfig.marginTopMm, 0.001f)
    assertEquals(0f, zeroMarginConfig.marginBottomMm, 0.001f)
    assertEquals(0f, zeroMarginConfig.marginLeftMm, 0.001f)
    assertEquals(0f, zeroMarginConfig.marginRightMm, 0.001f)
    assertTrue("Should fit comfortably with 0mm margins", zeroMarginConfig.fitsOnPage(85.6f, 53.98f))

    // Test slider value bounds (0mm minimum to 40mm)
    val sliderValue = 25f.coerceIn(0f, 40f)
    val updatedMarginConfig = defaultConfig.copy(
      marginTopMm = sliderValue,
      marginBottomMm = sliderValue,
      marginLeftMm = sliderValue,
      marginRightMm = sliderValue,
    )
    assertEquals(25f, updatedMarginConfig.marginTopMm, 0.001f)
    assertEquals(25f, updatedMarginConfig.marginLeftMm, 0.001f)
  }
}
