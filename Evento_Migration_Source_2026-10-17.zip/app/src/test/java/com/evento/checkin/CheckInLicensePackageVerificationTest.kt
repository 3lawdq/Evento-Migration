package com.evento.checkin

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.util.packageexport.EVENTO_HASH_ALGORITHM
import com.example.util.packageexport.EVENTO_PACKAGE_FORMAT_VERSION
import com.example.util.packageexport.EVENTO_PACKAGE_FORMAT_VERSION_V1
import com.example.util.packageexport.EVENTO_PACKAGE_TYPE
import com.example.util.packageexport.EVENTO_QR_PAYLOAD_FORMAT
import com.example.util.packageexport.EVENTO_SIGNATURE_VERSION_V2
import com.example.util.packageexport.EventPackageExportRequest
import com.example.util.packageexport.EventoPackageBuilder
import com.example.util.packageexport.EventoPackageCanonicalizer
import com.example.util.packageexport.EventoPackageEvent
import com.example.util.packageexport.EventoPackageGuest
import com.example.util.packageexport.EventoPackageGuestsContainer
import com.example.util.packageexport.EventoPackageHash
import com.example.util.packageexport.EventoPackageLicense
import com.example.util.packageexport.EventoPackageManifest
import com.example.util.packageexport.EventoPackageSignature
import com.example.util.packageexport.PackageGuestScope
import com.example.util.packageexport.security.EventoSigningKeyManager
import com.example.util.packageexport.security.JvmEphemeralEcPackageSigner
import com.evento.checkin.domain.license.EventLicenseValidator
import com.evento.checkin.domain.model.LicenseStatus
import com.evento.checkin.domain.model.PackageSecurityError
import com.evento.checkin.domain.model.PackageSecurityStatus
import com.evento.checkin.domain.model.PackageValidationResult
import com.evento.checkin.util.packageutil.CheckInTrustAnchorRegistry
import com.evento.checkin.util.packageutil.EventoPackageVerifier
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Phase 7.7 Step 1: Automated Test Suite for License-Aware Package Verification.
 *
 * Covers all 17 required verification conditions:
 * 1. Valid licensed package verifies successfully.
 * 2. Valid unlicensed package verifies successfully (legacy/backward compatibility).
 * 3. Modified license.json fails.
 * 4. Modified event.json fails.
 * 5. Modified guests.json fails.
 * 6. Missing license.json fails when declared in signature.
 * 7. Signature generated over old V2 canonical bytes does NOT pass for a V2.1 licensed package.
 * 8. Missing licenseJsonSha256 fails for a V2.1 licensed package.
 * 9. Signature with invalid ECDSA signature fails.
 * 10. Untrusted keyId fails.
 * 11. Expired license fails.
 * 12. Not yet valid license fails.
 * 13. Exceeded max guest limit fails.
 * 14. Device mismatch fails when a bound device is required.
 * 15. Device matching allowed bound device succeeds.
 * 16. Unbound license succeeds on any local device.
 * 17. Legacy V1 package remains functional and is treated as unlicensed/legacy.
 */
@RunWith(RobolectricTestRunner::class)
class CheckInLicensePackageVerificationTest {

  private lateinit var testSigner: JvmEphemeralEcPackageSigner
  private val referenceTime = 1750000000000L // arbitrary fixed test timestamp

  private val sampleEvent = EventEntity(
    id = 701L,
    name = "Global Innovation Summit 2026",
    date = "2026-10-20",
    location = "Main Auditorium",
    organizer = "Evento Enterprise Authority",
    status = EventStatus.ACTIVE,
  )

  private val sampleGuests = listOf(
    GuestEntity(
      id = 1L,
      eventId = 701L,
      fullName = "Tariq Mansour",
      email = "tariq@example.com",
      phone = "+971501112233",
      organization = "Tech Horizon",
      jobTitle = "Principal Engineer",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "VIP",
      uuid = "11111111-2222-3333-4444-555555555555",
    ),
    GuestEntity(
      id = 2L,
      eventId = 701L,
      fullName = "Noor Al-Hassan",
      email = "noor@example.com",
      phone = "+971509998877",
      organization = "AI Labs",
      jobTitle = "Research Scientist",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "Speaker",
      uuid = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    ),
  )

  @Before
  fun setUp() {
    testSigner = JvmEphemeralEcPackageSigner(
      keyId = "test-evento-license-signer-1",
      keyPair = JvmEphemeralEcPackageSigner.generateEcP256KeyPair(),
    )
    EventoSigningKeyManager.setSignerForTesting(testSigner)
    CheckInTrustAnchorRegistry.clear()
    CheckInTrustAnchorRegistry.register(testSigner.keyId, testSigner.getPublicKey())
  }

  @After
  fun tearDown() {
    CheckInTrustAnchorRegistry.clear()
    EventoSigningKeyManager.reset()
  }

  // =========================================================================
  // HELPER METHODS
  // =========================================================================

  private fun createVerifier(
    currentTime: Long = referenceTime,
  ): EventoPackageVerifier {
    return EventoPackageVerifier(
      licenseValidator = EventLicenseValidator(),
      timeProvider = { currentTime },
    )
  }

  private fun buildPackageZip(
    event: EventEntity = sampleEvent,
    guests: List<GuestEntity> = sampleGuests,
    license: EventoPackageLicense? = null,
    signer: JvmEphemeralEcPackageSigner = testSigner,
  ): ByteArray {
    val builder = EventoPackageBuilder(signer = signer)
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(
        event = event,
        guests = guests,
        scope = PackageGuestScope.ALL,
        license = license,
      )
    )

    val entries = mutableMapOf(
      "manifest.json" to payload.manifestJson.toByteArray(Charsets.UTF_8),
      "event.json" to payload.eventJson.toByteArray(Charsets.UTF_8),
      "guests.json" to payload.guestsJson.toByteArray(Charsets.UTF_8),
      "signature.json" to payload.signatureJson.toByteArray(Charsets.UTF_8),
    )
    if (payload.licenseJson != null) {
      entries["license.json"] = payload.licenseJson.toByteArray(Charsets.UTF_8)
    }

    return packZip(entries)
  }

  private fun buildCustomSignedPackage(
    event: EventEntity = sampleEvent,
    guests: List<GuestEntity> = sampleGuests,
    license: EventoPackageLicense? = null,
    signer: JvmEphemeralEcPackageSigner = testSigner,
  ): ByteArray {
    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    val eventDto = EventoPackageEvent.fromEntity(event)
    val eventJson = moshi.adapter(EventoPackageEvent::class.java).toJson(eventDto) + "\n"

    val sortedGuestDtos = guests
      .map { EventoPackageGuest.fromEntity(it) }
      .sortedBy { it.uuid.lowercase(Locale.ROOT) }
    val guestsContainer = EventoPackageGuestsContainer(guests = sortedGuestDtos)
    val guestsJson = moshi.adapter(EventoPackageGuestsContainer::class.java).toJson(guestsContainer) + "\n"

    val eventHash = EventoPackageHash.sha256(eventJson.toByteArray(Charsets.UTF_8))
    val guestsHash = EventoPackageHash.sha256(guestsJson.toByteArray(Charsets.UTF_8))

    val licenseJson = license?.let { moshi.adapter(EventoPackageLicense::class.java).toJson(it) + "\n" }
    val licenseHash = licenseJson?.let { EventoPackageHash.sha256(it.toByteArray(Charsets.UTF_8)) }

    val canonicalBytes = if (licenseHash != null) {
      EventoPackageCanonicalizer.buildCanonicalBytesV2_1(
        packageFormatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
        packageType = EVENTO_PACKAGE_TYPE,
        eventId = event.id,
        eventName = event.name,
        eventDate = event.date,
        eventLocation = event.location,
        eventOrganizer = event.organizer,
        guestCount = sortedGuestDtos.size,
        guestScope = PackageGuestScope.ALL.name,
        payloadFormat = EVENTO_QR_PAYLOAD_FORMAT,
        eventJsonSha256 = eventHash,
        guestsJsonSha256 = guestsHash,
        licenseJsonSha256 = licenseHash,
      )
    } else {
      EventoPackageCanonicalizer.buildCanonicalBytes(
        packageFormatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
        packageType = EVENTO_PACKAGE_TYPE,
        eventId = event.id,
        eventName = event.name,
        eventDate = event.date,
        eventLocation = event.location,
        eventOrganizer = event.organizer,
        guestCount = sortedGuestDtos.size,
        guestScope = PackageGuestScope.ALL.name,
        payloadFormat = EVENTO_QR_PAYLOAD_FORMAT,
        eventJsonSha256 = eventHash,
        guestsJsonSha256 = guestsHash,
      )
    }

    val signatureBytes = signer.sign(canonicalBytes)
    val signatureBase64 = android.util.Base64.encodeToString(signatureBytes, android.util.Base64.NO_WRAP)

    val signatureDto = EventoPackageSignature(
      algorithm = signer.algorithm,
      eventJsonSha256 = eventHash,
      guestsJsonSha256 = guestsHash,
      licenseJsonSha256 = licenseHash,
      signatureVersion = EVENTO_SIGNATURE_VERSION_V2,
      keyId = signer.keyId,
      signedContentDescriptor = if (licenseHash != null) EventoPackageCanonicalizer.DESCRIPTOR_V2_1 else EventoPackageCanonicalizer.DESCRIPTOR_V2,
      signature = signatureBase64,
    )
    val signatureJson = moshi.adapter(EventoPackageSignature::class.java).toJson(signatureDto) + "\n"

    val manifestDto = EventoPackageManifest(
      packageFormatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
      packageType = EVENTO_PACKAGE_TYPE,
      eventId = event.id,
      eventName = event.name.trim(),
      createdAt = "2026-09-16T12:00:00Z",
      guestCount = sortedGuestDtos.size,
      guestScope = PackageGuestScope.ALL.name,
      payloadFormat = EVENTO_QR_PAYLOAD_FORMAT,
      hashAlgorithm = EVENTO_HASH_ALGORITHM,
    )
    val manifestJson = moshi.adapter(EventoPackageManifest::class.java).toJson(manifestDto) + "\n"

    val entries = mutableMapOf(
      "manifest.json" to manifestJson.toByteArray(Charsets.UTF_8),
      "event.json" to eventJson.toByteArray(Charsets.UTF_8),
      "guests.json" to guestsJson.toByteArray(Charsets.UTF_8),
      "signature.json" to signatureJson.toByteArray(Charsets.UTF_8),
    )
    if (licenseJson != null) {
      entries["license.json"] = licenseJson.toByteArray(Charsets.UTF_8)
    }

    return packZip(entries)
  }

  private fun packZip(entries: Map<String, ByteArray>): ByteArray {
    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      for ((name, bytes) in entries) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(bytes)
        zos.closeEntry()
      }
    }
    return baos.toByteArray()
  }

  private fun unpackZip(zipBytes: ByteArray): MutableMap<String, ByteArray> {
    val map = mutableMapOf<String, ByteArray>()
    ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        map[entry.name] = zis.readBytes()
        zis.closeEntry()
        entry = zis.nextEntry
      }
    }
    return map
  }

  // =========================================================================
  // TEST CASES
  // =========================================================================

  @Test
  fun test01_validLicensedPackageVerifiesSuccessfully() {
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
      allowedDeviceCount = 2,
      boundDeviceId = null,
    )
    val zipBytes = buildPackageZip(license = license)
    val verifier = createVerifier()

    val result = verifier.verifyPackage(zipBytes, localDeviceId = "TERM-001")
    assertTrue("Valid licensed package must verify successfully", result is PackageValidationResult.Valid)

    val valid = result as PackageValidationResult.Valid
    assertEquals(PackageSecurityStatus.SIGNED_VERIFIED, valid.securityStatus)
    assertEquals(testSigner.keyId, valid.keyId)
    assertNotNull(valid.license)
    assertEquals("LIC-SUMMIT-2026", valid.license?.licenseId)
    assertEquals(50, valid.license?.maxGuests)
    assertEquals(LicenseStatus.ACTIVE, valid.license?.licenseStatus)
    assertTrue("Event must be flagged as licensed", valid.event.isLicensed)
    assertEquals(2, valid.guests.size)
  }

  @Test
  fun test02_validUnlicensedPackageVerifiesSuccessfully_legacyCompatibility() {
    val zipBytes = buildPackageZip(license = null)
    val verifier = createVerifier()

    val result = verifier.verifyPackage(zipBytes)
    assertTrue("Unlicensed V2 package must verify for backward compatibility", result is PackageValidationResult.Valid)

    val valid = result as PackageValidationResult.Valid
    assertEquals(PackageSecurityStatus.SIGNED_VERIFIED, valid.securityStatus)
    assertNull("Unlicensed package must have null license", valid.license)
    assertFalse("Event must not be flagged as licensed", valid.event.isLicensed)
  }

  @Test
  fun test03_modifiedLicenseJsonFailsIntegrityCheck() {
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 10,
    )
    val zipBytes = buildPackageZip(license = license)
    val entries = unpackZip(zipBytes)

    // Tamper with license capacity: modify 10 to 9999
    val tamperedLicenseJson = entries["license.json"]!!.toString(Charsets.UTF_8)
      .replace("\"maxGuests\": 10", "\"maxGuests\": 9999")
    entries["license.json"] = tamperedLicenseJson.toByteArray(Charsets.UTF_8)

    val verifier = createVerifier()
    val result = verifier.verifyPackage(packZip(entries))

    assertTrue("Tampered license.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.INTEGRITY_CHECK_FAILED, invalid.errorCategory)
  }

  @Test
  fun test04_modifiedEventJsonFailsIntegrityCheck() {
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = license)
    val entries = unpackZip(zipBytes)

    entries["event.json"] = entries["event.json"]!!.toString(Charsets.UTF_8)
      .replace("Global Innovation Summit 2026", "Tampered Title")
      .toByteArray(Charsets.UTF_8)

    val verifier = createVerifier()
    val result = verifier.verifyPackage(packZip(entries))

    assertTrue("Tampered event.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.INTEGRITY_CHECK_FAILED, invalid.errorCategory)
  }

  @Test
  fun test05_modifiedGuestsJsonFailsIntegrityCheck() {
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = license)
    val entries = unpackZip(zipBytes)

    entries["guests.json"] = entries["guests.json"]!!.toString(Charsets.UTF_8)
      .replace("Tariq Mansour", "Attacker Injected Name")
      .toByteArray(Charsets.UTF_8)

    val verifier = createVerifier()
    val result = verifier.verifyPackage(packZip(entries))

    assertTrue("Tampered guests.json must be rejected", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.INTEGRITY_CHECK_FAILED, invalid.errorCategory)
  }

  @Test
  fun test06_missingLicenseJsonFailsWhenDeclaredInSignature() {
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = license)
    val entries = unpackZip(zipBytes)
    entries.remove("license.json") // Strip license.json

    val verifier = createVerifier()
    val result = verifier.verifyPackage(packZip(entries))

    assertTrue("Missing license.json must fail closed", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.LICENSE_MISSING, invalid.errorCategory)
  }

  @Test
  fun test07_signatureOverOldV2CanonicalBytesFailsForV2_1LicensedPackage() {
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = license)
    val entries = unpackZip(zipBytes)

    // Parse existing signature.json
    val sigJsonObj = JSONObject(entries["signature.json"]!!.toString(Charsets.UTF_8))
    val eventHash = sigJsonObj.getString("eventJsonSha256")
    val guestsHash = sigJsonObj.getString("guestsJsonSha256")

    // Compute old V2 canonical bytes WITHOUT license
    val oldV2CanonicalBytes = EventoPackageCanonicalizer.buildCanonicalBytes(
      packageFormatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
      packageType = EVENTO_PACKAGE_TYPE,
      eventId = sampleEvent.id,
      eventName = sampleEvent.name,
      eventDate = sampleEvent.date,
      eventLocation = sampleEvent.location,
      eventOrganizer = sampleEvent.organizer,
      guestCount = sampleGuests.size,
      guestScope = PackageGuestScope.ALL.name,
      payloadFormat = EVENTO_QR_PAYLOAD_FORMAT,
      eventJsonSha256 = eventHash,
      guestsJsonSha256 = guestsHash,
    )
    val oldV2SigBytes = testSigner.sign(oldV2CanonicalBytes)
    val oldV2SigBase64 = android.util.Base64.encodeToString(oldV2SigBytes, android.util.Base64.NO_WRAP)

    // Put old signature in signature.json
    sigJsonObj.put("signature", oldV2SigBase64)
    entries["signature.json"] = sigJsonObj.toString(2).toByteArray(Charsets.UTF_8)

    val verifier = createVerifier()
    val result = verifier.verifyPackage(packZip(entries))

    assertTrue("Signature over old V2 bytes must fail for V2.1 package", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.SIGNATURE_INVALID, invalid.errorCategory)
  }

  @Test
  fun test08_missingLicenseJsonSha256FailsForV2_1LicensedPackage() {
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = license)
    val entries = unpackZip(zipBytes)

    // Remove licenseJsonSha256 from signature.json
    val sigJsonObj = JSONObject(entries["signature.json"]!!.toString(Charsets.UTF_8))
    sigJsonObj.remove("licenseJsonSha256")
    entries["signature.json"] = sigJsonObj.toString(2).toByteArray(Charsets.UTF_8)

    val verifier = createVerifier()
    val result = verifier.verifyPackage(packZip(entries))

    assertTrue("Missing licenseJsonSha256 when license is present must fail", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.LICENSE_INVALID, invalid.errorCategory)
  }

  @Test
  fun test09_signatureWithInvalidEcdsaFails() {
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = license)
    val entries = unpackZip(zipBytes)

    val sigJsonObj = JSONObject(entries["signature.json"]!!.toString(Charsets.UTF_8))
    val dummyInvalidSignature = android.util.Base64.encodeToString(
      ByteArray(64) { 0x42 },
      android.util.Base64.NO_WRAP
    )
    sigJsonObj.put("signature", dummyInvalidSignature)
    entries["signature.json"] = sigJsonObj.toString(2).toByteArray(Charsets.UTF_8)

    val verifier = createVerifier()
    val result = verifier.verifyPackage(packZip(entries))

    assertTrue("Corrupted ECDSA signature must fail", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.SIGNATURE_INVALID, invalid.errorCategory)
  }

  @Test
  fun test10_untrustedKeyIdFails() {
    val untrustedSigner = JvmEphemeralEcPackageSigner(
      keyId = "untrusted-attacker-key-99",
      keyPair = JvmEphemeralEcPackageSigner.generateEcP256KeyPair(),
    )
    val license = EventoPackageLicense(
      licenseId = "LIC-SUMMIT-2026",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = license, signer = untrustedSigner)

    val verifier = createVerifier()
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Untrusted keyId must fail closed", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.UNKNOWN_SIGNING_KEY, invalid.errorCategory)
  }

  @Test
  fun test11_expiredLicenseFails() {
    val expiredLicense = EventoPackageLicense(
      licenseId = "LIC-EXPIRED",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 100_000L,
      expiresAt = referenceTime - 1_000L, // Expired in the past relative to referenceTime
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = expiredLicense)
    val verifier = createVerifier(currentTime = referenceTime)

    val result = verifier.verifyPackage(zipBytes)
    assertTrue("Expired license must fail closed", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.LICENSE_EXPIRED, invalid.errorCategory)
  }

  @Test
  fun test12_notYetValidLicenseFails() {
    val futureLicense = EventoPackageLicense(
      licenseId = "LIC-FUTURE",
      eventId = sampleEvent.id,
      issuedAt = referenceTime + 50_000L, // Future start time
      expiresAt = referenceTime + 200_000L,
      maxGuests = 50,
    )
    val zipBytes = buildPackageZip(license = futureLicense)
    val verifier = createVerifier(currentTime = referenceTime)

    val result = verifier.verifyPackage(zipBytes)
    assertTrue("Not yet valid license must fail closed", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.LICENSE_NOT_YET_VALID, invalid.errorCategory)
  }

  @Test
  fun test13_exceededMaxGuestLimitFails() {
    // sampleGuests has 2 guests, but license maxGuests = 1
    val limitedLicense = EventoPackageLicense(
      licenseId = "LIC-RESTRICTED",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 1,
    )
    val zipBytes = buildCustomSignedPackage(license = limitedLicense)
    val verifier = createVerifier()

    val result = verifier.verifyPackage(zipBytes)
    assertTrue("Exceeded guest limit must fail closed", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.LICENSE_GUEST_LIMIT_EXCEEDED, invalid.errorCategory)
  }

  @Test
  fun test14_deviceMismatchFailsWhenBoundDeviceIsRequired() {
    val boundLicense = EventoPackageLicense(
      licenseId = "LIC-BOUND-01",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
      boundDeviceId = "TERM-HALL-A-01",
    )
    val zipBytes = buildPackageZip(license = boundLicense)
    val verifier = createVerifier()

    // Test with wrong device ID
    val wrongDeviceResult = verifier.verifyPackage(zipBytes, localDeviceId = "TERM-HALL-B-02")
    assertTrue("Mismatched bound device ID must fail closed", wrongDeviceResult is PackageValidationResult.Invalid)
    val invalidWrong = wrongDeviceResult as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.LICENSE_DEVICE_MISMATCH, invalidWrong.errorCategory)

    // Test with null device ID
    val nullDeviceResult = verifier.verifyPackage(zipBytes, localDeviceId = null)
    assertTrue("Null device ID when binding is required must fail closed", nullDeviceResult is PackageValidationResult.Invalid)
    val invalidNull = nullDeviceResult as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.LICENSE_DEVICE_MISMATCH, invalidNull.errorCategory)
  }

  @Test
  fun test15_deviceMatchingAllowedBoundDeviceSucceeds() {
    val boundLicense = EventoPackageLicense(
      licenseId = "LIC-BOUND-01",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
      boundDeviceId = "TERM-HALL-A-01",
    )
    val zipBytes = buildPackageZip(license = boundLicense)
    val verifier = createVerifier()

    // Match case-insensitively
    val result = verifier.verifyPackage(zipBytes, localDeviceId = "term-hall-a-01")
    assertTrue("Matching bound device must verify successfully", result is PackageValidationResult.Valid)
    val valid = result as PackageValidationResult.Valid
    assertEquals("TERM-HALL-A-01", valid.license?.boundDeviceId)
  }

  @Test
  fun test16_unboundLicenseSucceedsOnAnyLocalDevice() {
    val unboundLicense = EventoPackageLicense(
      licenseId = "LIC-UNBOUND",
      eventId = sampleEvent.id,
      issuedAt = referenceTime - 10_000L,
      expiresAt = referenceTime + 100_000L,
      maxGuests = 50,
      boundDeviceId = null,
    )
    val zipBytes = buildPackageZip(license = unboundLicense)
    val verifier = createVerifier()

    val result1 = verifier.verifyPackage(zipBytes, localDeviceId = "TERM-ANY-1")
    assertTrue(result1 is PackageValidationResult.Valid)

    val result2 = verifier.verifyPackage(zipBytes, localDeviceId = null)
    assertTrue(result2 is PackageValidationResult.Valid)
  }

  @Test
  fun test17_legacyV1PackageRemainsFunctionalAndTreatedAsUnlicensed() {
    val eventJson = JSONObject().apply {
      put("eventId", sampleEvent.id)
      put("name", sampleEvent.name)
      put("date", sampleEvent.date)
      put("location", sampleEvent.location)
      put("organizer", sampleEvent.organizer)
      put("packageFormatVersion", EVENTO_PACKAGE_FORMAT_VERSION_V1)
    }.toString(2).toByteArray(Charsets.UTF_8)

    val guestsJson = JSONObject().apply {
      put("guests", JSONArray().apply {
        sampleGuests.forEach { g ->
          put(JSONObject().apply {
            put("uuid", g.uuid)
            put("fullName", g.fullName)
            put("invitationStatus", g.invitationStatus.name)
            put("organization", g.organization)
            put("jobTitle", g.jobTitle)
          })
        }
      })
    }.toString(2).toByteArray(Charsets.UTF_8)

    val manifestJson = JSONObject().apply {
      put("packageFormatVersion", EVENTO_PACKAGE_FORMAT_VERSION_V1)
      put("packageType", EVENTO_PACKAGE_TYPE)
      put("eventId", sampleEvent.id)
      put("eventName", sampleEvent.name)
      put("createdAt", "2026-09-16T12:00:00Z")
      put("guestCount", sampleGuests.size)
      put("guestScope", "ALL")
      put("payloadFormat", EVENTO_QR_PAYLOAD_FORMAT)
      put("hashAlgorithm", EVENTO_HASH_ALGORITHM)
    }.toString(2).toByteArray(Charsets.UTF_8)

    val signatureJson = JSONObject().apply {
      put("algorithm", EVENTO_HASH_ALGORITHM)
      put("eventJsonSha256", EventoPackageHash.sha256(eventJson))
      put("guestsJsonSha256", EventoPackageHash.sha256(guestsJson))
      put("signatureVersion", 1)
    }.toString(2).toByteArray(Charsets.UTF_8)

    val v1Zip = packZip(
      mapOf(
        "manifest.json" to manifestJson,
        "event.json" to eventJson,
        "guests.json" to guestsJson,
        "signature.json" to signatureJson,
      )
    )

    val verifier = createVerifier()
    val result = verifier.verifyPackage(v1Zip)

    assertTrue("Legacy V1 package must be accepted", result is PackageValidationResult.Valid)
    val valid = result as PackageValidationResult.Valid
    assertEquals(PackageSecurityStatus.LEGACY_INTEGRITY_ONLY, valid.securityStatus)
    assertNull("Legacy V1 has no validated keyId", valid.keyId)
    assertNull("Legacy V1 has no license", valid.license)
    assertFalse("Legacy V1 event is not licensed", valid.event.isLicensed)
    assertEquals("LEGACY_INTEGRITY_ONLY", valid.event.verificationStatus)
  }
}
