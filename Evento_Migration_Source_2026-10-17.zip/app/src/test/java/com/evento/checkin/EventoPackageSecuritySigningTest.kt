package com.evento.checkin

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.util.packageexport.EVENTO_PACKAGE_FORMAT_VERSION
import com.example.util.packageexport.EVENTO_PACKAGE_TYPE
import com.example.util.packageexport.EVENTO_QR_PAYLOAD_FORMAT
import com.example.util.packageexport.EventPackageExportRequest
import com.example.util.packageexport.EventoPackageBuilder
import com.example.util.packageexport.EventoPackageCanonicalizer
import com.example.util.packageexport.PackageGuestScope
import com.example.util.packageexport.security.EventoSigningKeyManager
import com.example.util.packageexport.security.JvmEphemeralEcPackageSigner
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.CheckInSecurityArchitecture
import com.evento.checkin.domain.model.PackageSecurityError
import com.evento.checkin.domain.model.PackageSecurityStatus
import com.evento.checkin.domain.model.PackageValidationResult
import com.evento.checkin.util.packageutil.CheckInTrustAnchorRegistry
import com.evento.checkin.util.packageutil.EventoPackageImporter
import com.evento.checkin.util.packageutil.EventoPackageVerifier
import com.evento.checkin.util.packageutil.PackageImportResult
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.interfaces.ECPublicKey
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Phase 7.6 Comprehensive Security & Cryptographic Verification Test Suite.
 *
 * Covers all Phase 7.6 requirements:
 * 1. Admin ECDSA P-256 key generation / parameters / key manager retrieval
 * 2. Deterministic canonical byte reconstruction stability & strict field ordering
 * 3. Authentic Version 2 package signing and verification with trusted anchor
 * 4. Tampering detection:
 *    - modified manifest.json
 *    - modified event.json
 *    - modified guests.json
 *    - modified signature.json
 * 5. Missing critical entries (signature, manifest, event, guests) fail closed
 * 6. Untrusted signing key rejection (fail closed)
 * 7. Corrupted Base64 signature rejection (fail closed)
 * 8. Version 1 legacy package verification (flagged as LEGACY_INTEGRITY_ONLY)
 * 9. Fail-closed import behavior: Room database remains completely pristine on verification failure
 */
@RunWith(RobolectricTestRunner::class)
class EventoPackageSecuritySigningTest {

  private lateinit var context: Context
  private lateinit var database: CheckInDatabase
  private lateinit var repository: CheckInRepository
  private lateinit var verifier: EventoPackageVerifier
  private lateinit var importer: EventoPackageImporter
  private lateinit var testSigner: JvmEphemeralEcPackageSigner

  private val sampleEvent = EventEntity(
    id = 501L,
    name = "Cybersecurity Leadership Summit 2026",
    date = "2026-11-15",
    location = "Security Hall B",
    organizer = "Evento Trust Authority",
    status = EventStatus.ACTIVE,
  )

  private val sampleGuests = listOf(
    GuestEntity(
      id = 1L,
      eventId = 501L,
      fullName = "Dr. Layla Mansoor",
      email = "layla@example.com",
      phone = "+1234567890",
      organization = "Cyber Defense Institute",
      jobTitle = "Chief Security Officer",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "Keynote Speaker",
      uuid = "11111111-2222-3333-4444-555555555555",
    ),
    GuestEntity(
      id = 2L,
      eventId = 501L,
      fullName = "Kareem Rashid",
      email = "kareem@example.com",
      phone = "+9876543210",
      organization = "Network Sec Labs",
      jobTitle = "Security Architect",
      invitationStatus = InvitationStatus.CONFIRMED,
      notes = "Panelist",
      uuid = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    ),
  )

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    database = CheckInDatabase.createInMemory(context)
    repository = CheckInRepository(database.checkInDao())
    verifier = EventoPackageVerifier()
    importer = EventoPackageImporter(repository, verifier)

    // Reset and initialize isolated ephemeral signer for testing
    testSigner = JvmEphemeralEcPackageSigner(
      keyId = "test-evento-authority-key-1",
      keyPair = JvmEphemeralEcPackageSigner.generateEcP256KeyPair(),
    )
    EventoSigningKeyManager.setSignerForTesting(testSigner)

    // Ensure clean trust anchor registry state
    CheckInTrustAnchorRegistry.clear()
    CheckInTrustAnchorRegistry.register(testSigner.keyId, testSigner.getPublicKey())
  }

  @After
  fun tearDown() {
    database.close()
    CheckInTrustAnchorRegistry.clear()
    EventoSigningKeyManager.reset()
  }

  // =========================================================================
  // HELPER METHODS
  // =========================================================================

  private fun buildSignedPackageBytes(
    event: EventEntity = sampleEvent,
    guests: List<GuestEntity> = sampleGuests,
    signer: JvmEphemeralEcPackageSigner = testSigner,
  ): ByteArray {
    val builder = EventoPackageBuilder(signer = signer)
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(
        event = event,
        guests = guests,
        scope = PackageGuestScope.ALL,
      )
    )

    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      zos.putNextEntry(ZipEntry("manifest.json"))
      zos.write(payload.manifestJson.toByteArray(Charsets.UTF_8))
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("event.json"))
      zos.write(payload.eventJson.toByteArray(Charsets.UTF_8))
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("guests.json"))
      zos.write(payload.guestsJson.toByteArray(Charsets.UTF_8))
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("signature.json"))
      zos.write(payload.signatureJson.toByteArray(Charsets.UTF_8))
      zos.closeEntry()
    }
    return baos.toByteArray()
  }

  private fun unpackZipEntries(zipBytes: ByteArray): MutableMap<String, ByteArray> {
    val map = mutableMapOf<String, ByteArray>()
    ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        val entryBytes = zis.readBytes()
        map[entry.name] = entryBytes
        zis.closeEntry()
        entry = zis.nextEntry
      }
    }
    return map
  }

  private fun packZipEntries(entries: Map<String, ByteArray>): ByteArray {
    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      for ((name, bytes) in entries) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(bytes)
        zos.closeEntry()
      }
    }
    return baos.toByteArray()
  }

  // =========================================================================
  // 1. KEY GENERATION & MANAGEMENT TESTS
  // =========================================================================

  @Test
  fun test01_adminKeyGenerationAndCurveParameters() {
    val keyPair = JvmEphemeralEcPackageSigner.generateEcP256KeyPair()
    assertNotNull("Public key must be generated", keyPair.public)
    assertNotNull("Private key must be generated", keyPair.private)
    assertEquals("EC", keyPair.public.algorithm)

    val ecPub = keyPair.public as? ECPublicKey
    assertNotNull("Must be instance of ECPublicKey", ecPub)
    // P-256 field size is 256 bits
    assertEquals(256, ecPub?.params?.order?.bitLength())

    val signer = EventoSigningKeyManager.getSigner()
    assertEquals("SHA256withECDSA", signer.algorithm)
    assertNotNull("Signer must provide public key", signer.getPublicKey())
  }

  // =========================================================================
  // 2. DETERMINISTIC CANONICALIZATION TESTS
  // =========================================================================

  @Test
  fun test02_canonicalByteReconstructionStabilityAndFieldOrdering() {
    val canonicalBytes1 = EventoPackageCanonicalizer.buildCanonicalBytes(
      packageFormatVersion = 2,
      packageType = "EVENTO_EVENT",
      eventId = 501L,
      eventName = "Cybersecurity Leadership Summit 2026",
      eventDate = "2026-11-15",
      eventLocation = "Security Hall B",
      eventOrganizer = "Evento Trust Authority",
      guestCount = 2,
      guestScope = "ALL",
      payloadFormat = "EVT1:<guest_uuid>",
      eventJsonSha256 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      guestsJsonSha256 = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    )

    val canonicalBytes2 = EventoPackageCanonicalizer.buildCanonicalBytes(
      packageFormatVersion = 2,
      packageType = "EVENTO_EVENT",
      eventId = 501L,
      eventName = "Cybersecurity Leadership Summit 2026",
      eventDate = "2026-11-15",
      eventLocation = "Security Hall B",
      eventOrganizer = "Evento Trust Authority",
      guestCount = 2,
      guestScope = "ALL",
      payloadFormat = "EVT1:<guest_uuid>",
      eventJsonSha256 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      guestsJsonSha256 = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    )

    // Strict byte-for-byte reproducibility
    assertArrayEquals("Canonical bytes must be strictly deterministic", canonicalBytes1, canonicalBytes2)

    val canonicalText = canonicalBytes1.toString(Charsets.UTF_8)
    val lines = canonicalText.split("\n")

    // Verify ordering and structure
    assertEquals("EVENTO-CANONICAL-V2", lines[0])
    assertEquals("formatVersion:2", lines[1])
    assertEquals("packageType:EVENTO_EVENT", lines[2])
    assertEquals("eventId:501", lines[3])
    assertEquals("eventName:Cybersecurity Leadership Summit 2026", lines[4])
    assertEquals("eventDate:2026-11-15", lines[5])
    assertEquals("eventLocation:Security Hall B", lines[6])
    assertEquals("eventOrganizer:Evento Trust Authority", lines[7])
    assertEquals("guestCount:2", lines[8])
    assertEquals("guestScope:ALL", lines[9])
    assertEquals("payloadFormat:EVT1:<guest_uuid>", lines[10])
    assertEquals("eventJsonSha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", lines[11])
    assertEquals("guestsJsonSha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", lines[12])
  }

  // =========================================================================
  // 3. VALID V2 PACKAGE SIGNING AND VERIFICATION
  // =========================================================================

  @Test
  fun test03_validV2PackageSigningAndVerificationWithTrustedAnchor() {
    val zipBytes = buildSignedPackageBytes()
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Valid signed package must verify successfully", result is PackageValidationResult.Valid)
    val valid = result as PackageValidationResult.Valid
    assertEquals(PackageSecurityStatus.SIGNED_VERIFIED, valid.securityStatus)
    assertEquals(testSigner.keyId, valid.keyId)
    assertEquals("SIGNED_VERIFIED", valid.event.verificationStatus)
    assertEquals(2, valid.guests.size)
  }

  // =========================================================================
  // 4. TAMPERING DETECTION TESTS
  // =========================================================================

  @Test
  fun test04_tamperedManifestFailsVerification() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)

    // Alter event name in manifest
    val originalManifest = entries["manifest.json"]!!.toString(Charsets.UTF_8)
    val tamperedManifest = originalManifest.replace("Cybersecurity Leadership Summit 2026", "Tampered Event Name")
    entries["manifest.json"] = tamperedManifest.toByteArray(Charsets.UTF_8)

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Tampered manifest must fail verification", result is PackageValidationResult.Invalid)
  }

  @Test
  fun test05_tamperedEventFailsVerification() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)

    // Alter location in event.json
    val originalEvent = entries["event.json"]!!.toString(Charsets.UTF_8)
    val tamperedEvent = originalEvent.replace("Security Hall B", "Unauthorized Room")
    entries["event.json"] = tamperedEvent.toByteArray(Charsets.UTF_8)

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Tampered event.json must fail verification", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.INTEGRITY_CHECK_FAILED, invalid.errorCategory)
  }

  @Test
  fun test06_tamperedGuestsFailsVerification() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)

    // Alter attendee name in guests.json
    val originalGuests = entries["guests.json"]!!.toString(Charsets.UTF_8)
    val tamperedGuests = originalGuests.replace("Dr. Layla Mansoor", "Attacker Infiltration")
    entries["guests.json"] = tamperedGuests.toByteArray(Charsets.UTF_8)

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Tampered guests.json must fail verification", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.INTEGRITY_CHECK_FAILED, invalid.errorCategory)
  }

  @Test
  fun test07_tamperedSignatureBytesFailsVerification() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)

    // Alter signature in signature.json
    val originalSigJson = entries["signature.json"]!!.toString(Charsets.UTF_8)
    val json = JSONObject(originalSigJson)
    val validSigBase64 = json.getString("signature")
    // Flip a base64 character in the middle
    val corruptedSig = validSigBase64.substring(0, 10) + "A" + validSigBase64.substring(11)
    json.put("signature", corruptedSig)
    entries["signature.json"] = json.toString().toByteArray(Charsets.UTF_8)

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Tampered signature must fail verification", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.SIGNATURE_INVALID, invalid.errorCategory)
  }

  // =========================================================================
  // 5. MISSING CRITICAL ENTRIES TESTS
  // =========================================================================

  @Test
  fun test08_missingSignatureFailsClosed() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)
    entries.remove("signature.json")

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Missing signature.json must fail closed", result is PackageValidationResult.Invalid)
  }

  @Test
  fun test09_missingManifestFailsClosed() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)
    entries.remove("manifest.json")

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Missing manifest.json must fail closed", result is PackageValidationResult.Invalid)
  }

  @Test
  fun test10_missingEventFailsClosed() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)
    entries.remove("event.json")

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Missing event.json must fail closed", result is PackageValidationResult.Invalid)
  }

  @Test
  fun test11_missingGuestsFailsClosed() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)
    entries.remove("guests.json")

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Missing guests.json must fail closed", result is PackageValidationResult.Invalid)
  }

  // =========================================================================
  // 6. UNTRUSTED KEY REJECTION TESTS
  // =========================================================================

  @Test
  fun test12_untrustedKeyRejectionFailClosed() {
    // Generate a different valid signer with keyId not registered in trust anchor
    val rogueSigner = JvmEphemeralEcPackageSigner(
      keyId = "unauthorized-rogue-authority-key",
      keyPair = JvmEphemeralEcPackageSigner.generateEcP256KeyPair(),
    )

    val zipBytes = buildSignedPackageBytes(signer = rogueSigner)
    val result = verifier.verifyPackage(zipBytes)

    assertTrue("Package signed by unknown keyId must fail", result is PackageValidationResult.Invalid)
    val invalid = result as PackageValidationResult.Invalid
    assertEquals(PackageSecurityError.UNKNOWN_SIGNING_KEY, invalid.errorCategory)
  }

  // =========================================================================
  // 7. CORRUPTED BASE64 SIGNATURE TESTS
  // =========================================================================

  @Test
  fun test13_corruptedBase64SignatureFailsClosed() {
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)

    val originalSigJson = entries["signature.json"]!!.toString(Charsets.UTF_8)
    val json = JSONObject(originalSigJson)
    // Non-Base64 corrupted payload
    json.put("signature", "!!!NOT_BASE64_AT_ALL???")
    entries["signature.json"] = json.toString().toByteArray(Charsets.UTF_8)

    val tamperedZip = packZipEntries(entries)
    val result = verifier.verifyPackage(tamperedZip)

    assertTrue("Corrupted Base64 signature must fail closed", result is PackageValidationResult.Invalid)
  }

  // =========================================================================
  // 8. VERSION 1 LEGACY PACKAGE VERIFICATION TESTS
  // =========================================================================

  @Test
  fun test14_legacyVersion1IntegrityOnlyAccepted() {
    // Build a v1 package without digital signature
    val eventJson = JSONObject().apply {
      put("eventId", 801L)
      put("name", "Legacy Conference 2025")
      put("date", "2025-05-10")
      put("location", "Legacy Hall")
      put("organizer", "Old Organizer")
      put("packageFormatVersion", 1)
    }.toString(2).toByteArray(Charsets.UTF_8)

    val guestsArray = JSONArray().apply {
      put(JSONObject().apply {
        put("uuid", "99999999-9999-9999-9999-999999999999")
        put("fullName", "Legacy Attendee")
        put("invitationStatus", "CONFIRMED")
        put("organization", "Legacy Org")
        put("jobTitle", "Historian")
      })
    }
    val guestsJson = JSONObject().apply {
      put("guests", guestsArray)
    }.toString(2).toByteArray(Charsets.UTF_8)

    val eventSha256 = com.evento.checkin.util.packageutil.CheckInPackageSecurity.sha256Hex(eventJson)
    val guestsSha256 = com.evento.checkin.util.packageutil.CheckInPackageSecurity.sha256Hex(guestsJson)

    val manifestJson = JSONObject().apply {
      put("packageFormatVersion", 1)
      put("packageType", "EVENTO_EVENT")
      put("eventId", 801L)
      put("eventName", "Legacy Conference 2025")
      put("createdAt", "2025-05-01T00:00:00Z")
      put("guestCount", 1)
      put("guestScope", "ALL")
      put("payloadFormat", "EVT1:<guest_uuid>")
      put("hashAlgorithm", "SHA-256")
    }.toString(2).toByteArray(Charsets.UTF_8)

    val signatureJson = JSONObject().apply {
      put("algorithm", "SHA-256")
      put("eventJsonSha256", eventSha256)
      put("guestsJsonSha256", guestsSha256)
    }.toString(2).toByteArray(Charsets.UTF_8)

    val v1Zip = packZipEntries(
      mapOf(
        "manifest.json" to manifestJson,
        "event.json" to eventJson,
        "guests.json" to guestsJson,
        "signature.json" to signatureJson,
      )
    )

    val result = verifier.verifyPackage(v1Zip)
    assertTrue("Version 1 package must be accepted for backward compatibility", result is PackageValidationResult.Valid)
    val valid = result as PackageValidationResult.Valid
    assertEquals(PackageSecurityStatus.LEGACY_INTEGRITY_ONLY, valid.securityStatus)
    assertNull("Legacy package has no validated keyId", valid.keyId)
    assertEquals("LEGACY_INTEGRITY_ONLY", valid.event.verificationStatus)
  }

  // =========================================================================
  // 9. FAIL-CLOSED ROOM DATABASE INTEGRITY TESTS
  // =========================================================================

  @Test
  fun test15_failClosedImporterLeavesDatabaseUntouchedOnTamperedPackage(): Unit = runBlocking {
    // 1. Initial state: verify database is empty
    assertNull(database.checkInDao().getActiveEvent())
    assertEquals(0, database.checkInDao().getGuestCount())

    // 2. Create tampered package (tampered event.json)
    val zipBytes = buildSignedPackageBytes()
    val entries = unpackZipEntries(zipBytes)
    entries["event.json"] = entries["event.json"]!!.toString(Charsets.UTF_8)
      .replace("Cybersecurity Leadership Summit 2026", "Tampered Title")
      .toByteArray(Charsets.UTF_8)
    val tamperedZip = packZipEntries(entries)

    // 3. Attempt import
    val importResult = importer.importFromStream(ByteArrayInputStream(tamperedZip))
    assertTrue("Import of tampered package must fail", importResult is PackageImportResult.Error)

    // 4. Assert database remains strictly pristine (fail closed)
    assertNull("No event must be written to database", database.checkInDao().getActiveEvent())
    assertEquals("No guests must be written to database", 0, database.checkInDao().getGuestCount())
  }

  @Test
  fun test16_failClosedImporterLeavesDatabaseUntouchedOnUntrustedKey(): Unit = runBlocking {
    val rogueSigner = JvmEphemeralEcPackageSigner(
      keyId = "unauthorized-authority-key",
      keyPair = JvmEphemeralEcPackageSigner.generateEcP256KeyPair(),
    )
    val zipBytes = buildSignedPackageBytes(signer = rogueSigner)

    // Attempt import with untrusted key
    val importResult = importer.importFromStream(ByteArrayInputStream(zipBytes))
    assertTrue("Import with untrusted key must fail", importResult is PackageImportResult.Error)

    // Verify database remains pristine
    assertNull("No event must be written to database", database.checkInDao().getActiveEvent())
    assertEquals("No guests must be written to database", 0, database.checkInDao().getGuestCount())
  }
}
