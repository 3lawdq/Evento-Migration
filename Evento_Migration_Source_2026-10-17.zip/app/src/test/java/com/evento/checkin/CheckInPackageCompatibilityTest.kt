package com.evento.checkin

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.util.packageexport.EVENTO_PACKAGE_FORMAT_VERSION
import com.example.util.packageexport.EVENTO_PACKAGE_TYPE
import com.example.util.packageexport.EVENTO_QR_PAYLOAD_FORMAT
import com.example.util.packageexport.EventPackageExportRequest
import com.example.util.packageexport.EventPackageExportResult
import com.example.util.packageexport.EventoPackageBuilder
import com.example.util.packageexport.EventoPackageLicense
import com.example.util.packageexport.EventoPackageWriter
import com.example.util.packageexport.PackageGuestScope
import com.example.util.packageexport.security.EventoSigningKeyManager
import com.example.util.packageexport.security.JvmEphemeralEcPackageSigner
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.engine.CheckInEngine
import com.evento.checkin.domain.model.CheckInResult
import com.evento.checkin.domain.model.PackageSecurityError
import com.evento.checkin.domain.model.PackageSecurityStatus
import com.evento.checkin.domain.model.PackageValidationResult
import com.evento.checkin.domain.qr.QrCheckInResult
import com.evento.checkin.domain.qr.QrCheckInService
import com.evento.checkin.domain.qr.QrPayloadParseResult
import com.evento.checkin.domain.qr.QrPayloadParser
import com.evento.checkin.util.packageutil.CheckInTrustAnchorRegistry
import com.evento.checkin.util.packageutil.EventoPackageImporter
import com.evento.checkin.util.packageutil.EventoPackageVerifier
import com.evento.checkin.util.packageutil.PackageImportResult
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Phase 11.4: End-to-End Package Compatibility and Cross-Application Verification Suite.
 *
 * Verifies the complete compatibility chain:
 * Evento Admin (Export) -> .evento ZIP bytes -> Check-In (Verify/Import) -> Room -> QR Engine -> Attendance.
 */
@RunWith(RobolectricTestRunner::class)
class CheckInPackageCompatibilityTest {

  private lateinit var context: Context
  private lateinit var database: CheckInDatabase
  private lateinit var repository: CheckInRepository
  private lateinit var verifier: EventoPackageVerifier
  private lateinit var importer: EventoPackageImporter
  private lateinit var engine: CheckInEngine
  private lateinit var qrService: QrCheckInService
  private lateinit var testSigner: JvmEphemeralEcPackageSigner
  private lateinit var packageWriter: EventoPackageWriter

  private val testDeviceId = "TERM-COMPAT-DEVICE-01"
  private val referenceTime = 1750000000000L // 2025-06-15T10:13:20Z

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    database = CheckInDatabase.createInMemory(context)
    repository = CheckInRepository(database.checkInDao())

    // Configure deterministic ephemeral signer and register public key into Check-In trust anchor
    testSigner = JvmEphemeralEcPackageSigner(keyId = "evento-admin-p256-v1")
    EventoSigningKeyManager.setSignerForTesting(testSigner)
    CheckInTrustAnchorRegistry.clear()
    CheckInTrustAnchorRegistry.register(testSigner.keyId, testSigner.getPublicKey())

    verifier = EventoPackageVerifier(
      timeProvider = { referenceTime },
    )
    importer = EventoPackageImporter(repository, verifier)
    engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )
    qrService = QrCheckInService(
      engine = engine,
    )
    packageWriter = EventoPackageWriter(context)
  }

  @After
  fun tearDown() {
    database.close()
    EventoSigningKeyManager.reset()
    CheckInTrustAnchorRegistry.clear()
  }

  // =========================================================================
  // HELPER: Generate real package bytes using EventoPackageWriter
  // =========================================================================

  private suspend fun exportAdminPackageBytes(
    event: EventEntity,
    guests: List<GuestEntity>,
    license: EventoPackageLicense? = null,
    scope: PackageGuestScope = PackageGuestScope.ALL,
  ): ByteArray {
    val request = EventPackageExportRequest(
      event = event,
      guests = guests,
      scope = scope,
      license = license,
    )
    val exportResult = packageWriter.writePackage(request)
    assertTrue("Package export should succeed: ${(exportResult as? EventPackageExportResult.Error)?.message}",
      exportResult is EventPackageExportResult.Success)
    val success = exportResult as EventPackageExportResult.Success
    val bytes = success.file.readBytes()
    success.file.delete()
    return bytes
  }

  private fun modifyZipEntry(originalZipBytes: ByteArray, entryNameToModify: String, newContent: (String) -> String): ByteArray {
    val entries = mutableMapOf<String, ByteArray>()
    ZipInputStream(ByteArrayInputStream(originalZipBytes)).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        entries[entry.name] = zis.readBytes()
        zis.closeEntry()
        entry = zis.nextEntry
      }
    }

    val oldBytes = entries[entryNameToModify] ?: error("Entry $entryNameToModify not found")
    val modifiedStr = newContent(String(oldBytes, Charsets.UTF_8))
    entries[entryNameToModify] = modifiedStr.toByteArray(Charsets.UTF_8)

    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      for ((name, bytes) in entries) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(bytes)
        zos.closeEntry()
      }
    }
    return baos.toByteArray()
  }

  private fun removeZipEntry(originalZipBytes: ByteArray, entryNameToRemove: String): ByteArray {
    val entries = mutableMapOf<String, ByteArray>()
    ZipInputStream(ByteArrayInputStream(originalZipBytes)).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        if (entry.name != entryNameToRemove) {
          entries[entry.name] = zis.readBytes()
        }
        zis.closeEntry()
        entry = zis.nextEntry
      }
    }

    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      for ((name, bytes) in entries) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(bytes)
        zos.closeEntry()
      }
    }
    return baos.toByteArray()
  }

  // =========================================================================
  // CATEGORY A: PACKAGE STRUCTURE & REAL PACKAGE BYTES COMPATIBILITY
  // =========================================================================

  @Test
  fun testRealAdminPackageBytesConsumedByCheckInSuccessfully() = runBlocking {
    val event = EventEntity(
      id = 1001L,
      name = "National Technology Forum 2026",
      date = "2026-11-20",
      location = "Riyadh Exhibition Center",
      organizer = "Digital Saudi Authority",
      status = EventStatus.ACTIVE,
    )
    val guest1Uuid = "a1111111-1111-4111-8111-111111111111"
    val guest2Uuid = "b2222222-2222-4222-8222-222222222222"
    val guests = listOf(
      GuestEntity(
        id = 1L,
        eventId = 1001L,
        fullName = "Fahad Al-Harbi",
        email = "fahad@example.com",
        phone = "+966500000001",
        organization = "Ministry of Communications",
        jobTitle = "Digital Transformation Advisor",
        invitationStatus = InvitationStatus.CONFIRMED,
        notes = "VIP Stage Guest",
        uuid = guest1Uuid,
      ),
      GuestEntity(
        id = 2L,
        eventId = 1001L,
        fullName = "Reem Al-Mutairi",
        email = "reem@example.com",
        phone = "+966500000002",
        organization = "Future Systems",
        jobTitle = "Security Architect",
        invitationStatus = InvitationStatus.INVITED,
        notes = "Speaker",
        uuid = guest2Uuid,
      ),
    )

    val packageBytes = exportAdminPackageBytes(event, guests)
    val validation = verifier.verifyPackage(packageBytes)

    assertTrue("Validation should succeed for authentic Admin package: ${(validation as? PackageValidationResult.Invalid)?.technicalReason}",
      validation is PackageValidationResult.Valid)
    val valid = validation as PackageValidationResult.Valid
    assertEquals(1001L, valid.event.eventId)
    assertEquals("National Technology Forum 2026", valid.event.name)
    assertEquals(2, valid.guests.size)
    assertEquals(PackageSecurityStatus.SIGNED_VERIFIED, valid.securityStatus)
    assertEquals("evento-admin-p256-v1", valid.keyId)

    // Verify PII minimization: email, phone, notes must not be present in imported domain model
    assertEquals(guest1Uuid, valid.guests[0].uuid)
    assertEquals("Fahad Al-Harbi", valid.guests[0].fullName)
    assertEquals("Ministry of Communications", valid.guests[0].organization)
    assertEquals("Digital Transformation Advisor", valid.guests[0].jobTitle)
    assertEquals("CONFIRMED", valid.guests[0].invitationStatus)
  }

  @Test
  fun testValidLicensedPackageContainsLicenseJsonAndVerifies() = runBlocking {
    val event = EventEntity(
      id = 1002L,
      name = "Executive Cloud Summit 2026",
      date = "2026-12-05",
      location = "Kingdom Tower Ballroom",
      organizer = "Enterprise Cloud Alliance",
      status = EventStatus.ACTIVE,
    )
    val guestUuid = "c3333333-3333-4333-8333-333333333333"
    val guests = listOf(
      GuestEntity(
        id = 10L,
        eventId = 1002L,
        fullName = "Noura Al-Dosari",
        email = "noura@example.com",
        phone = "+966512345678",
        organization = "Cloud Tech",
        jobTitle = "VP Engineering",
        invitationStatus = InvitationStatus.CONFIRMED,
        notes = "VIP",
        uuid = guestUuid,
      ),
    )
    val license = EventoPackageLicense(
      licenseId = "LIC-CLOUD-2026-001",
      eventId = 1002L,
      issuedAt = referenceTime - 100000L,
      expiresAt = referenceTime + 864000000L,
      maxGuests = 100,
      allowedDeviceCount = 5,
      boundDeviceId = testDeviceId,
      licenseFormatVersion = 1,
    )

    val packageBytes = exportAdminPackageBytes(event, guests, license = license)
    val validation = verifier.verifyPackage(packageBytes, localDeviceId = testDeviceId)

    assertTrue("Licensed package verification must succeed: ${(validation as? PackageValidationResult.Invalid)?.technicalReason}",
      validation is PackageValidationResult.Valid)
    val valid = validation as PackageValidationResult.Valid
    assertNotNull(valid.license)
    assertEquals("LIC-CLOUD-2026-001", valid.license?.licenseId)
    assertEquals(100, valid.license?.maxGuests)
    assertEquals(testDeviceId, valid.license?.boundDeviceId)
  }

  // =========================================================================
  // CATEGORY B: ARABIC, UNICODE, AND SPECIAL CHARACTERS PRESERVATION
  // =========================================================================

  @Test
  fun testArabicEventAndGuestDataSurvivesAdminToCheckInPipeline() = runBlocking {
    val event = EventEntity(
      id = 2001L,
      name = "مؤتمر الذكاء الاصطناعي والأمن السيبراني ٢٠٢٦",
      date = "٢٠٢٦-١١-١٥",
      location = "مركز الملك فهد الثقافي - الرياض",
      organizer = "الهيئة الوطنية للأمن السيبراني & الذكاء الاصطناعي",
      status = EventStatus.ACTIVE,
    )
    val guest1Uuid = "d4444444-4444-4444-8444-444444444444"
    val guest2Uuid = "e5555555-5555-4555-8555-555555555555"
    val guests = listOf(
      GuestEntity(
        id = 21L,
        eventId = 2001L,
        fullName = "د. طارق بن عبد العزيز المنصور",
        email = "tariq@almansoor.sa",
        phone = "+966551234567",
        organization = "مركز البحوث والابتكار المتقدم",
        jobTitle = "كبير الباحثين ومستشار أمن المعلومات",
        invitationStatus = InvitationStatus.CONFIRMED,
        notes = "المتحدث الرئيسي للجلسة الافتتاحية",
        uuid = guest1Uuid,
      ),
      GuestEntity(
        id = 22L,
        eventId = 2001L,
        fullName = "سارة بنت خالد الشمري (M.Sc. & Ph.D.)",
        email = "sarah@tech.org",
        phone = "+966559876543",
        organization = "Global Innovation Labs <AI & Data>",
        jobTitle = "Director of Cloud Operations & Security",
        invitationStatus = InvitationStatus.CONFIRMED,
        notes = "Requires wheelchair access & VIP pass",
        uuid = guest2Uuid,
      ),
    )

    val packageBytes = exportAdminPackageBytes(event, guests)

    // Import into Check-In via importer
    val importResult = importer.importFromStream(ByteArrayInputStream(packageBytes))
    assertTrue("Import should succeed: ${(importResult as? PackageImportResult.Error)?.technicalDetails}",
      importResult is PackageImportResult.Success)

    // Verify persisted database records in Check-In Room DB
    val activeEvent = repository.getActiveEvent()
    assertNotNull(activeEvent)
    assertEquals(2001L, activeEvent?.eventId)
    assertEquals("مؤتمر الذكاء الاصطناعي والأمن السيبراني ٢٠٢٦", activeEvent?.name)
    assertEquals("مركز الملك فهد الثقافي - الرياض", activeEvent?.location)
    assertEquals("الهيئة الوطنية للأمن السيبراني & الذكاء الاصطناعي", activeEvent?.organizer)

    val importedGuest1 = repository.getGuestByUuidForEvent(2001L, guest1Uuid)
    assertNotNull(importedGuest1)
    assertEquals("د. طارق بن عبد العزيز المنصور", importedGuest1?.fullName)
    assertEquals("مركز البحوث والابتكار المتقدم", importedGuest1?.organization)
    assertEquals("كبير الباحثين ومستشار أمن المعلومات", importedGuest1?.jobTitle)

    val importedGuest2 = repository.getGuestByUuidForEvent(2001L, guest2Uuid)
    assertNotNull(importedGuest2)
    assertEquals("سارة بنت خالد الشمري (M.Sc. & Ph.D.)", importedGuest2?.fullName)
    assertEquals("Global Innovation Labs <AI & Data>", importedGuest2?.organization)
  }

  // =========================================================================
  // CATEGORY C & D: GUEST UUID INTEGRITY & QR CHECK-IN COMPATIBILITY
  // =========================================================================

  @Test
  fun testEndToEndQrPayloadEvaluationAndAttendancePersistence() = runBlocking {
    val event = EventEntity(
      id = 3001L,
      name = "FinTech Saudi Forum 2026",
      date = "2026-10-30",
      location = "Financial District",
      organizer = "Saudi FinTech Network",
      status = EventStatus.ACTIVE,
    )
    val guestUuid = "f6666666-6666-4666-8666-666666666666"
    val guests = listOf(
      GuestEntity(
        id = 31L,
        eventId = 3001L,
        fullName = "Sultan Al-Otaibi",
        email = "sultan@fintech.sa",
        phone = "+966540001122",
        organization = "Saudi Payment Hub",
        jobTitle = "Chief Operating Officer",
        invitationStatus = InvitationStatus.CONFIRMED,
        notes = "Panel Moderator",
        uuid = guestUuid,
      ),
    )

    val packageBytes = exportAdminPackageBytes(event, guests)
    val importResult = importer.importFromStream(ByteArrayInputStream(packageBytes))
    assertTrue(importResult is PackageImportResult.Success)

    // Construct exact QR payload matching EVT1:<guest_uuid>
    val validPayload = "EVT1:$guestUuid"

    // 1. Pure QR parser evaluation
    val parseResult = QrPayloadParser.parse(validPayload)
    assertTrue(parseResult is QrPayloadParseResult.Valid)
    assertEquals(guestUuid, (parseResult as QrPayloadParseResult.Valid).uuid)

    // 2. Offline Check-In Service execution
    val checkInResult = qrService.checkInWithQr(validPayload)
    assertTrue("Check-in should be Success: $checkInResult", checkInResult is QrCheckInResult.Success)
    val success = checkInResult as QrCheckInResult.Success
    assertEquals(guestUuid, success.guest.uuid)
    assertEquals("Sultan Al-Otaibi", success.guest.fullName)
    assertEquals(referenceTime, success.checkedInAt)

    // 3. Duplicate check-in detection (idempotent duplicate warning)
    val duplicateResult = qrService.checkInWithQr(validPayload)
    assertTrue("Second scan should be AlreadyCheckedIn: $duplicateResult", duplicateResult is QrCheckInResult.AlreadyCheckedIn)
    val already = duplicateResult as QrCheckInResult.AlreadyCheckedIn
    assertEquals(guestUuid, already.guest.uuid)
    assertEquals(referenceTime, already.checkedInAt)

    // 4. Unknown UUID
    val unknownUuidPayload = "EVT1:00000000-0000-4000-8000-000000000000"
    val unknownResult = qrService.checkInWithQr(unknownUuidPayload)
    assertTrue("Unknown guest UUID should return GuestNotFound", unknownResult is QrCheckInResult.GuestNotFound)

    // 5. Malformed QR payloads
    assertTrue(qrService.checkInWithQr("INVALID:$guestUuid") is QrCheckInResult.InvalidQr)
    assertTrue(qrService.checkInWithQr("EVT1: not-a-uuid") is QrCheckInResult.InvalidQr)
    assertTrue(qrService.checkInWithQr("EVT1:$guestUuid ") is QrCheckInResult.InvalidQr)
    assertTrue(qrService.checkInWithQr("EVT1:$guestUuid\n") is QrCheckInResult.InvalidQr)
    assertTrue(qrService.checkInWithQr("EVT1:$guestUuid;extra_data") is QrCheckInResult.InvalidQr)
    assertTrue(qrService.checkInWithQr("sultan@fintech.sa") is QrCheckInResult.InvalidQr)
  }

  // =========================================================================
  // CATEGORY E: TAMPER REJECTION TEST MATRIX
  // =========================================================================

  @Test
  fun testTamperMatrixRejectsModifiedManifest() = runBlocking {
    val (event, guests) = createStandardEventAndGuests(4001L)
    val cleanBytes = exportAdminPackageBytes(event, guests)

    val tamperedBytes = modifyZipEntry(cleanBytes, "manifest.json") { json ->
      JSONObject(json).put("eventName", "Tampered Event Name").toString()
    }
    val result = verifier.verifyPackage(tamperedBytes)
    assertTrue("Tampered manifest must fail verification", result is PackageValidationResult.Invalid)
  }

  @Test
  fun testTamperMatrixRejectsModifiedEvent() = runBlocking {
    val (event, guests) = createStandardEventAndGuests(4002L)
    val cleanBytes = exportAdminPackageBytes(event, guests)

    val tamperedBytes = modifyZipEntry(cleanBytes, "event.json") { json ->
      JSONObject(json).put("organizer", "Hacker Organization").toString()
    }
    val result = verifier.verifyPackage(tamperedBytes)
    assertTrue("Tampered event.json must fail verification", result is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.INTEGRITY_CHECK_FAILED, (result as PackageValidationResult.Invalid).errorCategory)
  }

  @Test
  fun testTamperMatrixRejectsModifiedGuests() = runBlocking {
    val (event, guests) = createStandardEventAndGuests(4003L)
    val cleanBytes = exportAdminPackageBytes(event, guests)

    val tamperedBytes = modifyZipEntry(cleanBytes, "guests.json") { json ->
      val root = JSONObject(json)
      val arr = root.getJSONArray("guests")
      val g0 = arr.getJSONObject(0)
      g0.put("fullName", "Malicious Attacker")
      root.toString()
    }
    val result = verifier.verifyPackage(tamperedBytes)
    assertTrue("Tampered guests.json must fail verification", result is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.INTEGRITY_CHECK_FAILED, (result as PackageValidationResult.Invalid).errorCategory)
  }

  @Test
  fun testTamperMatrixRejectsModifiedLicense() = runBlocking {
    val (event, guests) = createStandardEventAndGuests(4004L)
    val license = EventoPackageLicense(
      licenseId = "LIC-TAMPER-001",
      eventId = 4004L,
      issuedAt = referenceTime - 1000L,
      expiresAt = referenceTime + 100000L,
      maxGuests = 50,
    )
    val cleanBytes = exportAdminPackageBytes(event, guests, license = license)

    val tamperedBytes = modifyZipEntry(cleanBytes, "license.json") { json ->
      JSONObject(json).put("maxGuests", 99999).toString() // Attempt privilege escalation
    }
    val result = verifier.verifyPackage(tamperedBytes)
    assertTrue("Tampered license.json must fail verification", result is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.INTEGRITY_CHECK_FAILED, (result as PackageValidationResult.Invalid).errorCategory)
  }

  @Test
  fun testTamperMatrixRejectsModifiedOrRemovedSignature() = runBlocking {
    val (event, guests) = createStandardEventAndGuests(4005L)
    val cleanBytes = exportAdminPackageBytes(event, guests)

    // 1. Modified signature bytes
    val tamperedSigBytes = modifyZipEntry(cleanBytes, "signature.json") { json ->
      val root = JSONObject(json)
      root.put("signature", "MEQCIDummySignatureBytesThatAreInvalidBase64OrForgedSignature==")
      root.toString()
    }
    val result1 = verifier.verifyPackage(tamperedSigBytes)
    assertTrue("Modified signature must fail verification", result1 is PackageValidationResult.Invalid)

    // 2. Missing signature entry entirely
    val missingSigBytes = removeZipEntry(cleanBytes, "signature.json")
    val result2 = verifier.verifyPackage(missingSigBytes)
    assertTrue("Missing signature.json must fail verification", result2 is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.INVALID_PACKAGE, (result2 as PackageValidationResult.Invalid).errorCategory)
  }

  @Test
  fun testTamperMatrixRejectsPathTraversalAndDuplicateEntries() = runBlocking {
    val (event, guests) = createStandardEventAndGuests(4006L)
    val cleanBytes = exportAdminPackageBytes(event, guests)

    // 1. Path traversal injection
    val traversalBytes = ByteArrayOutputStream().also { baos ->
      ZipOutputStream(baos).use { zos ->
        ZipInputStream(ByteArrayInputStream(cleanBytes)).use { zis ->
          var e = zis.nextEntry
          while (e != null) {
            zos.putNextEntry(ZipEntry(e.name))
            zos.write(zis.readBytes())
            zos.closeEntry()
            e = zis.nextEntry
          }
        }
        zos.putNextEntry(ZipEntry("../../../etc/shadow"))
        zos.write("root:evil".toByteArray())
        zos.closeEntry()
      }
    }.toByteArray()

    val traversalResult = verifier.verifyPackage(traversalBytes)
    assertTrue("Path traversal must be rejected immediately", traversalResult is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.SECURITY_VIOLATION, (traversalResult as PackageValidationResult.Invalid).errorCategory)

    // 2. Duplicate entry injection (using raw bytes concatenation to allow duplicate ZIP entries)
    val duplicateBytes = ByteArrayOutputStream().also { baos ->
      val eventData = "{}".toByteArray(Charsets.UTF_8)
      val entries = listOf(
        Pair("manifest.json", eventData),
        Pair("event.json", eventData),
        Pair("EVENT.JSON", eventData), // case-insensitive duplicate of event.json
        Pair("guests.json", eventData),
        Pair("signature.json", eventData),
      )
      ZipOutputStream(baos).use { zos ->
        for ((name, data) in entries) {
          zos.putNextEntry(ZipEntry(name))
          zos.write(data)
          zos.closeEntry()
        }
      }
    }.toByteArray()

    val duplicateResult = verifier.verifyPackage(duplicateBytes)
    assertTrue("Duplicate ZIP entries must be rejected", duplicateResult is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.SECURITY_VIOLATION, (duplicateResult as PackageValidationResult.Invalid).errorCategory)
  }

  @Test
  fun testCorruptZipBytesRejectedGracefully() {
    val corruptBytes = "PK\u0003\u0004RandomCorruptedGarbageDataNotAZipContainer".toByteArray()
    val result = verifier.verifyPackage(corruptBytes)
    assertTrue("Corrupt archive must fail verification", result is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.INVALID_PACKAGE, (result as PackageValidationResult.Invalid).errorCategory)
  }

  // =========================================================================
  // CATEGORY F: LICENSE CONSTRAINTS (EXPIRY, MAX GUESTS, DEVICE BINDING)
  // =========================================================================

  @Test
  fun testLicenseExpiredRejectsPackageImport() = runBlocking {
    val (event, guests) = createStandardEventAndGuests(5001L)
    val expiredLicense = EventoPackageLicense(
      licenseId = "LIC-EXPIRED-01",
      eventId = 5001L,
      issuedAt = referenceTime - 200000L,
      expiresAt = referenceTime - 1000L, // Expired in the past relative to referenceTime
      maxGuests = 100,
    )
    val packageBytes = exportAdminPackageBytes(event, guests, license = expiredLicense)
    val result = verifier.verifyPackage(packageBytes)

    assertTrue("Expired license must be rejected", result is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.LICENSE_EXPIRED, (result as PackageValidationResult.Invalid).errorCategory)
  }

  @Test
  fun testLicenseMaxGuestsExceededRejectsPackage() = runBlocking {
    val event = EventEntity(
      id = 5002L,
      name = "Exclusive VIP Gala",
      date = "2026-11-20",
      location = "VIP Suite",
      organizer = "Luxury Events",
      status = EventStatus.ACTIVE,
    )
    val guests = listOf(
      GuestEntity(id = 1L, eventId = 5002L, fullName = "Guest 1", email = "g1@test.com", phone = "1", organization = "O", jobTitle = "T", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = "11111111-1111-4111-8111-111111111111"),
      GuestEntity(id = 2L, eventId = 5002L, fullName = "Guest 2", email = "g2@test.com", phone = "2", organization = "O", jobTitle = "T", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = "22222222-2222-4222-8222-222222222222"),
      GuestEntity(id = 3L, eventId = 5002L, fullName = "Guest 3", email = "g3@test.com", phone = "3", organization = "O", jobTitle = "T", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = "33333333-3333-4333-8333-333333333333"),
    )
    // License only permits max 2 guests
    val license = EventoPackageLicense(
      licenseId = "LIC-LIMITED-02",
      eventId = 5002L,
      issuedAt = referenceTime - 1000L,
      expiresAt = referenceTime + 100000L,
      maxGuests = 2,
    )

    // Admin writer pre-flight will reject generating package with > maxGuests
    val request = EventPackageExportRequest(event, guests, PackageGuestScope.ALL, license = license)
    val exportResult = packageWriter.writePackage(request)
    assertTrue("Admin should block generating package exceeding maxGuests", exportResult is EventPackageExportResult.Error)
  }

  @Test
  fun testDeviceBindingMismatchRejectsCheckInTerminal() = runBlocking {
    val (event, guests) = createStandardEventAndGuests(5003L)
    val boundLicense = EventoPackageLicense(
      licenseId = "LIC-BOUND-03",
      eventId = 5003L,
      issuedAt = referenceTime - 1000L,
      expiresAt = referenceTime + 100000L,
      maxGuests = 50,
      boundDeviceId = "TERM-AUTHORIZED-ONLY",
    )
    val packageBytes = exportAdminPackageBytes(event, guests, license = boundLicense)

    // 1. Verify on unauthorized device
    val rejected = verifier.verifyPackage(packageBytes, localDeviceId = "TERM-UNAUTHORIZED")
    assertTrue("Device mismatch must fail verification", rejected is PackageValidationResult.Invalid)
    assertEquals(PackageSecurityError.LICENSE_DEVICE_MISMATCH, (rejected as PackageValidationResult.Invalid).errorCategory)

    // 2. Verify on authorized device
    val accepted = verifier.verifyPackage(packageBytes, localDeviceId = "TERM-AUTHORIZED-ONLY")
    assertTrue("Matching device must succeed verification", accepted is PackageValidationResult.Valid)
  }

  // =========================================================================
  // CATEGORY G: ATOMIC IMPORT SAFETY & ROLLBACK
  // =========================================================================

  @Test
  fun testInvalidPackageLeavesCheckInDatabaseCompletelyUntouched() = runBlocking {
    // 1. Seed existing active event in Check-In
    val (initialEvent, initialGuests) = createStandardEventAndGuests(6001L)
    val cleanBytes = exportAdminPackageBytes(initialEvent, initialGuests)
    val initialImport = importer.importFromStream(ByteArrayInputStream(cleanBytes))
    assertTrue(initialImport is PackageImportResult.Success)

    val preActiveEvent = repository.getActiveEvent()
    assertEquals(6001L, preActiveEvent?.eventId)
    val preGuestCount = repository.getGuestCountForEvent(6001L)
    assertEquals(2, preGuestCount)

    // 2. Attempt to import tampered package for Event 6002
    val (badEvent, badGuests) = createStandardEventAndGuests(6002L)
    val badPackageBytes = exportAdminPackageBytes(badEvent, badGuests)
    val tamperedBytes = modifyZipEntry(badPackageBytes, "event.json") { json ->
      JSONObject(json).put("name", "Tampered Hack").toString()
    }

    val failedImport = importer.importFromStream(ByteArrayInputStream(tamperedBytes))
    assertTrue("Failed package must return Error: $failedImport", failedImport is PackageImportResult.Error)

    // 3. Verify Check-In database remains unchanged
    val postActiveEvent = repository.getActiveEvent()
    assertEquals(6001L, postActiveEvent?.eventId)
    assertEquals(preActiveEvent?.name, postActiveEvent?.name)
    assertEquals(2, repository.getGuestCountForEvent(6001L))
    assertEquals(0, repository.getGuestCountForEvent(6002L))
  }

  // =========================================================================
  // CATEGORY H: RE-IMPORT BEHAVIOR
  // =========================================================================

  @Test
  fun testReimportReplacesRosterAndRefreshesMetadataCleanly() = runBlocking {
    val event = EventEntity(
      id = 7001L,
      name = "Annual Partner Conference",
      date = "2026-11-25",
      location = "Convention Center",
      organizer = "Partner Alliance",
      status = EventStatus.ACTIVE,
    )
    val initialGuests = listOf(
      GuestEntity(id = 1L, eventId = 7001L, fullName = "Initial Guest 1", email = "g1@test.com", phone = "1", organization = "O", jobTitle = "T", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = "11111111-1111-4111-8111-111111111111"),
      GuestEntity(id = 2L, eventId = 7001L, fullName = "Initial Guest 2", email = "g2@test.com", phone = "2", organization = "O", jobTitle = "T", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = "22222222-2222-4222-8222-222222222222"),
    )

    val package1Bytes = exportAdminPackageBytes(event, initialGuests)
    val import1 = importer.importFromStream(ByteArrayInputStream(package1Bytes))
    assertTrue(import1 is PackageImportResult.Success)
    assertEquals(2, repository.getGuestCountForEvent(7001L))

    // Perform check-in for Guest 1
    val checkIn1 = qrService.checkInWithQr("EVT1:11111111-1111-4111-8111-111111111111")
    assertTrue(checkIn1 is QrCheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(7001L))

    // Now re-export updated roster with 3 guests
    val updatedGuests = listOf(
      GuestEntity(id = 1L, eventId = 7001L, fullName = "Initial Guest 1", email = "g1@test.com", phone = "1", organization = "O", jobTitle = "T", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = "11111111-1111-4111-8111-111111111111"),
      GuestEntity(id = 2L, eventId = 7001L, fullName = "Initial Guest 2", email = "g2@test.com", phone = "2", organization = "O", jobTitle = "T", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = "22222222-2222-4222-8222-222222222222"),
      GuestEntity(id = 3L, eventId = 7001L, fullName = "New Guest 3", email = "g3@test.com", phone = "3", organization = "O", jobTitle = "T", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = "33333333-3333-4333-8333-333333333333"),
    )
    val package2Bytes = exportAdminPackageBytes(event, updatedGuests)
    val import2 = importer.importFromStream(ByteArrayInputStream(package2Bytes))
    assertTrue(import2 is PackageImportResult.Success)

    assertEquals(3, repository.getGuestCountForEvent(7001L))
    assertNotNull(repository.getGuestByUuidForEvent(7001L, "33333333-3333-4333-8333-333333333333"))

    // Re-importing replaces all guests and resets previous attendance records cleanly
    val reScan = qrService.checkInWithQr("EVT1:11111111-1111-4111-8111-111111111111")
    assertTrue("Guest 1 can check in fresh after package re-import", reScan is QrCheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(7001L))
  }

  // =========================================================================
  // CATEGORY I: CROSS-EVENT ISOLATION
  // =========================================================================

  @Test
  fun testCrossEventIsolationBetweenEventAAndEventB() = runBlocking {
    val eventA = EventEntity(id = 8001L, name = "Event Alpha", date = "2026-10-01", location = "Hall A", organizer = "Org A", status = EventStatus.ACTIVE)
    val guestAUuid = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
    val guestsA = listOf(GuestEntity(id = 1L, eventId = 8001L, fullName = "Alpha Guest", email = "a@a.com", phone = "1", organization = "OA", jobTitle = "TA", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = guestAUuid))

    val eventB = EventEntity(id = 8002L, name = "Event Beta", date = "2026-10-02", location = "Hall B", organizer = "Org B", status = EventStatus.ACTIVE)
    val guestBUuid = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb"
    val guestsB = listOf(GuestEntity(id = 2L, eventId = 8002L, fullName = "Beta Guest", email = "b@b.com", phone = "2", organization = "OB", jobTitle = "TB", invitationStatus = InvitationStatus.CONFIRMED, notes = "", uuid = guestBUuid))

    // 1. Export & Import Event A
    val packageABytes = exportAdminPackageBytes(eventA, guestsA)
    importer.importFromStream(ByteArrayInputStream(packageABytes))

    // Verify Event A is active
    val currentEvent = repository.getActiveEvent()
    assertEquals(8001L, currentEvent?.eventId)

    // Guest A can check in
    assertTrue(qrService.checkInWithQr("EVT1:$guestAUuid") is QrCheckInResult.Success)

    // Guest B cannot check in into Event A (isolated!)
    val scanBInA = qrService.checkInWithQr("EVT1:$guestBUuid")
    assertTrue("Guest B must not be found in Event A", scanBInA is QrCheckInResult.GuestNotFound)
    assertNull(repository.getGuestByUuidForEvent(8001L, guestBUuid))
  }

  // =========================================================================
  // CATEGORY J: LARGE PACKAGE VERIFICATION (500, 1000 GUESTS)
  // =========================================================================

  @Test
  fun testLargePackage500GuestsExportAndImportPerformance() = runBlocking {
    val (event, guests) = createLargeEventRoster(9001L, 500)

    val startTime = System.currentTimeMillis()
    val packageBytes = exportAdminPackageBytes(event, guests)
    val exportDuration = System.currentTimeMillis() - startTime
    assertTrue("500-guest export took ${exportDuration}ms (expected < 6000ms)", exportDuration < 6000)

    val importStartTime = System.currentTimeMillis()
    val importResult = importer.importFromStream(ByteArrayInputStream(packageBytes))
    val importDuration = System.currentTimeMillis() - importStartTime
    assertTrue(importResult is PackageImportResult.Success)
    assertTrue("500-guest import took ${importDuration}ms (expected < 6000ms)", importDuration < 6000)

    assertEquals(500, repository.getGuestCountForEvent(9001L))
  }

  @Test
  fun testLargePackage1000GuestsExportAndImportPerformance() = runBlocking {
    val (event, guests) = createLargeEventRoster(9002L, 1000)

    val startTime = System.currentTimeMillis()
    val packageBytes = exportAdminPackageBytes(event, guests)
    val exportDuration = System.currentTimeMillis() - startTime
    assertTrue("1000-guest export took ${exportDuration}ms (expected < 8000ms)", exportDuration < 8000)

    val importStartTime = System.currentTimeMillis()
    val importResult = importer.importFromStream(ByteArrayInputStream(packageBytes))
    val importDuration = System.currentTimeMillis() - importStartTime
    assertTrue(importResult is PackageImportResult.Success)
    assertTrue("1000-guest import took ${importDuration}ms (expected < 8000ms)", importDuration < 8000)

    assertEquals(1000, repository.getGuestCountForEvent(9002L))

    // Quick verification that first, middle, and last guests resolve
    val firstUuid = guests[0].uuid
    val midUuid = guests[500].uuid
    val lastUuid = guests[999].uuid

    assertTrue(qrService.checkInWithQr("EVT1:$firstUuid") is QrCheckInResult.Success)
    assertTrue(qrService.checkInWithQr("EVT1:$midUuid") is QrCheckInResult.Success)
    assertTrue(qrService.checkInWithQr("EVT1:$lastUuid") is QrCheckInResult.Success)
    assertEquals(3, repository.getAttendanceCount(9002L))
  }

  // =========================================================================
  // HELPER FACTORIES
  // =========================================================================

  private fun createStandardEventAndGuests(eventId: Long): Pair<EventEntity, List<GuestEntity>> {
    val event = EventEntity(
      id = eventId,
      name = "Summit Event $eventId",
      date = "2026-11-15",
      location = "Convention Hall",
      organizer = "Global Authority",
      status = EventStatus.ACTIVE,
    )
    val guests = listOf(
      GuestEntity(
        id = eventId * 10 + 1,
        eventId = eventId,
        fullName = "Guest One of $eventId",
        email = "one@event$eventId.com",
        phone = "+111",
        organization = "Org One",
        jobTitle = "Title One",
        invitationStatus = InvitationStatus.CONFIRMED,
        notes = "Note One",
        uuid = String.format("11111111-1111-4111-8111-%012d", eventId),
      ),
      GuestEntity(
        id = eventId * 10 + 2,
        eventId = eventId,
        fullName = "Guest Two of $eventId",
        email = "two@event$eventId.com",
        phone = "+222",
        organization = "Org Two",
        jobTitle = "Title Two",
        invitationStatus = InvitationStatus.CONFIRMED,
        notes = "Note Two",
        uuid = String.format("22222222-2222-4222-8222-%012d", eventId),
      ),
    )
    return Pair(event, guests)
  }

  private fun createLargeEventRoster(eventId: Long, count: Int): Pair<EventEntity, List<GuestEntity>> {
    val event = EventEntity(
      id = eventId,
      name = "Mega Conference $eventId ($count Guests)",
      date = "2026-12-01",
      location = "Exhibition Hall A",
      organizer = "Mega Events Consortium",
      status = EventStatus.ACTIVE,
    )
    val guests = ArrayList<GuestEntity>(count)
    for (i in 1..count) {
      guests.add(
        GuestEntity(
          id = eventId * 10000 + i,
          eventId = eventId,
          fullName = "Delegate $i of $count",
          email = "delegate$i@conference$eventId.com",
          phone = "+96650000$i",
          organization = "Organization ${(i % 20) + 1}",
          jobTitle = "Specialist ${(i % 10) + 1}",
          invitationStatus = if (i % 5 == 0) InvitationStatus.INVITED else InvitationStatus.CONFIRMED,
          notes = "Attendee notes for index $i",
          uuid = String.format("ffffffff-%04x-4000-8000-%012x", eventId, i),
        )
      )
    }
    return Pair(event, guests)
  }
}
