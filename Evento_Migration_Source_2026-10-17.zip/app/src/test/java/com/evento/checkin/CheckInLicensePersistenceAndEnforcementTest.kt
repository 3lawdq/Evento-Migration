package com.evento.checkin

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.util.packageexport.EventPackageExportRequest
import com.example.util.packageexport.EventoPackageBuilder
import com.example.util.packageexport.EventoPackageLicense
import com.example.util.packageexport.PackageGuestScope
import com.example.util.packageexport.security.EventoSigningKeyManager
import com.example.util.packageexport.security.JvmEphemeralEcPackageSigner
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.engine.CheckInEngine
import com.evento.checkin.domain.license.EventLicenseValidator
import com.evento.checkin.domain.model.AttendanceRecord
import com.evento.checkin.domain.model.CheckInResult
import com.evento.checkin.domain.model.EventLicense
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.ImportedGuest
import com.evento.checkin.domain.model.LicenseStatus
import com.evento.checkin.domain.qr.QrCheckInResult
import com.evento.checkin.domain.qr.QrCheckInService
import com.evento.checkin.security.CheckInDeviceIdentityManager
import com.evento.checkin.util.packageutil.CheckInTrustAnchorRegistry
import com.evento.checkin.util.packageutil.EventoPackageImporter
import com.evento.checkin.util.packageutil.EventoPackageVerifier
import com.evento.checkin.util.packageutil.PackageImportResult
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Phase 7.7 Step 2: License Persistence and Check-In Engine Enforcement Test Suite.
 *
 * Covers:
 * A. Room Migration (V2 -> V3)
 * B. Licensed Import Persistence
 * C. Unlicensed Persistence
 * D. Invalid Package Preservation
 * E. Engine License Enforcement
 * F. Critical Safety (No attendance inserted on license rejection)
 * G. Duplicate Check-In under License
 * H. Event & License Isolation
 * I. Deterministic Time Providers
 */
@RunWith(RobolectricTestRunner::class)
class CheckInLicensePersistenceAndEnforcementTest {

  private lateinit var context: Context
  private lateinit var database: CheckInDatabase
  private lateinit var repository: CheckInRepository
  private lateinit var testSigner: JvmEphemeralEcPackageSigner

  private val testDeviceId = "TERM-TEST-DEVICE-0001"
  private val referenceTime = 1750000000000L // 2025-06-15T10:13:20Z

  private val sampleAdminEvent = EventEntity(
    id = 888L,
    name = "CyberSecurity Conclave 2026",
    date = "2026-11-20",
    location = "Convention Center",
    organizer = "SecureNet Inc",
    status = EventStatus.ACTIVE,
  )

  private val sampleAdminGuests = listOf(
    GuestEntity(
      id = 101L,
      eventId = 888L,
      fullName = "Dr. Elena Rostova",
      email = "elena@securenet.org",
      phone = "+14155550100",
      organization = "Quantum Labs",
      invitationStatus = InvitationStatus.CONFIRMED,
      uuid = "11111111-1111-1111-1111-111111111111",
    ),
    GuestEntity(
      id = 102L,
      eventId = 888L,
      fullName = "Marcus Vance",
      email = "marcus@securenet.org",
      phone = "+14155550101",
      organization = "Defense Dynamics",
      invitationStatus = InvitationStatus.CONFIRMED,
      uuid = "22222222-2222-2222-2222-222222222222",
    ),
  )

  private val guest1Uuid = "11111111-1111-1111-1111-111111111111"
  private val guest2Uuid = "22222222-2222-2222-2222-222222222222"

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    database = CheckInDatabase.createInMemory(context)
    repository = CheckInRepository(database.checkInDao())

    testSigner = JvmEphemeralEcPackageSigner(
      keyId = "test-checkin-persistence-signer-1",
      keyPair = JvmEphemeralEcPackageSigner.generateEcP256KeyPair(),
    )
    EventoSigningKeyManager.setSignerForTesting(testSigner)
    CheckInTrustAnchorRegistry.clear()
    CheckInTrustAnchorRegistry.register(testSigner.keyId, testSigner.getPublicKey())
  }

  @After
  fun tearDown() {
    database.close()
    CheckInTrustAnchorRegistry.clear()
    EventoSigningKeyManager.reset()
  }

  // =========================================================================
  // HELPER METHODS
  // =========================================================================

  private fun buildPackageZip(
    event: EventEntity = sampleAdminEvent,
    guests: List<GuestEntity> = sampleAdminGuests,
    license: EventoPackageLicense? = null,
  ): ByteArray {
    val builder = EventoPackageBuilder(signer = testSigner)
    val payload = builder.buildPackagePayload(
      EventPackageExportRequest(
        event = event,
        guests = guests,
        scope = PackageGuestScope.ALL,
        license = license,
      )
    )

    val entries = mutableMapOf(
      "manifest.json" to payload.manifestJson.toByteArray(Charsets.UTF_8),
      "event.json" to payload.eventJson.toByteArray(Charsets.UTF_8),
      "guests.json" to payload.guestsJson.toByteArray(Charsets.UTF_8),
      "signature.json" to payload.signatureJson.toByteArray(Charsets.UTF_8),
    )
    if (payload.licenseJson != null) {
      entries["license.json"] = payload.licenseJson.toByteArray(Charsets.UTF_8)
    }

    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      for ((name, data) in entries) {
        val entry = ZipEntry(name)
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
      }
    }
    return baos.toByteArray()
  }

  private fun createImporter(currentTime: Long = referenceTime): EventoPackageImporter {
    val verifier = EventoPackageVerifier(
      licenseValidator = EventLicenseValidator(timeProvider = { currentTime }),
      timeProvider = { currentTime },
    )
    return EventoPackageImporter(repository = repository, verifier = verifier)
  }

  // =========================================================================
  // SECTION A: ROOM MIGRATION (V2 -> V3)
  // =========================================================================

  @Test
  fun testA01_roomMigrationV2ToV3_preservesEventGuestsAndAttendanceNonDestructively(): Unit = runBlocking {
    val dbFile = File(context.filesDir, "test_v2_to_v3_migration.db")
    if (dbFile.exists()) dbFile.delete()

    // 1. Manually establish a SQLite database at Version 2 schema
    val rawDb = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
    rawDb.version = 2
    rawDb.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `imported_events` (
        `eventId` INTEGER NOT NULL PRIMARY KEY,
        `name` TEXT NOT NULL,
        `date` TEXT NOT NULL,
        `location` TEXT NOT NULL,
        `organizer` TEXT NOT NULL,
        `packageFormatVersion` INTEGER NOT NULL,
        `guestCount` INTEGER NOT NULL,
        `importedAt` INTEGER NOT NULL,
        `verificationStatus` TEXT NOT NULL
      )
      """.trimIndent()
    )
    rawDb.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `imported_guests` (
        `uuid` TEXT NOT NULL PRIMARY KEY,
        `eventId` INTEGER NOT NULL,
        `fullName` TEXT NOT NULL,
        `invitationStatus` TEXT NOT NULL,
        `organization` TEXT NOT NULL,
        `jobTitle` TEXT NOT NULL,
        `checkInStatus` TEXT NOT NULL
      )
      """.trimIndent()
    )
    rawDb.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `attendance_records` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        `eventId` INTEGER NOT NULL,
        `guestUuid` TEXT NOT NULL,
        `checkedInAt` INTEGER NOT NULL
      )
      """.trimIndent()
    )
    rawDb.execSQL(
      """
      CREATE UNIQUE INDEX IF NOT EXISTS `index_attendance_records_eventId_guestUuid` 
      ON `attendance_records` (`eventId`, `guestUuid`)
      """.trimIndent()
    )

    // Populate existing V2 records
    rawDb.execSQL("INSERT INTO `imported_events` VALUES (999, 'V2 Annual Gala', '2026-10-10', 'Hall 1', 'Evento Admin', 2, 50, 1720000000, 'VERIFIED')")
    rawDb.execSQL("INSERT INTO `imported_guests` VALUES ('11111111-1111-1111-1111-111111111111', 999, 'Alice Pioneer', 'CONFIRMED', 'Tech', 'Staff', 'NOT_CHECKED_IN')")
    rawDb.execSQL("INSERT INTO `attendance_records` (eventId, guestUuid, checkedInAt) VALUES (999, '11111111-1111-1111-1111-111111111111', 1720000500)")
    rawDb.close()

    // 2. Open via Room with MIGRATION_2_3 to migrate to V3
    val v3Db = Room.databaseBuilder(context, CheckInDatabase::class.java, dbFile.absolutePath)
      .addMigrations(CheckInDatabase.MIGRATION_1_2, CheckInDatabase.MIGRATION_2_3)
      .allowMainThreadQueries()
      .build()

    val dao = v3Db.checkInDao()
    val event = dao.getActiveEvent()
    val guest = dao.getGuestByUuid("11111111-1111-1111-1111-111111111111")
    val attendance = dao.getAttendance(999L, "11111111-1111-1111-1111-111111111111")

    assertNotNull("Imported event should survive migration intact", event)
    assertEquals(999L, event?.eventId)
    assertEquals("V2 Annual Gala", event?.name)
    // License fields should be null for migrated legacy/unlicensed V2 event
    assertNull("Legacy event licenseId must be null after migration", event?.licenseId)
    assertNull("Domain license object must be null for legacy event", event?.toDomain()?.license)

    assertNotNull("Guest should survive migration intact", guest)
    assertEquals("Alice Pioneer", guest?.fullName)

    assertNotNull("Attendance record must survive migration intact", attendance)
    assertEquals(1720000500L, attendance?.checkedInAt)

    v3Db.close()
    dbFile.delete()
  }

  // =========================================================================
  // SECTION B: LICENSED IMPORT PERSISTENCE
  // =========================================================================

  @Test
  fun testB01_validLicensedPackage_persistsLicenseAndRestoresAcrossDatabaseReopen(): Unit = runBlocking {
    val dbFile = File(context.filesDir, "test_license_persistence.db")
    if (dbFile.exists()) dbFile.delete()

    val license = EventoPackageLicense(
      licenseId = "LIC-PERSIST-9999",
      eventId = 888L,
      issuedAt = referenceTime - 10000,
      expiresAt = referenceTime + 1000000,
      maxGuests = 150,
      allowedDeviceCount = 1,
      boundDeviceId = testDeviceId,
    )

    val packageBytes = buildPackageZip(license = license)

    // 1. Open persistent database and import package
    val db1 = Room.databaseBuilder(context, CheckInDatabase::class.java, dbFile.absolutePath)
      .addMigrations(CheckInDatabase.MIGRATION_1_2, CheckInDatabase.MIGRATION_2_3)
      .build()
    val repo1 = CheckInRepository(db1.checkInDao())
    val verifier1 = EventoPackageVerifier(
      licenseValidator = EventLicenseValidator(timeProvider = { referenceTime }),
      timeProvider = { referenceTime },
    )
    val importer1 = EventoPackageImporter(repo1, verifier1)

    val importResult = importer1.importFromStream(
      inputStream = ByteArrayInputStream(packageBytes),
      localDeviceId = testDeviceId,
    )
    assertTrue("Package import must succeed: $importResult", importResult is PackageImportResult.Success)

    val activeEvent1 = repo1.getActiveEvent()
    assertNotNull("Active event must exist", activeEvent1)
    val restoredLicense1 = activeEvent1?.license
    assertNotNull("Restored domain license must exist", restoredLicense1)
    assertEquals("LIC-PERSIST-9999", restoredLicense1?.licenseId)
    assertEquals(888L, restoredLicense1?.eventId)
    assertEquals(referenceTime - 10000, restoredLicense1?.issuedAt)
    assertEquals(referenceTime + 1000000, restoredLicense1?.expiresAt)
    assertEquals(150, restoredLicense1?.maxGuests)
    assertEquals(1, restoredLicense1?.allowedDeviceCount)
    assertEquals(testDeviceId, restoredLicense1?.boundDeviceId)
    assertEquals(LicenseStatus.ACTIVE, restoredLicense1?.licenseStatus)
    assertEquals(1, restoredLicense1?.licenseFormatVersion)

    db1.close()

    // 2. Re-open database from disk and verify persistence
    val db2 = Room.databaseBuilder(context, CheckInDatabase::class.java, dbFile.absolutePath)
      .addMigrations(CheckInDatabase.MIGRATION_1_2, CheckInDatabase.MIGRATION_2_3)
      .build()
    val repo2 = CheckInRepository(db2.checkInDao())

    val activeEvent2 = repo2.getActiveEvent()
    assertNotNull("Active event must exist after reopening database", activeEvent2)
    val restoredLicense2 = activeEvent2?.license
    assertNotNull("License must be intact after reopening database", restoredLicense2)
    assertEquals("LIC-PERSIST-9999", restoredLicense2?.licenseId)
    assertEquals(888L, restoredLicense2?.eventId)
    assertEquals(150, restoredLicense2?.maxGuests)
    assertEquals(testDeviceId, restoredLicense2?.boundDeviceId)
    assertEquals(LicenseStatus.ACTIVE, restoredLicense2?.licenseStatus)

    db2.close()
    dbFile.delete()
  }

  // =========================================================================
  // SECTION C: UNLICENSED PERSISTENCE
  // =========================================================================

  @Test
  fun testC01_unlicensedV2Package_persistsWithNullLicenseAndRemainsFunctional(): Unit = runBlocking {
    val packageBytes = buildPackageZip(license = null)
    val importer = createImporter()

    val result = importer.importFromStream(ByteArrayInputStream(packageBytes))
    assertTrue(result is PackageImportResult.Success)

    val activeEvent = repository.getActiveEvent()
    assertNotNull(activeEvent)
    assertNull("Unlicensed package must store null license", activeEvent?.license)

    // Check-in must function normally for unlicensed packages
    val engine = CheckInEngine(repository, timeProvider = { referenceTime })
    val checkInResult = engine.checkIn(guest1Uuid)
    assertTrue("Unlicensed check-in must succeed", checkInResult is CheckInResult.Success)
  }

  // =========================================================================
  // SECTION D: INVALID PACKAGE PRESERVATION
  // =========================================================================

  @Test
  fun testD01_invalidPackageImport_preservesExistingLicensedEventGuestsAndAttendance(): Unit = runBlocking {
    val initialLicense = EventoPackageLicense(
      licenseId = "LIC-INITIAL-1",
      eventId = 888L,
      issuedAt = referenceTime - 1000,
      expiresAt = referenceTime + 100000,
      maxGuests = 50,
      allowedDeviceCount = 1,
      boundDeviceId = testDeviceId,
    )
    val validBytes = buildPackageZip(license = initialLicense)
    val importer = createImporter()

    // 1. Initial valid import
    val import1 = importer.importFromStream(ByteArrayInputStream(validBytes), localDeviceId = testDeviceId)
    assertTrue(import1 is PackageImportResult.Success)

    // 2. Record attendance for guest 1
    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )
    val checkInRes = engine.checkIn(guest1Uuid)
    assertTrue(checkInRes is CheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(888L))

    // 3. Attempt to import an invalid corrupted package
    val corruptedBytes = "corrupted-non-zip-payload".toByteArray(Charsets.UTF_8)
    val import2 = importer.importFromStream(ByteArrayInputStream(corruptedBytes))
    assertTrue("Corrupted import must fail", import2 is PackageImportResult.Error)

    // 4. Verify existing state is 100% preserved
    val activeEvent = repository.getActiveEvent()
    assertNotNull(activeEvent)
    assertEquals(888L, activeEvent?.eventId)
    assertEquals("LIC-INITIAL-1", activeEvent?.license?.licenseId)
    assertEquals(2, repository.getGuestCountForEvent(888L))
    assertEquals(1, repository.getAttendanceCount(888L))
    assertNotNull(repository.getAttendance(888L, guest1Uuid))
  }

  // =========================================================================
  // SECTION E: CHECK-IN ENGINE ENFORCEMENT
  // =========================================================================

  @Test
  fun testE01_validLicense_checkInSucceeds(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Valid Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 2,
      license = EventLicense(
        licenseId = "LIC-1",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        boundDeviceId = testDeviceId,
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("Valid license check-in should succeed", result is CheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE02_expiredLicense_returnsLicenseExpiredAndRejectsCheckIn(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Expired Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-EXPIRED",
        eventId = 888L,
        issuedAt = referenceTime - 50000,
        expiresAt = referenceTime - 1000, // Expired
        maxGuests = 10,
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("CheckInResult must be LicenseExpired", result is CheckInResult.LicenseExpired)
    // CRITICAL: Ensure no attendance record was created
    assertEquals("Attendance record must NOT be inserted when license is expired", 0, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE03_notYetValidLicense_returnsLicenseNotYetValidAndRejectsCheckIn(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Future Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-FUTURE",
        eventId = 888L,
        issuedAt = referenceTime + 10000, // In future
        expiresAt = referenceTime + 100000,
        maxGuests = 10,
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("CheckInResult must be LicenseNotYetValid", result is CheckInResult.LicenseNotYetValid)
    assertEquals("Attendance record must NOT be inserted when license is not yet valid", 0, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE04_guestLimitExceeded_returnsLicenseGuestLimitExceeded(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Small Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 2,
      license = EventLicense(
        licenseId = "LIC-LIMITED",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 1, // Only 1 guest allowed, but 2 exist in event
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
      ImportedGuest(uuid = guest2Uuid, eventId = 888L, fullName = "Marcus Vance", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("CheckInResult must be LicenseGuestLimitExceeded", result is CheckInResult.LicenseGuestLimitExceeded)
    assertEquals("Attendance record must NOT be inserted when guest limit is exceeded", 0, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE05_deviceMismatch_returnsLicenseDeviceMismatch(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Bound Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-BOUND",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        boundDeviceId = "TERM-AUTHORIZED-DEVICE-1",
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    // Current device is TERM-DIFFERENT-DEVICE-999
    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { "TERM-DIFFERENT-DEVICE-999" },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("CheckInResult must be LicenseDeviceMismatch", result is CheckInResult.LicenseDeviceMismatch)
    assertEquals("Attendance record must NOT be inserted on device mismatch", 0, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE06_missingCurrentDeviceIdForBoundLicense_returnsLicenseDeviceMismatch(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Bound Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-BOUND",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        boundDeviceId = "TERM-AUTHORIZED-DEVICE-1",
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    // Current device ID is null
    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { null },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("CheckInResult must be LicenseDeviceMismatch when local device ID is missing", result is CheckInResult.LicenseDeviceMismatch)
    assertEquals(0, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE07_matchingBoundDevice_succeeds(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Bound Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-BOUND",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        boundDeviceId = testDeviceId,
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("Matching bound device must succeed", result is CheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE08_unboundLicense_succeedsOnAnyLocalDevice(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Unbound Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-UNBOUND",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        boundDeviceId = null, // Not bound to any device
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { "TERM-ANY-ARBITRARY-DEVICE" },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("Unbound license must succeed on any device", result is CheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE09_invalidLicenseStatus_returnsLicenseInvalid(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Revoked Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-REVOKED",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        licenseStatus = LicenseStatus.INVALID,
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("CheckInResult must be LicenseInvalid", result is CheckInResult.LicenseInvalid)
    assertEquals(0, repository.getAttendanceCount(888L))
  }

  @Test
  fun testE10_noLicense_preservesLegacyBehavior(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Unlicensed Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = null,
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
    )

    val result = engine.checkIn(guest1Uuid)
    assertTrue("Unlicensed package check-in must succeed as legacy behavior", result is CheckInResult.Success)
    assertEquals(1, repository.getAttendanceCount(888L))
  }

  // =========================================================================
  // SECTION F: CRITICAL SAFETY (Zero Attendance On Rejection)
  // =========================================================================

  @Test
  fun testF01_allLicenseRejections_preventAttendanceInsertion(): Unit = runBlocking {
    val badStatuses = listOf(
      EventLicense(
        licenseId = "L1",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime - 100, // Expired
        maxGuests = 10,
      ),
      EventLicense(
        licenseId = "L2",
        eventId = 888L,
        issuedAt = referenceTime + 10000, // Future
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
      ),
      EventLicense(
        licenseId = "L3",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        boundDeviceId = "TERM-OTHER", // Mismatch
      ),
    )

    for ((index, badLic) in badStatuses.withIndex()) {
      val event = ImportedEvent(
        eventId = 888L,
        name = "Test $index",
        date = "2026-11-20",
        location = "Hall A",
        organizer = "Org",
        packageFormatVersion = 2,
        guestCount = 1,
        license = badLic,
      )
      val guests = listOf(
        ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
      )
      repository.replaceActivePackage(event, guests)

      val engine = CheckInEngine(
        repository = repository,
        timeProvider = { referenceTime },
        localDeviceIdProvider = { testDeviceId },
      )

      val result = engine.checkIn(guest1Uuid)
      assertTrue("Must reject check-in for bad license $index: $result", result !is CheckInResult.Success)
      assertEquals("Zero attendance must be recorded for failure case $index", 0, repository.getAttendanceCount(888L))
    }
  }

  // =========================================================================
  // SECTION G: DUPLICATE CHECK-IN UNDER LICENSE
  // =========================================================================

  @Test
  fun testG01_duplicateCheckInUnderValidLicense_returnsAlreadyCheckedIn(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "Valid Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-DUP-1",
        eventId = 888L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        boundDeviceId = testDeviceId,
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )

    // First scan -> Success
    val firstResult = engine.checkIn(guest1Uuid)
    assertTrue("First scan must succeed", firstResult is CheckInResult.Success)
    val success = firstResult as CheckInResult.Success
    assertEquals(referenceTime, success.checkedInAt)

    // Second scan -> AlreadyCheckedIn
    val secondResult = engine.checkIn(guest1Uuid)
    assertTrue("Second scan must return AlreadyCheckedIn", secondResult is CheckInResult.AlreadyCheckedIn)
    val already = secondResult as CheckInResult.AlreadyCheckedIn
    assertEquals("Original timestamp must be preserved", referenceTime, already.checkedInAt)
    assertEquals("Elena Rostova", already.guest.fullName)

    // Total records must still be exactly 1
    assertEquals("Duplicate attempt must not insert duplicate row", 1, repository.getAttendanceCount(888L))
  }

  // =========================================================================
  // SECTION H: EVENT & LICENSE ISOLATION
  // =========================================================================

  @Test
  fun testH01_eventAndLicenseIsolation_eventALicenseNeverAuthorizesEventB(): Unit = runBlocking {
    // Event A is imported with its license
    val eventA = ImportedEvent(
      eventId = 111L,
      name = "Event A",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org A",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-A",
        eventId = 111L,
        issuedAt = referenceTime - 5000,
        expiresAt = referenceTime + 50000,
        maxGuests = 10,
        boundDeviceId = testDeviceId,
      ),
    )
    val guestsA = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 111L, fullName = "Guest in Event A", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(eventA, guestsA)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )

    // Guest 2 belongs to a hypothetical Event B, not in active package
    val result = engine.checkIn(guest2Uuid)
    assertTrue("Guest not in event A must return GuestNotFound", result is CheckInResult.GuestNotFound)
    assertEquals(0, repository.getAttendanceCount(111L))
  }

  // =========================================================================
  // SECTION I: QR SERVICE BRIDGING WITH LICENSE
  // =========================================================================

  @Test
  fun testI01_qrCheckInService_bridgesLicenseEnforcementProperly(): Unit = runBlocking {
    val event = ImportedEvent(
      eventId = 888L,
      name = "QR Event",
      date = "2026-11-20",
      location = "Hall A",
      organizer = "Org",
      packageFormatVersion = 2,
      guestCount = 1,
      license = EventLicense(
        licenseId = "LIC-QR-EXPIRED",
        eventId = 888L,
        issuedAt = referenceTime - 50000,
        expiresAt = referenceTime - 1000, // Expired
        maxGuests = 10,
      ),
    )
    val guests = listOf(
      ImportedGuest(uuid = guest1Uuid, eventId = 888L, fullName = "Elena Rostova", invitationStatus = "CONFIRMED"),
    )
    repository.replaceActivePackage(event, guests)

    val engine = CheckInEngine(
      repository = repository,
      timeProvider = { referenceTime },
      localDeviceIdProvider = { testDeviceId },
    )
    val qrService = QrCheckInService(engine)

    val qrPayload = "EVT1:$guest1Uuid"
    val qrResult = qrService.checkInWithQr(qrPayload)

    assertTrue("QrCheckInResult must be LicenseExpired", qrResult is QrCheckInResult.LicenseExpired)
    assertEquals("CheckInResult getter must map to LicenseExpired", CheckInResult.LicenseExpired((qrResult as QrCheckInResult.LicenseExpired).reason), qrResult.checkInResult)
    assertEquals(0, repository.getAttendanceCount(888L))
  }
}
