package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.evento.checkin.util.packageutil.CheckInTrustAnchorRegistry
import com.example.ui.EventoApp
import com.example.ui.theme.EventoTheme
import com.example.util.packageexport.security.EventoSigningKeyManager

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Explicitly provision Admin public key into Check-In trust anchor registry (public-key-only)
    try {
      val signer = EventoSigningKeyManager.getSigner()
      CheckInTrustAnchorRegistry.register(
        keyId = signer.keyId,
        publicKey = signer.getPublicKey(),
      )
    } catch (_: Throwable) {
      // Keystore or crypto unavailable in this environment
    }

    setContent {
      EventoTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background,
        ) {
          EventoApp()
        }
      }
    }
  }
}

// Kept for backward compatibility with screenshot tests
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun EventoAppPreview() {
  EventoTheme {
    EventoApp()
  }
}
