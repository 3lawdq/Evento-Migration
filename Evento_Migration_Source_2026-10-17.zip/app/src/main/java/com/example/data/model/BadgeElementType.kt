package com.example.data.model

enum class BadgeElementType {
  ATTENDEE_NAME,
  JOB_TITLE,
  ORGANIZATION,
  EVENT_NAME,
  LOGO,
  QR_PLACEHOLDER,
  QR;

  val isQr: Boolean
    get() = this == QR_PLACEHOLDER || this == QR

  companion object {
    fun fromString(value: String?): BadgeElementType {
      if (value.equals("QR_PLACEHOLDER", ignoreCase = true) || value.equals("QR", ignoreCase = true)) {
        return QR_PLACEHOLDER
      }
      return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: ATTENDEE_NAME
    }
  }
}
