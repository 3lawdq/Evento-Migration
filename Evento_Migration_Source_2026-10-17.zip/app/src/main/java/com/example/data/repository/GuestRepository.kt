package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.importer.ExcelImportResult
import com.example.data.importer.ParsedGuestRow
import com.example.data.local.EventDatabase
import com.example.data.local.dao.GuestDao
import com.example.data.local.entity.GuestEntity
import com.example.data.model.InvitationStatus
import com.example.data.model.JobTitleStatsProjection
import com.example.data.model.OrganizationStatsProjection
import kotlinx.coroutines.flow.Flow
import java.util.UUID

interface GuestRepository {
  fun getGuestsForEvent(eventId: Long): Flow<List<GuestEntity>>
  suspend fun getGuestsForEventSync(eventId: Long): List<GuestEntity>
  fun getGuestsForEventByStatus(eventId: Long, status: InvitationStatus): Flow<List<GuestEntity>>
  fun getGuestById(id: Long): Flow<GuestEntity?>
  suspend fun getGuestByIdSync(id: Long): GuestEntity?
  suspend fun getGuestByUuid(uuid: String): GuestEntity?
  fun getTotalGuestsCount(): Flow<Int>
  fun getGuestsCountForEvent(eventId: Long): Flow<Int>
  fun getGuestsCountByStatus(eventId: Long, status: InvitationStatus): Flow<Int>
  fun searchGuests(eventId: Long, query: String): Flow<List<GuestEntity>>

  suspend fun createGuest(
    eventId: Long,
    fullName: String,
    email: String = "",
    phone: String = "",
    organization: String = "",
    jobTitle: String = "",
    invitationStatus: InvitationStatus = InvitationStatus.INVITED,
    notes: String = "",
  ): Long

  suspend fun importGuestsTransaction(
    eventId: Long,
    validRows: List<ParsedGuestRow>,
  ): ExcelImportResult

  suspend fun updateGuest(guest: GuestEntity)

  suspend fun deleteGuest(id: Long)

  suspend fun bulkUpdateStatus(eventId: Long, guestIds: List<Long>, status: InvitationStatus): Int

  suspend fun bulkUpdateOrganization(eventId: Long, guestIds: List<Long>, organization: String): Int

  suspend fun bulkUpdateJobTitle(eventId: Long, guestIds: List<Long>, jobTitle: String): Int

  suspend fun bulkDeleteGuests(eventId: Long, guestIds: List<Long>): Int

  fun getOrganizationStatsForEvent(eventId: Long): Flow<List<OrganizationStatsProjection>>
  fun getJobTitleStatsForEvent(eventId: Long): Flow<List<JobTitleStatsProjection>>
}

class GuestRepositoryImpl(
  private val guestDao: GuestDao,
  private val database: EventDatabase? = null,
) : GuestRepository {

  override fun getOrganizationStatsForEvent(eventId: Long): Flow<List<OrganizationStatsProjection>> =
    guestDao.getOrganizationStatsForEvent(eventId)

  override fun getJobTitleStatsForEvent(eventId: Long): Flow<List<JobTitleStatsProjection>> =
    guestDao.getJobTitleStatsForEvent(eventId)

  override fun getGuestsForEvent(eventId: Long): Flow<List<GuestEntity>> =
    guestDao.getGuestsForEvent(eventId)

  override suspend fun getGuestsForEventSync(eventId: Long): List<GuestEntity> =
    guestDao.getGuestsForEventSync(eventId)

  override fun getGuestsForEventByStatus(eventId: Long, status: InvitationStatus): Flow<List<GuestEntity>> =
    guestDao.getGuestsForEventByStatus(eventId, status)

  override fun getGuestById(id: Long): Flow<GuestEntity?> =
    guestDao.getGuestById(id)

  override suspend fun getGuestByIdSync(id: Long): GuestEntity? =
    guestDao.getGuestByIdSync(id)

  override suspend fun getGuestByUuid(uuid: String): GuestEntity? =
    guestDao.getGuestByUuid(uuid)

  override fun getTotalGuestsCount(): Flow<Int> =
    guestDao.getTotalGuestsCount()

  override fun getGuestsCountForEvent(eventId: Long): Flow<Int> =
    guestDao.getGuestsCountForEvent(eventId)

  override fun getGuestsCountByStatus(eventId: Long, status: InvitationStatus): Flow<Int> =
    guestDao.getGuestsCountByStatus(eventId, status)

  override fun searchGuests(eventId: Long, query: String): Flow<List<GuestEntity>> =
    guestDao.searchGuests(eventId, query)

  override suspend fun createGuest(
    eventId: Long,
    fullName: String,
    email: String,
    phone: String,
    organization: String,
    jobTitle: String,
    invitationStatus: InvitationStatus,
    notes: String,
  ): Long {
    val now = System.currentTimeMillis()
    // Generate cryptographically strong random UUID for new guest
    val guestUuid = UUID.randomUUID().toString()
    val entity = GuestEntity(
      eventId = eventId,
      uuid = guestUuid,
      fullName = fullName.trim(),
      email = email.trim(),
      phone = phone.trim(),
      organization = organization.trim(),
      jobTitle = jobTitle.trim(),
      invitationStatus = invitationStatus,
      notes = notes.trim(),
      createdAt = now,
      updatedAt = now,
    )
    val guestId = guestDao.insertGuest(entity)
    if (database != null) {
      val totalGuests = guestDao.getGuestsForEventSync(eventId).size
      val event = database.eventDao().getEventByIdSync(eventId)
      if (event != null && totalGuests > event.guestCapacity) {
        database.eventDao().updateEventCapacity(eventId, totalGuests, now)
      }
    }
    return guestId
  }

  override suspend fun importGuestsTransaction(
    eventId: Long,
    validRows: List<ParsedGuestRow>,
  ): ExcelImportResult {
    val executeBlock: suspend () -> ExcelImportResult = {
      val now = System.currentTimeMillis()
      val emptySlots = guestDao.getEmptyGuestSlotsForEvent(eventId)
      val slotsToUpdate = mutableListOf<GuestEntity>()
      val slotsToInsert = mutableListOf<GuestEntity>()

      validRows.forEachIndexed { index, row ->
        if (index < emptySlots.size) {
          // Populate existing empty slot, keeping slot's original UUID
          val slot = emptySlots[index]
          slotsToUpdate.add(
            slot.copy(
              fullName = row.fullName.trim(),
              email = row.email.trim(),
              phone = row.phone.trim(),
              organization = row.organization.trim(),
              jobTitle = row.jobTitle.trim(),
              invitationStatus = row.invitationStatus,
              notes = row.notes.trim(),
              updatedAt = now,
            )
          )
        } else {
          // Insert new guest
          val finalUuid = row.existingUuid?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
          slotsToInsert.add(
            GuestEntity(
              eventId = eventId,
              uuid = finalUuid,
              fullName = row.fullName.trim(),
              email = row.email.trim(),
              phone = row.phone.trim(),
              organization = row.organization.trim(),
              jobTitle = row.jobTitle.trim(),
              invitationStatus = row.invitationStatus,
              notes = row.notes.trim(),
              createdAt = now,
              updatedAt = now,
            )
          )
        }
      }

      for (slot in slotsToUpdate) {
        guestDao.updateGuest(slot)
      }

      slotsToInsert.chunked(500).forEach { batch ->
        guestDao.insertGuests(batch)
      }

      // Update event capacity if total slots now exceed it
      if (database != null) {
        val totalGuests = guestDao.getGuestsForEventSync(eventId).size
        val event = database.eventDao().getEventByIdSync(eventId)
        if (event != null && totalGuests > event.guestCapacity) {
          database.eventDao().updateEventCapacity(eventId, totalGuests, now)
        }
      }

      ExcelImportResult(
        importedCount = validRows.size,
        skippedCount = 0,
        invalidCount = 0,
        duplicateCount = 0,
      )
    }

    return try {
      if (database != null) {
        database.withTransaction {
          executeBlock()
        }
      } else {
        executeBlock()
      }
    } catch (e: Exception) {
      ExcelImportResult(
        importedCount = 0,
        skippedCount = validRows.size,
        invalidCount = 0,
        duplicateCount = 0,
        errorMessage = e.localizedMessage ?: "Database transaction failed",
      )
    }
  }

  override suspend fun updateGuest(guest: GuestEntity) {
    // Note: guest.uuid is retained untouched (preserves permanent unique identity)
    val updated = guest.copy(
      fullName = guest.fullName.trim(),
      email = guest.email.trim(),
      phone = guest.phone.trim(),
      organization = guest.organization.trim(),
      jobTitle = guest.jobTitle.trim(),
      notes = guest.notes.trim(),
      updatedAt = System.currentTimeMillis(),
    )
    guestDao.updateGuest(updated)
  }

  override suspend fun deleteGuest(id: Long) {
    guestDao.deleteGuestById(id)
  }

  override suspend fun bulkUpdateStatus(eventId: Long, guestIds: List<Long>, status: InvitationStatus): Int {
    if (guestIds.isEmpty()) return 0
    return if (database != null) {
      database.withTransaction {
        guestDao.updateGuestsStatus(eventId, guestIds, status)
      }
    } else {
      guestDao.updateGuestsStatus(eventId, guestIds, status)
    }
  }

  override suspend fun bulkUpdateOrganization(eventId: Long, guestIds: List<Long>, organization: String): Int {
    if (guestIds.isEmpty()) return 0
    val trimmed = organization.trim()
    return if (database != null) {
      database.withTransaction {
        guestDao.updateGuestsOrganization(eventId, guestIds, trimmed)
      }
    } else {
      guestDao.updateGuestsOrganization(eventId, guestIds, trimmed)
    }
  }

  override suspend fun bulkUpdateJobTitle(eventId: Long, guestIds: List<Long>, jobTitle: String): Int {
    if (guestIds.isEmpty()) return 0
    val trimmed = jobTitle.trim()
    return if (database != null) {
      database.withTransaction {
        guestDao.updateGuestsJobTitle(eventId, guestIds, trimmed)
      }
    } else {
      guestDao.updateGuestsJobTitle(eventId, guestIds, trimmed)
    }
  }

  override suspend fun bulkDeleteGuests(eventId: Long, guestIds: List<Long>): Int {
    if (guestIds.isEmpty()) return 0
    return if (database != null) {
      database.withTransaction {
        guestDao.deleteGuestsByIdsForEvent(eventId, guestIds)
      }
    } else {
      guestDao.deleteGuestsByIdsForEvent(eventId, guestIds)
    }
  }
}
