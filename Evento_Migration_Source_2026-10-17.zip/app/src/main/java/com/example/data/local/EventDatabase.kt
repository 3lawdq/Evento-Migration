package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.converter.EventConverters
import com.example.data.local.dao.BadgeDao
import com.example.data.local.dao.EventDao
import com.example.data.local.dao.ExportedPackageDao
import com.example.data.local.dao.GuestDao
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.ExportedPackageEntity
import com.example.data.local.entity.GuestEntity

@Database(
  entities = [
    EventEntity::class,
    GuestEntity::class,
    BadgeTemplateEntity::class,
    BadgeElementEntity::class,
    ExportedPackageEntity::class,
  ],
  version = 5,
  exportSchema = false,
)
@TypeConverters(EventConverters::class)
abstract class EventDatabase : RoomDatabase() {

  abstract fun eventDao(): EventDao
  abstract fun guestDao(): GuestDao
  abstract fun badgeDao(): BadgeDao
  abstract fun exportedPackageDao(): ExportedPackageDao

  companion object {
    @Volatile
    private var INSTANCE: EventDatabase? = null

    val MIGRATION_3_4 = object : Migration(3, 4) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE events ADD COLUMN guest_capacity INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE badge_templates ADD COLUMN is_active INTEGER NOT NULL DEFAULT 0")
      }
    }

    val MIGRATION_4_5 = object : Migration(4, 5) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `exported_packages` (
            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            `event_id` INTEGER NOT NULL,
            `file_name` TEXT NOT NULL,
            `guest_count` INTEGER NOT NULL,
            `file_size_bytes` INTEGER NOT NULL,
            `is_licensed` INTEGER NOT NULL,
            `exported_at` INTEGER NOT NULL,
            FOREIGN KEY(`event_id`) REFERENCES `events`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
          )
          """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_exported_packages_event_id` ON `exported_packages` (`event_id`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_exported_packages_exported_at` ON `exported_packages` (`exported_at`)")
      }
    }

    fun getDatabase(context: Context): EventDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          EventDatabase::class.java,
          "evento_admin.db",
        )
          .addMigrations(MIGRATION_3_4, MIGRATION_4_5)
          .fallbackToDestructiveMigration(dropAllTables = false)
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
