package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.InvitationStatus

/**
 * Guest entity representing an attendee associated with a specific event.
 * Foreign key references EventEntity.id with CASCADE delete so deleting an event
 * cleans up related guest records.
 *
 * UUID provides a cryptographically unique identifier per guest for future badge/signing operations.
 */
@Entity(
  tableName = "guests",
  foreignKeys = [
    ForeignKey(
      entity = EventEntity::class,
      parentColumns = ["id"],
      childColumns = ["event_id"],
      onDelete = ForeignKey.CASCADE,
    ),
  ],
  indices = [
    Index(value = ["event_id"]),
    Index(value = ["uuid"], unique = true),
    Index(value = ["invitation_status"]),
  ],
)
data class GuestEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,

  @ColumnInfo(name = "event_id")
  val eventId: Long,

  @ColumnInfo(name = "uuid")
  val uuid: String,

  @ColumnInfo(name = "full_name")
  val fullName: String,

  @ColumnInfo(name = "email")
  val email: String = "",

  @ColumnInfo(name = "phone")
  val phone: String = "",

  @ColumnInfo(name = "organization")
  val organization: String = "",

  @ColumnInfo(name = "job_title")
  val jobTitle: String = "",

  @ColumnInfo(name = "invitation_status")
  val invitationStatus: InvitationStatus = InvitationStatus.INVITED,

  @ColumnInfo(name = "notes")
  val notes: String = "",

  @ColumnInfo(name = "created_at")
  val createdAt: Long = System.currentTimeMillis(),

  @ColumnInfo(name = "updated_at")
  val updatedAt: Long = System.currentTimeMillis(),
) {
  val isEmptySlot: Boolean
    get() = com.example.data.model.GuestDataQualityEvaluator.isGuestEmptySlot(this)
}
