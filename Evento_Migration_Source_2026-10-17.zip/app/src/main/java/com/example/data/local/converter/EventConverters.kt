package com.example.data.local.converter

import androidx.room.TypeConverter
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus

class EventConverters {
  @TypeConverter
  fun fromEventStatus(status: EventStatus?): String {
    return status?.name ?: EventStatus.DRAFT.name
  }

  @TypeConverter
  fun toEventStatus(value: String?): EventStatus {
    return EventStatus.fromString(value)
  }

  @TypeConverter
  fun fromInvitationStatus(status: InvitationStatus?): String {
    return status?.name ?: InvitationStatus.INVITED.name
  }

  @TypeConverter
  fun toInvitationStatus(value: String?): InvitationStatus {
    return InvitationStatus.fromString(value)
  }

  @TypeConverter
  fun fromBadgeOrientation(orientation: BadgeOrientation?): String {
    return orientation?.name ?: BadgeOrientation.LANDSCAPE.name
  }

  @TypeConverter
  fun toBadgeOrientation(value: String?): BadgeOrientation {
    return BadgeOrientation.fromString(value)
  }

  @TypeConverter
  fun fromBadgeElementType(type: BadgeElementType?): String {
    return type?.name ?: BadgeElementType.ATTENDEE_NAME.name
  }

  @TypeConverter
  fun toBadgeElementType(value: String?): BadgeElementType {
    return BadgeElementType.fromString(value)
  }

  @TypeConverter
  fun fromBadgeAlignment(alignment: BadgeAlignment?): String {
    return alignment?.name ?: BadgeAlignment.CENTER.name
  }

  @TypeConverter
  fun toBadgeAlignment(value: String?): BadgeAlignment {
    return BadgeAlignment.fromString(value)
  }
}
