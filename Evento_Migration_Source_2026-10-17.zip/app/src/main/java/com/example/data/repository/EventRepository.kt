package com.example.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.example.R
import com.example.data.local.EventDatabase
import com.example.data.local.dao.EventDao
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import kotlinx.coroutines.flow.Flow
import java.util.Locale
import java.util.UUID

sealed class CapacityUpdateResult {
  data object Success : CapacityUpdateResult()
  data class Blocked(val reason: String, val filledCount: Int, val requestedCapacity: Int) : CapacityUpdateResult()
  data class Error(val message: String) : CapacityUpdateResult()
}

interface EventRepository {
  fun getAllEvents(): Flow<List<EventEntity>>
  fun getEventsByStatus(status: EventStatus): Flow<List<EventEntity>>
  fun getEventById(id: Long): Flow<EventEntity?>
  suspend fun getEventByIdSync(id: Long): EventEntity?
  fun getEventsCount(): Flow<Int>
  fun getActiveEventsCount(): Flow<Int>
  suspend fun createEvent(
    name: String,
    description: String,
    date: String,
    location: String,
    organizer: String,
    status: EventStatus = EventStatus.ACTIVE,
    guestCapacity: Int = 0,
    autoCreateSlots: Boolean = false,
    slotNameFormat: String? = null,
  ): Long
  suspend fun updateEvent(event: EventEntity)
  suspend fun updateEventStatus(id: Long, status: EventStatus)
  suspend fun updateEventCapacity(eventId: Long, newCapacity: Int): CapacityUpdateResult
  suspend fun createGuestSlots(eventId: Long, count: Int): Int
  suspend fun duplicateEvent(sourceEventId: Long, newName: String? = null, copyGuests: Boolean = false): Long
  suspend fun deleteEvent(id: Long)
}

class EventRepositoryImpl(
  private val eventDao: EventDao,
  private val database: EventDatabase? = null,
  private val context: Context? = null,
) : EventRepository {

  override fun getAllEvents(): Flow<List<EventEntity>> = eventDao.getAllEvents()

  override fun getEventsByStatus(status: EventStatus): Flow<List<EventEntity>> =
    eventDao.getEventsByStatus(status)

  override fun getEventById(id: Long): Flow<EventEntity?> = eventDao.getEventById(id)

  override suspend fun getEventByIdSync(id: Long): EventEntity? = eventDao.getEventByIdSync(id)

  override fun getEventsCount(): Flow<Int> = eventDao.getEventsCount()

  override fun getActiveEventsCount(): Flow<Int> = eventDao.getActiveEventsCount()

  override suspend fun createEvent(
    name: String,
    description: String,
    date: String,
    location: String,
    organizer: String,
    status: EventStatus,
    guestCapacity: Int,
    autoCreateSlots: Boolean,
    slotNameFormat: String?,
  ): Long {
    val now = System.currentTimeMillis()
    val boundedCapacity = guestCapacity.coerceIn(0, 10000)
    val entity = EventEntity(
      name = name.trim(),
      description = description.trim(),
      date = date.trim(),
      location = location.trim(),
      organizer = organizer.trim(),
      status = status,
      guestCapacity = boundedCapacity,
      createdAt = now,
      updatedAt = now,
    )

    val executeBlock: suspend () -> Long = {
      val eventId = eventDao.insertEvent(entity)
      if (autoCreateSlots && boundedCapacity > 0 && database != null) {
        val format = slotNameFormat
          ?: if (context != null) {
            try {
              context.getString(R.string.guest_placeholder_name_format)
            } catch (_: Exception) {
              null
            }
          } else null

        val slotEntities = (1..boundedCapacity).map { index ->
          val formattedName = if (!format.isNullOrBlank()) {
            try {
              String.format(Locale.US, format, index)
            } catch (_: Exception) {
              ""
            }
          } else {
            ""
          }
          GuestEntity(
            eventId = eventId,
            uuid = UUID.randomUUID().toString(),
            fullName = formattedName,
            email = "",
            phone = "",
            organization = "",
            jobTitle = "",
            invitationStatus = InvitationStatus.INVITED,
            notes = "",
            createdAt = now,
            updatedAt = now,
          )
        }
        slotEntities.chunked(500).forEach { batch ->
          database.guestDao().insertGuests(batch)
        }
      }
      eventId
    }

    return if (database != null) {
      database.withTransaction { executeBlock() }
    } else {
      executeBlock()
    }
  }

  override suspend fun updateEvent(event: EventEntity) {
    val updated = event.copy(
      name = event.name.trim(),
      description = event.description.trim(),
      date = event.date.trim(),
      location = event.location.trim(),
      organizer = event.organizer.trim(),
      guestCapacity = event.guestCapacity.coerceIn(0, 10000),
      updatedAt = System.currentTimeMillis(),
    )
    eventDao.updateEvent(updated)
  }

  override suspend fun updateEventStatus(id: Long, status: EventStatus) {
    eventDao.updateEventStatus(id, status, System.currentTimeMillis())
  }

  override suspend fun updateEventCapacity(eventId: Long, newCapacity: Int): CapacityUpdateResult {
    val boundedCapacity = newCapacity.coerceIn(0, 10000)
    val now = System.currentTimeMillis()

    if (database == null) {
      eventDao.updateEventCapacity(eventId, boundedCapacity, now)
      return CapacityUpdateResult.Success
    }

    return try {
      database.withTransaction {
        val allGuests = database.guestDao().getGuestsForEventSync(eventId)
        val filledGuests = allGuests.filter { !it.isEmptySlot }
        val emptySlots = allGuests.filter { it.isEmptySlot }

        if (boundedCapacity < filledGuests.size) {
          CapacityUpdateResult.Blocked(
            reason = "Cannot reduce capacity to $boundedCapacity. Event has ${filledGuests.size} registered guests.",
            filledCount = filledGuests.size,
            requestedCapacity = boundedCapacity,
          )
        } else {
          val currentTotal = allGuests.size
          if (boundedCapacity < currentTotal) {
            val slotsToRemoveCount = currentTotal - boundedCapacity
            val slotsToDelete = emptySlots.takeLast(slotsToRemoveCount)
            database.guestDao().deleteGuests(slotsToDelete)
          } else if (boundedCapacity > currentTotal) {
            val slotsToAddCount = boundedCapacity - currentTotal
            val format = if (context != null) {
              try { context.getString(R.string.guest_placeholder_name_format) } catch (_: Exception) { null }
            } else null
            val newSlots = (1..slotsToAddCount).map { index ->
              val slotIndex = currentTotal + index
              val formattedName = if (!format.isNullOrBlank()) {
                try { String.format(Locale.US, format, slotIndex) } catch (_: Exception) { "" }
              } else ""
              GuestEntity(
                eventId = eventId,
                uuid = UUID.randomUUID().toString(),
                fullName = formattedName,
                email = "",
                phone = "",
                organization = "",
                jobTitle = "",
                invitationStatus = InvitationStatus.INVITED,
                notes = "",
                createdAt = now,
                updatedAt = now,
              )
            }
            newSlots.chunked(500).forEach { batch ->
              database.guestDao().insertGuests(batch)
            }
          }
          eventDao.updateEventCapacity(eventId, boundedCapacity, now)
          CapacityUpdateResult.Success
        }
      }
    } catch (e: Exception) {
      CapacityUpdateResult.Error(e.localizedMessage ?: "Failed to update event capacity")
    }
  }

  override suspend fun createGuestSlots(eventId: Long, count: Int): Int {
    if (count <= 0 || database == null) return 0
    val now = System.currentTimeMillis()
    val boundedCount = count.coerceIn(1, 5000)
    return database.withTransaction {
      val existingCount = database.guestDao().getGuestsForEventSync(eventId).size
      val format = if (context != null) {
        try { context.getString(R.string.guest_placeholder_name_format) } catch (_: Exception) { null }
      } else null
      val slots = (1..boundedCount).map { index ->
        val slotIndex = existingCount + index
        val formattedName = if (!format.isNullOrBlank()) {
          try { String.format(Locale.US, format, slotIndex) } catch (_: Exception) { "" }
        } else ""
        GuestEntity(
          eventId = eventId,
          uuid = UUID.randomUUID().toString(),
          fullName = formattedName,
          email = "",
          phone = "",
          organization = "",
          jobTitle = "",
          invitationStatus = InvitationStatus.INVITED,
          notes = "",
          createdAt = now,
          updatedAt = now,
        )
      }
      slots.chunked(500).forEach { batch ->
        database.guestDao().insertGuests(batch)
      }
      val total = database.guestDao().getGuestsForEventSync(eventId).size
      val event = eventDao.getEventByIdSync(eventId)
      if (event != null && total > event.guestCapacity) {
        eventDao.updateEventCapacity(eventId, total, now)
      }
      boundedCount
    }
  }

  override suspend fun duplicateEvent(
    sourceEventId: Long,
    newName: String?,
    copyGuests: Boolean,
  ): Long {
    val source = eventDao.getEventByIdSync(sourceEventId)
      ?: throw IllegalArgumentException("Source event $sourceEventId not found")

    val now = System.currentTimeMillis()
    val eventName = newName?.trim()?.ifBlank { null } ?: "${source.name} (Copy)"
    val duplicatedEntity = EventEntity(
      id = 0L,
      name = eventName,
      description = source.description,
      date = source.date,
      location = source.location,
      organizer = source.organizer,
      status = EventStatus.ACTIVE,
      guestCapacity = source.guestCapacity,
      createdAt = now,
      updatedAt = now,
    )

    val executeBlock: suspend () -> Long = {
      val newEventId = eventDao.insertEvent(duplicatedEntity)

      if (database != null) {
        // Duplicate badge templates and elements
        val badgeDao = database.badgeDao()
        val templates = badgeDao.getTemplatesForEventSync(sourceEventId)
        if (templates.isNotEmpty()) {
          for (tpl in templates) {
            val elements = badgeDao.getElementsForTemplateSync(tpl.id)
            val newTemplate = tpl.copy(
              id = 0L,
              eventId = newEventId,
              createdAt = now,
              updatedAt = now,
            )
            val newTemplateId = badgeDao.insertTemplate(newTemplate)
            val newElements = elements.map { it.copy(id = 0L, templateId = newTemplateId) }
            if (newElements.isNotEmpty()) {
              badgeDao.insertElements(newElements)
            }
          }
        } else {
          val defaultTpl = BadgeTemplateEntity(
            eventId = newEventId,
            name = "Badge - $eventName",
            widthMm = 90f,
            heightMm = 60f,
            orientation = BadgeOrientation.LANDSCAPE,
            backgroundColor = "#FFFFFF",
            isActive = true,
          )
          val defaultElements = BadgeTemplateRepositoryImpl.createDefaultElements(templateId = 0L, eventName = eventName)
          badgeDao.saveTemplateWithElements(defaultTpl, defaultElements)
        }

        // Guests: OFF by default. If copyGuests is true, generate fresh UUIDs for each guest, reset invitation status to INVITED. Never copy attendance!
        if (copyGuests) {
          val guests = database.guestDao().getGuestsForEventSync(sourceEventId)
          if (guests.isNotEmpty()) {
            val copiedGuests = guests.map { original ->
              GuestEntity(
                eventId = newEventId,
                uuid = UUID.randomUUID().toString(), // FRESH UUID! Never reuse original!
                fullName = original.fullName,
                email = original.email,
                phone = original.phone,
                organization = original.organization,
                jobTitle = original.jobTitle,
                invitationStatus = InvitationStatus.INVITED, // Reset invitation status
                notes = original.notes,
                createdAt = now,
                updatedAt = now,
              )
            }
            copiedGuests.chunked(500).forEach { batch ->
              database.guestDao().insertGuests(batch)
            }
          }
        }
      }

      newEventId
    }

    return if (database != null) {
      database.withTransaction { executeBlock() }
    } else {
      executeBlock()
    }
  }

  override suspend fun deleteEvent(id: Long) {
    eventDao.deleteEventById(id)
  }
}
