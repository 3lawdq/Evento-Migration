package com.example.data.model

enum class InvitationStatus {
  INVITED,
  CONFIRMED,
  DECLINED,
  CHECKED_IN;

  companion object {
    fun fromString(value: String?): InvitationStatus {
      return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: INVITED
    }
  }
}
