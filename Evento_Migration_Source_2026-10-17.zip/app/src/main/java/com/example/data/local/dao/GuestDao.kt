package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.GuestEntity
import com.example.data.model.InvitationStatus
import com.example.data.model.JobTitleStatsProjection
import com.example.data.model.OrganizationStatsProjection
import kotlinx.coroutines.flow.Flow

@Dao
interface GuestDao {

  @Query("SELECT * FROM guests WHERE event_id = :eventId ORDER BY created_at DESC")
  fun getGuestsForEvent(eventId: Long): Flow<List<GuestEntity>>

  @Query("SELECT * FROM guests WHERE event_id = :eventId")
  suspend fun getGuestsForEventSync(eventId: Long): List<GuestEntity>

  @Query("SELECT * FROM guests WHERE event_id = :eventId AND invitation_status = :status ORDER BY created_at DESC")
  fun getGuestsForEventByStatus(eventId: Long, status: InvitationStatus): Flow<List<GuestEntity>>

  @Query("SELECT * FROM guests WHERE id = :id LIMIT 1")
  fun getGuestById(id: Long): Flow<GuestEntity?>

  @Query("SELECT * FROM guests WHERE id = :id LIMIT 1")
  suspend fun getGuestByIdSync(id: Long): GuestEntity?

  @Query("SELECT * FROM guests WHERE uuid = :uuid LIMIT 1")
  suspend fun getGuestByUuid(uuid: String): GuestEntity?

  @Query("SELECT COUNT(*) FROM guests")
  fun getTotalGuestsCount(): Flow<Int>

  @Query("SELECT COUNT(*) FROM guests WHERE event_id = :eventId")
  fun getGuestsCountForEvent(eventId: Long): Flow<Int>

  @Query("SELECT COUNT(*) FROM guests WHERE event_id = :eventId AND invitation_status = :status")
  fun getGuestsCountByStatus(eventId: Long, status: InvitationStatus): Flow<Int>

  @Query("""
    SELECT COUNT(*) FROM guests 
    WHERE event_id = :eventId 
      AND (full_name = '' OR TRIM(full_name) = '' OR full_name LIKE 'Guest %' OR full_name LIKE 'ضيف %')
      AND (email = '' OR email IS NULL)
      AND (phone = '' OR phone IS NULL)
  """)
  fun getEmptySlotsCount(eventId: Long): Flow<Int>

  @Query("""
    SELECT COUNT(*) FROM guests 
    WHERE event_id = :eventId 
      AND NOT (
        (full_name = '' OR TRIM(full_name) = '' OR full_name LIKE 'Guest %' OR full_name LIKE 'ضيف %')
        AND (email = '' OR email IS NULL)
        AND (phone = '' OR phone IS NULL)
      )
  """)
  fun getFilledGuestsCount(eventId: Long): Flow<Int>

  @Query("""
    SELECT * FROM guests 
    WHERE event_id = :eventId 
      AND (full_name = '' OR TRIM(full_name) = '' OR full_name LIKE 'Guest %' OR full_name LIKE 'ضيف %')
      AND (email = '' OR email IS NULL)
      AND (phone = '' OR phone IS NULL)
    ORDER BY id ASC
  """)
  suspend fun getEmptyGuestSlotsForEvent(eventId: Long): List<GuestEntity>

  @Query("""
    SELECT * FROM guests 
    WHERE event_id = :eventId 
      AND (full_name LIKE '%' || :query || '%' 
        OR email LIKE '%' || :query || '%' 
        OR phone LIKE '%' || :query || '%' 
        OR organization LIKE '%' || :query || '%')
    ORDER BY created_at DESC
  """)
  fun searchGuests(eventId: Long, query: String): Flow<List<GuestEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGuest(guest: GuestEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGuests(guests: List<GuestEntity>): List<Long>

  @Update
  suspend fun updateGuest(guest: GuestEntity)

  @Delete
  suspend fun deleteGuest(guest: GuestEntity)

  @Delete
  suspend fun deleteGuests(guests: List<GuestEntity>)

  @Query("DELETE FROM guests WHERE id IN (:ids)")
  suspend fun deleteGuestsByIds(ids: List<Long>)

  @Query("DELETE FROM guests WHERE id = :id")
  suspend fun deleteGuestById(id: Long)

  @Query("DELETE FROM guests WHERE id IN (:ids) AND event_id = :eventId")
  suspend fun deleteGuestsByIdsForEvent(eventId: Long, ids: List<Long>): Int

  @Query("UPDATE guests SET invitation_status = :status, updated_at = :updatedAt WHERE id IN (:ids) AND event_id = :eventId")
  suspend fun updateGuestsStatus(eventId: Long, ids: List<Long>, status: InvitationStatus, updatedAt: Long = System.currentTimeMillis()): Int

  @Query("UPDATE guests SET organization = :organization, updated_at = :updatedAt WHERE id IN (:ids) AND event_id = :eventId")
  suspend fun updateGuestsOrganization(eventId: Long, ids: List<Long>, organization: String, updatedAt: Long = System.currentTimeMillis()): Int

  @Query("UPDATE guests SET job_title = :jobTitle, updated_at = :updatedAt WHERE id IN (:ids) AND event_id = :eventId")
  suspend fun updateGuestsJobTitle(eventId: Long, ids: List<Long>, jobTitle: String, updatedAt: Long = System.currentTimeMillis()): Int

  @Query("DELETE FROM guests WHERE event_id = :eventId")
  suspend fun deleteAllGuestsForEvent(eventId: Long)

  @Query("""
    SELECT 
      organization, 
      COUNT(*) AS totalGuests, 
      SUM(CASE WHEN invitation_status = 'CHECKED_IN' THEN 1 ELSE 0 END) AS checkedInGuests 
    FROM guests 
    WHERE event_id = :eventId AND organization != '' AND TRIM(organization) != '' 
    GROUP BY organization 
    ORDER BY totalGuests DESC
  """)
  fun getOrganizationStatsForEvent(eventId: Long): Flow<List<OrganizationStatsProjection>>

  @Query("""
    SELECT 
      job_title AS jobTitle, 
      COUNT(*) AS totalGuests, 
      SUM(CASE WHEN invitation_status = 'CHECKED_IN' THEN 1 ELSE 0 END) AS checkedInGuests 
    FROM guests 
    WHERE event_id = :eventId AND job_title != '' AND TRIM(job_title) != '' 
    GROUP BY job_title 
    ORDER BY totalGuests DESC
  """)
  fun getJobTitleStatsForEvent(eventId: Long): Flow<List<JobTitleStatsProjection>>
}
