package com.example.data.repository

import com.example.data.local.dao.ExportedPackageDao
import com.example.data.local.entity.ExportedPackageEntity
import com.example.util.packageexport.EventPackageExportRequest
import com.example.util.packageexport.EventPackageExportResult
import com.example.util.packageexport.EventoPackageWriter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

interface EventPackageRepository {
  fun getExportedPackagesCount(): Flow<Int>
  fun getPackagesForEvent(eventId: Long): Flow<List<ExportedPackageEntity>>
  suspend fun exportEventPackage(request: EventPackageExportRequest): EventPackageExportResult
}

class EventPackageRepositoryImpl(
  private val writer: EventoPackageWriter,
  private val packageDao: ExportedPackageDao? = null,
) : EventPackageRepository {

  override fun getExportedPackagesCount(): Flow<Int> {
    return packageDao?.getExportedPackagesCount() ?: flowOf(0)
  }

  override fun getPackagesForEvent(eventId: Long): Flow<List<ExportedPackageEntity>> {
    return packageDao?.getPackagesForEvent(eventId) ?: flowOf(emptyList())
  }

  override suspend fun exportEventPackage(request: EventPackageExportRequest): EventPackageExportResult {
    val result = writer.writePackage(request)
    if (result is EventPackageExportResult.Success) {
      packageDao?.let { dao ->
        val entity = ExportedPackageEntity(
          eventId = request.event.id,
          fileName = result.file.name,
          guestCount = result.guestCount,
          fileSizeBytes = result.fileSizeInBytes,
          isLicensed = result.isLicensed,
          exportedAt = System.currentTimeMillis(),
        )
        dao.insertExportedPackage(entity)
      }
    }
    return result
  }
}
