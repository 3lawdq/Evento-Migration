package com.example.data.importer

import com.example.data.local.entity.GuestEntity
import com.example.data.model.InvitationStatus

/**
 * Result model for parsed guest rows from Excel before commitment.
 */
data class ParsedGuestRow(
  val rowIndex: Int,
  val fullName: String,
  val email: String,
  val phone: String,
  val organization: String,
  val jobTitle: String,
  val invitationStatus: InvitationStatus,
  val notes: String,
  val existingUuid: String? = null,
  val isValid: Boolean,
  val isDuplicate: Boolean,
  val duplicateReason: String? = null,
  val invalidReason: String? = null,
)

/**
 * Summary of analysis performed on an imported file.
 */
data class ExcelImportPreview(
  val fileName: String,
  val detectedColumns: List<String>,
  val totalRows: Int,
  val validRows: List<ParsedGuestRow>,
  val invalidRows: List<ParsedGuestRow>,
  val duplicateRows: List<ParsedGuestRow>,
) {
  val willBeImportedCount: Int
    get() = validRows.filter { !it.isDuplicate && it.isValid }.size
}

/**
 * Final execution report returned after Room database transaction completes.
 */
data class ExcelImportResult(
  val importedCount: Int,
  val skippedCount: Int,
  val invalidCount: Int,
  val duplicateCount: Int,
  val errorMessage: String? = null,
)
