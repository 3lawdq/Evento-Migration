package com.example.data.model

import com.example.data.local.entity.GuestEntity

enum class GuestQualityField {
  FULL_NAME,
  EMAIL,
  PHONE,
  ORGANIZATION,
  JOB_TITLE,
}

enum class DataQualityFilter {
  ALL,
  COMPLETE_ONLY,
  INCOMPLETE_ONLY,
  EMPTY_SLOTS_ONLY,
}

enum class GuestSortOption {
  NAME_ASC,
  NAME_DESC,
  ORG_ASC,
  CREATED_DESC,
  STATUS,
}

data class GuestQualityReport(
  val guestId: Long,
  val isComplete: Boolean,
  val isEmptySlot: Boolean,
  val missingFields: List<GuestQualityField>,
)

data class EventDataQualitySummary(
  val totalRecords: Int = 0,
  val emptySlotsCount: Int = 0,
  val registeredGuestsCount: Int = 0,
  val completeGuestsCount: Int = 0,
  val incompleteGuestsCount: Int = 0,
) {
  val completenessPercentage: Int
    get() = if (registeredGuestsCount > 0) {
      ((completeGuestsCount.toDouble() / registeredGuestsCount) * 100).toInt().coerceIn(0, 100)
    } else {
      100
    }
}

object GuestDataQualityEvaluator {

  private val PLACEHOLDER_REGEX = Regex("""^(?:Guest|ضيف)\s+\d+$""", RegexOption.IGNORE_CASE)

  fun isPlaceholderName(name: String): Boolean {
    val trimmed = name.trim()
    return trimmed.isEmpty() || PLACEHOLDER_REGEX.matches(trimmed)
  }

  fun isGuestEmptySlot(guest: GuestEntity): Boolean {
    return guest.fullName.isBlank() || (
      isPlaceholderName(guest.fullName) &&
        guest.email.isBlank() &&
        guest.phone.isBlank() &&
        guest.organization.isBlank() &&
        guest.jobTitle.isBlank()
    )
  }

  fun evaluateGuest(guest: GuestEntity): GuestQualityReport {
    val isEmptySlot = isGuestEmptySlot(guest)
    val missing = mutableListOf<GuestQualityField>()

    if (guest.fullName.isBlank() || isPlaceholderName(guest.fullName)) {
      missing.add(GuestQualityField.FULL_NAME)
    }
    if (guest.email.isBlank()) missing.add(GuestQualityField.EMAIL)
    if (guest.phone.isBlank()) missing.add(GuestQualityField.PHONE)
    if (guest.organization.isBlank()) missing.add(GuestQualityField.ORGANIZATION)
    if (guest.jobTitle.isBlank()) missing.add(GuestQualityField.JOB_TITLE)

    val isComplete = !isEmptySlot && missing.isEmpty()

    return GuestQualityReport(
      guestId = guest.id,
      isComplete = isComplete,
      isEmptySlot = isEmptySlot,
      missingFields = missing,
    )
  }

  fun summarize(guests: List<GuestEntity>): EventDataQualitySummary {
    var emptySlots = 0
    var complete = 0
    var incomplete = 0

    for (guest in guests) {
      if (isGuestEmptySlot(guest)) {
        emptySlots++
      } else {
        val hasEmail = guest.email.isNotBlank()
        val hasPhone = guest.phone.isNotBlank()
        val hasOrg = guest.organization.isNotBlank()
        val hasTitle = guest.jobTitle.isNotBlank()
        if (hasEmail && hasPhone && hasOrg && hasTitle) {
          complete++
        } else {
          incomplete++
        }
      }
    }

    val registered = complete + incomplete

    return EventDataQualitySummary(
      totalRecords = guests.size,
      emptySlotsCount = emptySlots,
      registeredGuestsCount = registered,
      completeGuestsCount = complete,
      incompleteGuestsCount = incomplete,
    )
  }
}
