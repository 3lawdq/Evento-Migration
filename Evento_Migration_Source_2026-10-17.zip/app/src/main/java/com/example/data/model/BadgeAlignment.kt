package com.example.data.model

enum class BadgeAlignment {
  START,
  CENTER,
  END;

  companion object {
    fun fromString(value: String?): BadgeAlignment {
      return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: CENTER
    }
  }
}
