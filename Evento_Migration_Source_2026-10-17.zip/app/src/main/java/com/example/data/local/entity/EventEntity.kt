package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.EventStatus

/**
 * Event entity representing an event in the Evento system.
 * Designed with a primary key 'id' to support foreign keys from future Guest records
 * and packaging into Evento Event Packages.
 */
@Entity(
  tableName = "events",
  indices = [
    Index(value = ["status"]),
    Index(value = ["date"]),
  ],
)
data class EventEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,

  @ColumnInfo(name = "name")
  val name: String,

  @ColumnInfo(name = "description")
  val description: String = "",

  @ColumnInfo(name = "date")
  val date: String = "",

  @ColumnInfo(name = "location")
  val location: String = "",

  @ColumnInfo(name = "organizer")
  val organizer: String = "",

  @ColumnInfo(name = "status")
  val status: EventStatus = EventStatus.DRAFT,

  @ColumnInfo(name = "guest_capacity")
  val guestCapacity: Int = 0,

  @ColumnInfo(name = "created_at")
  val createdAt: Long = System.currentTimeMillis(),

  @ColumnInfo(name = "updated_at")
  val updatedAt: Long = System.currentTimeMillis(),
)
