package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType

/**
 * Element placed on a badge template.
 * Uses device-independent normalized coordinates (0.0 to 1.0) so it scales
 * identically onto screen previews, high-DPI canvases, and PDF print renderers.
 */
@Entity(
  tableName = "badge_elements",
  foreignKeys = [
    ForeignKey(
      entity = BadgeTemplateEntity::class,
      parentColumns = ["id"],
      childColumns = ["template_id"],
      onDelete = ForeignKey.CASCADE,
    ),
  ],
  indices = [
    Index(value = ["template_id"]),
    Index(value = ["type"]),
  ],
)
data class BadgeElementEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,

  @ColumnInfo(name = "template_id")
  val templateId: Long,

  @ColumnInfo(name = "type")
  val type: BadgeElementType,

  @ColumnInfo(name = "x")
  val x: Float,

  @ColumnInfo(name = "y")
  val y: Float,

  @ColumnInfo(name = "width")
  val width: Float,

  @ColumnInfo(name = "height")
  val height: Float,

  @ColumnInfo(name = "rotation")
  val rotation: Float = 0f,

  @ColumnInfo(name = "visible")
  val visible: Boolean = true,

  @ColumnInfo(name = "text")
  val text: String? = null,

  @ColumnInfo(name = "font_size")
  val fontSize: Float = 14f,

  @ColumnInfo(name = "font_weight")
  val fontWeight: String = "BOLD",

  @ColumnInfo(name = "alignment")
  val alignment: BadgeAlignment = BadgeAlignment.CENTER,

  @ColumnInfo(name = "text_color")
  val textColor: String = "#1E293B",

  @ColumnInfo(name = "background_color")
  val backgroundColor: String? = null,

  @ColumnInfo(name = "z_index")
  val zIndex: Int = 0,
)
