package com.example.data.importer

import com.example.data.local.entity.GuestEntity
import com.example.data.model.InvitationStatus
import com.example.util.excel.XlsxParser
import java.io.InputStream
import java.util.Locale

/**
 * Recognizes and parses Excel tabular data into structured guest models.
 * Supports intelligent column recognition in English and Arabic.
 */
object ExcelGuestParser {

  private enum class FieldType {
    FULL_NAME,
    EMAIL,
    PHONE,
    ORGANIZATION,
    JOB_TITLE,
    INVITATION_STATUS,
    NOTES,
    UUID,
  }

  fun parse(
    inputStream: InputStream,
    fileName: String,
    existingGuests: List<GuestEntity>,
  ): ExcelImportPreview {
    val rawRows = XlsxParser.parse(inputStream)
    if (rawRows.isEmpty()) {
      return ExcelImportPreview(
        fileName = fileName,
        detectedColumns = emptyList(),
        totalRows = 0,
        validRows = emptyList(),
        invalidRows = emptyList(),
        duplicateRows = emptyList(),
      )
    }

    val headerRow = rawRows.first()
    val columnMap = mapHeadersToFields(headerRow)
    val dataRows = rawRows.drop(1)

    // Pre-build lookups for duplicate checks within existing guests of this event
    val existingUuids = existingGuests.mapNotNull { it.uuid.takeIf { u -> u.isNotBlank() } }.toSet()
    val existingEmails = existingGuests.mapNotNull { normalizeEmail(it.email).takeIf { e -> e.isNotBlank() } }.toSet()
    val existingPhones = existingGuests.mapNotNull { normalizePhone(it.phone).takeIf { p -> p.isNotBlank() } }.toSet()

    // Also track in-file duplicates (prevent duplicate rows within the same sheet)
    val seenInFileEmails = mutableSetOf<String>()
    val seenInFilePhones = mutableSetOf<String>()
    val seenInFileUuids = mutableSetOf<String>()

    val validRows = mutableListOf<ParsedGuestRow>()
    val invalidRows = mutableListOf<ParsedGuestRow>()
    val duplicateRows = mutableListOf<ParsedGuestRow>()

    for ((index, row) in dataRows.withIndex()) {
      val rowNumber = index + 2 // 1-based index including header row
      val fullName = getCellValue(row, columnMap[FieldType.FULL_NAME]).trim()
      val email = getCellValue(row, columnMap[FieldType.EMAIL]).trim()
      val phone = getCellValue(row, columnMap[FieldType.PHONE]).trim()
      val organization = getCellValue(row, columnMap[FieldType.ORGANIZATION]).trim()
      val jobTitle = getCellValue(row, columnMap[FieldType.JOB_TITLE]).trim()
      val statusRaw = getCellValue(row, columnMap[FieldType.INVITATION_STATUS]).trim()
      val notes = getCellValue(row, columnMap[FieldType.NOTES]).trim()
      val uuidRaw = getCellValue(row, columnMap[FieldType.UUID]).trim()

      val status = mapInvitationStatus(statusRaw)

      // 1. Validation check: Full name is required
      if (fullName.isEmpty()) {
        val invalidRow = ParsedGuestRow(
          rowIndex = rowNumber,
          fullName = "",
          email = email,
          phone = phone,
          organization = organization,
          jobTitle = jobTitle,
          invitationStatus = status,
          notes = notes,
          existingUuid = uuidRaw.ifEmpty { null },
          isValid = false,
          isDuplicate = false,
          invalidReason = "Full Name is missing or empty",
        )
        invalidRows.add(invalidRow)
        continue
      }

      // 2. Duplicate checks: UUID, Email, Phone
      val normalizedEmail = normalizeEmail(email)
      val normalizedPhone = normalizePhone(phone)

      var isDuplicate = false
      var duplicateReason: String? = null

      if (uuidRaw.isNotEmpty() && (existingUuids.contains(uuidRaw) || seenInFileUuids.contains(uuidRaw))) {
        isDuplicate = true
        duplicateReason = "Duplicate UUID: $uuidRaw"
      } else if (normalizedEmail.isNotEmpty() && (existingEmails.contains(normalizedEmail) || seenInFileEmails.contains(normalizedEmail))) {
        isDuplicate = true
        duplicateReason = "Duplicate Email: $email"
      } else if (normalizedPhone.isNotEmpty() && (existingPhones.contains(normalizedPhone) || seenInFilePhones.contains(normalizedPhone))) {
        isDuplicate = true
        duplicateReason = "Duplicate Phone: $phone"
      }

      val parsed = ParsedGuestRow(
        rowIndex = rowNumber,
        fullName = fullName,
        email = email,
        phone = phone,
        organization = organization,
        jobTitle = jobTitle,
        invitationStatus = status,
        notes = notes,
        existingUuid = uuidRaw.ifEmpty { null },
        isValid = true,
        isDuplicate = isDuplicate,
        duplicateReason = duplicateReason,
      )

      if (isDuplicate) {
        duplicateRows.add(parsed)
      } else {
        validRows.add(parsed)
        if (uuidRaw.isNotEmpty()) seenInFileUuids.add(uuidRaw)
        if (normalizedEmail.isNotEmpty()) seenInFileEmails.add(normalizedEmail)
        if (normalizedPhone.isNotEmpty()) seenInFilePhones.add(normalizedPhone)
      }
    }

    return ExcelImportPreview(
      fileName = fileName,
      detectedColumns = headerRow,
      totalRows = dataRows.size,
      validRows = validRows,
      invalidRows = invalidRows,
      duplicateRows = duplicateRows,
    )
  }

  private fun getCellValue(row: List<String>, colIndex: Int?): String {
    if (colIndex == null || colIndex < 0 || colIndex >= row.size) return ""
    return row[colIndex]
  }

  private fun mapHeadersToFields(headerRow: List<String>): Map<FieldType, Int> {
    val map = mutableMapOf<FieldType, Int>()

    headerRow.forEachIndexed { index, header ->
      val normalized = header.trim().lowercase(Locale.getDefault())

      when {
        matchesField(normalized, listOf("full name", "fullname", "name", "guest name", "attendee", "الاسم الكامل", "الاسم", "اسم الضيف")) -> {
          if (!map.containsKey(FieldType.FULL_NAME)) map[FieldType.FULL_NAME] = index
        }
        matchesField(normalized, listOf("email", "e-mail", "mail", "البريد الإلكتروني", "البريد", "ايميل")) -> {
          if (!map.containsKey(FieldType.EMAIL)) map[FieldType.EMAIL] = index
        }
        matchesField(normalized, listOf("phone", "mobile", "telephone", "cell", "الهاتف", "الجوال", "رقم الهاتف", "رقم الجوال")) -> {
          if (!map.containsKey(FieldType.PHONE)) map[FieldType.PHONE] = index
        }
        matchesField(normalized, listOf("organization", "company", "org", "entity", "agency", "الجهة", "المنظمة", "الشركة", "جهة العمل")) -> {
          if (!map.containsKey(FieldType.ORGANIZATION)) map[FieldType.ORGANIZATION] = index
        }
        matchesField(normalized, listOf("job title", "title", "job", "position", "role", "المسمى الوظيفي", "الوظيفة", "المنصب")) -> {
          if (!map.containsKey(FieldType.JOB_TITLE)) map[FieldType.JOB_TITLE] = index
        }
        matchesField(normalized, listOf("invitation status", "status", "invitation", "rsvp", "حالة الدعوة", "الحالة")) -> {
          if (!map.containsKey(FieldType.INVITATION_STATUS)) map[FieldType.INVITATION_STATUS] = index
        }
        matchesField(normalized, listOf("notes", "note", "comments", "remarks", "ملاحظات", "ملاحظة")) -> {
          if (!map.containsKey(FieldType.NOTES)) map[FieldType.NOTES] = index
        }
        matchesField(normalized, listOf("uuid", "id", "guid", "المعرف")) -> {
          if (!map.containsKey(FieldType.UUID)) map[FieldType.UUID] = index
        }
      }
    }

    return map
  }

  private fun matchesField(normalizedHeader: String, keywords: List<String>): Boolean {
    return keywords.any { keyword ->
      normalizedHeader == keyword || normalizedHeader.contains(keyword)
    }
  }

  fun mapInvitationStatus(raw: String): InvitationStatus {
    if (raw.isBlank()) return InvitationStatus.INVITED
    val lower = raw.trim().lowercase(Locale.getDefault())
    return when {
      lower.contains("confirm") || lower.contains("مؤكد") || lower.contains("تاكيد") || lower.contains("تأكيد") -> InvitationStatus.CONFIRMED
      lower.contains("decline") || lower.contains("معتذر") || lower.contains("رفض") || lower.contains("اعتذار") -> InvitationStatus.DECLINED
      lower.contains("check") || lower.contains("حضور") || lower.contains("حضر") || lower.contains("تم الحضور") -> InvitationStatus.CHECKED_IN
      lower.contains("invit") || lower.contains("مدعو") || lower.contains("دعوة") -> InvitationStatus.INVITED
      else -> InvitationStatus.INVITED
    }
  }

  private fun normalizeEmail(email: String): String = email.trim().lowercase(Locale.getDefault())

  private fun normalizePhone(phone: String): String {
    // Keep only digits and leading plus
    val trimmed = phone.trim()
    val digits = trimmed.filter { it.isDigit() }
    return if (trimmed.startsWith("+")) "+$digits" else digits
  }
}
