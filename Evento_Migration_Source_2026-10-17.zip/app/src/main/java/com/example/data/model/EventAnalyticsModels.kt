package com.example.data.model

import com.example.data.local.entity.EventEntity

/**
 * Domain model for event-level attendance summary.
 */
data class EventAttendanceSummary(
  val totalGuests: Int = 0,
  val checkedInGuests: Int = 0,
  val remainingGuests: Int = 0,
  val attendancePercentage: Double = 0.0,
  val nonAttendancePercentage: Double = 0.0,
) {
  val formattedAttendancePercentage: String
    get() = String.format(java.util.Locale.US, "%.1f%%", attendancePercentage)

  val formattedNonAttendancePercentage: String
    get() = String.format(java.util.Locale.US, "%.1f%%", nonAttendancePercentage)
}

/**
 * Aggregated count per invitation status.
 */
data class InvitationStatusCount(
  val status: InvitationStatus,
  val count: Int,
  val percentageOfTotal: Double = 0.0,
)

/**
 * Cross-analysis between invitation status and actual attendance.
 */
data class AttendanceStatusCrossAnalysis(
  val invitedNotCheckedIn: Int = 0,
  val confirmedAndCheckedIn: Int = 0,
  val confirmedNotCheckedIn: Int = 0,
  val declined: Int = 0,
  val totalCheckedIn: Int = 0,
)

/**
 * Attendance count within a specific chronological time bucket (e.g. 1 hour).
 */
data class AttendanceTimeBucket(
  val bucketStartEpochMs: Long,
  val formattedTime: String,
  val count: Int,
  val percentageOfTotalCheckIns: Double = 0.0,
)

/**
 * Details of the peak check-in window.
 */
data class PeakCheckInPeriod(
  val bucketStartEpochMs: Long,
  val formattedTimeRange: String,
  val checkInCount: Int,
)

/**
 * Organization attendance metrics.
 */
data class OrganizationAttendanceSummary(
  val organization: String,
  val totalGuests: Int,
  val checkedInGuests: Int,
  val attendancePercentage: Double = 0.0,
) {
  val formattedPercentage: String
    get() = String.format(java.util.Locale.US, "%.1f%%", attendancePercentage)
}

/**
 * Job title attendance metrics.
 */
data class JobTitleAttendanceSummary(
  val jobTitle: String,
  val totalGuests: Int,
  val checkedInGuests: Int,
  val attendancePercentage: Double = 0.0,
) {
  val formattedPercentage: String
    get() = String.format(java.util.Locale.US, "%.1f%%", attendancePercentage)
}

/**
 * Room projection POJO for organization grouping query.
 */
data class OrganizationStatsProjection(
  val organization: String,
  val totalGuests: Int,
  val checkedInGuests: Int,
)

/**
 * Room projection POJO for job title grouping query.
 */
data class JobTitleStatsProjection(
  val jobTitle: String,
  val totalGuests: Int,
  val checkedInGuests: Int,
)
