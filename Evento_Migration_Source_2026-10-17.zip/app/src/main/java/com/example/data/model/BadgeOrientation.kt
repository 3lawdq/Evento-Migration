package com.example.data.model

enum class BadgeOrientation {
  PORTRAIT,
  LANDSCAPE;

  companion object {
    fun fromString(value: String?): BadgeOrientation {
      return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: LANDSCAPE
    }
  }
}
