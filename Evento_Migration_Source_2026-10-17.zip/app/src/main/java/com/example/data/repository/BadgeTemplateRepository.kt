package com.example.data.repository

import com.example.data.local.dao.BadgeDao
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.BadgeTemplateWithElements
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import kotlinx.coroutines.flow.Flow

interface BadgeTemplateRepository {
  fun getTotalTemplatesCount(): Flow<Int>
  fun getTemplateWithElements(eventId: Long): Flow<BadgeTemplateWithElements?>
  fun getTemplatesForEvent(eventId: Long): Flow<List<BadgeTemplateEntity>>
  fun getTemplateWithElementsById(templateId: Long): Flow<BadgeTemplateWithElements?>
  suspend fun getTemplateForEventSync(eventId: Long): BadgeTemplateEntity?
  suspend fun createDefaultTemplate(eventId: Long, eventName: String): Long
  suspend fun createTemplate(
    eventId: Long,
    name: String,
    widthMm: Float = 90f,
    heightMm: Float = 60f,
    orientation: BadgeOrientation = BadgeOrientation.LANDSCAPE,
    backgroundColor: String = "#FFFFFF",
    setActive: Boolean = false,
  ): Long
  suspend fun duplicateTemplate(templateId: Long, newName: String): Long
  suspend fun setActiveTemplate(eventId: Long, templateId: Long)
  suspend fun renameTemplate(templateId: Long, newName: String)
  suspend fun saveTemplate(
    template: BadgeTemplateEntity,
    elements: List<BadgeElementEntity>,
  ): Long
  suspend fun deleteTemplate(templateId: Long): Boolean
  suspend fun deleteElement(elementId: Long): Boolean
}

class BadgeTemplateRepositoryImpl(
  private val badgeDao: BadgeDao,
) : BadgeTemplateRepository {

  override fun getTotalTemplatesCount(): Flow<Int> {
    return badgeDao.getTotalTemplatesCount()
  }

  override fun getTemplateWithElements(eventId: Long): Flow<BadgeTemplateWithElements?> {
    return badgeDao.getTemplateWithElements(eventId)
  }

  override fun getTemplatesForEvent(eventId: Long): Flow<List<BadgeTemplateEntity>> {
    return badgeDao.getTemplatesForEvent(eventId)
  }

  override fun getTemplateWithElementsById(templateId: Long): Flow<BadgeTemplateWithElements?> {
    return badgeDao.getTemplateWithElementsById(templateId)
  }

  override suspend fun getTemplateForEventSync(eventId: Long): BadgeTemplateEntity? {
    return badgeDao.getTemplateForEventSync(eventId)
  }

  override suspend fun createDefaultTemplate(eventId: Long, eventName: String): Long {
    val template = BadgeTemplateEntity(
      eventId = eventId,
      name = "Badge - $eventName",
      widthMm = 90f,
      heightMm = 60f,
      orientation = BadgeOrientation.LANDSCAPE,
      backgroundColor = "#FFFFFF",
      isActive = true,
    )
    val defaultElements = createDefaultElements(templateId = 0L, eventName = eventName)
    return badgeDao.saveTemplateWithElements(template, defaultElements)
  }

  override suspend fun createTemplate(
    eventId: Long,
    name: String,
    widthMm: Float,
    heightMm: Float,
    orientation: BadgeOrientation,
    backgroundColor: String,
    setActive: Boolean,
  ): Long {
    val template = BadgeTemplateEntity(
      eventId = eventId,
      name = name.trim(),
      widthMm = widthMm,
      heightMm = heightMm,
      orientation = orientation,
      backgroundColor = backgroundColor,
      isActive = setActive,
    )
    val defaultElements = createDefaultElements(templateId = 0L, eventName = "")
    val newId = badgeDao.saveTemplateWithElements(template, defaultElements)
    if (setActive) {
      badgeDao.setActiveTemplate(eventId, newId)
    }
    return newId
  }

  override suspend fun duplicateTemplate(templateId: Long, newName: String): Long {
    return badgeDao.duplicateTemplate(templateId, newName.trim())
  }

  override suspend fun setActiveTemplate(eventId: Long, templateId: Long) {
    badgeDao.setActiveTemplate(eventId, templateId)
  }

  override suspend fun renameTemplate(templateId: Long, newName: String) {
    badgeDao.renameTemplate(templateId, newName.trim())
  }

  override suspend fun saveTemplate(
    template: BadgeTemplateEntity,
    elements: List<BadgeElementEntity>,
  ): Long {
    return badgeDao.saveTemplateWithElements(
      template = template.copy(updatedAt = System.currentTimeMillis()),
      elements = elements,
    )
  }

  override suspend fun deleteTemplate(templateId: Long): Boolean {
    return badgeDao.deleteTemplateById(templateId) > 0
  }

  override suspend fun deleteElement(elementId: Long): Boolean {
    return badgeDao.deleteElementById(elementId) > 0
  }

  companion object {
    /**
     * Builds the default set of badge elements in normalized coordinates (0.0 to 1.0).
     * These normalized values scale identically across Android screen canvases and future PDF renderers.
     */
    fun createDefaultElements(templateId: Long = 0L, eventName: String = ""): List<BadgeElementEntity> {
      return listOf(
        // 1. Event Name header banner
        BadgeElementEntity(
          templateId = templateId,
          type = BadgeElementType.EVENT_NAME,
          x = 0.06f,
          y = 0.05f,
          width = 0.88f,
          height = 0.13f,
          rotation = 0f,
          visible = true,
          text = eventName.ifBlank { null },
          fontSize = 12f,
          fontWeight = "BOLD",
          alignment = BadgeAlignment.CENTER,
          textColor = "#0284C7",
          backgroundColor = "#F0F9FF",
          zIndex = 1,
        ),
        // 2. Logo / Embelm placeholder (top left)
        BadgeElementEntity(
          templateId = templateId,
          type = BadgeElementType.LOGO,
          x = 0.06f,
          y = 0.21f,
          width = 0.16f,
          height = 0.21f,
          rotation = 0f,
          visible = true,
          text = null,
          fontSize = 10f,
          fontWeight = "NORMAL",
          alignment = BadgeAlignment.CENTER,
          textColor = "#64748B",
          backgroundColor = "#F1F5F9",
          zIndex = 2,
        ),
        // 3. Attendee Name (Primary title)
        BadgeElementEntity(
          templateId = templateId,
          type = BadgeElementType.ATTENDEE_NAME,
          x = 0.25f,
          y = 0.23f,
          width = 0.69f,
          height = 0.18f,
          rotation = 0f,
          visible = true,
          text = null,
          fontSize = 19f,
          fontWeight = "BOLD",
          alignment = BadgeAlignment.START,
          textColor = "#0F172A",
          backgroundColor = null,
          zIndex = 3,
        ),
        // 4. Job Title
        BadgeElementEntity(
          templateId = templateId,
          type = BadgeElementType.JOB_TITLE,
          x = 0.06f,
          y = 0.46f,
          width = 0.58f,
          height = 0.15f,
          rotation = 0f,
          visible = true,
          text = null,
          fontSize = 13f,
          fontWeight = "NORMAL",
          alignment = BadgeAlignment.START,
          textColor = "#475569",
          backgroundColor = null,
          zIndex = 4,
        ),
        // 5. Organization
        BadgeElementEntity(
          templateId = templateId,
          type = BadgeElementType.ORGANIZATION,
          x = 0.06f,
          y = 0.63f,
          width = 0.58f,
          height = 0.16f,
          rotation = 0f,
          visible = true,
          text = null,
          fontSize = 14f,
          fontWeight = "BOLD",
          alignment = BadgeAlignment.START,
          textColor = "#1E293B",
          backgroundColor = null,
          zIndex = 5,
        ),
        // 6. QR Code Placeholder (Strictly visual placeholder marked "QR — Reserved")
        BadgeElementEntity(
          templateId = templateId,
          type = BadgeElementType.QR_PLACEHOLDER,
          x = 0.68f,
          y = 0.46f,
          width = 0.26f,
          height = 0.46f,
          rotation = 0f,
          visible = true,
          text = "QR — Reserved",
          fontSize = 10f,
          fontWeight = "BOLD",
          alignment = BadgeAlignment.CENTER,
          textColor = "#64748B",
          backgroundColor = "#F8FAFC",
          zIndex = 6,
        ),
      )
    }
  }
}
