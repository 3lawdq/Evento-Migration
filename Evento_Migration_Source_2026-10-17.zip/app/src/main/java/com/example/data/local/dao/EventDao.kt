package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.EventEntity
import com.example.data.model.EventStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {

  @Query("SELECT * FROM events ORDER BY created_at DESC")
  fun getAllEvents(): Flow<List<EventEntity>>

  @Query("SELECT * FROM events WHERE status = :status ORDER BY created_at DESC")
  fun getEventsByStatus(status: EventStatus): Flow<List<EventEntity>>

  @Query("SELECT * FROM events WHERE id = :id LIMIT 1")
  fun getEventById(id: Long): Flow<EventEntity?>

  @Query("SELECT * FROM events WHERE id = :id LIMIT 1")
  suspend fun getEventByIdSync(id: Long): EventEntity?

  @Query("SELECT COUNT(*) FROM events")
  fun getEventsCount(): Flow<Int>

  @Query("SELECT COUNT(*) FROM events WHERE status = 'ACTIVE'")
  fun getActiveEventsCount(): Flow<Int>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEvent(event: EventEntity): Long

  @Update
  suspend fun updateEvent(event: EventEntity)

  @Query("UPDATE events SET status = :status, updated_at = :updatedAt WHERE id = :id")
  suspend fun updateEventStatus(id: Long, status: EventStatus, updatedAt: Long = System.currentTimeMillis())

  @Query("UPDATE events SET guest_capacity = :capacity, updated_at = :updatedAt WHERE id = :id")
  suspend fun updateEventCapacity(id: Long, capacity: Int, updatedAt: Long = System.currentTimeMillis())

  @Delete
  suspend fun deleteEvent(event: EventEntity)

  @Query("DELETE FROM events WHERE id = :id")
  suspend fun deleteEventById(id: Long)
}
