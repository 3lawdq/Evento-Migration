package com.example.data.local.entity

import androidx.room.Embedded
import androidx.room.Relation

data class BadgeTemplateWithElements(
  @Embedded val template: BadgeTemplateEntity,
  @Relation(
    parentColumn = "id",
    entityColumn = "template_id",
  )
  val elements: List<BadgeElementEntity> = emptyList(),
)
