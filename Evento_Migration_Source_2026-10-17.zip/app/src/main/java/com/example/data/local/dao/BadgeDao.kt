package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.BadgeTemplateWithElements
import kotlinx.coroutines.flow.Flow

@Dao
interface BadgeDao {

  @Query("SELECT COUNT(*) FROM badge_templates")
  fun getTotalTemplatesCount(): Flow<Int>

  @Transaction
  @Query("SELECT * FROM badge_templates WHERE event_id = :eventId ORDER BY is_active DESC, id ASC LIMIT 1")
  fun getTemplateWithElements(eventId: Long): Flow<BadgeTemplateWithElements?>

  @Query("SELECT * FROM badge_templates WHERE event_id = :eventId ORDER BY is_active DESC, id ASC LIMIT 1")
  suspend fun getTemplateForEventSync(eventId: Long): BadgeTemplateEntity?

  @Query("SELECT * FROM badge_templates WHERE event_id = :eventId ORDER BY is_active DESC, id ASC")
  fun getTemplatesForEvent(eventId: Long): Flow<List<BadgeTemplateEntity>>

  @Query("SELECT * FROM badge_templates WHERE event_id = :eventId ORDER BY is_active DESC, id ASC")
  suspend fun getTemplatesForEventSync(eventId: Long): List<BadgeTemplateEntity>

  @Transaction
  @Query("SELECT * FROM badge_templates WHERE id = :templateId")
  fun getTemplateWithElementsById(templateId: Long): Flow<BadgeTemplateWithElements?>

  @Transaction
  @Query("SELECT * FROM badge_templates WHERE id = :templateId")
  suspend fun getTemplateWithElementsByIdSync(templateId: Long): BadgeTemplateWithElements?

  @Query("SELECT * FROM badge_templates WHERE event_id = :eventId AND is_active = 1 LIMIT 1")
  suspend fun getActiveTemplateForEventSync(eventId: Long): BadgeTemplateEntity?

  @Query("UPDATE badge_templates SET is_active = 0 WHERE event_id = :eventId")
  suspend fun clearActiveTemplatesForEvent(eventId: Long)

  @Query("UPDATE badge_templates SET is_active = 1 WHERE id = :templateId")
  suspend fun markTemplateActive(templateId: Long)

  @Query("UPDATE badge_templates SET name = :newName, updated_at = :updatedAt WHERE id = :templateId")
  suspend fun renameTemplate(templateId: Long, newName: String, updatedAt: Long = System.currentTimeMillis())

  @Transaction
  suspend fun setActiveTemplate(eventId: Long, templateId: Long) {
    clearActiveTemplatesForEvent(eventId)
    markTemplateActive(templateId)
  }

  @Transaction
  suspend fun duplicateTemplate(templateId: Long, newName: String): Long {
    val source = getTemplateById(templateId) ?: throw IllegalArgumentException("Template $templateId not found")
    val sourceElements = getElementsForTemplateSync(templateId)
    val now = System.currentTimeMillis()
    val duplicate = source.copy(
      id = 0L,
      name = newName,
      isActive = false,
      createdAt = now,
      updatedAt = now,
    )
    val newId = insertTemplate(duplicate)
    val copiedElements = sourceElements.map { it.copy(id = 0L, templateId = newId) }
    if (copiedElements.isNotEmpty()) {
      insertElements(copiedElements)
    }
    return newId
  }

  @Query("SELECT * FROM badge_templates WHERE id = :templateId")
  suspend fun getTemplateById(templateId: Long): BadgeTemplateEntity?

  @Query("SELECT * FROM badge_elements WHERE template_id = :templateId ORDER BY z_index ASC, id ASC")
  suspend fun getElementsForTemplateSync(templateId: Long): List<BadgeElementEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTemplate(template: BadgeTemplateEntity): Long

  @Update
  suspend fun updateTemplate(template: BadgeTemplateEntity)

  @Delete
  suspend fun deleteTemplate(template: BadgeTemplateEntity)

  @Query("DELETE FROM badge_templates WHERE id = :templateId")
  suspend fun deleteTemplateById(templateId: Long): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertElements(elements: List<BadgeElementEntity>): List<Long>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertElement(element: BadgeElementEntity): Long

  @Update
  suspend fun updateElement(element: BadgeElementEntity)

  @Delete
  suspend fun deleteElement(element: BadgeElementEntity)

  @Query("DELETE FROM badge_elements WHERE template_id = :templateId")
  suspend fun deleteElementsForTemplate(templateId: Long): Int

  @Query("DELETE FROM badge_elements WHERE id = :elementId")
  suspend fun deleteElementById(elementId: Long): Int

  @Transaction
  suspend fun saveTemplateWithElements(
    template: BadgeTemplateEntity,
    elements: List<BadgeElementEntity>,
  ): Long {
    val templateId = if (template.id == 0L) {
      insertTemplate(template)
    } else {
      updateTemplate(template)
      template.id
    }

    deleteElementsForTemplate(templateId)
    val elementsToInsert = elements.map { it.copy(id = 0L, templateId = templateId) }
    if (elementsToInsert.isNotEmpty()) {
      insertElements(elementsToInsert)
    }
    return templateId
  }
}
