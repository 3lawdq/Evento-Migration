package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.ExportedPackageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExportedPackageDao {

  @Query("SELECT COUNT(*) FROM exported_packages")
  fun getExportedPackagesCount(): Flow<Int>

  @Query("SELECT COUNT(*) FROM exported_packages")
  suspend fun getExportedPackagesCountSync(): Int

  @Query("SELECT * FROM exported_packages WHERE event_id = :eventId ORDER BY exported_at DESC")
  fun getPackagesForEvent(eventId: Long): Flow<List<ExportedPackageEntity>>

  @Query("SELECT * FROM exported_packages ORDER BY exported_at DESC")
  fun getAllExportedPackages(): Flow<List<ExportedPackageEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertExportedPackage(pkg: ExportedPackageEntity): Long

  @Delete
  suspend fun deleteExportedPackage(pkg: ExportedPackageEntity)

  @Query("DELETE FROM exported_packages WHERE event_id = :eventId")
  suspend fun deletePackagesForEvent(eventId: Long)

  @Query("DELETE FROM exported_packages")
  suspend fun deleteAllPackages()
}
