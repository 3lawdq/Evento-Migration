package com.example.data.model

enum class EventStatus {
  DRAFT,
  ACTIVE,
  ARCHIVED;

  companion object {
    fun fromString(value: String?): EventStatus {
      return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: DRAFT
    }
  }
}
