package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Tracks successfully exported .evento packages in durable Room storage.
 */
@Entity(
  tableName = "exported_packages",
  foreignKeys = [
    ForeignKey(
      entity = EventEntity::class,
      parentColumns = ["id"],
      childColumns = ["event_id"],
      onDelete = ForeignKey.CASCADE,
    ),
  ],
  indices = [
    Index(value = ["event_id"]),
    Index(value = ["exported_at"]),
  ],
)
data class ExportedPackageEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,

  @ColumnInfo(name = "event_id")
  val eventId: Long,

  @ColumnInfo(name = "file_name")
  val fileName: String,

  @ColumnInfo(name = "guest_count")
  val guestCount: Int,

  @ColumnInfo(name = "file_size_bytes")
  val fileSizeBytes: Long,

  @ColumnInfo(name = "is_licensed")
  val isLicensed: Boolean,

  @ColumnInfo(name = "exported_at")
  val exportedAt: Long = System.currentTimeMillis(),
)
