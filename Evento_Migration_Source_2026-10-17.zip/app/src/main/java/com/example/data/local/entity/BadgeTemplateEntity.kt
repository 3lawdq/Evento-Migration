package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.BadgeOrientation

/**
 * Badge template entity associated with an EventEntity.
 * Holds physical dimensions in millimeters, orientation, colors, and background image URI.
 * Stored dimensions remain strictly in millimeters for future 1:1 PDF reproduction.
 */
@Entity(
  tableName = "badge_templates",
  foreignKeys = [
    ForeignKey(
      entity = EventEntity::class,
      parentColumns = ["id"],
      childColumns = ["event_id"],
      onDelete = ForeignKey.CASCADE,
    ),
  ],
  indices = [
    Index(value = ["event_id"]),
  ],
)
data class BadgeTemplateEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,

  @ColumnInfo(name = "event_id")
  val eventId: Long,

  @ColumnInfo(name = "name")
  val name: String = "Default Attendee Badge",

  @ColumnInfo(name = "width_mm")
  val widthMm: Float = 90f,

  @ColumnInfo(name = "height_mm")
  val heightMm: Float = 60f,

  @ColumnInfo(name = "orientation")
  val orientation: BadgeOrientation = BadgeOrientation.LANDSCAPE,

  @ColumnInfo(name = "background_color")
  val backgroundColor: String = "#FFFFFF",

  @ColumnInfo(name = "background_image_uri")
  val backgroundImageUri: String? = null,

  @ColumnInfo(name = "is_active")
  val isActive: Boolean = false,

  @ColumnInfo(name = "created_at")
  val createdAt: Long = System.currentTimeMillis(),

  @ColumnInfo(name = "updated_at")
  val updatedAt: Long = System.currentTimeMillis(),
)
