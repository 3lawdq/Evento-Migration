package com.example.data.model

import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity

enum class ReadinessSeverity {
  CRITICAL,  // Must fix before production (e.g. event name empty, no active badge template)
  WARNING,   // Production risk (e.g. no guests, date missing, incomplete contact info)
  PASSED,    // Check passed cleanly
  INFO,      // Informational metric (e.g. capacity usage)
}

data class ReadinessCheckItem(
  val id: String,
  val titleKey: String,
  val detail: String,
  val severity: ReadinessSeverity,
  val isActionable: Boolean = true,
)

data class ProductionReadinessReport(
  val eventId: Long,
  val scorePercentage: Int, // 0 to 100
  val isProductionReady: Boolean,
  val checks: List<ReadinessCheckItem>,
  val criticalCount: Int,
  val warningCount: Int,
  val passedCount: Int,
)

object ProductionReadinessEvaluator {

  fun evaluate(
    event: EventEntity?,
    guests: List<GuestEntity> = emptyList(),
    activeBadgeTemplate: BadgeTemplateEntity? = null,
    pdfFitsOnPage: Boolean = true,
  ): ProductionReadinessReport {
    if (event == null) {
      return ProductionReadinessReport(
        eventId = 0L,
        scorePercentage = 0,
        isProductionReady = false,
        checks = emptyList(),
        criticalCount = 0,
        warningCount = 0,
        passedCount = 0,
      )
    }

    val checks = mutableListOf<ReadinessCheckItem>()

    // 1. Event Name
    if (event.name.isNotBlank()) {
      checks.add(
        ReadinessCheckItem(
          id = "event_name",
          titleKey = "readiness_name_passed",
          detail = event.name,
          severity = ReadinessSeverity.PASSED,
        )
      )
    } else {
      checks.add(
        ReadinessCheckItem(
          id = "event_name",
          titleKey = "readiness_name_missing",
          detail = "Event title is required",
          severity = ReadinessSeverity.CRITICAL,
        )
      )
    }

    // 2. Event Date
    if (event.date.isNotBlank()) {
      checks.add(
        ReadinessCheckItem(
          id = "event_date",
          titleKey = "readiness_date_passed",
          detail = event.date,
          severity = ReadinessSeverity.PASSED,
        )
      )
    } else {
      checks.add(
        ReadinessCheckItem(
          id = "event_date",
          titleKey = "readiness_date_missing",
          detail = "No scheduled date set",
          severity = ReadinessSeverity.WARNING,
        )
      )
    }

    // 3. Event Location
    if (event.location.isNotBlank()) {
      checks.add(
        ReadinessCheckItem(
          id = "event_location",
          titleKey = "readiness_location_passed",
          detail = event.location,
          severity = ReadinessSeverity.PASSED,
        )
      )
    } else {
      checks.add(
        ReadinessCheckItem(
          id = "event_location",
          titleKey = "readiness_location_missing",
          detail = "Venue location is not specified",
          severity = ReadinessSeverity.WARNING,
        )
      )
    }

    // 4. Guest Count & Empty Slots
    val filledGuests = guests.filter { it.fullName.isNotBlank() }
    val emptySlots = guests.filter { it.fullName.isBlank() }

    if (filledGuests.isNotEmpty()) {
      checks.add(
        ReadinessCheckItem(
          id = "guests_present",
          titleKey = "readiness_guests_passed",
          detail = "${filledGuests.size} registered guests",
          severity = ReadinessSeverity.PASSED,
        )
      )
    } else {
      checks.add(
        ReadinessCheckItem(
          id = "guests_present",
          titleKey = "readiness_guests_missing",
          detail = "No registered guests found",
          severity = ReadinessSeverity.WARNING,
        )
      )
    }

    // 5. Guest Capacity
    if (event.guestCapacity > 0) {
      if (filledGuests.size > event.guestCapacity) {
        checks.add(
          ReadinessCheckItem(
            id = "guest_capacity",
            titleKey = "readiness_capacity_exceeded",
            detail = "${filledGuests.size}/${event.guestCapacity} (Over capacity)",
            severity = ReadinessSeverity.WARNING,
          )
        )
      } else {
        checks.add(
          ReadinessCheckItem(
            id = "guest_capacity",
            titleKey = "readiness_capacity_valid",
            detail = "${filledGuests.size}/${event.guestCapacity} slots used",
            severity = ReadinessSeverity.PASSED,
          )
        )
      }
    } else {
      checks.add(
        ReadinessCheckItem(
          id = "guest_capacity",
          titleKey = "readiness_capacity_unlimited",
          detail = "Open capacity (${filledGuests.size} registered)",
          severity = ReadinessSeverity.INFO,
        )
      )
    }

    // 6. Active Badge Template
    if (activeBadgeTemplate != null) {
      checks.add(
        ReadinessCheckItem(
          id = "badge_template",
          titleKey = "readiness_badge_template_passed",
          detail = activeBadgeTemplate.name,
          severity = ReadinessSeverity.PASSED,
        )
      )

      // 7. Badge Dimensions
      if (activeBadgeTemplate.widthMm > 0f && activeBadgeTemplate.heightMm > 0f) {
        checks.add(
          ReadinessCheckItem(
            id = "badge_dimensions",
            titleKey = "readiness_dimensions_passed",
            detail = "${activeBadgeTemplate.widthMm} x ${activeBadgeTemplate.heightMm} mm",
            severity = ReadinessSeverity.PASSED,
          )
        )
      } else {
        checks.add(
          ReadinessCheckItem(
            id = "badge_dimensions",
            titleKey = "readiness_dimensions_invalid",
            detail = "Invalid badge physical dimensions",
            severity = ReadinessSeverity.CRITICAL,
          )
        )
      }
    } else {
      checks.add(
        ReadinessCheckItem(
          id = "badge_template",
          titleKey = "readiness_badge_template_missing",
          detail = "No active badge template configured",
          severity = ReadinessSeverity.CRITICAL,
        )
      )
    }

    // 8. PDF Layout Fit
    if (pdfFitsOnPage) {
      checks.add(
        ReadinessCheckItem(
          id = "pdf_layout",
          titleKey = "readiness_pdf_layout_passed",
          detail = "Badge layout fits target print sheets",
          severity = ReadinessSeverity.PASSED,
        )
      )
    } else {
      checks.add(
        ReadinessCheckItem(
          id = "pdf_layout",
          titleKey = "readiness_pdf_layout_overflow",
          detail = "Badge dimensions exceed current printable area",
          severity = ReadinessSeverity.WARNING,
        )
      )
    }

    // 9. Data Quality / Incomplete Records
    val incompleteCount = filledGuests.count {
      it.email.isBlank() || it.phone.isBlank() || it.organization.isBlank() || it.jobTitle.isBlank()
    }
    if (filledGuests.isNotEmpty()) {
      if (incompleteCount == 0) {
        checks.add(
          ReadinessCheckItem(
            id = "data_completeness",
            titleKey = "readiness_data_complete",
            detail = "100% guest profiles complete",
            severity = ReadinessSeverity.PASSED,
          )
        )
      } else {
        val pct = ((incompleteCount.toDouble() / filledGuests.size) * 100).toInt()
        checks.add(
          ReadinessCheckItem(
            id = "data_completeness",
            titleKey = "readiness_data_incomplete",
            detail = "$incompleteCount of ${filledGuests.size} profiles incomplete ($pct%)",
            severity = ReadinessSeverity.WARNING,
          )
        )
      }
    }

    // 10. Duplicate Emails Detection
    val emails = filledGuests.map { it.email.trim().lowercase() }.filter { it.isNotBlank() }
    val duplicates = emails.groupBy { it }.filter { it.value.size > 1 }
    if (duplicates.isNotEmpty()) {
      checks.add(
        ReadinessCheckItem(
          id = "duplicate_emails",
          titleKey = "readiness_duplicate_emails_found",
          detail = "${duplicates.size} duplicate email addresses detected",
          severity = ReadinessSeverity.WARNING,
        )
      )
    }

    // 11. Event Status Check
    if (event.status == EventStatus.ACTIVE) {
      checks.add(
        ReadinessCheckItem(
          id = "event_status",
          titleKey = "readiness_status_active",
          detail = "Event is Active",
          severity = ReadinessSeverity.PASSED,
        )
      )
    } else {
      checks.add(
        ReadinessCheckItem(
          id = "event_status",
          titleKey = "readiness_status_non_active",
          detail = "Event status is ${event.status.name}",
          severity = ReadinessSeverity.INFO,
        )
      )
    }

    val criticalCount = checks.count { it.severity == ReadinessSeverity.CRITICAL }
    val warningCount = checks.count { it.severity == ReadinessSeverity.WARNING }
    val passedCount = checks.count { it.severity == ReadinessSeverity.PASSED }

    // Weighted Score: Passed = 10 pts, Warning = 5 pts, Critical = 0 pts
    val totalPossibleWeight = checks.size * 10
    val actualWeight = (passedCount * 10) + (warningCount * 5)
    val score = if (totalPossibleWeight > 0) {
      ((actualWeight.toDouble() / totalPossibleWeight) * 100).toInt().coerceIn(0, 100)
    } else {
      0
    }

    val isProductionReady = criticalCount == 0 && (filledGuests.isNotEmpty() || emptySlots.isNotEmpty())

    return ProductionReadinessReport(
      eventId = event.id,
      scorePercentage = score,
      isProductionReady = isProductionReady,
      checks = checks,
      criticalCount = criticalCount,
      warningCount = warningCount,
      passedCount = passedCount,
    )
  }
}
