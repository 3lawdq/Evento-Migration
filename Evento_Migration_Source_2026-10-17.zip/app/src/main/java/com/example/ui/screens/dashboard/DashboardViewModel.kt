package com.example.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.EventEntity
import com.example.data.model.EventStatus
import com.example.data.repository.BadgeTemplateRepository
import com.example.data.repository.EventPackageRepository
import com.example.data.repository.EventRepository
import com.example.data.repository.GuestRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
  val totalEvents: Int = 0,
  val activeEvents: Int = 0,
  val totalGuests: Int = 0,
  val designedBadges: Int = 0,
  val preparedPackages: Int = 0,
  val recentEvents: List<EventEntity> = emptyList(),
  val isLoading: Boolean = false,
)

class DashboardViewModel(
  eventRepository: EventRepository,
  guestRepository: GuestRepository,
  badgeTemplateRepository: BadgeTemplateRepository,
  packageRepository: EventPackageRepository,
  coroutineScope: CoroutineScope? = null,
) : ViewModel() {

  private val scope = coroutineScope ?: viewModelScope

  val uiState: StateFlow<DashboardUiState> = combine(
    eventRepository.getAllEvents(),
    guestRepository.getTotalGuestsCount(),
    badgeTemplateRepository.getTotalTemplatesCount(),
    packageRepository.getExportedPackagesCount(),
  ) { events, totalGuests, badgeCount, packageCount ->
    val activeCount = events.count { it.status == EventStatus.ACTIVE }
    val recent = events.take(3)
    DashboardUiState(
      totalEvents = events.size,
      activeEvents = activeCount,
      totalGuests = totalGuests,
      designedBadges = badgeCount,
      preparedPackages = packageCount,
      recentEvents = recent,
      isLoading = false,
    )
  }.stateIn(
    scope = scope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = DashboardUiState(isLoading = true),
  )

  companion object {
    fun provideFactory(
      eventRepository: EventRepository,
      guestRepository: GuestRepository,
      badgeTemplateRepository: BadgeTemplateRepository,
      packageRepository: EventPackageRepository,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return DashboardViewModel(
          eventRepository = eventRepository,
          guestRepository = guestRepository,
          badgeTemplateRepository = badgeTemplateRepository,
          packageRepository = packageRepository,
        ) as T
      }
    }
  }
}
