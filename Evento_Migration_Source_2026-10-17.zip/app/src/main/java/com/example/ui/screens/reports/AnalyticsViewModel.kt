package com.example.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.evento.checkin.data.repository.CheckInRepository
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.AttendanceStatusCrossAnalysis
import com.example.data.model.AttendanceTimeBucket
import com.example.data.model.EventAttendanceSummary
import com.example.data.model.EventDataQualitySummary
import com.example.data.model.GuestDataQualityEvaluator
import com.example.data.model.InvitationStatus
import com.example.data.model.InvitationStatusCount
import com.example.data.model.JobTitleAttendanceSummary
import com.example.data.model.OrganizationAttendanceSummary
import com.example.data.model.PeakCheckInPeriod
import com.example.data.repository.EventRepository
import com.example.data.repository.GuestRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AnalyticsUiState(
  val events: List<EventEntity> = emptyList(),
  val selectedEvent: EventEntity? = null,
  val attendanceSummary: EventAttendanceSummary = EventAttendanceSummary(),
  val invitationBreakdown: List<InvitationStatusCount> = emptyList(),
  val crossAnalysis: AttendanceStatusCrossAnalysis = AttendanceStatusCrossAnalysis(),
  val timeline: List<AttendanceTimeBucket> = emptyList(),
  val peakCheckIn: PeakCheckInPeriod? = null,
  val dataQualitySummary: EventDataQualitySummary = EventDataQualitySummary(),
  val organizationSummaries: List<OrganizationAttendanceSummary> = emptyList(),
  val jobTitleSummaries: List<JobTitleAttendanceSummary> = emptyList(),
  val isLoading: Boolean = false,
  val errorMessage: String? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class AnalyticsViewModel(
  private val eventRepository: EventRepository,
  private val guestRepository: GuestRepository,
  private val checkInRepository: CheckInRepository? = null,
  coroutineScope: CoroutineScope? = null,
) : ViewModel() {

  private val scope = coroutineScope ?: viewModelScope

  private val _selectedEventId = MutableStateFlow<Long?>(null)
  val selectedEventId: StateFlow<Long?> = _selectedEventId.asStateFlow()

  fun selectEvent(eventId: Long?) {
    _selectedEventId.value = eventId
  }

  val uiState: StateFlow<AnalyticsUiState> = combine(
    eventRepository.getAllEvents(),
    _selectedEventId,
  ) { allEvents, currentSelectedId ->
    Pair(allEvents, currentSelectedId)
  }.flatMapLatest { (allEvents, currentSelectedId) ->
    val effectiveEvent = if (currentSelectedId != null) {
      allEvents.find { it.id == currentSelectedId }
    } else {
      allEvents.firstOrNull()
    }

    if (effectiveEvent == null) {
      flowOf(
        AnalyticsUiState(
          events = allEvents,
          selectedEvent = null,
          isLoading = false,
        )
      )
    } else {
      val eventId = effectiveEvent.id
      val attendanceFlow = checkInRepository?.getAttendanceForEventFlow(eventId) ?: flowOf(emptyList())

      combine(
        guestRepository.getGuestsForEvent(eventId),
        guestRepository.getOrganizationStatsForEvent(eventId),
        guestRepository.getJobTitleStatsForEvent(eventId),
        attendanceFlow,
      ) { guests, orgStats, jobStats, checkInRecords ->
        computeAnalytics(
          allEvents = allEvents,
          event = effectiveEvent,
          guests = guests,
          orgProjections = orgStats,
          jobProjections = jobStats,
          attendanceRecords = checkInRecords,
        )
      }
    }
  }.stateIn(
    scope = scope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = AnalyticsUiState(isLoading = true),
  )

  private fun computeAnalytics(
    allEvents: List<EventEntity>,
    event: EventEntity,
    guests: List<GuestEntity>,
    orgProjections: List<com.example.data.model.OrganizationStatsProjection>,
    jobProjections: List<com.example.data.model.JobTitleStatsProjection>,
    attendanceRecords: List<com.evento.checkin.domain.model.AttendanceRecord>,
  ): AnalyticsUiState {
    val totalGuests = guests.size

    // Determine checked-in attendees
    val checkInUuids = attendanceRecords.map { it.guestUuid }.toSet()
    val checkedInGuestsCount = guests.count {
      it.invitationStatus == InvitationStatus.CHECKED_IN || checkInUuids.contains(it.uuid)
    }
    val remaining = (totalGuests - checkedInGuestsCount).coerceAtLeast(0)

    val attendancePct = if (totalGuests > 0) {
      (checkedInGuestsCount.toDouble() / totalGuests.toDouble()) * 100.0
    } else {
      0.0
    }
    val nonAttendancePct = if (totalGuests > 0) {
      (remaining.toDouble() / totalGuests.toDouble()) * 100.0
    } else {
      0.0
    }

    val summary = EventAttendanceSummary(
      totalGuests = totalGuests,
      checkedInGuests = checkedInGuestsCount,
      remainingGuests = remaining,
      attendancePercentage = attendancePct,
      nonAttendancePercentage = nonAttendancePct,
    )

    // Invitation status breakdown
    val statusGroups = guests.groupBy { it.invitationStatus }
    val invitationBreakdown = InvitationStatus.entries.map { status ->
      val count = statusGroups[status]?.size ?: 0
      val pct = if (totalGuests > 0) (count.toDouble() / totalGuests.toDouble()) * 100.0 else 0.0
      InvitationStatusCount(
        status = status,
        count = count,
        percentageOfTotal = pct,
      )
    }

    // Cross-analysis
    var invitedNotCheckedIn = 0
    var confirmedAndCheckedIn = 0
    var confirmedNotCheckedIn = 0
    var declined = 0

    for (guest in guests) {
      val isCheckedIn = guest.invitationStatus == InvitationStatus.CHECKED_IN || checkInUuids.contains(guest.uuid)
      when (guest.invitationStatus) {
        InvitationStatus.INVITED -> {
          if (!isCheckedIn) invitedNotCheckedIn++
        }
        InvitationStatus.CONFIRMED -> {
          if (isCheckedIn) confirmedAndCheckedIn++ else confirmedNotCheckedIn++
        }
        InvitationStatus.DECLINED -> {
          declined++
        }
        InvitationStatus.CHECKED_IN -> {
          // If the guest is marked CHECKED_IN, they confirmed attendance
          confirmedAndCheckedIn++
        }
      }
    }

    val crossAnalysis = AttendanceStatusCrossAnalysis(
      invitedNotCheckedIn = invitedNotCheckedIn,
      confirmedAndCheckedIn = confirmedAndCheckedIn,
      confirmedNotCheckedIn = confirmedNotCheckedIn,
      declined = declined,
      totalCheckedIn = checkedInGuestsCount,
    )

    // Timeline and Peak calculation
    val (timeline, peak) = calculateTimelineAndPeak(attendanceRecords)

    // Data quality evaluation
    val qualitySummary = GuestDataQualityEvaluator.summarize(guests)

    // Organization analysis (combines guest roster invitation status with checkInRecords)
    val orgGroups = guests.filter { it.organization.isNotBlank() }.groupBy { it.organization.trim() }
    val organizations = orgGroups.map { (orgName, orgGuests) ->
      val totalInOrg = orgGuests.size
      val checkedInInOrg = orgGuests.count {
        it.invitationStatus == InvitationStatus.CHECKED_IN || checkInUuids.contains(it.uuid)
      }
      val orgAttendancePct = if (totalInOrg > 0) {
        (checkedInInOrg.toDouble() / totalInOrg.toDouble()) * 100.0
      } else {
        0.0
      }
      OrganizationAttendanceSummary(
        organization = orgName,
        totalGuests = totalInOrg,
        checkedInGuests = checkedInInOrg,
        attendancePercentage = orgAttendancePct,
      )
    }.sortedByDescending { it.totalGuests }

    // Job title analysis (combines guest roster invitation status with checkInRecords)
    val jobGroups = guests.filter { it.jobTitle.isNotBlank() }.groupBy { it.jobTitle.trim() }
    val jobTitles = jobGroups.map { (jobName, jobGuests) ->
      val totalInJob = jobGuests.size
      val checkedInInJob = jobGuests.count {
        it.invitationStatus == InvitationStatus.CHECKED_IN || checkInUuids.contains(it.uuid)
      }
      val jobAttendancePct = if (totalInJob > 0) {
        (checkedInInJob.toDouble() / totalInJob.toDouble()) * 100.0
      } else {
        0.0
      }
      JobTitleAttendanceSummary(
        jobTitle = jobName,
        totalGuests = totalInJob,
        checkedInGuests = checkedInInJob,
        attendancePercentage = jobAttendancePct,
      )
    }.sortedByDescending { it.totalGuests }

    return AnalyticsUiState(
      events = allEvents,
      selectedEvent = event,
      attendanceSummary = summary,
      invitationBreakdown = invitationBreakdown,
      crossAnalysis = crossAnalysis,
      timeline = timeline,
      peakCheckIn = peak,
      dataQualitySummary = qualitySummary,
      organizationSummaries = organizations,
      jobTitleSummaries = jobTitles,
      isLoading = false,
      errorMessage = null,
    )
  }

  private fun calculateTimelineAndPeak(
    records: List<com.evento.checkin.domain.model.AttendanceRecord>,
  ): Pair<List<AttendanceTimeBucket>, PeakCheckInPeriod?> {
    if (records.isEmpty()) {
      return Pair(emptyList(), null)
    }

    val oneHourMs = 3600000L
    val timeFormat = SimpleDateFormat("HH:00", Locale.getDefault())
    val rangeFormat = SimpleDateFormat("HH:00 - ", Locale.getDefault())
    val endFormat = SimpleDateFormat("HH:00", Locale.getDefault())

    // Group timestamps by 1-hour window (truncated to hour)
    val grouped = records.groupBy { (it.checkedInAt / oneHourMs) * oneHourMs }
      .toSortedMap()

    val totalRecordsCount = records.size
    val timeline = grouped.map { (bucketStart, bucketRecords) ->
      val count = bucketRecords.size
      val pct = (count.toDouble() / totalRecordsCount.toDouble()) * 100.0
      AttendanceTimeBucket(
        bucketStartEpochMs = bucketStart,
        formattedTime = timeFormat.format(Date(bucketStart)),
        count = count,
        percentageOfTotalCheckIns = pct,
      )
    }

    val peakEntry = grouped.maxByOrNull { it.value.size }
    val peakPeriod = peakEntry?.let { (bucketStart, bucketRecords) ->
      val timeRange = "${rangeFormat.format(Date(bucketStart))}${endFormat.format(Date(bucketStart + oneHourMs))}"
      PeakCheckInPeriod(
        bucketStartEpochMs = bucketStart,
        formattedTimeRange = timeRange,
        checkInCount = bucketRecords.size,
      )
    }

    return Pair(timeline, peakPeriod)
  }

  companion object {
    fun provideFactory(
      eventRepository: EventRepository,
      guestRepository: GuestRepository,
      checkInRepository: CheckInRepository? = null,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AnalyticsViewModel(
          eventRepository = eventRepository,
          guestRepository = guestRepository,
          checkInRepository = checkInRepository,
        ) as T
      }
    }
  }
}
