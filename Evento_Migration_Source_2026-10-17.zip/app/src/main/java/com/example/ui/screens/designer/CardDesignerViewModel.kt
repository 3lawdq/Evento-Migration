package com.example.ui.screens.designer

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import com.example.data.repository.BadgeTemplateRepository
import com.example.data.repository.BadgeTemplateRepositoryImpl
import com.example.data.repository.EventRepository
import com.example.data.repository.GuestRepository
import com.example.ui.screens.designer.model.PreviewGuest
import com.example.util.qr.QrCodeGenerator
import com.example.util.qr.QrCodeGeneratorImpl
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface DesignerUiState {
  data object Loading : DesignerUiState
  data object NoEvents : DesignerUiState
  data class Ready(
    val selectedEvent: EventEntity,
    val template: BadgeTemplateEntity?,
    val elements: List<BadgeElementEntity>,
    val selectedElement: BadgeElementEntity?,
    val isPreviewMode: Boolean,
    val isDirty: Boolean,
    val previewGuest: PreviewGuest,
  ) : DesignerUiState
}

class CardDesignerViewModel(
  private val badgeRepository: BadgeTemplateRepository,
  private val eventRepository: EventRepository,
  private val guestRepository: GuestRepository,
  private val qrCodeGenerator: QrCodeGenerator = QrCodeGeneratorImpl(),
  private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : ViewModel() {

  val previewGuest = PreviewGuest()

  private val _selectedEventId = MutableStateFlow<Long?>(null)
  val selectedEventId: StateFlow<Long?> = _selectedEventId.asStateFlow()

  val allEvents: StateFlow<List<EventEntity>> = eventRepository.getAllEvents()
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  @OptIn(ExperimentalCoroutinesApi::class)
  val eventGuests: StateFlow<List<GuestEntity>> = _selectedEventId
    .flatMapLatest { eventId ->
      if (eventId != null) {
        guestRepository.getGuestsForEvent(eventId)
      } else {
        flowOf(emptyList())
      }
    }
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  // Templates available for the selected event
  private val _selectedTemplateId = MutableStateFlow<Long?>(null)
  val selectedTemplateId: StateFlow<Long?> = _selectedTemplateId.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val eventTemplates: StateFlow<List<BadgeTemplateEntity>> = _selectedEventId
    .flatMapLatest { eventId ->
      if (eventId != null) {
        badgeRepository.getTemplatesForEvent(eventId)
      } else {
        flowOf(emptyList())
      }
    }
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  // Real guest selected for preview only (strictly does NOT modify GuestEntity in Room)
  private val _selectedPreviewGuest = MutableStateFlow<GuestEntity?>(null)
  val selectedPreviewGuest: StateFlow<GuestEntity?> = _selectedPreviewGuest.asStateFlow()

  // In-memory generated QR bitmap for selected preview guest (never stored in Room)
  private val _previewQrBitmap = MutableStateFlow<Bitmap?>(null)
  val previewQrBitmap: StateFlow<Bitmap?> = _previewQrBitmap.asStateFlow()

  // In-memory working copies of template and elements
  private val _currentTemplate = MutableStateFlow<BadgeTemplateEntity?>(null)
  val currentTemplate: StateFlow<BadgeTemplateEntity?> = _currentTemplate.asStateFlow()

  private val _currentElements = MutableStateFlow<List<BadgeElementEntity>>(emptyList())
  val currentElements: StateFlow<List<BadgeElementEntity>> = _currentElements.asStateFlow()

  private val _selectedElementId = MutableStateFlow<Long?>(null)
  val selectedElementId: StateFlow<Long?> = _selectedElementId.asStateFlow()

  private val _isPreviewMode = MutableStateFlow(false)
  val isPreviewMode: StateFlow<Boolean> = _isPreviewMode.asStateFlow()

  private val _isDirty = MutableStateFlow(false)
  val isDirty: StateFlow<Boolean> = _isDirty.asStateFlow()

  private val _isSaving = MutableStateFlow(false)
  val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

  private val _snackbarMessage = MutableSharedFlow<String>()
  val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

  private var temporaryElementIdCounter = -1L
  private var templateObserveJob: kotlinx.coroutines.Job? = null

  init {
    // Automatically select the first event if none is selected
    viewModelScope.launch {
      allEvents.collect { events ->
        if (events.isNotEmpty() && _selectedEventId.value == null) {
          selectEvent(events.first().id)
        }
      }
    }
  }

  fun selectEvent(eventId: Long) {
    _selectedEventId.value = eventId
    _selectedTemplateId.value = null
    _selectedElementId.value = null
    _selectedPreviewGuest.value = null
    _previewQrBitmap.value = null
    _isDirty.value = false

    observeCurrentTemplate(eventId, templateId = null)
  }

  fun selectTemplate(templateId: Long) {
    _selectedTemplateId.value = templateId
    _selectedElementId.value = null
    _isDirty.value = false
    val eventId = _selectedEventId.value ?: return
    observeCurrentTemplate(eventId, templateId)
  }

  private fun observeCurrentTemplate(eventId: Long, templateId: Long?) {
    templateObserveJob?.cancel()
    templateObserveJob = viewModelScope.launch(Dispatchers.IO) {
      val flow = if (templateId != null) {
        badgeRepository.getTemplateWithElementsById(templateId)
      } else {
        badgeRepository.getTemplateWithElements(eventId)
      }

      flow.collect { templateWithElements ->
        withContext(Dispatchers.Main) {
          if (templateWithElements != null) {
            _currentTemplate.value = templateWithElements.template
            _currentElements.value = templateWithElements.elements
            if (_selectedTemplateId.value == null) {
              _selectedTemplateId.value = templateWithElements.template.id
            }
          } else {
            _currentTemplate.value = null
            _currentElements.value = emptyList()
          }
        }
      }
    }
  }

  fun createDefaultTemplate() {
    val eventId = _selectedEventId.value ?: return
    val event = allEvents.value.firstOrNull { it.id == eventId }
    val eventName = event?.name ?: "Event"

    viewModelScope.launch(Dispatchers.IO) {
      val newId = badgeRepository.createDefaultTemplate(eventId, eventName)
      withContext(Dispatchers.Main) {
        _selectedTemplateId.value = newId
        _isDirty.value = false
        _snackbarMessage.emit("Default template created")
      }
    }
  }

  fun createNewTemplate(name: String, widthMm: Float = 90f, heightMm: Float = 60f, orientation: BadgeOrientation = BadgeOrientation.LANDSCAPE) {
    val eventId = _selectedEventId.value ?: return
    viewModelScope.launch(Dispatchers.IO) {
      val newId = badgeRepository.createTemplate(
        eventId = eventId,
        name = name,
        widthMm = widthMm,
        heightMm = heightMm,
        orientation = orientation,
        setActive = true,
      )
      withContext(Dispatchers.Main) {
        _selectedTemplateId.value = newId
        _isDirty.value = false
        _snackbarMessage.emit("Template '$name' created")
      }
    }
  }

  fun duplicateCurrentTemplate(newName: String) {
    val current = _currentTemplate.value ?: return
    viewModelScope.launch(Dispatchers.IO) {
      val newId = badgeRepository.duplicateTemplate(current.id, newName)
      withContext(Dispatchers.Main) {
        _selectedTemplateId.value = newId
        _isDirty.value = false
        _snackbarMessage.emit("Template duplicated as '$newName'")
      }
    }
  }

  fun duplicateTemplate(newName: String) {
    duplicateCurrentTemplate(newName)
  }

  fun duplicateTemplate(templateId: Long, newName: String) {
    viewModelScope.launch(Dispatchers.IO) {
      val newId = badgeRepository.duplicateTemplate(templateId, newName)
      withContext(Dispatchers.Main) {
        _selectedTemplateId.value = newId
        _isDirty.value = false
        _snackbarMessage.emit("Template duplicated as '$newName'")
      }
    }
  }

  fun renameCurrentTemplate(newName: String) {
    val current = _currentTemplate.value ?: return
    viewModelScope.launch(Dispatchers.IO) {
      badgeRepository.renameTemplate(current.id, newName)
      withContext(Dispatchers.Main) {
        _currentTemplate.value = _currentTemplate.value?.copy(name = newName)
        _snackbarMessage.emit("Template renamed to '$newName'")
      }
    }
  }

  fun setAsActiveTemplate() {
    val current = _currentTemplate.value ?: return
    val eventId = _selectedEventId.value ?: return
    viewModelScope.launch(Dispatchers.IO) {
      badgeRepository.setActiveTemplate(eventId, current.id)
      withContext(Dispatchers.Main) {
        _currentTemplate.value = _currentTemplate.value?.copy(isActive = true)
        _snackbarMessage.emit("Active template updated")
      }
    }
  }

  fun setTemplateActive(templateId: Long) {
    val eventId = _selectedEventId.value ?: return
    viewModelScope.launch(Dispatchers.IO) {
      badgeRepository.setActiveTemplate(eventId, templateId)
      withContext(Dispatchers.Main) {
        if (_currentTemplate.value?.id == templateId) {
          _currentTemplate.value = _currentTemplate.value?.copy(isActive = true)
        }
        _snackbarMessage.emit("Active template updated")
      }
    }
  }

  fun setBackgroundImage(uriString: String?) {
    if (uriString == null) {
      removeBackgroundImage()
    } else {
      _currentTemplate.value = _currentTemplate.value?.copy(
        backgroundImageUri = uriString,
        updatedAt = System.currentTimeMillis(),
      )
      _isDirty.value = true
    }
  }

  fun removeBackgroundImage() {
    _currentTemplate.value = _currentTemplate.value?.copy(
      backgroundImageUri = null,
      updatedAt = System.currentTimeMillis(),
    )
    _isDirty.value = true
  }

  fun matchDimensionsToRatio(imageWidth: Int, imageHeight: Int) {
    val template = _currentTemplate.value ?: return
    if (imageWidth <= 0 || imageHeight <= 0) return
    val ratio = imageWidth.toFloat() / imageHeight.toFloat()
    if (ratio >= 1f) {
      val newHeight = (90f / ratio).coerceIn(20f, 300f)
      _currentTemplate.value = template.copy(
        widthMm = 90f,
        heightMm = newHeight,
        orientation = BadgeOrientation.LANDSCAPE,
        updatedAt = System.currentTimeMillis(),
      )
    } else {
      val newWidth = (90f * ratio).coerceIn(20f, 300f)
      _currentTemplate.value = template.copy(
        widthMm = newWidth,
        heightMm = 90f,
        orientation = BadgeOrientation.PORTRAIT,
        updatedAt = System.currentTimeMillis(),
      )
    }
    _isDirty.value = true
  }

  fun saveTemplate() {
    val template = _currentTemplate.value ?: return
    val elements = _currentElements.value

    _isSaving.value = true
    viewModelScope.launch(Dispatchers.IO) {
      badgeRepository.saveTemplate(template, elements)
      withContext(Dispatchers.Main) {
        _isSaving.value = false
        _isDirty.value = false
        _snackbarMessage.emit("✓ تم حفظ القالب بنجاح")
      }
    }
  }

  fun saveAsNewTemplate(newName: String) {
    val current = _currentTemplate.value ?: return
    val elements = _currentElements.value
    viewModelScope.launch(Dispatchers.IO) {
      val newTemplate = current.copy(
        id = 0L,
        name = newName.trim(),
        createdAt = System.currentTimeMillis(),
        updatedAt = System.currentTimeMillis(),
      )
      val newElements = elements.map { it.copy(id = 0L, templateId = 0L) }
      val newId = badgeRepository.saveTemplate(newTemplate, newElements)
      withContext(Dispatchers.Main) {
        _selectedTemplateId.value = newId
        _isDirty.value = false
        _snackbarMessage.emit("✓ تم حفظ القالب كـ '$newName'")
      }
    }
  }

  fun deleteTemplate() {
    val template = _currentTemplate.value ?: return
    val eventId = _selectedEventId.value ?: return
    viewModelScope.launch(Dispatchers.IO) {
      badgeRepository.deleteTemplate(template.id)
      withContext(Dispatchers.Main) {
        _selectedTemplateId.value = null
        _selectedElementId.value = null
        _isDirty.value = false
        _snackbarMessage.emit("Badge template deleted")
        observeCurrentTemplate(eventId, null)
      }
    }
  }

  fun resetToDefault() {
    val eventId = _selectedEventId.value ?: return
    val event = allEvents.value.firstOrNull { it.id == eventId }
    val eventName = event?.name ?: "Event"
    val template = _currentTemplate.value

    val defaultTemplate = (template ?: BadgeTemplateEntity(
      eventId = eventId,
      name = "Badge - $eventName",
      widthMm = 90f,
      heightMm = 60f,
      orientation = BadgeOrientation.LANDSCAPE,
      backgroundColor = "#FFFFFF",
    )).copy(
      widthMm = 90f,
      heightMm = 60f,
      orientation = BadgeOrientation.LANDSCAPE,
      backgroundColor = "#FFFFFF",
    )

    val defaultElements = BadgeTemplateRepositoryImpl.createDefaultElements(
      templateId = defaultTemplate.id,
      eventName = eventName,
    )

    _currentTemplate.value = defaultTemplate
    _currentElements.value = defaultElements
    _selectedElementId.value = null
    _isDirty.value = true
  }

  fun togglePreviewMode() {
    _isPreviewMode.value = !_isPreviewMode.value
  }

  fun selectPreviewGuest(guest: GuestEntity?) {
    _selectedPreviewGuest.value = guest
    if (guest != null) {
      viewModelScope.launch(ioDispatcher) {
        val bitmap = qrCodeGenerator.generateQrBitmap(guest.uuid, 512)
        withContext(Dispatchers.Main) {
          _previewQrBitmap.value = bitmap
        }
      }
    } else {
      _previewQrBitmap.value = null
    }
  }

  fun selectElement(elementId: Long?) {
    _selectedElementId.value = elementId
  }

  // --- Element Position & Size Updates (Normalized 0.0 to 1.0) ---

  fun updateElementPosition(elementId: Long, deltaNormalizedX: Float, deltaNormalizedY: Float) {
    _currentElements.value = _currentElements.value.map { element ->
      if (element.id == elementId) {
        val newX = (element.x + deltaNormalizedX).coerceIn(0f, (1f - element.width).coerceAtLeast(0f))
        val newY = (element.y + deltaNormalizedY).coerceIn(0f, (1f - element.height).coerceAtLeast(0f))
        element.copy(x = newX, y = newY)
      } else {
        element
      }
    }
    _isDirty.value = true
  }

  fun updateQrSize(sizeFraction: Float) {
    val template = _currentTemplate.value ?: return
    val widthMm = template.widthMm
    val heightMm = template.heightMm
    val isLandscape = template.orientation == BadgeOrientation.LANDSCAPE
    val effectiveWidthMm = if (isLandscape) max(widthMm, heightMm) else min(widthMm, heightMm)
    val effectiveHeightMm = if (isLandscape) min(widthMm, heightMm) else max(widthMm, heightMm)
    val whRatio = if (effectiveHeightMm > 0f) effectiveWidthMm / effectiveHeightMm else 1f

    _currentElements.value = _currentElements.value.map { element ->
      if (element.type.isQr) {
        val newWidth = sizeFraction.coerceIn(0.12f, 0.65f)
        val newHeight = (newWidth * whRatio).coerceIn(0.12f, 0.90f)
        val clampedX = element.x.coerceIn(0f, (1f - newWidth).coerceAtLeast(0f))
        val clampedY = element.y.coerceIn(0f, (1f - newHeight).coerceAtLeast(0f))
        element.copy(
          width = newWidth,
          height = newHeight,
          x = clampedX,
          y = clampedY,
        )
      } else {
        element
      }
    }
    _isDirty.value = true
  }

  fun updateElementSize(elementId: Long, deltaNormalizedWidth: Float, deltaNormalizedHeight: Float) {
    _currentElements.value = _currentElements.value.map { element ->
      if (element.id == elementId) {
        val isQr = element.type.isQr
        if (isQr) {
          // Clamping & 1:1 square aspect ratio for QR code to guarantee scanning reliability
          val delta = if (kotlin.math.abs(deltaNormalizedWidth) > kotlin.math.abs(deltaNormalizedHeight)) {
            deltaNormalizedWidth
          } else {
            deltaNormalizedHeight
          }
          val maxAvailable = kotlin.math.min(1f - element.x, 1f - element.y)
          val newSquare = (element.width + delta).coerceIn(0.15f, maxAvailable)
          element.copy(width = newSquare, height = newSquare)
        } else {
          val newWidth = (element.width + deltaNormalizedWidth).coerceIn(0.05f, 1f - element.x)
          val newHeight = (element.height + deltaNormalizedHeight).coerceIn(0.05f, 1f - element.y)
          element.copy(width = newWidth, height = newHeight)
        }
      } else {
        element
      }
    }
    _isDirty.value = true
  }

  fun toggleElementVisibility(type: BadgeElementType) {
    val existing = _currentElements.value.firstOrNull {
      it.type == type || (type.isQr && it.type.isQr)
    }
    if (existing != null) {
      val updatedVisibility = !existing.visible
      _currentElements.value = _currentElements.value.map {
        if (it.id == existing.id) it.copy(visible = updatedVisibility) else it
      }
      if (!updatedVisibility && _selectedElementId.value == existing.id) {
        _selectedElementId.value = null
      }
    } else {
      // Add standard element if not currently in list
      addElement(type)
    }
    _isDirty.value = true
  }

  fun addElement(type: BadgeElementType) {
    val templateId = _currentTemplate.value?.id ?: 0L
    val newElement = when (type) {
      BadgeElementType.ATTENDEE_NAME -> BadgeElementEntity(
        id = temporaryElementIdCounter--,
        templateId = templateId,
        type = type,
        x = 0.1f,
        y = 0.35f,
        width = 0.8f,
        height = 0.18f,
        fontSize = 20f,
        fontWeight = "BOLD",
        alignment = BadgeAlignment.CENTER,
        textColor = "#0F172A",
      )
      BadgeElementType.JOB_TITLE -> BadgeElementEntity(
        id = temporaryElementIdCounter--,
        templateId = templateId,
        type = type,
        x = 0.1f,
        y = 0.54f,
        width = 0.8f,
        height = 0.14f,
        fontSize = 14f,
        fontWeight = "NORMAL",
        alignment = BadgeAlignment.CENTER,
        textColor = "#475569",
      )
      BadgeElementType.ORGANIZATION -> BadgeElementEntity(
        id = temporaryElementIdCounter--,
        templateId = templateId,
        type = type,
        x = 0.1f,
        y = 0.69f,
        width = 0.8f,
        height = 0.14f,
        fontSize = 14f,
        fontWeight = "BOLD",
        alignment = BadgeAlignment.CENTER,
        textColor = "#1E293B",
      )
      BadgeElementType.EVENT_NAME -> BadgeElementEntity(
        id = temporaryElementIdCounter--,
        templateId = templateId,
        type = type,
        x = 0.05f,
        y = 0.06f,
        width = 0.9f,
        height = 0.13f,
        fontSize = 12f,
        fontWeight = "BOLD",
        alignment = BadgeAlignment.CENTER,
        textColor = "#0284C7",
        backgroundColor = "#F0F9FF",
      )
      BadgeElementType.LOGO -> BadgeElementEntity(
        id = temporaryElementIdCounter--,
        templateId = templateId,
        type = type,
        x = 0.08f,
        y = 0.06f,
        width = 0.18f,
        height = 0.22f,
        alignment = BadgeAlignment.CENTER,
        backgroundColor = "#F1F5F9",
      )
      BadgeElementType.QR_PLACEHOLDER,
      BadgeElementType.QR -> BadgeElementEntity(
        id = temporaryElementIdCounter--,
        templateId = templateId,
        type = type,
        x = 0.68f,
        y = 0.46f,
        width = 0.26f,
        height = 0.46f,
        text = "QR — Reserved",
        fontSize = 10f,
        fontWeight = "BOLD",
        alignment = BadgeAlignment.CENTER,
        textColor = "#64748B",
        backgroundColor = "#F8FAFC",
      )
    }

    _currentElements.value = _currentElements.value + newElement
    _selectedElementId.value = newElement.id
    _isDirty.value = true
  }

  fun removeElement(elementId: Long) {
    _currentElements.value = _currentElements.value.filter { it.id != elementId }
    if (_selectedElementId.value == elementId) {
      _selectedElementId.value = null
    }
    _isDirty.value = true
  }

  fun updateElementFontSize(elementId: Long, fontSize: Float) {
    _currentElements.value = _currentElements.value.map {
      if (it.id == elementId) it.copy(fontSize = fontSize) else it
    }
    _isDirty.value = true
  }

  fun updateElementFontWeight(elementId: Long, fontWeight: String) {
    _currentElements.value = _currentElements.value.map {
      if (it.id == elementId) it.copy(fontWeight = fontWeight) else it
    }
    _isDirty.value = true
  }

  fun updateElementAlignment(elementId: Long, alignment: BadgeAlignment) {
    _currentElements.value = _currentElements.value.map {
      if (it.id == elementId) it.copy(alignment = alignment) else it
    }
    _isDirty.value = true
  }

  fun updateElementTextColor(elementId: Long, colorHex: String) {
    _currentElements.value = _currentElements.value.map {
      if (it.id == elementId) it.copy(textColor = colorHex) else it
    }
    _isDirty.value = true
  }

  fun updateElementRotation(elementId: Long, rotation: Float) {
    _currentElements.value = _currentElements.value.map {
      if (it.id == elementId) it.copy(rotation = rotation) else it
    }
    _isDirty.value = true
  }

  fun updateElementLogoUri(uri: String?) {
    // Update logo element text (used to store the selected image URI)
    _currentElements.value = _currentElements.value.map {
      if (it.type == BadgeElementType.LOGO) it.copy(text = uri) else it
    }
    // Also store in template if present
    _currentTemplate.value = _currentTemplate.value?.copy(backgroundImageUri = uri)
    _isDirty.value = true
  }

  fun updateTemplateDimensions(widthMm: Float, heightMm: Float, orientation: BadgeOrientation) {
    _currentTemplate.value = _currentTemplate.value?.copy(
      widthMm = widthMm,
      heightMm = heightMm,
      orientation = orientation,
    )
    _isDirty.value = true
  }

  fun updateTemplateBackgroundColor(colorHex: String) {
    _currentTemplate.value = _currentTemplate.value?.copy(backgroundColor = colorHex)
    _isDirty.value = true
  }

  companion object {
    fun provideFactory(
      badgeRepository: BadgeTemplateRepository,
      eventRepository: EventRepository,
      guestRepository: GuestRepository,
      qrCodeGenerator: QrCodeGenerator = QrCodeGeneratorImpl(),
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return CardDesignerViewModel(badgeRepository, eventRepository, guestRepository, qrCodeGenerator) as T
      }
    }
  }
}
