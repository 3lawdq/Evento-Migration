package com.example.ui.screens.guests.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.importer.ExcelImportPreview
import com.example.data.importer.ExcelImportResult
import com.example.data.importer.ParsedGuestRow
import com.example.ui.screens.guests.ExcelImportDialogState

@Composable
fun ExcelImportDialog(
  importState: ExcelImportDialogState,
  onConfirmImport: (ExcelImportPreview) -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  when (importState) {
    is ExcelImportDialogState.Idle -> {
      // Nothing to render
    }

    is ExcelImportDialogState.Parsing -> {
      AlertDialog(
        onDismissRequest = { /* prevent dismissal during parsing */ },
        icon = {
          CircularProgressIndicator(
            modifier = Modifier
              .size(36.dp)
              .testTag("excel_import_parsing_spinner"),
          )
        },
        title = {
          Text(
            text = stringResource(R.string.excel_import_dialog_title),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          )
        },
        text = {
          Text(
            text = stringResource(R.string.excel_import_status_parsing),
            style = MaterialTheme.typography.bodyMedium,
          )
        },
        confirmButton = {},
        modifier = modifier.testTag("excel_import_parsing_dialog"),
      )
    }

    is ExcelImportDialogState.Importing -> {
      AlertDialog(
        onDismissRequest = { /* prevent dismissal during database transaction */ },
        icon = {
          CircularProgressIndicator(
            modifier = Modifier
              .size(36.dp)
              .testTag("excel_import_importing_spinner"),
          )
        },
        title = {
          Text(
            text = stringResource(R.string.excel_import_dialog_title),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          )
        },
        text = {
          Text(
            text = stringResource(R.string.excel_import_status_importing),
            style = MaterialTheme.typography.bodyMedium,
          )
        },
        confirmButton = {},
        modifier = modifier.testTag("excel_import_importing_dialog"),
      )
    }

    is ExcelImportDialogState.Preview -> {
      val preview = importState.preview
      AlertDialog(
        onDismissRequest = onDismiss,
        title = {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Icon(
              imageVector = Icons.Default.TableChart,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
            )
            Text(
              text = stringResource(R.string.excel_import_preview_title),
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            )
          }
        },
        text = {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            // File metadata info
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = "${stringResource(R.string.excel_import_file_label)} ${preview.fileName}",
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = stringResource(
                    R.string.excel_import_detected_columns,
                    preview.detectedColumns.joinToString(", "),
                  ),
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }

            // Metric Summary Chips (Total, Ready, Invalid, Duplicates)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                StatBadge(
                  label = stringResource(R.string.excel_import_total_rows, preview.totalRows),
                  color = MaterialTheme.colorScheme.secondaryContainer,
                  textColor = MaterialTheme.colorScheme.onSecondaryContainer,
                  icon = Icons.Default.People,
                  modifier = Modifier.weight(1f),
                  testTag = "excel_stat_total",
                )
                StatBadge(
                  label = stringResource(R.string.excel_import_ready_count, preview.willBeImportedCount),
                  color = MaterialTheme.colorScheme.primaryContainer,
                  textColor = MaterialTheme.colorScheme.onPrimaryContainer,
                  icon = Icons.Default.CheckCircle,
                  modifier = Modifier.weight(1f),
                  testTag = "excel_stat_ready",
                )
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                StatBadge(
                  label = stringResource(R.string.excel_import_invalid_count, preview.invalidRows.size),
                  color = MaterialTheme.colorScheme.errorContainer,
                  textColor = MaterialTheme.colorScheme.onErrorContainer,
                  icon = Icons.Default.Error,
                  modifier = Modifier.weight(1f),
                  testTag = "excel_stat_invalid",
                )
                StatBadge(
                  label = stringResource(R.string.excel_import_duplicate_count, preview.duplicateRows.size),
                  color = MaterialTheme.colorScheme.tertiaryContainer,
                  textColor = MaterialTheme.colorScheme.onTertiaryContainer,
                  icon = Icons.Default.Warning,
                  modifier = Modifier.weight(1f),
                  testTag = "excel_stat_duplicate",
                )
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // Sample Preview Rows
            Text(
              text = stringResource(R.string.excel_import_sample_preview_header),
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            )

            val rowsToDisplay = preview.validRows.filter { !it.isDuplicate }.take(5)
            if (rowsToDisplay.isEmpty()) {
              Text(
                text = stringResource(R.string.excel_import_no_valid_rows),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
              )
            } else {
              Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth(),
              ) {
                rowsToDisplay.forEach { row ->
                  PreviewRowItem(row = row)
                }
                if (preview.validRows.size > 5) {
                  Text(
                    text = "+ ${preview.validRows.size - 5} more attendee records...",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 8.dp),
                  )
                }
              }
            }
          }
        },
        confirmButton = {
          Button(
            onClick = { onConfirmImport(preview) },
            enabled = preview.willBeImportedCount > 0,
            modifier = Modifier.testTag("excel_import_btn_confirm"),
          ) {
            Icon(
              imageVector = Icons.Default.FileDownload,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(stringResource(R.string.excel_import_btn_proceed, preview.willBeImportedCount))
          }
        },
        dismissButton = {
          TextButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("excel_import_btn_cancel"),
          ) {
            Text(stringResource(R.string.excel_import_btn_cancel))
          }
        },
        modifier = modifier.testTag("excel_import_preview_dialog"),
      )
    }

    is ExcelImportDialogState.Result -> {
      val result = importState.result
      AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
          Icon(
            imageVector = if (result.importedCount > 0) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (result.importedCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            modifier = Modifier.size(36.dp),
          )
        },
        title = {
          Text(
            text = stringResource(R.string.excel_import_result_title),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          )
        },
        text = {
          Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            if (result.errorMessage != null) {
              Text(
                text = result.errorMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
              )
            } else {
              ResultSummaryRow(
                icon = Icons.Default.CheckCircle,
                label = stringResource(R.string.excel_import_result_imported, result.importedCount),
                color = MaterialTheme.colorScheme.primary,
                testTag = "excel_result_imported_text",
              )
              ResultSummaryRow(
                icon = Icons.Default.Warning,
                label = stringResource(R.string.excel_import_result_skipped, result.skippedCount),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                testTag = "excel_result_skipped_text",
              )
              ResultSummaryRow(
                icon = Icons.Default.Error,
                label = stringResource(R.string.excel_import_result_invalid, result.invalidCount),
                color = MaterialTheme.colorScheme.error,
                testTag = "excel_result_invalid_text",
              )
              ResultSummaryRow(
                icon = Icons.Default.Warning,
                label = stringResource(R.string.excel_import_result_duplicates, result.duplicateCount),
                color = MaterialTheme.colorScheme.tertiary,
                testTag = "excel_result_duplicates_text",
              )
            }
          }
        },
        confirmButton = {
          Button(
            onClick = onDismiss,
            modifier = Modifier.testTag("excel_import_result_btn_close"),
          ) {
            Text(stringResource(R.string.btn_close))
          }
        },
        modifier = modifier.testTag("excel_import_result_dialog"),
      )
    }

    is ExcelImportDialogState.Error -> {
      AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
          Icon(
            imageVector = Icons.Default.Error,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(36.dp),
          )
        },
        title = {
          Text(
            text = stringResource(R.string.excel_import_dialog_title),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          )
        },
        text = {
          Text(
            text = importState.message,
            style = MaterialTheme.typography.bodyMedium,
          )
        },
        confirmButton = {
          Button(
            onClick = onDismiss,
            modifier = Modifier.testTag("excel_import_error_btn_close"),
          ) {
            Text(stringResource(R.string.btn_close))
          }
        },
        modifier = modifier.testTag("excel_import_error_dialog"),
      )
    }
  }
}

@Composable
private fun StatBadge(
  label: String,
  color: Color,
  textColor: Color,
  icon: ImageVector,
  modifier: Modifier = Modifier,
  testTag: String = "",
) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = color,
    modifier = modifier.testTag(testTag),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = textColor,
        modifier = Modifier.size(16.dp),
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
        color = textColor,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun PreviewRowItem(
  row: ParsedGuestRow,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
    modifier = modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = row.fullName,
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        val subtitle = listOfNotNull(
          row.organization.ifBlank { null },
          row.email.ifBlank { null },
        ).joinToString(" • ")

        if (subtitle.isNotBlank()) {
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
      InvitationStatusBadge(status = row.invitationStatus)
    }
  }
}

@Composable
private fun ResultSummaryRow(
  icon: ImageVector,
  label: String,
  color: Color,
  modifier: Modifier = Modifier,
  testTag: String = "",
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .testTag(testTag),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = color,
      modifier = Modifier.size(18.dp),
    )
    Spacer(modifier = Modifier.width(10.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
      color = MaterialTheme.colorScheme.onSurface,
    )
  }
}
