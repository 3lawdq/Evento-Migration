package com.example.ui.screens.events.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.EventEntity

@Composable
fun ArchiveConfirmationDialog(
  event: EventEntity,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Archive,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
      )
    },
    title = {
      Text(
        text = stringResource(R.string.confirm_archive_title),
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column {
        Text(
          text = stringResource(R.string.confirm_archive_message, event.name),
          style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = stringResource(R.string.confirm_archive_detail),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        modifier = Modifier.testTag("confirm_archive_button"),
      ) {
        Text(stringResource(R.string.btn_archive))
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("dismiss_archive_button"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    modifier = modifier.testTag("archive_confirmation_dialog"),
    shape = RoundedCornerShape(20.dp),
  )
}

@Composable
fun DeleteConfirmationDialog(
  event: EventEntity,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Delete,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.error,
      )
    },
    title = {
      Text(
        text = stringResource(R.string.confirm_delete_title),
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column {
        Text(
          text = stringResource(R.string.confirm_delete_message, event.name),
          style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = stringResource(R.string.confirm_delete_detail),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.error,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.error,
          contentColor = MaterialTheme.colorScheme.onError,
        ),
        modifier = Modifier.testTag("confirm_delete_button"),
      ) {
        Text(stringResource(R.string.btn_delete))
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("dismiss_delete_button"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    modifier = modifier.testTag("delete_confirmation_dialog"),
    shape = RoundedCornerShape(20.dp),
  )
}

@Composable
fun DuplicateEventDialog(
  event: EventEntity,
  isDuplicating: Boolean,
  onConfirm: (newName: String, copyGuests: Boolean) -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var newName by remember { mutableStateOf("${event.name} (Copy)") }
  var copyGuests by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = { if (!isDuplicating) onDismiss() },
    icon = {
      Icon(
        imageVector = Icons.Default.ContentCopy,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
      )
    },
    title = {
      Text(
        text = stringResource(R.string.duplicate_event_title),
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column {
        Text(
          text = stringResource(R.string.duplicate_event_desc),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
          value = newName,
          onValueChange = { newName = it },
          label = { Text(stringResource(R.string.duplicate_event_name_label)) },
          modifier = Modifier.fillMaxWidth().testTag("duplicate_name_input"),
          singleLine = true,
          enabled = !isDuplicating,
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Checkbox(
            checked = copyGuests,
            onCheckedChange = { copyGuests = it },
            enabled = !isDuplicating,
            modifier = Modifier.testTag("duplicate_copy_guests_checkbox"),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = stringResource(R.string.duplicate_copy_guests_label),
              style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            )
            Text(
              text = stringResource(R.string.duplicate_copy_guests_desc),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(newName.trim().ifEmpty { "${event.name} (Copy)" }, copyGuests) },
        enabled = !isDuplicating && newName.isNotBlank(),
        modifier = Modifier.testTag("confirm_duplicate_button"),
      ) {
        if (isDuplicating) {
          CircularProgressIndicator(
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp,
            color = MaterialTheme.colorScheme.onPrimary,
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(stringResource(R.string.btn_duplicating))
        } else {
          Text(stringResource(R.string.btn_duplicate))
        }
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        enabled = !isDuplicating,
        modifier = Modifier.testTag("dismiss_duplicate_button"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    modifier = modifier.testTag("duplicate_event_dialog"),
    shape = RoundedCornerShape(20.dp),
  )
}

