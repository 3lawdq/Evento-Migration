package com.example.ui.screens.events

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.EventStatus
import com.example.ui.components.EventoEmptyState
import com.example.ui.components.EventoTopAppBar
import com.example.ui.screens.events.components.ArchiveConfirmationDialog
import com.example.ui.screens.events.components.DeleteConfirmationDialog
import com.example.ui.screens.events.components.DuplicateEventDialog
import com.example.ui.screens.events.components.EventDetailsDialog
import com.example.ui.screens.events.components.EventFormDialog
import com.example.ui.screens.events.components.EventItemCard

@Composable
fun EventsScreen(
  viewModel: EventsViewModel,
  onOpenMenu: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val formState by viewModel.formState.collectAsStateWithLifecycle()
  val viewingEvent by viewModel.viewingEvent.collectAsStateWithLifecycle()
  val pendingArchive by viewModel.pendingArchiveEvent.collectAsStateWithLifecycle()
  val pendingDelete by viewModel.pendingDeleteEvent.collectAsStateWithLifecycle()
  val pendingDuplicate by viewModel.pendingDuplicateEvent.collectAsStateWithLifecycle()
  val isDuplicating by viewModel.isDuplicating.collectAsStateWithLifecycle()
  val operationMessage by viewModel.operationMessage.collectAsStateWithLifecycle()
  val selectedFilter by viewModel.statusFilter.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }

  androidx.compose.runtime.LaunchedEffect(operationMessage) {
    operationMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearOperationMessage()
    }
  }

  Scaffold(
    topBar = {
      EventoTopAppBar(
        title = stringResource(R.string.events_title),
        onNavigationClick = onOpenMenu,
        actions = {
          if (uiState is EventsUiState.Success) {
            val count = (uiState as EventsUiState.Success).totalCount
            Surface(
              shape = MaterialTheme.shapes.small,
              color = MaterialTheme.colorScheme.primaryContainer,
              modifier = Modifier.padding(end = 12.dp),
            ) {
              Text(
                text = "$count",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }
        },
      )
    },
    floatingActionButton = {
      ExtendedFloatingActionButton(
        onClick = { viewModel.openCreateForm() },
        icon = { Icon(Icons.Default.Add, contentDescription = null) },
        text = { Text(stringResource(R.string.btn_add_event)) },
        modifier = Modifier.testTag("events_fab"),
      )
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    modifier = modifier.fillMaxSize().testTag("events_screen"),
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      when (val state = uiState) {
        is EventsUiState.Loading -> {
          Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
          ) {
            CircularProgressIndicator(modifier = Modifier.testTag("events_loading_indicator"))
          }
        }

        is EventsUiState.Error -> {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(16.dp),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = state.message,
              style = MaterialTheme.typography.bodyLarge,
              color = MaterialTheme.colorScheme.error,
            )
          }
        }

        is EventsUiState.Success -> {
          if (state.events.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
              contentAlignment = Alignment.Center,
            ) {
              EventoEmptyState(
                icon = Icons.Default.Event,
                title = stringResource(R.string.events_empty_title),
                description = stringResource(R.string.events_empty_desc),
                badgeText = stringResource(R.string.badge_ready),
                actionLabel = stringResource(R.string.btn_add_event),
                onActionClick = { viewModel.openCreateForm() },
                testTag = "events_empty_state",
              )
            }
          } else {
            Column(modifier = Modifier.fillMaxSize()) {
              // Status filter tabs / chips
              LazyRow(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                item {
                  FilterChip(
                    selected = selectedFilter == null,
                    onClick = { viewModel.setFilter(null) },
                    label = { Text("${stringResource(R.string.filter_all)} (${state.totalCount})") },
                    modifier = Modifier.testTag("filter_all_chip"),
                  )
                }

                item {
                  FilterChip(
                    selected = selectedFilter == EventStatus.ACTIVE,
                    onClick = { viewModel.setFilter(EventStatus.ACTIVE) },
                    label = { Text("${stringResource(R.string.status_active)} (${state.activeCount})") },
                    modifier = Modifier.testTag("filter_active_chip"),
                  )
                }

                item {
                  FilterChip(
                    selected = selectedFilter == EventStatus.DRAFT,
                    onClick = { viewModel.setFilter(EventStatus.DRAFT) },
                    label = { Text("${stringResource(R.string.status_draft)} (${state.draftCount})") },
                    modifier = Modifier.testTag("filter_draft_chip"),
                  )
                }

                item {
                  FilterChip(
                    selected = selectedFilter == EventStatus.ARCHIVED,
                    onClick = { viewModel.setFilter(EventStatus.ARCHIVED) },
                    label = { Text("${stringResource(R.string.status_archived)} (${state.archivedCount})") },
                    modifier = Modifier.testTag("filter_archived_chip"),
                  )
                }
              }

              if (state.filteredEvents.isEmpty()) {
                Box(
                  modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                  contentAlignment = Alignment.Center,
                ) {
                  Text(
                    text = stringResource(R.string.events_empty_title),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
              } else {
                LazyColumn(
                  modifier = Modifier
                    .fillMaxSize()
                    .testTag("events_list"),
                  contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                  verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  items(
                    items = state.filteredEvents,
                    key = { it.id },
                  ) { event ->
                    EventItemCard(
                      event = event,
                      onClick = { viewModel.openDetails(event) },
                      onEdit = { viewModel.openEditForm(event) },
                      onArchive = { viewModel.requestArchiveConfirmation(event) },
                      onRestore = { viewModel.setEventActive(event) },
                      onDelete = { viewModel.requestDeleteConfirmation(event) },
                      onDuplicate = { viewModel.requestDuplicate(event) },
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // Add / Edit Event Dialog
  formState?.let { form ->
    val slotFormat = stringResource(R.string.guest_placeholder_name_format)
    EventFormDialog(
      formState = form,
      onNameChange = { viewModel.updateFormName(it) },
      onDescriptionChange = { viewModel.updateFormDescription(it) },
      onDateChange = { viewModel.updateFormDate(it) },
      onLocationChange = { viewModel.updateFormLocation(it) },
      onOrganizerChange = { viewModel.updateFormOrganizer(it) },
      onStatusChange = { viewModel.updateFormStatus(it) },
      onGuestCapacityChange = { viewModel.updateFormGuestCapacity(it) },
      onAutoCreateSlotsChange = { viewModel.updateFormAutoCreateSlots(it) },
      onSave = { viewModel.saveForm(slotFormat) },
      onDismiss = { viewModel.closeForm() },
    )
  }

  // Event Details Dialog
  viewingEvent?.let { event ->
    EventDetailsDialog(
      event = event,
      onDismiss = { viewModel.closeDetails() },
      onEdit = {
        viewModel.closeDetails()
        viewModel.openEditForm(event)
      },
      onArchive = { viewModel.requestArchiveConfirmation(event) },
      onRestore = { viewModel.setEventActive(event) },
      onDelete = { viewModel.requestDeleteConfirmation(event) },
    )
  }

  // Confirmation: Archive
  pendingArchive?.let { event ->
    ArchiveConfirmationDialog(
      event = event,
      onConfirm = { viewModel.confirmArchive() },
      onDismiss = { viewModel.dismissArchiveConfirmation() },
    )
  }

  // Confirmation: Delete
  pendingDelete?.let { event ->
    DeleteConfirmationDialog(
      event = event,
      onConfirm = { viewModel.confirmDelete() },
      onDismiss = { viewModel.dismissDeleteConfirmation() },
    )
  }

  // Duplicate Event Dialog
  pendingDuplicate?.let { event ->
    DuplicateEventDialog(
      event = event,
      isDuplicating = isDuplicating,
      onConfirm = { newName, copyGuests ->
        viewModel.confirmDuplicate(newName, copyGuests)
      },
      onDismiss = { viewModel.dismissDuplicate() },
    )
  }
}
