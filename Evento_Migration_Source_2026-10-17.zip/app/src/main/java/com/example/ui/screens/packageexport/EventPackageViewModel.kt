package com.example.ui.screens.packageexport

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.InvitationStatus
import com.example.data.repository.EventPackageRepository
import com.example.data.repository.EventRepository
import com.example.data.repository.GuestRepository
import com.example.util.packageexport.EventPackageExportRequest
import com.example.util.packageexport.EventPackageExportResult
import com.example.util.packageexport.PackageGuestScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

import com.evento.checkin.domain.model.LicenseStatus
import com.example.util.packageexport.EventoPackageLicense
import java.util.UUID

data class LicenseConfigUiState(
  val isLicenseEnabled: Boolean = false,
  val licenseId: String = "",
  val issuedAt: Long = 0L,
  val expiresAt: Long = 0L,
  val maxGuestsInput: String = "",
  val allowedDeviceCountInput: String = "1",
  val isDeviceBindingEnabled: Boolean = false,
  val boundDeviceId: String = "",
  val licenseStatus: LicenseStatus = LicenseStatus.ACTIVE,
  val licenseFormatVersion: Int = 1,
  val durationDays: Int = 30,
)

data class EventPackageUiState(
  val events: List<EventEntity> = emptyList(),
  val selectedEvent: EventEntity? = null,
  val allGuests: List<GuestEntity> = emptyList(),
  val selectedGuestIds: Set<Long> = emptySet(),
  val guestScope: PackageGuestScope = PackageGuestScope.ALL,
  val searchQuery: String = "",
  val isExporting: Boolean = false,
  val exportResult: EventPackageExportResult? = null,
  val validationError: String? = null,
  val isLoadingData: Boolean = true,
  val licenseConfig: LicenseConfigUiState = LicenseConfigUiState(),
) {
  val confirmedGuests: List<GuestEntity>
    get() = allGuests.filter { it.invitationStatus == InvitationStatus.CONFIRMED }

  val effectiveGuestsToExport: List<GuestEntity>
    get() = when (guestScope) {
      PackageGuestScope.ALL -> allGuests
      PackageGuestScope.CONFIRMED -> confirmedGuests
      PackageGuestScope.CUSTOM -> allGuests.filter { selectedGuestIds.contains(it.id) }
    }

  val filteredGuestsForList: List<GuestEntity>
    get() {
      if (searchQuery.isBlank()) return allGuests
      return allGuests.filter {
        it.fullName.contains(searchQuery, ignoreCase = true) ||
          it.organization.contains(searchQuery, ignoreCase = true) ||
          it.jobTitle.contains(searchQuery, ignoreCase = true)
      }
    }
}

class EventPackageViewModel(
  private val eventRepository: EventRepository,
  private val guestRepository: GuestRepository,
  private val packageRepository: EventPackageRepository,
) : ViewModel() {

  private val _uiState = MutableStateFlow(EventPackageUiState())
  val uiState: StateFlow<EventPackageUiState> = _uiState.asStateFlow()

  private var guestJob: Job? = null

  init {
    loadEvents()
  }

  private fun loadEvents() {
    viewModelScope.launch {
      eventRepository.getAllEvents().collect { events ->
        _uiState.update { current ->
          val selected = current.selectedEvent?.let { prev ->
            events.firstOrNull { it.id == prev.id }
          } ?: events.firstOrNull()

          current.copy(
            events = events,
            selectedEvent = selected,
            isLoadingData = false,
          )
        }

        val selected = _uiState.value.selectedEvent
        if (selected != null) {
          observeGuestsForEvent(selected.id)
        }
      }
    }
  }

  fun selectEvent(event: EventEntity) {
    if (_uiState.value.selectedEvent?.id == event.id) return
    _uiState.update {
      it.copy(
        selectedEvent = event,
        selectedGuestIds = emptySet(),
        exportResult = null,
        validationError = null,
      )
    }
    observeGuestsForEvent(event.id)
  }

  private fun observeGuestsForEvent(eventId: Long) {
    guestJob?.cancel()
    guestJob = viewModelScope.launch {
      guestRepository.getGuestsForEvent(eventId).collect { guests ->
        _uiState.update { current ->
          current.copy(
            allGuests = guests,
            selectedGuestIds = if (current.guestScope == PackageGuestScope.CUSTOM) {
              current.selectedGuestIds.intersect(guests.map { g -> g.id }.toSet())
            } else {
              emptySet()
            },
          )
        }
      }
    }
  }

  fun setGuestScope(scope: PackageGuestScope) {
    _uiState.update { current ->
      val initialSelection = if (scope == PackageGuestScope.CUSTOM && current.selectedGuestIds.isEmpty()) {
        current.allGuests.map { it.id }.toSet()
      } else {
        current.selectedGuestIds
      }
      current.copy(
        guestScope = scope,
        selectedGuestIds = initialSelection,
        validationError = null,
      )
    }
  }

  fun toggleGuestSelection(guestId: Long) {
    _uiState.update { current ->
      val newSelection = if (current.selectedGuestIds.contains(guestId)) {
        current.selectedGuestIds - guestId
      } else {
        current.selectedGuestIds + guestId
      }
      current.copy(selectedGuestIds = newSelection)
    }
  }

  fun selectAllGuests() {
    _uiState.update { current ->
      current.copy(selectedGuestIds = current.allGuests.map { it.id }.toSet())
    }
  }

  fun deselectAllGuests() {
    _uiState.update { current ->
      current.copy(selectedGuestIds = emptySet())
    }
  }

  fun updateSearchQuery(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun clearExportResult() {
    _uiState.update { it.copy(exportResult = null, validationError = null) }
  }

  fun setLicenseEnabled(enabled: Boolean) {
    _uiState.update { current ->
      if (!enabled) {
        current.copy(
          licenseConfig = current.licenseConfig.copy(isLicenseEnabled = false),
          validationError = null,
        )
      } else {
        val now = System.currentTimeMillis()
        val durationDays = if (current.licenseConfig.durationDays > 0) current.licenseConfig.durationDays else 30
        val issuedAt = if (current.licenseConfig.issuedAt > 0L) current.licenseConfig.issuedAt else now
        val expiresAt = if (current.licenseConfig.expiresAt > issuedAt) {
          current.licenseConfig.expiresAt
        } else {
          issuedAt + durationDays * 24L * 60L * 60L * 1000L
        }
        val licenseId = current.licenseConfig.licenseId.ifBlank { UUID.randomUUID().toString() }
        val maxGuests = current.licenseConfig.maxGuestsInput.ifBlank {
          maxOf(current.effectiveGuestsToExport.size, 1).toString()
        }
        val deviceCount = current.licenseConfig.allowedDeviceCountInput.ifBlank { "1" }

        current.copy(
          licenseConfig = current.licenseConfig.copy(
            isLicenseEnabled = true,
            licenseId = licenseId,
            issuedAt = issuedAt,
            expiresAt = expiresAt,
            maxGuestsInput = maxGuests,
            allowedDeviceCountInput = deviceCount,
          ),
          validationError = null,
        )
      }
    }
  }

  fun regenerateLicenseId() {
    _uiState.update { current ->
      current.copy(
        licenseConfig = current.licenseConfig.copy(licenseId = UUID.randomUUID().toString())
      )
    }
  }

  fun setMaxGuestsInput(input: String) {
    _uiState.update { current ->
      current.copy(
        licenseConfig = current.licenseConfig.copy(maxGuestsInput = input),
        validationError = null,
      )
    }
  }

  fun setAllowedDeviceCountInput(input: String) {
    _uiState.update { current ->
      current.copy(
        licenseConfig = current.licenseConfig.copy(allowedDeviceCountInput = input),
        validationError = null,
      )
    }
  }

  fun setDeviceBindingEnabled(enabled: Boolean) {
    _uiState.update { current ->
      current.copy(
        licenseConfig = current.licenseConfig.copy(isDeviceBindingEnabled = enabled),
        validationError = null,
      )
    }
  }

  fun setBoundDeviceId(deviceId: String) {
    _uiState.update { current ->
      current.copy(
        licenseConfig = current.licenseConfig.copy(boundDeviceId = deviceId),
        validationError = null,
      )
    }
  }

  fun setDurationDays(days: Int) {
    _uiState.update { current ->
      val issuedAt = if (current.licenseConfig.issuedAt > 0L) current.licenseConfig.issuedAt else System.currentTimeMillis()
      val expiresAt = issuedAt + days * 24L * 60L * 60L * 1000L
      current.copy(
        licenseConfig = current.licenseConfig.copy(
          durationDays = days,
          issuedAt = issuedAt,
          expiresAt = expiresAt,
        ),
        validationError = null,
      )
    }
  }

  fun setCustomExpiration(expiresAtMs: Long) {
    _uiState.update { current ->
      current.copy(
        licenseConfig = current.licenseConfig.copy(expiresAt = expiresAtMs),
        validationError = null,
      )
    }
  }

  fun exportPackage() {
    val state = _uiState.value
    val event = state.selectedEvent ?: run {
      _uiState.update { it.copy(validationError = "Please select an event.") }
      return
    }

    val guestsToExport = state.effectiveGuestsToExport
    if (guestsToExport.isEmpty()) {
      _uiState.update { it.copy(validationError = "No guests selected to export.") }
      return
    }

    val packageLicense: EventoPackageLicense? = if (state.licenseConfig.isLicenseEnabled) {
      val licConfig = state.licenseConfig
      if (licConfig.licenseId.isBlank()) {
        _uiState.update { it.copy(validationError = "License identifier cannot be blank.") }
        return
      }

      val idPattern = Regex("^[a-zA-Z0-9_\\-\\.:]+$")
      if (!licConfig.licenseId.trim().matches(idPattern)) {
        _uiState.update { it.copy(validationError = "License identifier contains invalid characters.") }
        return
      }

      if (licConfig.issuedAt <= 0L) {
        _uiState.update { it.copy(validationError = "License issue timestamp must be positive.") }
        return
      }

      if (licConfig.expiresAt <= licConfig.issuedAt) {
        _uiState.update { it.copy(validationError = "Invalid expiration: expiration date must be after issue date.") }
        return
      }

      val maxGuests = licConfig.maxGuestsInput.trim().toIntOrNull()
      if (maxGuests == null || maxGuests <= 0) {
        _uiState.update { it.copy(validationError = "Invalid maximum guests: must be a positive number.") }
        return
      }

      if (maxGuests < guestsToExport.size) {
        _uiState.update {
          it.copy(validationError = "Maximum guests ($maxGuests) cannot be below package guest count (${guestsToExport.size}).")
        }
        return
      }

      val allowedDevices = licConfig.allowedDeviceCountInput.trim().toIntOrNull()
      if (allowedDevices == null || allowedDevices <= 0) {
        _uiState.update { it.copy(validationError = "Invalid allowed device count: must be a positive integer.") }
        return
      }

      val boundId = if (licConfig.isDeviceBindingEnabled) {
        val trimmed = licConfig.boundDeviceId.trim()
        if (trimmed.isBlank()) {
          _uiState.update { it.copy(validationError = "Invalid device ID: bound device identifier cannot be blank when device binding is enabled.") }
          return
        }
        trimmed
      } else {
        null
      }

      EventoPackageLicense(
        licenseId = licConfig.licenseId.trim(),
        eventId = event.id,
        issuedAt = licConfig.issuedAt,
        expiresAt = licConfig.expiresAt,
        maxGuests = maxGuests,
        allowedDeviceCount = allowedDevices,
        boundDeviceId = boundId,
        licenseFormatVersion = licConfig.licenseFormatVersion,
      )
    } else {
      null
    }

    _uiState.update {
      it.copy(
        isExporting = true,
        validationError = null,
        exportResult = null,
      )
    }

    viewModelScope.launch {
      val request = EventPackageExportRequest(
        event = event,
        guests = guestsToExport,
        scope = state.guestScope,
        license = packageLicense,
      )

      val result = packageRepository.exportEventPackage(request)

      _uiState.update {
        it.copy(
          isExporting = false,
          exportResult = result,
          validationError = if (result is EventPackageExportResult.Error) result.message else null,
        )
      }
    }
  }

  companion object {
    fun provideFactory(
      eventRepository: EventRepository,
      guestRepository: GuestRepository,
      packageRepository: EventPackageRepository,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return EventPackageViewModel(
          eventRepository = eventRepository,
          guestRepository = guestRepository,
          packageRepository = packageRepository,
        ) as T
      }
    }
  }
}
