package com.example.ui.screens.guests

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.entity.EventEntity
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.ui.components.ArchivedEventBanner
import com.example.ui.components.EventoEmptyState
import com.example.ui.components.EventoTopAppBar
import com.example.ui.screens.guests.components.BulkActionBar
import com.example.ui.screens.guests.components.BulkDeleteConfirmDialog
import com.example.ui.screens.guests.components.BulkStatusDialog
import com.example.ui.screens.guests.components.BulkTextUpdateDialog
import com.example.ui.screens.guests.components.ExcelImportDialog
import com.example.ui.screens.guests.components.GuestDeleteConfirmationDialog
import com.example.ui.screens.guests.components.GuestDetailsDialog
import com.example.ui.screens.guests.components.GuestFormDialog
import com.example.ui.screens.guests.components.GuestItemCard
import com.example.ui.screens.guests.components.QualityAndSortRow
import com.example.ui.screens.guests.components.QualitySummaryHeader
import com.example.util.excel.ExcelGuestExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuestsScreen(
  viewModel: GuestsViewModel,
  onOpenMenu: () -> Unit,
  onNavigateToEvents: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val isFormOpen by viewModel.isFormOpen.collectAsStateWithLifecycle()
  val formState by viewModel.formState.collectAsStateWithLifecycle()
  val detailsGuest by viewModel.detailsGuest.collectAsStateWithLifecycle()
  val guestToDelete by viewModel.guestToDelete.collectAsStateWithLifecycle()
  val excelImportState by viewModel.excelImportState.collectAsStateWithLifecycle()
  val showBulkStatusDialog by viewModel.showBulkStatusDialog.collectAsStateWithLifecycle()
  val showBulkOrgDialog by viewModel.showBulkOrgDialog.collectAsStateWithLifecycle()
  val showBulkTitleDialog by viewModel.showBulkTitleDialog.collectAsStateWithLifecycle()
  val showBulkDeleteDialog by viewModel.showBulkDeleteDialog.collectAsStateWithLifecycle()
  val operationFeedback by viewModel.operationFeedback.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }
  val coroutineScope = rememberCoroutineScope()

  LaunchedEffect(operationFeedback) {
    operationFeedback?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearOperationFeedback()
    }
  }

  // Open Document contract for .xlsx selection
  val excelPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument(),
  ) { uri: Uri? ->
    if (uri != null) {
      try {
        var fileName = "guests.xlsx"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
          val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
          if (nameIndex != -1 && cursor.moveToFirst()) {
            fileName = cursor.getString(nameIndex) ?: fileName
          }
        }
        val stream = context.contentResolver.openInputStream(uri)
        if (stream != null) {
          viewModel.processExcelInputStream(stream, fileName)
        }
      } catch (e: Exception) {
        // Handled gracefully without crash
      }
    }
  }

  Scaffold(
    topBar = {
      EventoTopAppBar(
        title = stringResource(R.string.guests_title),
        onNavigationClick = onOpenMenu,
        actions = {
          if (uiState is GuestsUiState.Success) {
            val success = uiState as GuestsUiState.Success
            val isArchived = success.selectedEvent?.status == EventStatus.ARCHIVED
            if (success.selectedEvent != null) {
              if (!isArchived) {
                OutlinedButton(
                  onClick = {
                    excelPickerLauncher.launch(
                      arrayOf(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/octet-stream",
                        "*/*",
                      )
                    )
                  },
                  modifier = Modifier
                    .padding(end = 8.dp)
                    .testTag("guests_btn_import_excel"),
                ) {
                  Icon(
                    imageVector = Icons.Default.TableChart,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = stringResource(R.string.guests_action_import_excel),
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  )
                }
              }

              // Export Excel Button
              OutlinedButton(
                onClick = {
                  if (success.guests.isEmpty()) {
                    coroutineScope.launch {
                      snackbarHostState.showSnackbar(context.getString(R.string.guests_export_excel_empty))
                    }
                  } else {
                    coroutineScope.launch(Dispatchers.IO) {
                      try {
                        val file = ExcelGuestExporter.exportGuestsToXlsx(
                          context = context,
                          eventName = success.selectedEvent.name,
                          guests = success.guests,
                        )
                        withContext(Dispatchers.Main) {
                          val shared = ExcelGuestExporter.shareExcelFile(context, file)
                          if (shared) {
                            snackbarHostState.showSnackbar(context.getString(R.string.guests_export_excel_success))
                          } else {
                            snackbarHostState.showSnackbar(context.getString(R.string.guests_export_excel_error))
                          }
                        }
                      } catch (_: Exception) {
                        withContext(Dispatchers.Main) {
                          snackbarHostState.showSnackbar(context.getString(R.string.guests_export_excel_error))
                        }
                      }
                    }
                  }
                },
                modifier = Modifier
                  .padding(end = 8.dp)
                  .testTag("guests_btn_export_excel"),
              ) {
                Icon(
                  imageVector = Icons.Default.FileDownload,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = stringResource(R.string.guests_action_export_excel),
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                )
              }

              Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier
                  .padding(end = 12.dp)
                  .testTag("guests_header_count_badge"),
              ) {
                Text(
                  text = stringResource(R.string.guests_total_count, success.totalGuestsInEvent),
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                )
              }
            }
          }
        },
      )
    },
    floatingActionButton = {
      if (uiState is GuestsUiState.Success) {
        val success = uiState as GuestsUiState.Success
        val isArchived = success.selectedEvent?.status == EventStatus.ARCHIVED
        if (success.selectedEvent != null && !isArchived) {
          ExtendedFloatingActionButton(
            onClick = { viewModel.openCreateForm() },
            icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
            text = { Text(stringResource(R.string.guests_action_add)) },
            modifier = Modifier.testTag("guests_fab"),
          )
        }
      }
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    modifier = modifier.fillMaxSize().testTag("guests_screen"),
  ) { innerPadding ->
    when (val state = uiState) {
      is GuestsUiState.Loading -> {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
          contentAlignment = Alignment.Center,
        ) {
          CircularProgressIndicator(modifier = Modifier.testTag("guests_loading_indicator"))
        }
      }

      is GuestsUiState.Success -> {
        if (state.events.isEmpty()) {
          // No events exist yet
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
              .padding(16.dp),
            contentAlignment = Alignment.Center,
          ) {
            EventoEmptyState(
              icon = Icons.Default.Event,
              title = stringResource(R.string.guests_no_events_title),
              description = stringResource(R.string.guests_no_events_desc),
              badgeText = stringResource(R.string.badge_ready),
              actionLabel = stringResource(R.string.btn_add_event),
              onActionClick = onNavigateToEvents,
              testTag = "guests_no_events_empty_state",
            )
          }
        } else {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding),
          ) {
            val isArchived = state.selectedEvent?.status == EventStatus.ARCHIVED

            if (isArchived) {
              ArchivedEventBanner(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 6.dp),
              )
            }

            // 1. Event Selector Dropdown / Card
            EventSelectorSection(
              events = state.events,
              selectedEvent = state.selectedEvent,
              onSelectEvent = { viewModel.selectEvent(it.id) },
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            )

            // 2. Search Box
            OutlinedTextField(
              value = state.searchQuery,
              onValueChange = { viewModel.updateSearchQuery(it) },
              placeholder = { Text(stringResource(R.string.guests_search_placeholder)) },
              leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
              trailingIcon = {
                if (state.searchQuery.isNotBlank()) {
                  IconButton(
                    onClick = { viewModel.updateSearchQuery("") },
                    modifier = Modifier.testTag("guests_clear_search_btn"),
                  ) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                  }
                }
              },
              singleLine = true,
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .testTag("guests_search_field"),
            )

            // 3. Filter Chips Row (All, Invited, Confirmed, Declined, Checked In)
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              FilterChip(
                selected = state.selectedStatusFilter == null,
                onClick = { viewModel.setStatusFilter(null) },
                label = { Text(stringResource(R.string.guest_status_all)) },
                modifier = Modifier.testTag("guest_filter_all"),
              )

              listOf(
                InvitationStatus.INVITED to R.string.guest_status_invited,
                InvitationStatus.CONFIRMED to R.string.guest_status_confirmed,
                InvitationStatus.DECLINED to R.string.guest_status_declined,
                InvitationStatus.CHECKED_IN to R.string.guest_status_checked_in,
              ).forEach { (status, labelRes) ->
                FilterChip(
                  selected = state.selectedStatusFilter == status,
                  onClick = {
                    if (state.selectedStatusFilter == status) {
                      viewModel.setStatusFilter(null)
                    } else {
                      viewModel.setStatusFilter(status)
                    }
                  },
                  label = { Text(stringResource(labelRes)) },
                  modifier = Modifier.testTag("guest_filter_${status.name}"),
                )
              }
            }

            // Quality & Sort Row
            QualityAndSortRow(
              selectedQualityFilter = state.selectedQualityFilter,
              selectedSortOption = state.selectedSortOption,
              summary = state.qualitySummary,
              onQualityFilterChange = { viewModel.setQualityFilter(it) },
              onSortOptionChange = { viewModel.setSortOption(it) },
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )

            // Quality Summary Bar
            QualitySummaryHeader(
              summary = state.qualitySummary,
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )

            // Bulk Action Bar (Visible when 1+ guests selected and event is not archived)
            if (state.selectedGuestIds.isNotEmpty() && !isArchived) {
              BulkActionBar(
                selectedCount = state.selectedGuestIds.size,
                totalVisible = state.guests.size,
                onSelectAll = { viewModel.selectAll(state.guests) },
                onClearSelection = { viewModel.clearSelection() },
                onUpdateStatus = { viewModel.openBulkStatusDialog() },
                onUpdateOrg = { viewModel.openBulkOrgDialog() },
                onUpdateTitle = { viewModel.openBulkTitleDialog() },
                onDeleteSelected = { viewModel.openBulkDeleteDialog() },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
              )
            }

            // Results count banner
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = stringResource(
                  R.string.guests_filtered_count,
                  state.guests.size,
                  state.totalGuestsInEvent,
                ),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.testTag("guests_filtered_count_text"),
              )
            }

            // 4. Guest List or Empty State
            if (state.guests.isEmpty()) {
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .padding(16.dp),
                contentAlignment = Alignment.Center,
              ) {
                if (state.searchQuery.isNotBlank() || state.selectedStatusFilter != null) {
                  EventoEmptyState(
                    icon = Icons.Default.Search,
                    title = stringResource(R.string.guests_empty_search_title),
                    description = stringResource(R.string.guests_empty_search_desc),
                    badgeText = stringResource(R.string.badge_ready),
                    actionLabel = null,
                    testTag = "guests_search_empty_state",
                  )
                } else {
                  EventoEmptyState(
                    icon = Icons.Default.People,
                    title = stringResource(R.string.guests_empty_title),
                    description = stringResource(R.string.guests_empty_desc),
                    badgeText = stringResource(R.string.badge_ready),
                    actionLabel = if (!isArchived) stringResource(R.string.guests_action_add) else null,
                    onActionClick = { if (!isArchived) viewModel.openCreateForm() },
                    testTag = "guests_list_empty_state",
                  )
                }
              }
            } else {
              LazyColumn(
                modifier = Modifier
                  .fillMaxSize()
                  .testTag("guests_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                items(state.guests, key = { it.id }) { guest ->
                  GuestItemCard(
                    guest = guest,
                    onCardClick = { viewModel.openDetails(guest) },
                    onEditClick = { viewModel.openEditForm(guest) },
                    onDeleteClick = { viewModel.confirmDelete(guest) },
                    isSelected = state.selectedGuestIds.contains(guest.id),
                    onToggleSelect = { viewModel.toggleSelectGuest(guest.id) },
                    isReadOnly = isArchived,
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  // Add / Edit Dialog
  if (isFormOpen) {
    GuestFormDialog(
      formData = formState,
      onFormFieldChange = { name, email, phone, org, title, status, notes ->
        viewModel.updateFormField(
          fullName = name,
          email = email,
          phone = phone,
          organization = org,
          jobTitle = title,
          invitationStatus = status,
          notes = notes,
        )
      },
      onDismiss = { viewModel.closeForm() },
      onSave = { viewModel.saveGuest() },
    )
  }

  // Details Dialog
  detailsGuest?.let { guest ->
    val isArchived = (uiState as? GuestsUiState.Success)?.selectedEvent?.status == EventStatus.ARCHIVED
    GuestDetailsDialog(
      guest = guest,
      onDismiss = { viewModel.closeDetails() },
      onEdit = {
        viewModel.closeDetails()
        viewModel.openEditForm(guest)
      },
      onDelete = {
        viewModel.closeDetails()
        viewModel.confirmDelete(guest)
      },
      isReadOnly = isArchived,
    )
  }

  // Delete Confirmation Dialog
  guestToDelete?.let { guest ->
    GuestDeleteConfirmationDialog(
      guest = guest,
      onDismiss = { viewModel.dismissDeleteDialog() },
      onConfirmDelete = { viewModel.executeDelete() },
    )
  }

  // Excel Import Dialog Flow (Parsing, Preview, Importing, Result, Error)
  ExcelImportDialog(
    importState = excelImportState,
    onConfirmImport = { preview -> viewModel.confirmImport(preview) },
    onDismiss = { viewModel.dismissExcelImport() },
  )

  // Bulk Status Dialog
  if (showBulkStatusDialog) {
    val selectedCount = (uiState as? GuestsUiState.Success)?.selectedGuestIds?.size ?: 0
    BulkStatusDialog(
      selectedCount = selectedCount,
      onConfirm = { viewModel.bulkUpdateStatus(it) },
      onDismiss = { viewModel.closeBulkStatusDialog() },
    )
  }

  // Bulk Org Dialog
  if (showBulkOrgDialog) {
    val selectedCount = (uiState as? GuestsUiState.Success)?.selectedGuestIds?.size ?: 0
    BulkTextUpdateDialog(
      title = stringResource(R.string.bulk_org_dialog_title, selectedCount),
      label = stringResource(R.string.label_guest_organization),
      testTagPrefix = "bulk_org",
      onConfirm = { viewModel.bulkUpdateOrganization(it) },
      onDismiss = { viewModel.closeBulkOrgDialog() },
    )
  }

  // Bulk Title Dialog
  if (showBulkTitleDialog) {
    val selectedCount = (uiState as? GuestsUiState.Success)?.selectedGuestIds?.size ?: 0
    BulkTextUpdateDialog(
      title = stringResource(R.string.bulk_title_dialog_title, selectedCount),
      label = stringResource(R.string.label_guest_job_title),
      testTagPrefix = "bulk_title",
      onConfirm = { viewModel.bulkUpdateJobTitle(it) },
      onDismiss = { viewModel.closeBulkTitleDialog() },
    )
  }

  // Bulk Delete Dialog
  if (showBulkDeleteDialog) {
    val selectedCount = (uiState as? GuestsUiState.Success)?.selectedGuestIds?.size ?: 0
    BulkDeleteConfirmDialog(
      selectedCount = selectedCount,
      onConfirm = { viewModel.bulkDelete() },
      onDismiss = { viewModel.closeBulkDeleteDialog() },
    )
  }
}

@Composable
private fun EventSelectorSection(
  events: List<EventEntity>,
  selectedEvent: EventEntity?,
  onSelectEvent: (EventEntity) -> Unit,
  modifier: Modifier = Modifier,
) {
  var menuExpanded by remember { mutableStateOf(false) }

  OutlinedCard(
    shape = RoundedCornerShape(14.dp),
    modifier = modifier.testTag("guests_event_selector_card"),
    onClick = { menuExpanded = true },
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f),
      ) {
        Icon(
          imageVector = Icons.Default.Event,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = stringResource(R.string.guests_select_event),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Text(
            text = selectedEvent?.name ?: "—",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      Box {
        Icon(
          imageVector = Icons.Default.KeyboardArrowDown,
          contentDescription = "Dropdown",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        DropdownMenu(
          expanded = menuExpanded,
          onDismissRequest = { menuExpanded = false },
          modifier = Modifier.testTag("guests_events_dropdown"),
        ) {
          events.forEach { event ->
            DropdownMenuItem(
              text = {
                Column {
                  Text(
                    text = event.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontWeight = if (event.id == selectedEvent?.id) FontWeight.Bold else FontWeight.Normal,
                    ),
                  )
                  if (event.date.isNotBlank()) {
                    Text(
                      text = event.date,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              },
              leadingIcon = {
                Icon(
                  Icons.Default.Event,
                  contentDescription = null,
                  tint = if (event.id == selectedEvent?.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
              },
              onClick = {
                menuExpanded = false
                onSelectEvent(event)
              },
              modifier = Modifier.testTag("event_dropdown_item_${event.id}"),
            )
          }
        }
      }
    }
  }
}
