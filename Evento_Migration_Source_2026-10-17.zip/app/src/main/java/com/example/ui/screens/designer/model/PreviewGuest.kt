package com.example.ui.screens.designer.model

/**
 * In-memory preview guest used exclusively for live visual rendering on the badge canvas.
 *
 * CRITICAL CONSTRAINT:
 * This preview guest is strictly in-memory and MUST NEVER be saved to the Room database.
 */
data class PreviewGuest(
  val fullName: String = "Ahmed Mohammed",
  val jobTitle: String = "Event Manager",
  val organization: String = "Evento Organization",
)
