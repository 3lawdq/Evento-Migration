package com.example.ui.screens.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.EventEntity
import com.example.data.model.AttendanceStatusCrossAnalysis
import com.example.data.model.AttendanceTimeBucket
import com.example.data.model.EventAttendanceSummary
import com.example.data.model.EventDataQualitySummary
import com.example.data.model.EventStatus
import com.example.data.model.InvitationStatus
import com.example.data.model.InvitationStatusCount
import com.example.data.model.JobTitleAttendanceSummary
import com.example.data.model.OrganizationAttendanceSummary
import com.example.data.model.PeakCheckInPeriod
import com.example.ui.components.EventoEmptyState
import com.example.ui.components.EventoTopAppBar

@Composable
fun ReportsScreen(
  viewModel: AnalyticsViewModel,
  onOpenMenu: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsState()

  Scaffold(
    topBar = {
      EventoTopAppBar(
        title = stringResource(R.string.reports_title),
        onNavigationClick = onOpenMenu,
      )
    },
    modifier = modifier.testTag("reports_screen"),
  ) { paddingValues ->
    if (uiState.events.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues),
        contentAlignment = Alignment.Center,
      ) {
        EventoEmptyState(
          title = stringResource(R.string.reports_no_events_title),
          description = stringResource(R.string.reports_no_events_desc),
          icon = Icons.Default.Event,
          modifier = Modifier.testTag("reports_empty_no_events"),
        )
      }
    } else if (uiState.selectedEvent == null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues),
        contentAlignment = Alignment.Center,
      ) {
        EventoEmptyState(
          title = stringResource(R.string.reports_empty_title),
          description = stringResource(R.string.reports_empty_desc),
          icon = Icons.Default.Analytics,
          modifier = Modifier.testTag("reports_empty_no_selection"),
        )
      }
    } else {
      AnalyticsContent(
        uiState = uiState,
        onSelectEvent = { viewModel.selectEvent(it) },
        contentPadding = paddingValues,
      )
    }
  }
}

@Composable
private fun AnalyticsContent(
  uiState: AnalyticsUiState,
  onSelectEvent: (Long) -> Unit,
  contentPadding: PaddingValues,
) {
  val currentEvent = uiState.selectedEvent ?: return

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(contentPadding)
      .testTag("reports_content_list"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Event Selector & Header
    item(key = "event_selector") {
      EventSelectorCard(
        events = uiState.events,
        selectedEvent = currentEvent,
        onSelectEvent = onSelectEvent,
      )
    }

    // 2. Attendance Overview Cards
    item(key = "attendance_summary") {
      AttendanceOverviewSection(summary = uiState.attendanceSummary)
    }

    // 3. Invitation Status Breakdown
    item(key = "invitation_breakdown") {
      InvitationStatusSection(breakdown = uiState.invitationBreakdown)
    }

    // 4. Attendance vs Invitation Cross-Analysis
    item(key = "cross_analysis") {
      CrossAnalysisSection(crossAnalysis = uiState.crossAnalysis)
    }

    // 5. Timeline & Peak Check-In Window
    item(key = "timeline_and_peak") {
      TimelineSection(
        timeline = uiState.timeline,
        peak = uiState.peakCheckIn,
      )
    }

    // 6. Data Quality Summary
    item(key = "data_quality") {
      DataQualitySection(quality = uiState.dataQualitySummary)
    }

    // 7. Organization Analysis
    item(key = "organization_breakdown") {
      OrganizationSection(organizations = uiState.organizationSummaries)
    }

    // 8. Job Title Distribution
    item(key = "job_title_breakdown") {
      JobTitleSection(jobTitles = uiState.jobTitleSummaries)
    }
  }
}

@Composable
private fun EventSelectorCard(
  events: List<EventEntity>,
  selectedEvent: EventEntity,
  onSelectEvent: (Long) -> Unit,
) {
  var expanded by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("reports_event_selector_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.reports_select_event),
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (selectedEvent.status == EventStatus.ARCHIVED) {
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(4.dp),
          ) {
            Text(
              text = stringResource(R.string.reports_read_only_badge),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Box {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = true }
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
            .testTag("reports_event_dropdown_trigger"),
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surface,
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = selectedEvent.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              if (selectedEvent.date.isNotBlank() || selectedEvent.location.isNotBlank()) {
                Text(
                  text = listOf(selectedEvent.date, selectedEvent.location).filter { it.isNotBlank() }.joinToString(" • "),
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
            Icon(
              imageVector = Icons.Default.KeyboardArrowDown,
              contentDescription = stringResource(R.string.reports_select_event),
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }

        DropdownMenu(
          expanded = expanded,
          onDismissRequest = { expanded = false },
          modifier = Modifier.testTag("reports_event_dropdown_menu"),
        ) {
          events.forEach { event ->
            DropdownMenuItem(
              text = {
                Column {
                  Text(text = event.name, fontWeight = FontWeight.SemiBold)
                  if (event.status == EventStatus.ARCHIVED) {
                    Text(
                      text = stringResource(R.string.reports_event_archived_tag),
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.secondary,
                    )
                  }
                }
              },
              onClick = {
                onSelectEvent(event.id)
                expanded = false
              },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun AttendanceOverviewSection(summary: EventAttendanceSummary) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("reports_attendance_overview_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = stringResource(R.string.reports_summary_section),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
      )

      Spacer(modifier = Modifier.height(16.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        MetricTile(
          title = stringResource(R.string.reports_metric_total_guests),
          value = summary.totalGuests.toString(),
          modifier = Modifier.weight(1f).testTag("metric_total_guests"),
        )
        MetricTile(
          title = stringResource(R.string.reports_metric_checked_in),
          value = summary.checkedInGuests.toString(),
          highlightColor = MaterialTheme.colorScheme.primary,
          modifier = Modifier.weight(1f).testTag("metric_checked_in"),
        )
        MetricTile(
          title = stringResource(R.string.reports_metric_remaining),
          value = summary.remainingGuests.toString(),
          modifier = Modifier.weight(1f).testTag("metric_remaining"),
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = stringResource(R.string.reports_metric_attendance_rate),
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Medium,
        )
        Text(
          text = summary.formattedAttendancePercentage,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      LinearProgressIndicator(
        progress = { (summary.attendancePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp))
          .testTag("reports_attendance_progress"),
      )
    }
  }
}

@Composable
private fun MetricTile(
  title: String,
  value: String,
  modifier: Modifier = Modifier,
  highlightColor: Color? = null,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(8.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
  ) {
    Column(
      modifier = Modifier.padding(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = highlightColor ?: MaterialTheme.colorScheme.onSurface,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun InvitationStatusSection(breakdown: List<InvitationStatusCount>) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("reports_invitation_status_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = stringResource(R.string.reports_invitation_breakdown),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
      )

      Spacer(modifier = Modifier.height(12.dp))

      breakdown.forEach { item ->
        val label = when (item.status) {
          InvitationStatus.INVITED -> stringResource(R.string.reports_status_invited)
          InvitationStatus.CONFIRMED -> stringResource(R.string.reports_status_confirmed)
          InvitationStatus.DECLINED -> stringResource(R.string.reports_status_declined)
          InvitationStatus.CHECKED_IN -> stringResource(R.string.reports_status_checked_in)
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = item.count.toString(),
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "(${String.format(java.util.Locale.US, "%.1f%%", item.percentageOfTotal)})",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun CrossAnalysisSection(crossAnalysis: AttendanceStatusCrossAnalysis) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("reports_cross_analysis_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = stringResource(R.string.reports_cross_analysis_section),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
      )

      Spacer(modifier = Modifier.height(12.dp))

      CrossAnalysisRow(
        title = stringResource(R.string.reports_cross_confirmed_arrived),
        count = crossAnalysis.confirmedAndCheckedIn,
        color = MaterialTheme.colorScheme.primary,
      )
      CrossAnalysisRow(
        title = stringResource(R.string.reports_cross_confirmed_not_arrived),
        count = crossAnalysis.confirmedNotCheckedIn,
        color = MaterialTheme.colorScheme.error,
      )
      CrossAnalysisRow(
        title = stringResource(R.string.reports_cross_invited_not_arrived),
        count = crossAnalysis.invitedNotCheckedIn,
      )
      CrossAnalysisRow(
        title = stringResource(R.string.reports_cross_declined),
        count = crossAnalysis.declined,
      )
    }
  }
}

@Composable
private fun CrossAnalysisRow(
  title: String,
  count: Int,
  color: Color = MaterialTheme.colorScheme.onSurface,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text(
      text = count.toString(),
      style = MaterialTheme.typography.bodyMedium,
      fontWeight = FontWeight.Bold,
      color = color,
    )
  }
}

@Composable
private fun TimelineSection(
  timeline: List<AttendanceTimeBucket>,
  peak: PeakCheckInPeriod?,
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("reports_timeline_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.reports_timeline_section),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Icon(
          imageVector = Icons.Default.Schedule,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Peak summary tile
      if (peak != null) {
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth().testTag("reports_peak_period_card"),
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column {
              Text(
                text = stringResource(R.string.reports_peak_period_label),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = peak.formattedTimeRange,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
              )
            }
            Text(
              text = stringResource(R.string.reports_peak_checkins_count, peak.checkInCount),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        }
        Spacer(modifier = Modifier.height(12.dp))
      }

      if (timeline.isEmpty()) {
        Text(
          text = stringResource(R.string.reports_timeline_empty),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      } else {
        timeline.forEach { bucket ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = bucket.formattedTime,
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Medium,
              modifier = Modifier.width(60.dp),
            )
            LinearProgressIndicator(
              progress = { (bucket.percentageOfTotalCheckIns / 100.0).toFloat().coerceIn(0f, 1f) },
              modifier = Modifier
                .weight(1f)
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = bucket.count.toString(),
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun DataQualitySection(quality: EventDataQualitySummary) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("reports_data_quality_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = stringResource(R.string.reports_quality_section),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
      )

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = stringResource(R.string.reports_quality_rate),
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Medium,
        )
        Text(
          text = "${quality.completenessPercentage}%",
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      LinearProgressIndicator(
        progress = { (quality.completenessPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
      )

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        MetricTile(
          title = stringResource(R.string.reports_quality_complete),
          value = quality.completeGuestsCount.toString(),
          modifier = Modifier.weight(1f),
        )
        MetricTile(
          title = stringResource(R.string.reports_quality_incomplete),
          value = quality.incompleteGuestsCount.toString(),
          modifier = Modifier.weight(1f),
        )
        MetricTile(
          title = stringResource(R.string.reports_quality_empty_slots),
          value = quality.emptySlotsCount.toString(),
          modifier = Modifier.weight(1f),
        )
      }
    }
  }
}

@Composable
private fun OrganizationSection(organizations: List<OrganizationAttendanceSummary>) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("reports_organization_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.reports_org_section),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Icon(
          imageVector = Icons.Default.Business,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (organizations.isEmpty()) {
        Text(
          text = stringResource(R.string.reports_org_empty),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      } else {
        organizations.forEach { org ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = org.organization,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "${org.checkedInGuests}/${org.totalGuests} (${org.formattedPercentage})",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            LinearProgressIndicator(
              progress = { (org.attendancePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
              modifier = Modifier
                .width(100.dp)
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun JobTitleSection(jobTitles: List<JobTitleAttendanceSummary>) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("reports_job_title_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.reports_job_section),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Icon(
          imageVector = Icons.Default.Work,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (jobTitles.isEmpty()) {
        Text(
          text = stringResource(R.string.reports_job_empty),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      } else {
        jobTitles.forEach { job ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = job.jobTitle,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "${job.checkedInGuests}/${job.totalGuests} (${job.formattedPercentage})",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            LinearProgressIndicator(
              progress = { (job.attendancePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
              modifier = Modifier
                .width(100.dp)
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            )
          }
        }
      }
    }
  }
}
