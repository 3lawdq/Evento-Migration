package com.example.ui.screens.guests.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.GuestEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GuestDetailsDialog(
  guest: GuestEntity,
  onDismiss: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier,
  isReadOnly: Boolean = false,
) {
  val dateFormatter = rememberDateFormatter()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text = stringResource(R.string.guest_details_title),
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
        InvitationStatusBadge(status = guest.invitationStatus)
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        // Name & Avatar Header
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(52.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              val initials = guest.fullName
                .split(" ")
                .filter { it.isNotBlank() }
                .take(2)
                .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                .joinToString("")
                .ifEmpty { "G" }

              Text(
                text = initials,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
              )
            }
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column {
            Text(
              text = guest.fullName,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface,
            )
            if (guest.jobTitle.isNotBlank() || guest.organization.isNotBlank()) {
              val subtitle = buildString {
                if (guest.jobTitle.isNotBlank()) append(guest.jobTitle)
                if (guest.jobTitle.isNotBlank() && guest.organization.isNotBlank()) append(" • ")
                if (guest.organization.isNotBlank()) append(guest.organization)
              }
              Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        // Contact & Info rows
        if (guest.email.isNotBlank()) {
          GuestDetailRow(
            icon = Icons.Default.Email,
            label = stringResource(R.string.label_guest_email),
            value = guest.email,
          )
        }

        if (guest.phone.isNotBlank()) {
          GuestDetailRow(
            icon = Icons.Default.Phone,
            label = stringResource(R.string.label_guest_phone),
            value = guest.phone,
          )
        }

        if (guest.organization.isNotBlank()) {
          GuestDetailRow(
            icon = Icons.Default.Business,
            label = stringResource(R.string.label_guest_organization),
            value = guest.organization,
          )
        }

        if (guest.jobTitle.isNotBlank()) {
          GuestDetailRow(
            icon = Icons.Default.Work,
            label = stringResource(R.string.label_guest_job_title),
            value = guest.jobTitle,
          )
        }

        if (guest.notes.isNotBlank()) {
          GuestDetailRow(
            icon = androidx.compose.material.icons.Icons.AutoMirrored.Filled.Notes,
            label = stringResource(R.string.label_guest_notes),
            value = guest.notes,
          )
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        // Permanent UUID Section
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Fingerprint,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.primary,
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = stringResource(R.string.label_guest_uuid),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = guest.uuid,
              style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.testTag("guest_details_uuid"),
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = stringResource(R.string.guest_uuid_hint),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            )
          }
        }

        // Timestamps
        GuestDetailRow(
          icon = Icons.Default.Schedule,
          label = stringResource(R.string.label_created_at),
          value = dateFormatter.format(Date(guest.createdAt)),
        )

        GuestDetailRow(
          icon = Icons.Default.Schedule,
          label = stringResource(R.string.label_last_updated),
          value = dateFormatter.format(Date(guest.updatedAt)),
        )
      }
    },
    confirmButton = {
      if (!isReadOnly) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          OutlinedButton(
            onClick = {
              onDismiss()
              onDelete()
            },
            colors = ButtonDefaults.outlinedButtonColors(
              contentColor = MaterialTheme.colorScheme.error,
            ),
            modifier = Modifier.testTag("guest_details_btn_delete"),
          ) {
            Icon(
              imageVector = Icons.Default.Delete,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(stringResource(R.string.btn_delete))
          }

          Button(
            onClick = {
              onDismiss()
              onEdit()
            },
            modifier = Modifier.testTag("guest_details_btn_edit"),
          ) {
            Icon(
              imageVector = Icons.Default.Edit,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(stringResource(R.string.guests_action_edit))
          }
        }
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("guest_details_btn_close"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    modifier = modifier.testTag("guest_details_dialog"),
  )
}

@Composable
fun GuestDeleteConfirmationDialog(
  guest: GuestEntity,
  onDismiss: () -> Unit,
  onConfirmDelete: () -> Unit,
  modifier: Modifier = Modifier,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Delete,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.error,
      )
    },
    title = {
      Text(
        text = stringResource(R.string.confirm_delete_guest_title),
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Text(
        text = stringResource(R.string.confirm_delete_guest_message, guest.fullName),
        style = MaterialTheme.typography.bodyMedium,
      )
    },
    confirmButton = {
      Button(
        onClick = onConfirmDelete,
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.error,
          contentColor = MaterialTheme.colorScheme.onError,
        ),
        modifier = Modifier.testTag("btn_confirm_delete_guest"),
      ) {
        Text(stringResource(R.string.btn_delete))
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("btn_cancel_delete_guest"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    modifier = modifier.testTag("guest_delete_confirmation_dialog"),
  )
}

@Composable
private fun GuestDetailRow(
  icon: ImageVector,
  label: String,
  value: String,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier.fillMaxWidth(),
    verticalAlignment = Alignment.Top,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier
        .size(18.dp)
        .padding(top = 2.dp),
    )
    Spacer(modifier = Modifier.width(12.dp))
    Column {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface,
      )
    }
  }
}

@Composable
private fun rememberDateFormatter(): SimpleDateFormat {
  return androidx.compose.runtime.remember {
    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
  }
}
