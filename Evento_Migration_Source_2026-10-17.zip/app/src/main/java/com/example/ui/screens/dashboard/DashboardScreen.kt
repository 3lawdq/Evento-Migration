package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.entity.EventEntity
import com.example.ui.components.EventoEmptyState
import com.example.ui.components.EventoTopAppBar
import com.example.ui.navigation.EventoDestination
import com.example.ui.screens.events.EventsViewModel
import com.example.ui.screens.events.components.EventStatusBadge

@Composable
fun DashboardScreen(
  dashboardViewModel: DashboardViewModel,
  eventsViewModel: EventsViewModel,
  onNavigateTo: (EventoDestination) -> Unit,
  onOpenMenu: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val dashboardState by dashboardViewModel.uiState.collectAsStateWithLifecycle()

  val totalEvents = dashboardState.totalEvents
  val activeEvents = dashboardState.activeEvents
  val totalGuests = dashboardState.totalGuests
  val designedBadges = dashboardState.designedBadges
  val preparedPackages = dashboardState.preparedPackages
  val recentEvents = dashboardState.recentEvents

  Scaffold(
    topBar = {
      EventoTopAppBar(
        title = stringResource(R.string.dashboard_title),
        onNavigationClick = onOpenMenu,
        actions = {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.secondaryContainer,
            modifier = Modifier
              .padding(end = 12.dp)
              .testTag("admin_badge"),
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
              Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "ADMIN",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSecondaryContainer,
              )
            }
          }
        },
      )
    },
    modifier = modifier.fillMaxSize().testTag("dashboard_screen"),
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Welcome Admin Banner
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("welcome_card"),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
          ),
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Text(
              text = stringResource(R.string.dashboard_welcome),
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = stringResource(R.string.dashboard_subtitle),
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
            )
          }
        }
      }

      // Stats 2x2 Grid backed by Room reactive metrics
      item {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            MetricCard(
              title = stringResource(R.string.stat_total_events),
              value = "$totalEvents",
              subtitle = "$activeEvents ${stringResource(R.string.status_active).lowercase()}",
              icon = Icons.Default.Event,
              modifier = Modifier.weight(1f),
              testTag = "stat_events",
            )
            MetricCard(
              title = stringResource(R.string.stat_registered_guests),
              value = "$totalGuests",
              subtitle = stringResource(R.string.stat_registered_guests_desc),
              icon = Icons.Default.People,
              modifier = Modifier.weight(1f),
              testTag = "stat_guests",
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            MetricCard(
              title = stringResource(R.string.stat_designed_badges),
              value = "$designedBadges",
              subtitle = stringResource(R.string.stat_designed_badges_desc),
              icon = Icons.Default.Badge,
              modifier = Modifier.weight(1f),
              testTag = "stat_badges",
            )
            MetricCard(
              title = stringResource(R.string.stat_checkin_ready),
              value = "$preparedPackages",
              subtitle = stringResource(R.string.stat_checkin_ready_desc),
              icon = Icons.Default.CheckCircle,
              modifier = Modifier.weight(1f),
              testTag = "stat_checkin",
            )
          }
        }
      }

      // Quick Actions Section
      item {
        Text(
          text = stringResource(R.string.quick_actions_title),
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.padding(top = 4.dp),
        )
      }

      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          QuickActionCard(
            title = stringResource(R.string.action_events_title),
            description = stringResource(R.string.action_events_desc),
            icon = Icons.Default.Event,
            onClick = { onNavigateTo(EventoDestination.Events) },
            testTag = "action_events",
          )

          QuickActionCard(
            title = stringResource(R.string.action_guests_title),
            description = stringResource(R.string.action_guests_desc),
            icon = Icons.Default.People,
            onClick = { onNavigateTo(EventoDestination.Guests) },
            testTag = "action_guests",
          )

          QuickActionCard(
            title = stringResource(R.string.action_designer_title),
            description = stringResource(R.string.action_designer_desc),
            icon = Icons.Default.Badge,
            onClick = { onNavigateTo(EventoDestination.CardDesigner) },
            testTag = "action_designer",
          )

          QuickActionCard(
            title = stringResource(R.string.action_pdf_title),
            description = stringResource(R.string.action_pdf_desc),
            icon = Icons.Default.PictureAsPdf,
            onClick = { onNavigateTo(EventoDestination.PdfGenerator) },
            testTag = "action_pdf",
          )

          QuickActionCard(
            title = stringResource(R.string.action_package_title),
            description = stringResource(R.string.action_package_desc),
            icon = Icons.Default.Archive,
            onClick = { onNavigateTo(EventoDestination.EventPackage) },
            testTag = "action_package",
          )
        }
      }

      // Recent Events Section
      item {
        Text(
          text = stringResource(R.string.recent_events_title),
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.padding(top = 8.dp),
        )
      }

      if (recentEvents.isEmpty()) {
        item {
          EventoEmptyState(
            icon = Icons.Default.Event,
            title = stringResource(R.string.empty_recent_events_title),
            description = stringResource(R.string.empty_recent_events_desc),
            badgeText = stringResource(R.string.badge_ready),
            actionLabel = stringResource(R.string.btn_add_event),
            onActionClick = {
              eventsViewModel.openCreateForm()
              onNavigateTo(EventoDestination.Events)
            },
            testTag = "recent_events_empty_state",
            modifier = Modifier.padding(vertical = 4.dp),
          )
        }
      } else {
        items(recentEvents, key = { it.id }) { event ->
          DashboardRecentEventCard(
            event = event,
            onClick = {
              eventsViewModel.openDetails(event)
              onNavigateTo(EventoDestination.Events)
            },
          )
        }
      }
    }
  }
}

@Composable
private fun DashboardRecentEventCard(
  event: EventEntity,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("dashboard_event_card_${event.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.Event,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.size(24.dp),
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = event.name,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f, fill = false),
          )
          EventStatusBadge(status = event.status)
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          if (event.date.isNotBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.CalendarToday,
                contentDescription = null,
                modifier = Modifier.size(13.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = event.date,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          if (event.location.isNotBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                modifier = Modifier.size(13.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = event.location,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }

      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        modifier = Modifier.size(20.dp),
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun MetricCard(
  title: String,
  value: String,
  subtitle: String,
  icon: ImageVector,
  modifier: Modifier = Modifier,
  testTag: String = "",
) {
  Card(
    modifier = modifier.testTag(testTag),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.secondaryContainer),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.size(20.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = value,
        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.testTag("${testTag}_value"),
      )

      Spacer(modifier = Modifier.height(2.dp))

      Text(
        text = title,
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurface,
      )

      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun QuickActionCard(
  title: String,
  description: String,
  icon: ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String = "",
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag(testTag),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.size(22.dp),
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        modifier = Modifier.size(18.dp),
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}
