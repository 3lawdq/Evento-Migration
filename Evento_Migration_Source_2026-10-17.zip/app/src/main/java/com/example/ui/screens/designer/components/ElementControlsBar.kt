package com.example.ui.screens.designer.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CorporateFare
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.model.BadgeElementType

data class ElementTypeDescriptor(
  val type: BadgeElementType,
  val labelRes: Int,
  val icon: ImageVector,
)

val BADGE_ELEMENT_DESCRIPTORS = listOf(
  ElementTypeDescriptor(BadgeElementType.ATTENDEE_NAME, R.string.designer_element_attendee_name, Icons.Default.Person),
  ElementTypeDescriptor(BadgeElementType.JOB_TITLE, R.string.designer_element_job_title, Icons.Default.Work),
  ElementTypeDescriptor(BadgeElementType.ORGANIZATION, R.string.designer_element_organization, Icons.Default.Business),
  ElementTypeDescriptor(BadgeElementType.EVENT_NAME, R.string.designer_element_event_name, Icons.Default.Event),
  ElementTypeDescriptor(BadgeElementType.LOGO, R.string.designer_element_logo, Icons.Default.CorporateFare),
  ElementTypeDescriptor(BadgeElementType.QR_PLACEHOLDER, R.string.designer_element_qr, Icons.Default.QrCode2),
)

@Composable
fun ElementControlsBar(
  elements: List<BadgeElementEntity>,
  selectedElementId: Long?,
  onToggleElement: (BadgeElementType) -> Unit,
  onSelectElement: (Long) -> Unit,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    BADGE_ELEMENT_DESCRIPTORS.forEach { descriptor ->
      val activeElement = elements.firstOrNull {
        (it.type == descriptor.type || (descriptor.type.isQr && it.type.isQr)) && it.visible
      }
      val isPresent = activeElement != null
      val isSelected = activeElement?.id == selectedElementId

      FilterChip(
        selected = isPresent,
        onClick = {
          if (activeElement != null) {
            if (isSelected) {
              // Second click toggles off
              onToggleElement(descriptor.type)
            } else {
              // First click selects
              onSelectElement(activeElement.id)
            }
          } else {
            // Add element
            onToggleElement(descriptor.type)
          }
        },
        label = { Text(stringResource(descriptor.labelRes)) },
        leadingIcon = {
          Icon(descriptor.icon, contentDescription = null)
        },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = if (isSelected) {
            MaterialTheme.colorScheme.primary
          } else {
            MaterialTheme.colorScheme.secondaryContainer
          },
          selectedLabelColor = if (isSelected) {
            MaterialTheme.colorScheme.onPrimary
          } else {
            MaterialTheme.colorScheme.onSecondaryContainer
          },
          selectedLeadingIconColor = if (isSelected) {
            MaterialTheme.colorScheme.onPrimary
          } else {
            MaterialTheme.colorScheme.onSecondaryContainer
          },
        ),
        modifier = Modifier.testTag("element_chip_${descriptor.type.name.lowercase()}"),
      )
    }
  }
}
