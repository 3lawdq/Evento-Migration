package com.example.ui.screens.designer

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.ui.components.ArchivedEventBanner
import com.example.ui.components.EventoEmptyState
import com.example.ui.screens.designer.components.BadgeCanvas
import com.example.ui.screens.designer.components.BadgeDimensionsDialog
import com.example.ui.screens.designer.components.ElementControlsBar
import com.example.ui.screens.designer.components.ElementPropertiesPanel
import com.example.ui.screens.designer.model.PreviewGuest
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardDesignerScreen(
  viewModel: CardDesignerViewModel,
  onOpenMenu: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val allEvents by viewModel.allEvents.collectAsStateWithLifecycle()
  val selectedEventId by viewModel.selectedEventId.collectAsStateWithLifecycle()
  val currentTemplate by viewModel.currentTemplate.collectAsStateWithLifecycle()
  val currentElements by viewModel.currentElements.collectAsStateWithLifecycle()
  val selectedElementId by viewModel.selectedElementId.collectAsStateWithLifecycle()
  val isPreviewMode by viewModel.isPreviewMode.collectAsStateWithLifecycle()
  val isDirty by viewModel.isDirty.collectAsStateWithLifecycle()
  val isSaving by viewModel.isSaving.collectAsStateWithLifecycle()
  val eventGuests by viewModel.eventGuests.collectAsStateWithLifecycle()
  val selectedPreviewGuest by viewModel.selectedPreviewGuest.collectAsStateWithLifecycle()
  val previewQrBitmap by viewModel.previewQrBitmap.collectAsStateWithLifecycle()
  val eventTemplates by viewModel.eventTemplates.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  var showEventMenu by remember { mutableStateOf(false) }
  var showGuestMenu by remember { mutableStateOf(false) }
  var showTemplateMenu by remember { mutableStateOf(false) }
  var showMoreMenu by remember { mutableStateOf(false) }
  var showDimensionsDialog by remember { mutableStateOf(false) }
  var showDeleteDialog by remember { mutableStateOf(false) }
  var showResetDialog by remember { mutableStateOf(false) }
  var showNewTemplateDialog by remember { mutableStateOf(false) }
  var showRenameTemplateDialog by remember { mutableStateOf(false) }
  var showDuplicateTemplateDialog by remember { mutableStateOf(false) }
  var templateNameInput by remember { mutableStateOf("") }

  val imagePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    uri?.let {
      viewModel.setBackgroundImage(it.toString())
    }
  }

  val selectedEvent = allEvents.firstOrNull { it.id == selectedEventId }
  val isArchived = selectedEvent?.status == EventStatus.ARCHIVED
  val selectedElement = currentElements.firstOrNull { it.id == selectedElementId }

  LaunchedEffect(Unit) {
    viewModel.snackbarMessage.collect { message ->
      snackbarHostState.showSnackbar(message)
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = stringResource(R.string.designer_title),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
            if (selectedEvent != null) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .testTag("event_selector_dropdown_trigger")
                  .clickable { showEventMenu = true },
              ) {
                Text(
                  text = selectedEvent.name,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Icon(
                  imageVector = Icons.Default.KeyboardArrowDown,
                  contentDescription = stringResource(R.string.designer_select_event),
                  modifier = Modifier.size(16.dp),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onOpenMenu,
            modifier = Modifier.testTag("top_bar_nav_button"),
          ) {
            Icon(
              imageVector = Icons.Default.Menu,
              contentDescription = stringResource(R.string.nav_menu),
            )
          }
        },
        actions = {
          if (currentTemplate != null) {
            // Preview / Edit Mode Toggle
            IconButton(
              onClick = { viewModel.togglePreviewMode() },
              modifier = Modifier.testTag("toggle_preview_button"),
            ) {
              Icon(
                imageVector = if (isPreviewMode) Icons.Default.Edit else Icons.Default.Visibility,
                contentDescription = if (isPreviewMode) {
                  stringResource(R.string.designer_action_edit_mode)
                } else {
                  stringResource(R.string.designer_action_preview)
                },
                tint = if (isPreviewMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
              )
            }

            // Save Action (Prominent Button with isDirty indicator and feedback)
            if (!isArchived) {
              Button(
                onClick = { viewModel.saveTemplate() },
                enabled = !isSaving && isDirty,
                colors = ButtonDefaults.buttonColors(
                  containerColor = MaterialTheme.colorScheme.primary,
                  contentColor = MaterialTheme.colorScheme.onPrimary,
                  disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                  disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                  .padding(end = 4.dp)
                  .testTag("save_template_button"),
              ) {
                if (isSaving) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(14.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp,
                  )
                } else {
                  Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                  )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = stringResource(R.string.designer_action_save),
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                )
              }

              // Overflow Menu (Dimensions, Reset, Delete, Save as new)
              IconButton(
                onClick = { showMoreMenu = true },
                modifier = Modifier.testTag("designer_overflow_button"),
              ) {
                Icon(
                  imageVector = Icons.Default.MoreVert,
                  contentDescription = "More Options",
                )
              }
            }

            DropdownMenu(
              expanded = showMoreMenu,
              onDismissRequest = { showMoreMenu = false },
            ) {
              DropdownMenuItem(
                text = { Text(stringResource(R.string.designer_action_dimensions)) },
                leadingIcon = { Icon(Icons.Default.AspectRatio, contentDescription = null) },
                onClick = {
                  showMoreMenu = false
                  showDimensionsDialog = true
                },
              )
              DropdownMenuItem(
                text = { Text(stringResource(R.string.designer_action_choose_bg_image)) },
                leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) },
                onClick = {
                  showMoreMenu = false
                  imagePickerLauncher.launch("image/*")
                },
              )
              if (currentTemplate?.backgroundImageUri != null) {
                DropdownMenuItem(
                  text = { Text(stringResource(R.string.designer_action_remove_bg_image)) },
                  leadingIcon = { Icon(Icons.Default.Close, contentDescription = null) },
                  onClick = {
                    showMoreMenu = false
                    viewModel.removeBackgroundImage()
                  },
                )
              }
              DropdownMenuItem(
                text = { Text(stringResource(R.string.designer_action_save_as_new)) },
                leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                onClick = {
                  showMoreMenu = false
                  templateNameInput = "${currentTemplate?.name ?: "Template"} (New)"
                  showDuplicateTemplateDialog = true
                },
              )
              DropdownMenuItem(
                text = { Text(stringResource(R.string.designer_action_rename_template)) },
                leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, contentDescription = null) },
                onClick = {
                  showMoreMenu = false
                  templateNameInput = currentTemplate?.name ?: ""
                  showRenameTemplateDialog = true
                },
              )
              if (currentTemplate?.isActive == false) {
                DropdownMenuItem(
                  text = { Text(stringResource(R.string.designer_action_set_active_template)) },
                  leadingIcon = { Icon(Icons.Default.Star, contentDescription = null) },
                  onClick = {
                    showMoreMenu = false
                    currentTemplate?.let { viewModel.setTemplateActive(it.id) }
                  },
                )
              }
              DropdownMenuItem(
                text = { Text(stringResource(R.string.designer_action_reset)) },
                leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) },
                onClick = {
                  showMoreMenu = false
                  showResetDialog = true
                },
              )
              DropdownMenuItem(
                text = { Text(stringResource(R.string.designer_action_delete)) },
                leadingIcon = {
                  Icon(
                    Icons.Default.Delete,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                  )
                },
                onClick = {
                  showMoreMenu = false
                  showDeleteDialog = true
                },
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
        ),
      )
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    modifier = modifier.fillMaxSize().testTag("designer_screen"),
  ) { innerPadding ->
    // Events Selection Dropdown Menu
    DropdownMenu(
      expanded = showEventMenu,
      onDismissRequest = { showEventMenu = false },
    ) {
      allEvents.forEach { event ->
        DropdownMenuItem(
          text = { Text(event.name) },
          trailingIcon = if (event.id == selectedEventId) {
            { Icon(Icons.Default.Check, contentDescription = null) }
          } else null,
          onClick = {
            viewModel.selectEvent(event.id)
            showEventMenu = false
          },
        )
      }
    }

    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      when {
        allEvents.isEmpty() -> {
          // No events state
          Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center,
          ) {
            EventoEmptyState(
              icon = Icons.Default.Badge,
              title = stringResource(R.string.guests_no_events_title),
              description = stringResource(R.string.designer_no_events),
              badgeText = stringResource(R.string.status_draft),
              testTag = "designer_no_events_state",
            )
          }
        }

        currentTemplate == null -> {
          // Event has no template yet
          Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center,
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center,
            ) {
              EventoEmptyState(
                icon = Icons.Default.Badge,
                title = stringResource(R.string.designer_no_template_title),
                description = stringResource(R.string.designer_no_template_desc),
                badgeText = stringResource(R.string.badge_upcoming),
                actionLabel = if (!isArchived) stringResource(R.string.designer_create_template) else null,
                onActionClick = { if (!isArchived) viewModel.createDefaultTemplate() },
                testTag = "designer_no_template_state",
              )
            }
          }
        }

        else -> {
          val template = currentTemplate!!

          Column(
            modifier = Modifier.fillMaxSize(),
          ) {
            if (isArchived) {
              ArchivedEventBanner(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 6.dp),
              )
            }

            // Mode Banner (Live Data Preview vs Visual Layout Editor)
            Surface(
              color = if (isPreviewMode) {
                MaterialTheme.colorScheme.primaryContainer
              } else {
                MaterialTheme.colorScheme.surfaceVariant
              },
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = if (isPreviewMode) {
                    stringResource(R.string.designer_live_preview_mode)
                  } else {
                    stringResource(R.string.designer_edit_canvas_mode)
                  },
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = if (isPreviewMode) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                  } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                  },
                )
                Text(
                  text = stringResource(
                    R.string.designer_preview_badge_label,
                    template.widthMm,
                    template.heightMm,
                    if (template.orientation == BadgeOrientation.LANDSCAPE) {
                      stringResource(R.string.designer_orientation_landscape)
                    } else {
                      stringResource(R.string.designer_orientation_portrait)
                    },
                  ),
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }

            // Template Switcher & Management Bar
            Surface(
              color = MaterialTheme.colorScheme.surface,
              tonalElevation = 1.dp,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier
                    .weight(1f)
                    .clickable { showTemplateMenu = true }
                    .testTag("template_selector_dropdown_trigger"),
                ) {
                  Icon(
                    imageVector = Icons.Default.Badge,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = template.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  if (template.isActive) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                      color = MaterialTheme.colorScheme.primaryContainer,
                      shape = MaterialTheme.shapes.extraSmall,
                    ) {
                      Text(
                        text = stringResource(R.string.designer_active_template_badge),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                      )
                    }
                  }
                  Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }

                if (!isArchived) {
                  IconButton(
                    onClick = {
                      templateNameInput = ""
                      showNewTemplateDialog = true
                    },
                    modifier = Modifier.size(32.dp).testTag("add_new_template_button"),
                  ) {
                    Icon(
                      imageVector = Icons.Default.Add,
                      contentDescription = stringResource(R.string.designer_action_new_template),
                      modifier = Modifier.size(20.dp),
                    )
                  }
                }

                DropdownMenu(
                  expanded = showTemplateMenu,
                  onDismissRequest = { showTemplateMenu = false },
                ) {
                  eventTemplates.forEach { t ->
                    DropdownMenuItem(
                      text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                          Text(
                            text = t.name,
                            fontWeight = if (t.id == template.id) FontWeight.Bold else FontWeight.Normal,
                          )
                          if (t.isActive) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                              text = "(${stringResource(R.string.designer_active_template_badge)})",
                              style = MaterialTheme.typography.labelSmall,
                              color = MaterialTheme.colorScheme.primary,
                            )
                          }
                        }
                      },
                      trailingIcon = if (t.id == template.id) {
                        { Icon(Icons.Default.Check, contentDescription = null) }
                      } else null,
                      onClick = {
                        viewModel.selectTemplate(t.id)
                        showTemplateMenu = false
                      },
                    )
                  }
                }
              }
            }

            // Preview Guest Selector Bar (Visible during Live Preview mode)
            if (isPreviewMode) {
              Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                      .weight(1f)
                      .clickable { showGuestMenu = true }
                      .testTag("preview_guest_selector"),
                  ) {
                    Icon(
                      imageVector = Icons.Default.Person,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = stringResource(R.string.designer_preview_guest_label) + ": ",
                      style = MaterialTheme.typography.labelMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                      text = selectedPreviewGuest?.fullName
                        ?: stringResource(R.string.designer_preview_no_guest),
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.SemiBold,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Icon(
                      imageVector = Icons.Default.ArrowDropDown,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }

                  if (selectedPreviewGuest != null) {
                    IconButton(
                      onClick = { viewModel.selectPreviewGuest(null) },
                      modifier = Modifier.size(28.dp).testTag("clear_preview_guest_button"),
                    ) {
                      Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear Guest",
                        modifier = Modifier.size(16.dp),
                      )
                    }
                  }

                  DropdownMenu(
                    expanded = showGuestMenu,
                    onDismissRequest = { showGuestMenu = false },
                  ) {
                    DropdownMenuItem(
                      text = { Text(stringResource(R.string.designer_preview_no_guest)) },
                      trailingIcon = if (selectedPreviewGuest == null) {
                        { Icon(Icons.Default.Check, contentDescription = null) }
                      } else null,
                      onClick = {
                        viewModel.selectPreviewGuest(null)
                        showGuestMenu = false
                      },
                    )
                    if (eventGuests.isEmpty()) {
                      DropdownMenuItem(
                        text = {
                          Text(
                            text = stringResource(R.string.designer_no_guests_in_event),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                          )
                        },
                        enabled = false,
                        onClick = {},
                      )
                    } else {
                      eventGuests.forEach { guest ->
                        DropdownMenuItem(
                          text = {
                            Column {
                              Text(guest.fullName, fontWeight = FontWeight.Medium)
                              if (guest.jobTitle.isNotBlank() || guest.organization.isNotBlank()) {
                                Text(
                                  text = listOf(guest.jobTitle, guest.organization)
                                    .filter { it.isNotBlank() }
                                    .joinToString(" • "),
                                  style = MaterialTheme.typography.bodySmall,
                                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                              }
                            }
                          },
                          trailingIcon = if (selectedPreviewGuest?.id == guest.id) {
                            { Icon(Icons.Default.Check, contentDescription = null) }
                          } else null,
                          onClick = {
                            viewModel.selectPreviewGuest(guest)
                            showGuestMenu = false
                          },
                        )
                      }
                    }
                  }
                }
              }
            }

            // Central Badge Canvas Area
            Box(
              modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
              contentAlignment = Alignment.Center,
            ) {
              BadgeCanvas(
                template = template,
                elements = currentElements,
                selectedElementId = selectedElementId,
                isPreviewMode = isPreviewMode,
                previewGuest = if (selectedPreviewGuest != null) {
                  PreviewGuest(
                    fullName = selectedPreviewGuest!!.fullName,
                    jobTitle = selectedPreviewGuest!!.jobTitle.ifBlank { "Attendee" },
                    organization = selectedPreviewGuest!!.organization.ifBlank { "Organization" },
                  )
                } else {
                  viewModel.previewGuest
                },
                eventName = selectedEvent?.name ?: "Event",
                onSelectElement = { id -> viewModel.selectElement(id) },
                onUpdateElementPosition = { id, dx, dy ->
                  viewModel.updateElementPosition(id, dx, dy)
                },
                onUpdateElementSize = { id, dw, dh ->
                  viewModel.updateElementSize(id, dw, dh)
                },
                qrBitmap = previewQrBitmap,
                isReadOnly = isArchived,
                modifier = Modifier.fillMaxWidth(),
              )
            }

            // Bottom Element Selection & Control Bar
            if (!isPreviewMode && !isArchived) {
              ElementControlsBar(
                elements = currentElements,
                selectedElementId = selectedElementId,
                onToggleElement = { type -> viewModel.toggleElementVisibility(type) },
                onSelectElement = { id -> viewModel.selectElement(id) },
              )
            }

            // Slide-up properties panel when an element is selected
            AnimatedVisibility(
              visible = !isPreviewMode && !isArchived && selectedElement != null,
              enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
              exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            ) {
              if (selectedElement != null) {
                ElementPropertiesPanel(
                  element = selectedElement,
                  onUpdateFontSize = { size ->
                    viewModel.updateElementFontSize(selectedElement.id, size)
                  },
                  onUpdateFontWeight = { weight ->
                    viewModel.updateElementFontWeight(selectedElement.id, weight)
                  },
                  onUpdateAlignment = { alignment ->
                    viewModel.updateElementAlignment(selectedElement.id, alignment)
                  },
                  onUpdateTextColor = { colorHex ->
                    viewModel.updateElementTextColor(selectedElement.id, colorHex)
                  },
                  onUpdateRotation = { rotation ->
                    viewModel.updateElementRotation(selectedElement.id, rotation)
                  },
                  onUpdateLogoUri = { uri ->
                    viewModel.updateElementLogoUri(uri)
                  },
                  onDeleteElement = {
                    viewModel.removeElement(selectedElement.id)
                  },
                  onClose = {
                    viewModel.selectElement(null)
                  },
                  onUpdateQrSize = { size ->
                    viewModel.updateQrSize(size)
                  },
                )
              }
            }
          }
        }
      }
    }
  }

  // Badge Dimensions & Orientation Dialog
  if (showDimensionsDialog && currentTemplate != null) {
    val template = currentTemplate!!
    BadgeDimensionsDialog(
      currentWidthMm = template.widthMm,
      currentHeightMm = template.heightMm,
      currentOrientation = template.orientation,
      onApply = { widthMm, heightMm, orientation ->
        viewModel.updateTemplateDimensions(widthMm, heightMm, orientation)
      },
      onDismiss = { showDimensionsDialog = false },
    )
  }

  // Confirm Delete Template Dialog
  if (showDeleteDialog) {
    AlertDialog(
      onDismissRequest = { showDeleteDialog = false },
      title = { Text(stringResource(R.string.designer_confirm_delete_title)) },
      text = { Text(stringResource(R.string.designer_confirm_delete_msg)) },
      confirmButton = {
        TextButton(
          onClick = {
            viewModel.deleteTemplate()
            showDeleteDialog = false
          },
          modifier = Modifier.testTag("confirm_delete_template_button"),
        ) {
          Text(
            stringResource(R.string.btn_delete),
            color = MaterialTheme.colorScheme.error,
          )
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteDialog = false }) {
          Text(stringResource(R.string.btn_cancel))
        }
      },
    )
  }

  // Confirm Reset Default Layout Dialog
  if (showResetDialog) {
    AlertDialog(
      onDismissRequest = { showResetDialog = false },
      title = { Text(stringResource(R.string.designer_confirm_reset_title)) },
      text = { Text(stringResource(R.string.designer_confirm_reset_msg)) },
      confirmButton = {
        TextButton(
          onClick = {
            viewModel.resetToDefault()
            showResetDialog = false
          },
          modifier = Modifier.testTag("confirm_reset_template_button"),
        ) {
          Text(stringResource(R.string.designer_action_reset))
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetDialog = false }) {
          Text(stringResource(R.string.btn_cancel))
        }
      },
    )
  }

  // Create New Template Dialog
  if (showNewTemplateDialog) {
    AlertDialog(
      onDismissRequest = { showNewTemplateDialog = false },
      title = { Text(stringResource(R.string.designer_action_new_template)) },
      text = {
        Column {
          OutlinedTextField(
            value = templateNameInput,
            onValueChange = { templateNameInput = it },
            label = { Text(stringResource(R.string.designer_action_new_template)) },
            placeholder = { Text("VIP Badge / Speaker Badge") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("new_template_name_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val name = templateNameInput.trim().ifEmpty { "New Template" }
            viewModel.createNewTemplate(name)
            showNewTemplateDialog = false
          },
          modifier = Modifier.testTag("confirm_create_template_button"),
        ) {
          Text(stringResource(R.string.btn_save))
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewTemplateDialog = false }) {
          Text(stringResource(R.string.btn_cancel))
        }
      },
    )
  }

  // Rename Template Dialog
  if (showRenameTemplateDialog) {
    AlertDialog(
      onDismissRequest = { showRenameTemplateDialog = false },
      title = { Text(stringResource(R.string.designer_action_rename_template)) },
      text = {
        Column {
          OutlinedTextField(
            value = templateNameInput,
            onValueChange = { templateNameInput = it },
            label = { Text(stringResource(R.string.designer_action_rename_template)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("rename_template_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val name = templateNameInput.trim().ifEmpty { currentTemplate?.name ?: "Template" }
            viewModel.renameCurrentTemplate(name)
            showRenameTemplateDialog = false
          },
          modifier = Modifier.testTag("confirm_rename_template_button"),
        ) {
          Text(stringResource(R.string.btn_save))
        }
      },
      dismissButton = {
        TextButton(onClick = { showRenameTemplateDialog = false }) {
          Text(stringResource(R.string.btn_cancel))
        }
      },
    )
  }

  // Save as New Template Dialog
  if (showDuplicateTemplateDialog) {
    AlertDialog(
      onDismissRequest = { showDuplicateTemplateDialog = false },
      title = { Text(stringResource(R.string.designer_action_save_as_new)) },
      text = {
        Column {
          OutlinedTextField(
            value = templateNameInput,
            onValueChange = { templateNameInput = it },
            label = { Text(stringResource(R.string.designer_action_save_as_new)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("duplicate_template_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val name = templateNameInput.trim().ifEmpty { "${currentTemplate?.name ?: "Template"} (New)" }
            viewModel.saveAsNewTemplate(name)
            showDuplicateTemplateDialog = false
          },
          modifier = Modifier.testTag("confirm_duplicate_template_button"),
        ) {
          Text(stringResource(R.string.designer_action_save_as_new))
        }
      },
      dismissButton = {
        TextButton(onClick = { showDuplicateTemplateDialog = false }) {
          Text(stringResource(R.string.btn_cancel))
        }
      },
    )
  }
}
