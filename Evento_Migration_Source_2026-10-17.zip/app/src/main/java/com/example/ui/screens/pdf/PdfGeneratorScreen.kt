package com.example.ui.screens.pdf

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeOrientation
import com.example.data.model.EventStatus
import com.example.ui.components.ArchivedEventBanner
import com.example.ui.components.EventoEmptyState
import com.example.ui.components.EventoTopAppBar
import com.example.util.pdf.PdfGenerationResult
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfGeneratorScreen(
  viewModel: PdfGeneratorViewModel,
  onOpenMenu: () -> Unit,
  onNavigateToDesigner: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val context = LocalContext.current

  var showEventDropdown by remember { mutableStateOf(false) }

  // Observe errors
  LaunchedEffect(uiState.validationError) {
    uiState.validationError?.let { error ->
      scope.launch {
        snackbarHostState.showSnackbar(
          message = error,
          duration = SnackbarDuration.Long,
        )
      }
    }
  }

  Scaffold(
    topBar = {
      EventoTopAppBar(
        title = stringResource(R.string.pdf_title),
        onNavigationClick = onOpenMenu,
      )
    },
    floatingActionButton = {
      if (uiState.selectedEvent != null && uiState.templateWithElements != null && uiState.effectiveGuestsToExport.isNotEmpty()) {
        ExtendedFloatingActionButton(
          onClick = { viewModel.generateBadges() },
          icon = {
            if (uiState.isGenerating) {
              CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                strokeWidth = 2.dp,
              )
            } else {
              Icon(Icons.Default.PictureAsPdf, contentDescription = null)
            }
          },
          text = {
            Text(
              if (uiState.isGenerating) {
                val prog = uiState.currentProgress
                if (prog != null) {
                  stringResource(R.string.pdf_generating_progress, prog.first, prog.second)
                } else {
                  "Generating..."
                }
              } else {
                stringResource(R.string.pdf_generate_action, uiState.effectiveGuestsToExport.size)
              }
            )
          },
          expanded = true,
          modifier = Modifier.testTag("pdf_fab"),
        )
      }
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    modifier = modifier.fillMaxSize().testTag("pdf_screen"),
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      if (uiState.showHighVolumeWarningDialog) {
        androidx.compose.material3.AlertDialog(
          onDismissRequest = { viewModel.dismissHighVolumeWarning() },
          icon = {
            Icon(
              Icons.Default.Warning,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.error,
              modifier = Modifier.size(28.dp),
            )
          },
          title = {
            Text(
              text = stringResource(R.string.pdf_high_volume_warning_title),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
          },
          text = {
            Text(
              text = stringResource(
                R.string.pdf_high_volume_warning_desc,
                uiState.effectiveGuestsToExport.size,
              ),
              style = MaterialTheme.typography.bodyMedium,
            )
          },
          confirmButton = {
            Button(
              onClick = { viewModel.proceedWithHighVolumeGeneration() },
              colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.error,
                contentColor = MaterialTheme.colorScheme.onError,
              ),
              modifier = Modifier.testTag("pdf_high_volume_continue_button"),
            ) {
              Text(stringResource(R.string.pdf_high_volume_continue_btn))
            }
          },
          dismissButton = {
            OutlinedButton(
              onClick = { viewModel.dismissHighVolumeWarning() },
              modifier = Modifier.testTag("pdf_high_volume_cancel_button"),
            ) {
              Text(stringResource(R.string.btn_cancel))
            }
          },
          shape = RoundedCornerShape(20.dp),
          modifier = Modifier.testTag("pdf_high_volume_dialog"),
        )
      }

      if (uiState.isGenerating) {
        androidx.compose.material3.AlertDialog(
          onDismissRequest = { /* Prevent accidental dismissal */ },
          title = {
            Text(
              text = stringResource(R.string.pdf_title),
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
            )
          },
          text = {
            Column(
              modifier = Modifier.fillMaxWidth(),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              val prog = uiState.currentProgress
              if (prog != null && prog.second > 0) {
                val progressFraction = prog.first.toFloat() / prog.second.toFloat()
                LinearProgressIndicator(
                  progress = { progressFraction },
                  modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                  text = stringResource(R.string.pdf_generating_progress, prog.first, prog.second),
                  style = MaterialTheme.typography.bodyMedium,
                )
              } else {
                LinearProgressIndicator(
                  modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                  text = "Generating...",
                  style = MaterialTheme.typography.bodyMedium,
                )
              }
            }
          },
          confirmButton = {},
          dismissButton = {
            OutlinedButton(
              onClick = { viewModel.cancelGeneration() },
              modifier = Modifier.testTag("pdf_cancel_generation_button"),
            ) {
              Text(stringResource(R.string.btn_cancel))
            }
          },
          shape = RoundedCornerShape(20.dp),
          modifier = Modifier.testTag("pdf_generating_dialog"),
        )
      }

      if (uiState.isLoadingData) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator()
        }
      } else if (uiState.events.isEmpty()) {
        EventoEmptyState(
          icon = Icons.Default.Event,
          title = stringResource(R.string.guests_no_events_title),
          description = stringResource(R.string.guests_no_events_desc),
          badgeText = stringResource(R.string.badge_upcoming),
          actionLabel = null,
          testTag = "pdf_no_events_empty",
        )
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          if (uiState.selectedEvent?.status == EventStatus.ARCHIVED) {
            item {
              ArchivedEventBanner(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 8.dp)
                  .testTag("pdf_archived_event_banner"),
              )
            }
          }

          item {
            Spacer(modifier = Modifier.height(8.dp))
            // Section 1: Event & Template Selection
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("pdf_event_template_card"),
              colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              ),
              shape = RoundedCornerShape(16.dp),
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Text(
                  text = stringResource(R.string.pdf_section_event_template),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Event Selector Dropdown
                Box(modifier = Modifier.fillMaxWidth()) {
                  OutlinedCard(
                    onClick = { showEventDropdown = true },
                    modifier = Modifier
                      .fillMaxWidth()
                      .testTag("pdf_event_selector"),
                  ) {
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Column(modifier = Modifier.weight(1f)) {
                        Text(
                          text = stringResource(R.string.pdf_select_event_label),
                          style = MaterialTheme.typography.labelSmall,
                          color = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                          text = uiState.selectedEvent?.name ?: "Select Event",
                          style = MaterialTheme.typography.bodyLarge,
                          fontWeight = FontWeight.SemiBold,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis,
                        )
                      }
                      Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                  }

                  DropdownMenu(
                    expanded = showEventDropdown,
                    onDismissRequest = { showEventDropdown = false },
                    modifier = Modifier.testTag("pdf_event_dropdown"),
                  ) {
                    uiState.events.forEach { event ->
                      DropdownMenuItem(
                        text = { Text(event.name) },
                        onClick = {
                          viewModel.selectEvent(event.id)
                          showEventDropdown = false
                        },
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Badge Template Info
                val template = uiState.templateWithElements?.template
                val elements = uiState.templateWithElements?.elements ?: emptyList()
                if (template != null) {
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      val orientationStr = if (template.orientation == BadgeOrientation.LANDSCAPE) "Landscape" else "Portrait"
                      val bgParsedColor = try {
                        Color(android.graphics.Color.parseColor(template.backgroundColor))
                      } catch (_: Exception) {
                        Color.White
                      }

                      Box(
                        modifier = Modifier
                          .size(36.dp)
                          .clip(CircleShape)
                          .background(bgParsedColor)
                          .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape),
                      )

                      Spacer(modifier = Modifier.width(12.dp))

                      Column(modifier = Modifier.weight(1f)) {
                        Text(
                          text = stringResource(R.string.pdf_template_info, template.name),
                          style = MaterialTheme.typography.bodyMedium,
                          fontWeight = FontWeight.Bold,
                        )
                        Text(
                          text = stringResource(R.string.pdf_dimensions_label, template.widthMm, template.heightMm, orientationStr),
                          style = MaterialTheme.typography.bodySmall,
                          color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                          text = "${elements.count { it.visible }} visible elements • QR Barcode Included",
                          style = MaterialTheme.typography.labelSmall,
                          color = MaterialTheme.colorScheme.primary,
                        )
                      }
                    }
                  }
                } else {
                  OutlinedCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.outlinedCardColors(
                      containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                    ),
                  ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                          Icons.Default.Warning,
                          contentDescription = null,
                          tint = MaterialTheme.colorScheme.error,
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                          text = stringResource(R.string.pdf_no_template_warning),
                          style = MaterialTheme.typography.bodySmall,
                          color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                      }
                      Spacer(modifier = Modifier.height(8.dp))
                      OutlinedButton(
                        onClick = onNavigateToDesigner,
                        modifier = Modifier.align(Alignment.End),
                      ) {
                        Text("Open Card Designer")
                      }
                    }
                  }
                }
              }
            }
          }

          // Section 1.5: Page & Grid Layout Configuration & Preview
          if (uiState.selectedEvent != null && uiState.templateWithElements != null) {
            item {
              com.example.ui.screens.pdf.components.PdfLayoutConfigCard(
                layoutConfig = uiState.layoutConfig,
                template = uiState.templateWithElements?.template,
                totalGuests = uiState.effectiveGuestsToExport.size,
                onPaperSizeChange = { viewModel.setPaperSize(it) },
                onOrientationChange = { viewModel.setPaperOrientation(it) },
                onGridChange = { cols, rows -> viewModel.setGrid(cols, rows) },
                onMarginsChange = { top, bottom, left, right -> viewModel.setMargins(top, bottom, left, right) },
                onSpacingChange = { h, v -> viewModel.setSpacing(h, v) },
                onZeroMarginsClick = { viewModel.setZeroMargins() },
                onShowCutMarksChange = { viewModel.setShowCutMarks(it) },
              )
            }
          }

          // Section 2: Success Result Banner
          if (uiState.generationResult is PdfGenerationResult.Success) {
            val success = uiState.generationResult as PdfGenerationResult.Success
            item {
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("pdf_success_card"),
                colors = CardDefaults.cardColors(
                  containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
                shape = RoundedCornerShape(16.dp),
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      Icons.Default.CheckCircle,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.size(28.dp),
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = stringResource(R.string.pdf_success_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                      )
                      val kb = success.fileSizeInBytes / 1024
                      val sizeStr = if (kb > 1024) "%.1f MB".format(kb / 1024f) else "$kb KB"
                      Text(
                        text = stringResource(R.string.pdf_success_details, success.pageCount, sizeStr),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                      )
                    }
                    IconButton(onClick = { viewModel.clearResult() }) {
                      Icon(Icons.Default.Close, contentDescription = stringResource(R.string.pdf_action_dismiss))
                    }
                  }

                  Spacer(modifier = Modifier.height(14.dp))

                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                  ) {
                    Button(
                      onClick = {
                        val uri = success.uri
                        if (uri != null) {
                          openPdf(context, uri)
                        } else {
                          Toast.makeText(context, "PDF file located at: ${success.file.name}", Toast.LENGTH_SHORT).show()
                        }
                      },
                      modifier = Modifier
                        .weight(1f)
                        .testTag("pdf_action_open"),
                    ) {
                      Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(stringResource(R.string.pdf_action_open))
                    }

                    OutlinedButton(
                      onClick = {
                        val uri = success.uri
                        if (uri != null) {
                          sharePdf(context, uri, success.file.name)
                        } else {
                          Toast.makeText(context, "PDF file located at: ${success.file.name}", Toast.LENGTH_SHORT).show()
                        }
                      },
                      modifier = Modifier
                        .weight(1f)
                        .testTag("pdf_action_share"),
                    ) {
                      Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(stringResource(R.string.pdf_action_share))
                    }
                  }
                }
              }
            }
          }

          // Section 3: Generating Progress Indicator
          if (uiState.isGenerating) {
            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  val prog = uiState.currentProgress
                  val (current, total) = prog ?: (0 to 1)
                  val fraction = if (total > 0) current.toFloat() / total.toFloat() else 0f

                  Text(
                    text = stringResource(R.string.pdf_generating_progress, current, total),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                  )
                  Spacer(modifier = Modifier.height(8.dp))
                  LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                      .fillMaxWidth()
                      .height(8.dp)
                      .clip(RoundedCornerShape(4.dp)),
                  )
                }
              }
            }
          }

          // Section 4: Attendee Selection Scope
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface,
              ),
              border = CardDefaults.outlinedCardBorder(),
              shape = RoundedCornerShape(16.dp),
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Text(
                  text = stringResource(R.string.pdf_section_guest_selection),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Mode Chips
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  FilterChip(
                    selected = uiState.exportMode == GuestExportMode.ALL,
                    onClick = { viewModel.setExportMode(GuestExportMode.ALL) },
                    label = { Text(stringResource(R.string.pdf_filter_all, uiState.allGuests.size)) },
                    modifier = Modifier.testTag("pdf_filter_all"),
                  )
                  FilterChip(
                    selected = uiState.exportMode == GuestExportMode.CONFIRMED,
                    onClick = { viewModel.setExportMode(GuestExportMode.CONFIRMED) },
                    label = { Text(stringResource(R.string.pdf_filter_confirmed, uiState.confirmedGuests.size)) },
                    modifier = Modifier.testTag("pdf_filter_confirmed"),
                  )
                  FilterChip(
                    selected = uiState.exportMode == GuestExportMode.CUSTOM,
                    onClick = { viewModel.setExportMode(GuestExportMode.CUSTOM) },
                    label = { Text(stringResource(R.string.pdf_filter_custom, uiState.selectedGuestIds.size)) },
                    modifier = Modifier.testTag("pdf_filter_custom"),
                  )
                }

                // Summary Note
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = stringResource(R.string.pdf_export_summary, uiState.effectiveGuestsToExport.size),
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(14.dp))

                // Phase 10: Production Print Summary & Data Quality Controls
                Text(
                  text = stringResource(R.string.pdf_production_summary_title),
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.height(8.dp))

                val quality = uiState.qualitySummary
                Text(
                  text = "${stringResource(R.string.pdf_summary_total_guests, quality.totalRecords)} • ${stringResource(R.string.pdf_summary_empty_slots, quality.emptySlotsCount)} • ${stringResource(R.string.pdf_summary_incomplete_profiles, quality.incompleteGuestsCount)}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Toggle: Include Empty Slots
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pdf_toggle_empty_slots_row"),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = stringResource(R.string.pdf_summary_include_empty_slots),
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.Medium,
                    )
                    Text(
                      text = stringResource(R.string.pdf_summary_include_empty_slots_desc),
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  Spacer(modifier = Modifier.width(12.dp))
                  Switch(
                    checked = uiState.includeEmptySlots,
                    onCheckedChange = { viewModel.setIncludeEmptySlots(it) },
                    modifier = Modifier.testTag("pdf_toggle_empty_slots_switch"),
                  )
                }

                // Toggle: Exclude Incomplete Profiles
                if (quality.incompleteGuestsCount > 0) {
                  Spacer(modifier = Modifier.height(8.dp))
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .testTag("pdf_toggle_exclude_incomplete_row"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = stringResource(R.string.pdf_summary_exclude_incomplete),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                      )
                      Text(
                        text = stringResource(R.string.pdf_summary_incomplete_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                      )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Switch(
                      checked = uiState.excludeIncompleteProfiles,
                      onCheckedChange = { viewModel.setExcludeIncompleteProfiles(it) },
                      modifier = Modifier.testTag("pdf_toggle_exclude_incomplete_switch"),
                    )
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = stringResource(R.string.pdf_summary_expected_rendered, uiState.effectiveGuestsToExport.size),
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.SemiBold,
                  color = MaterialTheme.colorScheme.primary,
                )

                // Custom selection controls
                if (uiState.exportMode == GuestExportMode.CUSTOM) {
                  Spacer(modifier = Modifier.height(12.dp))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    TextButton(onClick = { viewModel.selectAllGuests() }) {
                      Text(stringResource(R.string.pdf_select_all))
                    }
                    TextButton(onClick = { viewModel.deselectAllGuests() }) {
                      Text(stringResource(R.string.pdf_deselect_all))
                    }
                  }

                  OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text(stringResource(R.string.pdf_search_guests_hint)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                      .fillMaxWidth()
                      .testTag("pdf_guest_search_input"),
                  )
                }
              }
            }
          }

          // Section 5: Guest List (when Custom mode is active or to inspect attendees)
          if (uiState.exportMode == GuestExportMode.CUSTOM) {
            val displayGuests = uiState.filteredGuestsForList
            if (displayGuests.isEmpty()) {
              item {
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                  contentAlignment = Alignment.Center,
                ) {
                  Text(
                    text = "No matching attendees found.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
              }
            } else {
              items(displayGuests, key = { it.id }) { guest ->
                GuestSelectionItem(
                  guest = guest,
                  isSelected = uiState.selectedGuestIds.contains(guest.id),
                  onToggle = { viewModel.toggleGuestSelection(guest.id) },
                )
              }
            }
          }

          // Section 6: Prominent Export PDF Action Card
          item {
            val canExport = uiState.selectedEvent != null &&
                uiState.templateWithElements != null &&
                uiState.effectiveGuestsToExport.isNotEmpty() &&
                !uiState.isGenerating

            Card(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("pdf_export_action_card"),
              colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
              ),
              shape = RoundedCornerShape(16.dp),
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Button(
                  onClick = { viewModel.generateBadges() },
                  enabled = canExport,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("export_pdf_button"),
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                  ),
                ) {
                  if (uiState.isGenerating) {
                    CircularProgressIndicator(
                      modifier = Modifier.size(22.dp),
                      color = MaterialTheme.colorScheme.onPrimary,
                      strokeWidth = 2.dp,
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    val prog = uiState.currentProgress
                    Text(
                      text = if (prog != null) {
                        stringResource(R.string.pdf_generating_progress, prog.first, prog.second)
                      } else {
                        stringResource(R.string.pdf_export_action_button)
                      },
                      fontWeight = FontWeight.Bold,
                    )
                  } else {
                    Icon(
                      imageVector = Icons.Default.PictureAsPdf,
                      contentDescription = null,
                      modifier = Modifier.size(22.dp),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    val count = uiState.effectiveGuestsToExport.size
                    Text(
                      text = if (count > 0) {
                        stringResource(R.string.pdf_export_action_button_count, count)
                      } else {
                        stringResource(R.string.pdf_export_action_button)
                      },
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    )
                  }
                }

                if (!canExport && !uiState.isGenerating) {
                  Spacer(modifier = Modifier.height(8.dp))
                  val reason = when {
                    uiState.selectedEvent == null -> stringResource(R.string.guests_no_events_desc)
                    uiState.templateWithElements == null -> stringResource(R.string.pdf_no_template_warning)
                    uiState.effectiveGuestsToExport.isEmpty() -> stringResource(R.string.pdf_no_guests_to_export)
                    else -> ""
                  }
                  if (reason.isNotBlank()) {
                    Text(
                      text = reason,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.error,
                    )
                  }
                }
              }
            }
          }

          // Bottom padding so items are not covered by the FAB
          item {
            Spacer(modifier = Modifier.height(88.dp))
          }
        }
      }
    }
  }
}

@Composable
private fun GuestSelectionItem(
  guest: GuestEntity,
  isSelected: Boolean,
  onToggle: () -> Unit,
  modifier: Modifier = Modifier,
) {
  OutlinedCard(
    onClick = onToggle,
    modifier = modifier
      .fillMaxWidth()
      .testTag("pdf_guest_item_${guest.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.outlinedCardColors(
      containerColor = if (isSelected) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
      } else {
        MaterialTheme.colorScheme.surface
      },
    ),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Checkbox(
        checked = isSelected,
        onCheckedChange = { onToggle() },
        modifier = Modifier.testTag("pdf_guest_checkbox_${guest.id}"),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = guest.fullName,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold,
        )
        if (guest.organization.isNotBlank() || guest.jobTitle.isNotBlank()) {
          val subtitle = listOf(guest.jobTitle, guest.organization)
            .filter { it.isNotBlank() }
            .joinToString(" • ")
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }
  }
}

@Composable
private fun TextButton(
  onClick: () -> Unit,
  content: @Composable () -> Unit,
) {
  Button(
    onClick = onClick,
    colors = ButtonDefaults.buttonColors(
      containerColor = Color.Transparent,
      contentColor = MaterialTheme.colorScheme.primary,
    ),
    elevation = null,
  ) {
    content()
  }
}

private fun openPdf(context: Context, uri: Uri) {
  val intent = Intent(Intent.ACTION_VIEW).apply {
    setDataAndType(uri, "application/pdf")
    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
  }
  try {
    context.startActivity(intent)
  } catch (_: Exception) {
    Toast.makeText(context, "No PDF viewer application found on device.", Toast.LENGTH_SHORT).show()
  }
}

private fun sharePdf(context: Context, uri: Uri, fileName: String) {
  val intent = Intent(Intent.ACTION_SEND).apply {
    type = "application/pdf"
    putExtra(Intent.EXTRA_STREAM, uri)
    putExtra(Intent.EXTRA_SUBJECT, fileName)
    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
  }
  try {
    context.startActivity(Intent.createChooser(intent, "Share Badges PDF"))
  } catch (_: Exception) {
    Toast.makeText(context, "No sharing application found.", Toast.LENGTH_SHORT).show()
  }
}
