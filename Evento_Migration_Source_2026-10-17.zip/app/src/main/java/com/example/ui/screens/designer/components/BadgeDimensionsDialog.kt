package com.example.ui.screens.designer.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.StayCurrentLandscape
import androidx.compose.material.icons.filled.StayCurrentPortrait
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.BadgeOrientation

data class PresetBadgeSize(
  val labelRes: Int,
  val widthMm: Float,
  val heightMm: Float,
)

val BADGE_PRESETS = listOf(
  PresetBadgeSize(R.string.designer_preset_conference, 90f, 60f),
  PresetBadgeSize(R.string.designer_preset_id_card, 85f, 55f),
  PresetBadgeSize(R.string.designer_preset_large_pass, 100f, 70f),
  PresetBadgeSize(R.string.designer_preset_square, 80f, 80f),
)

@Composable
fun BadgeDimensionsDialog(
  currentWidthMm: Float,
  currentHeightMm: Float,
  currentOrientation: BadgeOrientation,
  onApply: (widthMm: Float, heightMm: Float, orientation: BadgeOrientation) -> Unit,
  onDismiss: () -> Unit,
) {
  var selectedWidth by remember { mutableStateOf(currentWidthMm.toString()) }
  var selectedHeight by remember { mutableStateOf(currentHeightMm.toString()) }
  var orientation by remember { mutableStateOf(currentOrientation) }

  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.imePadding(),
    icon = {
      Icon(
        imageVector = Icons.Default.AspectRatio,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
      )
    },
    title = {
      Text(
        text = stringResource(R.string.designer_dimensions_title),
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
      )
    },
    text = {
      val scrollState = rememberScrollState()
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(scrollState)
          .padding(vertical = 4.dp),
      ) {
        // Presets List
        Text(
          text = stringResource(R.string.designer_properties_title),
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(8.dp))

        BADGE_PRESETS.forEach { preset ->
          val isSelected = selectedWidth.toFloatOrNull() == preset.widthMm &&
            selectedHeight.toFloatOrNull() == preset.heightMm

          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 3.dp)
              .clickable {
                selectedWidth = preset.widthMm.toString()
                selectedHeight = preset.heightMm.toString()
              },
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer
              } else {
                MaterialTheme.colorScheme.surfaceVariant
              },
            ),
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = stringResource(preset.labelRes),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              )
              if (isSelected) {
                Icon(
                  imageVector = Icons.Default.Check,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Orientation Selection
        Text(
          text = stringResource(R.string.designer_alignment),
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          FilterChip(
            selected = orientation == BadgeOrientation.LANDSCAPE,
            onClick = { orientation = BadgeOrientation.LANDSCAPE },
            label = { Text(stringResource(R.string.designer_orientation_landscape)) },
            leadingIcon = {
              Icon(Icons.Default.StayCurrentLandscape, contentDescription = null)
            },
            modifier = Modifier.weight(1f),
          )
          FilterChip(
            selected = orientation == BadgeOrientation.PORTRAIT,
            onClick = { orientation = BadgeOrientation.PORTRAIT },
            label = { Text(stringResource(R.string.designer_orientation_portrait)) },
            leadingIcon = {
              Icon(Icons.Default.StayCurrentPortrait, contentDescription = null)
            },
            modifier = Modifier.weight(1f),
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Custom MM Inputs
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          OutlinedTextField(
            value = selectedWidth,
            onValueChange = { selectedWidth = it },
            label = { Text(stringResource(R.string.designer_dimension_width)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f).testTag("input_dimension_width"),
            singleLine = true,
          )
          OutlinedTextField(
            value = selectedHeight,
            onValueChange = { selectedHeight = it },
            label = { Text(stringResource(R.string.designer_dimension_height)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f).testTag("input_dimension_height"),
            singleLine = true,
          )
        }
      }
    },
    confirmButton = {
      TextButton(
        onClick = {
          val w = selectedWidth.toFloatOrNull()?.coerceIn(40f, 250f) ?: 90f
          val h = selectedHeight.toFloatOrNull()?.coerceIn(40f, 250f) ?: 60f
          onApply(w, h, orientation)
          onDismiss()
        },
        modifier = Modifier.testTag("apply_dimensions_button"),
      ) {
        Text(stringResource(R.string.btn_save))
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
  )
}
