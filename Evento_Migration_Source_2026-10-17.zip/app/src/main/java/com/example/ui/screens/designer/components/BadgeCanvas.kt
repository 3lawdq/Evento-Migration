package com.example.ui.screens.designer.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CorporateFare
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.data.model.BadgeOrientation
import com.example.ui.screens.designer.model.PreviewGuest
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun BadgeCanvas(
  template: BadgeTemplateEntity,
  elements: List<BadgeElementEntity>,
  selectedElementId: Long?,
  isPreviewMode: Boolean,
  previewGuest: PreviewGuest,
  eventName: String,
  onSelectElement: (Long?) -> Unit,
  onUpdateElementPosition: (elementId: Long, dxNorm: Float, dyNorm: Float) -> Unit,
  onUpdateElementSize: (elementId: Long, dwNorm: Float, dhNorm: Float) -> Unit,
  modifier: Modifier = Modifier,
  qrBitmap: Bitmap? = null,
  isReadOnly: Boolean = false,
) {
  // Calculate aspect ratio based on millimeters and orientation
  val widthMm = template.widthMm
  val heightMm = template.heightMm
  val isLandscape = template.orientation == BadgeOrientation.LANDSCAPE

  val effectiveWidthMm = if (isLandscape) max(widthMm, heightMm) else min(widthMm, heightMm)
  val effectiveHeightMm = if (isLandscape) min(widthMm, heightMm) else max(widthMm, heightMm)
  val aspectRatio = (effectiveWidthMm / effectiveHeightMm).coerceIn(0.4f, 2.5f)

  val cardBackgroundColor = try {
    Color(android.graphics.Color.parseColor(template.backgroundColor))
  } catch (_: Exception) {
    Color.White
  }

  // Card Outer Container
  Card(
    modifier = modifier
      .fillMaxWidth(if (isLandscape) 0.96f else 0.72f)
      .aspectRatio(aspectRatio)
      .shadow(elevation = 12.dp, shape = RoundedCornerShape(16.dp))
      .testTag("badge_canvas_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = cardBackgroundColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
  ) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
      BoxWithConstraints(
        modifier = Modifier
          .fillMaxSize()
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = { if (!isPreviewMode) onSelectElement(null) },
          )
          .testTag("badge_canvas_box"),
      ) {
        val canvasWidthPx = constraints.maxWidth.toFloat()
        val canvasHeightPx = constraints.maxHeight.toFloat()
        val density = LocalDensity.current

        // Background Image (if configured)
        if (!template.backgroundImageUri.isNullOrBlank()) {
          AsyncImage(
            model = template.backgroundImageUri,
            contentDescription = "Badge Background Image",
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .fillMaxSize()
              .clip(RoundedCornerShape(16.dp)),
          )
        }

        // Lanyard punch hole indicator (top center)
        Box(
          modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 6.dp)
            .width(28.dp)
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFFE2E8F0)),
        )

      // Render Badge Elements
      elements.filter { it.visible }.forEach { element ->
        val isSelected = !isPreviewMode && (element.id == selectedElementId)
        val isQr = element.type.isQr

        // Convert normalized coordinates (0.0 to 1.0) into canvas pixels
        // For QR elements, lock to exact 1:1 square based on canvas width
        val elementLeftPx = element.x * canvasWidthPx
        val elementTopPx = element.y * canvasHeightPx
        val elementWidthPx: Float
        val elementHeightPx: Float
        if (isQr) {
          val sidePx = element.width * canvasWidthPx
          elementWidthPx = sidePx
          elementHeightPx = sidePx
        } else {
          elementWidthPx = element.width * canvasWidthPx
          elementHeightPx = element.height * canvasHeightPx
        }

        val elementWidthDp = with(density) { elementWidthPx.toDp() }
        val elementHeightDp = with(density) { elementHeightPx.toDp() }

        Box(
          modifier = Modifier
            .offset { IntOffset(elementLeftPx.roundToInt(), elementTopPx.roundToInt()) }
            .size(width = elementWidthDp, height = elementHeightDp)
            .rotate(element.rotation)
            .then(
              if (!isPreviewMode && !isReadOnly) {
                Modifier
                  .clickable { onSelectElement(element.id) }
                  .pointerInput(element.id, canvasWidthPx, canvasHeightPx) {
                    detectDragGestures { change, dragAmount ->
                      change.consume()
                      val dxNorm = dragAmount.x / canvasWidthPx
                      val dyNorm = dragAmount.y / canvasHeightPx
                      onUpdateElementPosition(element.id, dxNorm, dyNorm)
                    }
                  }
              } else if (!isPreviewMode) {
                Modifier.clickable { onSelectElement(element.id) }
              } else {
                Modifier
              },
            )
            .then(
              if (isSelected) {
                Modifier.border(
                  width = 2.dp,
                  color = MaterialTheme.colorScheme.primary,
                  shape = RoundedCornerShape(6.dp),
                )
              } else if (!isPreviewMode) {
                Modifier.border(
                  width = 1.dp,
                  color = Color(0x3364748B),
                  shape = RoundedCornerShape(4.dp),
                )
              } else {
                Modifier
              },
            )
            .testTag("badge_element_${element.type.name.lowercase()}"),
        ) {
          // Inner Element Content
          BadgeElementContent(
            element = element,
            previewGuest = previewGuest,
            eventName = eventName,
            qrBitmap = qrBitmap,
            modifier = Modifier.fillMaxSize(),
          )

          // Resize Handle for Selected Element (Bottom-End Corner)
          // QR elements are resized via dedicated horizontal size control in properties panel
          if (isSelected && !isReadOnly && !isQr) {
            Box(
              modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = 6.dp, y = 6.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .pointerInput(element.id, canvasWidthPx, canvasHeightPx) {
                  detectDragGestures { change, dragAmount ->
                    change.consume()
                    val dwNorm = dragAmount.x / canvasWidthPx
                    val dhNorm = dragAmount.y / canvasHeightPx
                    onUpdateElementSize(element.id, dwNorm, dhNorm)
                  }
                }
                .testTag("resize_handle_${element.id}"),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Default.OpenWith,
                contentDescription = "Resize",
                tint = Color.White,
                modifier = Modifier.size(14.dp),
              )
            }
          }
        }
      }

      // Badge physical dimension badge (subtle overlay on bottom corner)
      if (!isPreviewMode) {
        Surface(
          color = Color(0xCC0F172A),
          shape = RoundedCornerShape(topStart = 8.dp),
          modifier = Modifier.align(Alignment.BottomEnd),
        ) {
          Text(
            text = "${effectiveWidthMm.roundToInt()} × ${effectiveHeightMm.roundToInt()} mm",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
          )
        }
      }
    }
    }
  }
}

@Composable
private fun BadgeElementContent(
  element: BadgeElementEntity,
  previewGuest: PreviewGuest,
  eventName: String,
  qrBitmap: Bitmap? = null,
  modifier: Modifier = Modifier,
) {
  val textColor = try {
    Color(android.graphics.Color.parseColor(element.textColor))
  } catch (_: Exception) {
    Color(0xFF1E293B)
  }

  val backgroundColor = element.backgroundColor?.let {
    try {
      Color(android.graphics.Color.parseColor(it))
    } catch (_: Exception) {
      null
    }
  }

  val textAlign = when (element.alignment) {
    BadgeAlignment.START -> TextAlign.Start
    BadgeAlignment.CENTER -> TextAlign.Center
    BadgeAlignment.END -> TextAlign.End
  }

  val fontWeight = if (element.fontWeight.equals("BOLD", ignoreCase = true)) {
    FontWeight.Bold
  } else {
    FontWeight.Normal
  }

  val containerModifier = if (backgroundColor != null) {
    modifier
      .background(backgroundColor, RoundedCornerShape(4.dp))
      .padding(horizontal = 4.dp, vertical = 2.dp)
  } else {
    modifier.padding(horizontal = 2.dp, vertical = 1.dp)
  }

  Box(
    modifier = containerModifier,
    contentAlignment = when (element.alignment) {
      BadgeAlignment.START -> Alignment.CenterStart
      BadgeAlignment.CENTER -> Alignment.Center
      BadgeAlignment.END -> Alignment.CenterEnd
    },
  ) {
    when (element.type) {
      BadgeElementType.ATTENDEE_NAME -> {
        Text(
          text = previewGuest.fullName,
          color = textColor,
          fontSize = element.fontSize.sp,
          fontWeight = fontWeight,
          textAlign = textAlign,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.fillMaxWidth(),
        )
      }

      BadgeElementType.JOB_TITLE -> {
        Text(
          text = previewGuest.jobTitle,
          color = textColor,
          fontSize = element.fontSize.sp,
          fontWeight = fontWeight,
          textAlign = textAlign,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.fillMaxWidth(),
        )
      }

      BadgeElementType.ORGANIZATION -> {
        Text(
          text = previewGuest.organization,
          color = textColor,
          fontSize = element.fontSize.sp,
          fontWeight = fontWeight,
          textAlign = textAlign,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.fillMaxWidth(),
        )
      }

      BadgeElementType.EVENT_NAME -> {
        Text(
          text = element.text ?: eventName.ifBlank { "Event" },
          color = textColor,
          fontSize = element.fontSize.sp,
          fontWeight = fontWeight,
          textAlign = textAlign,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.fillMaxWidth(),
        )
      }

      BadgeElementType.LOGO -> {
        val logoUri = element.text
        if (!logoUri.isNullOrBlank()) {
          AsyncImage(
            model = logoUri,
            contentDescription = stringResource(R.string.designer_element_logo),
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
          )
        } else {
          // Default vector logo placeholder
          Box(
            modifier = Modifier
              .fillMaxSize()
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFFF1F5F9)),
            contentAlignment = Alignment.Center,
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(
                imageVector = Icons.Default.CorporateFare,
                contentDescription = stringResource(R.string.designer_element_logo),
                tint = Color(0xFF64748B),
                modifier = Modifier.size(24.dp),
              )
              Text(
                text = "LOGO",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF64748B),
                fontWeight = FontWeight.Bold,
              )
            }
          }
        }
      }

      BadgeElementType.QR_PLACEHOLDER,
      BadgeElementType.QR -> {
        if (qrBitmap != null) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .clip(RoundedCornerShape(4.dp))
              .background(Color.White)
              .padding(4.dp),
            contentAlignment = Alignment.Center,
          ) {
            Image(
              bitmap = qrBitmap.asImageBitmap(),
              contentDescription = stringResource(R.string.designer_element_qr),
              contentScale = ContentScale.Fit,
              modifier = Modifier
                .fillMaxSize()
                .aspectRatio(1f)
                .testTag("rendered_qr_image"),
            )
          }
        } else {
          // Visual placeholder only. No personal data & no QR generation.
          Box(
            modifier = Modifier
              .fillMaxSize()
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFFF8FAFC))
              .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(6.dp))
              .padding(4.dp),
            contentAlignment = Alignment.Center,
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Icon(
                imageVector = Icons.Default.QrCode2,
                contentDescription = stringResource(R.string.designer_element_qr),
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(32.dp),
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = stringResource(R.string.designer_qr_placeholder_text),
                style = MaterialTheme.typography.labelSmall,
                fontSize = 8.sp,
                color = Color(0xFF64748B),
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
              )
            }
          }
        }
      }
    }
  }
}
