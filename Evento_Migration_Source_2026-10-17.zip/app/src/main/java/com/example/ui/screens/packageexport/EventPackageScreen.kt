package com.example.ui.screens.packageexport

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.util.packageexport.EVENTO_PACKAGE_FORMAT_VERSION
import com.example.util.packageexport.EVENTO_PACKAGE_TYPE
import com.example.util.packageexport.EVENTO_QR_PAYLOAD_FORMAT
import com.example.util.packageexport.EventPackageExportResult
import com.example.util.packageexport.PackageGuestScope

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventPackageScreen(
  viewModel: EventPackageViewModel,
  onOpenMenu: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = stringResource(R.string.package_title),
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            )
            Text(
              text = stringResource(R.string.package_subtitle),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onOpenMenu,
            modifier = Modifier.testTag("package_menu_button"),
          ) {
            Icon(
              imageVector = Icons.Default.Menu,
              contentDescription = stringResource(R.string.nav_menu),
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
        ),
      )
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    floatingActionButton = {
      if (uiState.selectedEvent != null && uiState.effectiveGuestsToExport.isNotEmpty() && !uiState.isExporting) {
        ExtendedFloatingActionButton(
          onClick = { viewModel.exportPackage() },
          icon = { Icon(Icons.Default.Archive, contentDescription = null) },
          text = {
            Text(
              stringResource(
                R.string.package_action_export,
                uiState.effectiveGuestsToExport.size,
              )
            )
          },
          modifier = Modifier.testTag("export_package_fab"),
        )
      }
    },
    modifier = modifier.fillMaxSize().testTag("event_package_screen"),
  ) { paddingValues ->
    if (uiState.isLoadingData) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues),
        contentAlignment = Alignment.Center,
      ) {
        CircularProgressIndicator()
      }
      return@Scaffold
    }

    if (uiState.events.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .padding(24.dp),
        contentAlignment = Alignment.Center,
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Icon(
            imageVector = Icons.Default.Event,
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            tint = MaterialTheme.colorScheme.outline,
          )
          Text(
            text = stringResource(R.string.guests_no_events_title),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          )
          Text(
            text = stringResource(R.string.guests_no_events_desc),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      return@Scaffold
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item { Spacer(modifier = Modifier.height(4.dp)) }

      // 1. Event Selector Card
      item {
        EventSelectorCard(
          events = uiState.events,
          selectedEvent = uiState.selectedEvent,
          onSelectEvent = { viewModel.selectEvent(it) },
        )
      }

      // 2. Package Format & Integrity Information Card
      item {
        PackageMetadataCard(
          formatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
          packageType = EVENTO_PACKAGE_TYPE,
          payloadFormat = EVENTO_QR_PAYLOAD_FORMAT,
          selectedEvent = uiState.selectedEvent,
          guestCount = uiState.effectiveGuestsToExport.size,
          isLicensed = uiState.licenseConfig.isLicenseEnabled,
        )
      }

      // 2b. License Configuration Card
      item {
        LicenseConfigurationCard(
          licenseConfig = uiState.licenseConfig,
          effectiveGuestCount = uiState.effectiveGuestsToExport.size,
          onToggleLicense = { viewModel.setLicenseEnabled(it) },
          onRegenerateId = { viewModel.regenerateLicenseId() },
          onSelectDurationDays = { viewModel.setDurationDays(it) },
          onChangeMaxGuests = { viewModel.setMaxGuestsInput(it) },
          onChangeAllowedDeviceCount = { viewModel.setAllowedDeviceCountInput(it) },
          onToggleDeviceBinding = { viewModel.setDeviceBindingEnabled(it) },
          onChangeBoundDeviceId = { viewModel.setBoundDeviceId(it) },
        )
      }

      // 3. Export Success Result (if available)
      val exportResult = uiState.exportResult
      if (exportResult is EventPackageExportResult.Success) {
        item {
          PackageExportSuccessCard(
            result = exportResult,
            onOpen = { openPackageFile(context, exportResult.uri) },
            onShare = { sharePackageFile(context, exportResult.uri, exportResult.file.name) },
            onDismiss = { viewModel.clearExportResult() },
          )
        }
      }

      // 4. Validation Error Alert (if present)
      uiState.validationError?.let { err ->
        item {
          Card(
            colors = CardDefaults.cardColors(
              containerColor = MaterialTheme.colorScheme.errorContainer,
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("package_error_card"),
          ) {
            Row(
              modifier = Modifier.padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(24.dp),
              )
              Spacer(modifier = Modifier.width(12.dp))
              Text(
                text = err,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer,
              )
            }
          }
        }
      }

      // 5. Guest Scope Selection Chips
      item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = stringResource(R.string.package_section_guest_scope),
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            FilterChip(
              selected = uiState.guestScope == PackageGuestScope.ALL,
              onClick = { viewModel.setGuestScope(PackageGuestScope.ALL) },
              label = { Text(stringResource(R.string.pdf_filter_all, uiState.allGuests.size)) },
              colors = FilterChipDefaults.filterChipColors(),
              modifier = Modifier.testTag("chip_scope_all"),
            )
            FilterChip(
              selected = uiState.guestScope == PackageGuestScope.CONFIRMED,
              onClick = { viewModel.setGuestScope(PackageGuestScope.CONFIRMED) },
              label = { Text(stringResource(R.string.pdf_filter_confirmed, uiState.confirmedGuests.size)) },
              colors = FilterChipDefaults.filterChipColors(),
              modifier = Modifier.testTag("chip_scope_confirmed"),
            )
            FilterChip(
              selected = uiState.guestScope == PackageGuestScope.CUSTOM,
              onClick = { viewModel.setGuestScope(PackageGuestScope.CUSTOM) },
              label = { Text(stringResource(R.string.pdf_filter_custom, uiState.selectedGuestIds.size)) },
              colors = FilterChipDefaults.filterChipColors(),
              modifier = Modifier.testTag("chip_scope_custom"),
            )
          }
        }
      }

      // 6. Custom Selection Filter Controls
      if (uiState.guestScope == PackageGuestScope.CUSTOM) {
        item {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = uiState.searchQuery,
              onValueChange = { viewModel.updateSearchQuery(it) },
              placeholder = { Text(stringResource(R.string.pdf_search_guests_hint)) },
              leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
              trailingIcon = {
                if (uiState.searchQuery.isNotBlank()) {
                  IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                    Icon(Icons.Default.Close, contentDescription = null)
                  }
                }
              },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("package_search_input"),
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "${uiState.selectedGuestIds.size} / ${uiState.allGuests.size} selected",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )

              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                  onClick = { viewModel.selectAllGuests() },
                  contentPadding = ButtonDefaults.TextButtonContentPadding,
                  modifier = Modifier.testTag("package_select_all_btn"),
                ) {
                  Text(stringResource(R.string.pdf_select_all))
                }
                OutlinedButton(
                  onClick = { viewModel.deselectAllGuests() },
                  contentPadding = ButtonDefaults.TextButtonContentPadding,
                  modifier = Modifier.testTag("package_deselect_all_btn"),
                ) {
                  Text(stringResource(R.string.pdf_deselect_all))
                }
              }
            }
          }
        }

        val guestsToShow = uiState.filteredGuestsForList
        if (guestsToShow.isEmpty()) {
          item {
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            ) {
              Box(
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = stringResource(R.string.guests_empty_search_desc),
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        } else {
          items(guestsToShow, key = { it.id }) { guest ->
            GuestSelectionRow(
              guest = guest,
              isSelected = uiState.selectedGuestIds.contains(guest.id),
              onToggle = { viewModel.toggleGuestSelection(guest.id) },
            )
          }
        }
      }

      item { Spacer(modifier = Modifier.height(80.dp)) }
    }
  }
}

@Composable
private fun EventSelectorCard(
  events: List<EventEntity>,
  selectedEvent: EventEntity?,
  onSelectEvent: (EventEntity) -> Unit,
) {
  var expanded by remember { mutableStateOf(false) }

  OutlinedCard(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("package_event_selector_card"),
    shape = RoundedCornerShape(16.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = stringResource(R.string.guests_select_event),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
      )
      Spacer(modifier = Modifier.height(8.dp))

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
          .clickable { expanded = true }
          .padding(horizontal = 16.dp, vertical = 12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = selectedEvent?.name ?: stringResource(R.string.guests_select_event),
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            )
            if (selectedEvent != null) {
              Text(
                text = "${selectedEvent.date} • ${selectedEvent.location}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Icon(
            imageVector = Icons.Default.ArrowDropDown,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        DropdownMenu(
          expanded = expanded,
          onDismissRequest = { expanded = false },
          modifier = Modifier.fillMaxWidth(0.85f),
        ) {
          events.forEach { event ->
            DropdownMenuItem(
              text = {
                Column {
                  Text(
                    text = event.name,
                    style = MaterialTheme.typography.bodyLarge.copy(
                      fontWeight = if (event.id == selectedEvent?.id) FontWeight.Bold else FontWeight.Normal,
                    ),
                  )
                  Text(
                    text = "${event.date} • ${event.location}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
              },
              onClick = {
                onSelectEvent(event)
                expanded = false
              },
              modifier = Modifier.testTag("package_dropdown_item_${event.id}"),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun PackageMetadataCard(
  formatVersion: Int,
  packageType: String,
  payloadFormat: String,
  selectedEvent: EventEntity?,
  guestCount: Int,
  isLicensed: Boolean = false,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
    shape = RoundedCornerShape(16.dp),
    modifier = Modifier.fillMaxWidth().testTag("package_metadata_card"),
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Info,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = stringResource(R.string.package_spec_title),
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        )
      }

      HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
          text = stringResource(R.string.package_label_format_version),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = if (isLicensed) "v$formatVersion ($packageType • V2.1 Signed)" else "v$formatVersion ($packageType • V2 Signed)",
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
        )
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
          text = stringResource(R.string.package_license_type_label),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = stringResource(if (isLicensed) R.string.package_license_option_licensed else R.string.package_license_option_unlicensed),
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
          color = if (isLicensed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
          text = stringResource(R.string.package_label_payload_format),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = payloadFormat,
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary,
        )
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
          text = stringResource(R.string.package_label_integrity),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = "ECDSA P-256 + SHA-256",
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary,
        )
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
          text = stringResource(R.string.package_label_authorized_guests),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = "$guestCount attendees",
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
        )
      }
    }
  }
}

@Composable
private fun LicenseConfigurationCard(
  licenseConfig: LicenseConfigUiState,
  effectiveGuestCount: Int,
  onToggleLicense: (Boolean) -> Unit,
  onRegenerateId: () -> Unit,
  onSelectDurationDays: (Int) -> Unit,
  onChangeMaxGuests: (String) -> Unit,
  onChangeAllowedDeviceCount: (String) -> Unit,
  onToggleDeviceBinding: (Boolean) -> Unit,
  onChangeBoundDeviceId: (String) -> Unit,
) {
  val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }
  val formattedExpiresAt = remember(licenseConfig.expiresAt) {
    if (licenseConfig.expiresAt > 0L) dateFormat.format(Date(licenseConfig.expiresAt)) else "—"
  }
  val formattedIssuedAt = remember(licenseConfig.issuedAt) {
    if (licenseConfig.issuedAt > 0L) dateFormat.format(Date(licenseConfig.issuedAt)) else "—"
  }

  OutlinedCard(
    shape = RoundedCornerShape(16.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("package_license_card"),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Header: Title and Mode Badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.package_license_section_title),
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          )
        }

        Surface(
          color = if (licenseConfig.isLicenseEnabled) {
            MaterialTheme.colorScheme.primaryContainer
          } else {
            MaterialTheme.colorScheme.surfaceVariant
          },
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("package_license_badge"),
        ) {
          Text(
            text = stringResource(
              if (licenseConfig.isLicenseEnabled) R.string.package_license_badge_licensed else R.string.package_license_badge_unlicensed
            ),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (licenseConfig.isLicenseEnabled) {
              MaterialTheme.colorScheme.onPrimaryContainer
            } else {
              MaterialTheme.colorScheme.onSurfaceVariant
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

      // License Mode Toggle (Licensed Package vs Unlicensed Package)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
          Text(
            text = stringResource(
              if (licenseConfig.isLicenseEnabled) R.string.package_license_option_licensed else R.string.package_license_option_unlicensed
            ),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
          )
          Text(
            text = stringResource(
              if (licenseConfig.isLicenseEnabled) R.string.package_license_licensed_desc else R.string.package_license_unlicensed_desc
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        Switch(
          checked = licenseConfig.isLicenseEnabled,
          onCheckedChange = onToggleLicense,
          modifier = Modifier.testTag("package_license_toggle_switch"),
        )
      }

      // If License is enabled, reveal configuration fields
      AnimatedVisibility(visible = licenseConfig.isLicenseEnabled) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
          // 1. License ID with Regenerate Button
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
              text = stringResource(R.string.package_license_id_label),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.SemiBold,
            )
            OutlinedTextField(
              value = licenseConfig.licenseId,
              onValueChange = {},
              readOnly = true,
              leadingIcon = {
                Icon(
                  imageVector = Icons.Default.Key,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              },
              trailingIcon = {
                IconButton(
                  onClick = onRegenerateId,
                  modifier = Modifier.testTag("package_license_regenerate_btn"),
                ) {
                  Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = stringResource(R.string.package_license_id_regenerate),
                  )
                }
              },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("package_license_id_field"),
            )
          }

          // 2. Validity Period & Expiration Preview
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = stringResource(R.string.package_license_duration_label),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.SemiBold,
            )

            val durationPresets = listOf(
              1 to stringResource(R.string.package_license_duration_1d),
              7 to stringResource(R.string.package_license_duration_7d),
              30 to stringResource(R.string.package_license_duration_30d),
              90 to stringResource(R.string.package_license_duration_90d),
              365 to stringResource(R.string.package_license_duration_1y),
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              durationPresets.forEach { (days, label) ->
                FilterChip(
                  selected = licenseConfig.durationDays == days,
                  onClick = { onSelectDurationDays(days) },
                  label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                  modifier = Modifier.testTag("package_license_duration_$days"),
                )
              }
            }

            // Expiration Date/Time Preview
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column {
                  Text(
                    text = stringResource(R.string.package_license_issued_at_label),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                  Text(
                    text = formattedIssuedAt,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                  )
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = stringResource(R.string.package_license_expires_at_label),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                  )
                  Text(
                    text = formattedExpiresAt,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                  )
                }
              }
            }
          }

          // 3. Guest Capacity Limit
          val maxGuestsInt = licenseConfig.maxGuestsInput.trim().toIntOrNull()
          val isCapacityWarning = maxGuestsInt != null && maxGuestsInt < effectiveGuestCount
          OutlinedTextField(
            value = licenseConfig.maxGuestsInput,
            onValueChange = onChangeMaxGuests,
            label = { Text(stringResource(R.string.package_license_max_guests_label)) },
            supportingText = {
              if (isCapacityWarning) {
                Text(
                  text = stringResource(
                    R.string.package_license_error_max_guests_below_count,
                    maxGuestsInt ?: 0,
                    effectiveGuestCount,
                  ),
                  color = MaterialTheme.colorScheme.error,
                )
              } else {
                Text(stringResource(R.string.package_license_max_guests_helper, effectiveGuestCount))
              }
            },
            isError = isCapacityWarning,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("package_license_max_guests_input"),
          )

          // 4. Allowed Device Count
          OutlinedTextField(
            value = licenseConfig.allowedDeviceCountInput,
            onValueChange = onChangeAllowedDeviceCount,
            label = { Text(stringResource(R.string.package_license_allowed_devices_label)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("package_license_devices_input"),
          )

          // 5. Device Binding Section
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                  text = stringResource(R.string.package_license_device_binding_switch),
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                )
                Text(
                  text = stringResource(R.string.package_license_device_binding_desc),
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }

              Switch(
                checked = licenseConfig.isDeviceBindingEnabled,
                onCheckedChange = onToggleDeviceBinding,
                modifier = Modifier.testTag("package_license_binding_switch"),
              )
            }

            if (licenseConfig.isDeviceBindingEnabled) {
              OutlinedTextField(
                value = licenseConfig.boundDeviceId,
                onValueChange = onChangeBoundDeviceId,
                label = { Text(stringResource(R.string.package_license_bound_device_id_label)) },
                placeholder = { Text(stringResource(R.string.package_license_bound_device_id_hint)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("package_license_bound_device_input"),
              )
            }

            Text(
              text = if (licenseConfig.isDeviceBindingEnabled && licenseConfig.boundDeviceId.isNotBlank()) {
                stringResource(R.string.package_license_bound_label, licenseConfig.boundDeviceId.trim())
              } else {
                stringResource(R.string.package_license_unbound_label)
              },
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          // 6. Offline Operation Indicator
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().testTag("package_license_offline_card"),
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = stringResource(R.string.package_license_offline_notice),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PackageExportSuccessCard(
  result: EventPackageExportResult.Success,
  onOpen: () -> Unit,
  onShare: () -> Unit,
  onDismiss: () -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    shape = RoundedCornerShape(16.dp),
    modifier = Modifier.fillMaxWidth().testTag("package_success_card"),
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = stringResource(R.string.package_success_title),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onPrimaryContainer,
          )
        }

        Surface(
          color = if (result.isLicensed) {
            MaterialTheme.colorScheme.primary
          } else {
            MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
          },
          shape = RoundedCornerShape(8.dp),
        ) {
          Text(
            text = stringResource(
              if (result.isLicensed) R.string.package_license_badge_licensed else R.string.package_license_badge_unlicensed
            ),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (result.isLicensed) {
              MaterialTheme.colorScheme.onPrimary
            } else {
              MaterialTheme.colorScheme.onSurface
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      val formattedSize = "${result.fileSizeInBytes / 1024} KB"
      Text(
        text = stringResource(
          R.string.package_success_details,
          result.manifest.eventName,
          result.guestCount,
          result.manifest.packageFormatVersion,
          formattedSize,
        ),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onPrimaryContainer,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Button(
          onClick = onShare,
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          modifier = Modifier.weight(1f).testTag("package_action_share"),
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(stringResource(R.string.package_action_share_label))
        }

        OutlinedButton(
          onClick = onOpen,
          modifier = Modifier.weight(1f).testTag("package_action_open"),
        ) {
          Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(stringResource(R.string.package_action_open_label))
        }

        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("package_action_dismiss"),
        ) {
          Icon(Icons.Default.Close, contentDescription = null)
        }
      }
    }
  }
}

@Composable
private fun GuestSelectionRow(
  guest: GuestEntity,
  isSelected: Boolean,
  onToggle: () -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(10.dp))
      .clickable { onToggle() }
      .padding(vertical = 8.dp, horizontal = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Checkbox(
      checked = isSelected,
      onCheckedChange = { onToggle() },
      modifier = Modifier.testTag("package_guest_cb_${guest.id}"),
    )
    Spacer(modifier = Modifier.width(8.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = guest.fullName,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Bold,
      )
      if (guest.organization.isNotBlank() || guest.jobTitle.isNotBlank()) {
        val subtitle = listOf(guest.jobTitle, guest.organization)
          .filter { it.isNotBlank() }
          .joinToString(" • ")
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}

private fun openPackageFile(context: Context, uri: Uri) {
  val intent = Intent(Intent.ACTION_VIEW).apply {
    setDataAndType(uri, "application/octet-stream")
    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
  }
  try {
    context.startActivity(intent)
  } catch (_: Exception) {
    Toast.makeText(context, "No compatible package viewer found.", Toast.LENGTH_SHORT).show()
  }
}

private fun sharePackageFile(context: Context, uri: Uri, fileName: String) {
  val intent = Intent(Intent.ACTION_SEND).apply {
    type = "application/octet-stream"
    putExtra(Intent.EXTRA_STREAM, uri)
    putExtra(Intent.EXTRA_SUBJECT, fileName)
    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
  }
  try {
    context.startActivity(Intent.createChooser(intent, "Share Event Package (.evento)"))
  } catch (_: Exception) {
    Toast.makeText(context, "No sharing application found.", Toast.LENGTH_SHORT).show()
  }
}
