package com.example.ui.screens.guests

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.importer.ExcelGuestParser
import com.example.data.importer.ExcelImportPreview
import com.example.data.importer.ExcelImportResult
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.DataQualityFilter
import com.example.data.model.EventDataQualitySummary
import com.example.data.model.GuestDataQualityEvaluator
import com.example.data.model.GuestSortOption
import com.example.data.model.InvitationStatus
import com.example.data.repository.EventRepository
import com.example.data.repository.GuestRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

sealed interface ExcelImportDialogState {
  data object Idle : ExcelImportDialogState
  data object Parsing : ExcelImportDialogState
  data class Preview(val preview: ExcelImportPreview) : ExcelImportDialogState
  data object Importing : ExcelImportDialogState
  data class Result(val result: ExcelImportResult) : ExcelImportDialogState
  data class Error(val message: String) : ExcelImportDialogState
}

sealed interface GuestsUiState {
  data object Loading : GuestsUiState
  data class Success(
    val events: List<EventEntity>,
    val selectedEvent: EventEntity?,
    val guests: List<GuestEntity>,
    val totalGuestsInEvent: Int,
    val searchQuery: String,
    val selectedStatusFilter: InvitationStatus?,
    val selectedQualityFilter: DataQualityFilter = DataQualityFilter.ALL,
    val selectedSortOption: GuestSortOption = GuestSortOption.NAME_ASC,
    val selectedGuestIds: Set<Long> = emptySet(),
    val qualitySummary: EventDataQualitySummary = EventDataQualitySummary(),
  ) : GuestsUiState
}

data class GuestFormData(
  val id: Long = 0L,
  val eventId: Long = 0L,
  val uuid: String = "",
  val fullName: String = "",
  val email: String = "",
  val phone: String = "",
  val organization: String = "",
  val jobTitle: String = "",
  val invitationStatus: InvitationStatus = InvitationStatus.INVITED,
  val notes: String = "",
  val fullNameError: Boolean = false,
)

class GuestsViewModel(
  private val guestRepository: GuestRepository,
  private val eventRepository: EventRepository,
) : ViewModel() {

  private val _selectedEventId = MutableStateFlow<Long?>(null)
  val selectedEventId: StateFlow<Long?> = _selectedEventId

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery

  private val _statusFilter = MutableStateFlow<InvitationStatus?>(null)
  val statusFilter: StateFlow<InvitationStatus?> = _statusFilter

  private val _qualityFilter = MutableStateFlow(DataQualityFilter.ALL)
  val qualityFilter: StateFlow<DataQualityFilter> = _qualityFilter

  private val _sortOption = MutableStateFlow(GuestSortOption.NAME_ASC)
  val sortOption: StateFlow<GuestSortOption> = _sortOption

  private val _selectedGuestIds = MutableStateFlow<Set<Long>>(emptySet())
  val selectedGuestIds: StateFlow<Set<Long>> = _selectedGuestIds

  private val _showBulkStatusDialog = MutableStateFlow(false)
  val showBulkStatusDialog: StateFlow<Boolean> = _showBulkStatusDialog

  private val _showBulkOrgDialog = MutableStateFlow(false)
  val showBulkOrgDialog: StateFlow<Boolean> = _showBulkOrgDialog

  private val _showBulkTitleDialog = MutableStateFlow(false)
  val showBulkTitleDialog: StateFlow<Boolean> = _showBulkTitleDialog

  private val _showBulkDeleteDialog = MutableStateFlow(false)
  val showBulkDeleteDialog: StateFlow<Boolean> = _showBulkDeleteDialog

  private val _operationFeedback = MutableStateFlow<String?>(null)
  val operationFeedback: StateFlow<String?> = _operationFeedback

  // Dialog State Machine
  private val _isFormOpen = MutableStateFlow(false)
  val isFormOpen: StateFlow<Boolean> = _isFormOpen

  private val _formState = MutableStateFlow(GuestFormData())
  val formState: StateFlow<GuestFormData> = _formState

  private val _detailsGuest = MutableStateFlow<GuestEntity?>(null)
  val detailsGuest: StateFlow<GuestEntity?> = _detailsGuest

  private val _guestToDelete = MutableStateFlow<GuestEntity?>(null)
  val guestToDelete: StateFlow<GuestEntity?> = _guestToDelete

  // Excel Import State Machine
  private val _excelImportState = MutableStateFlow<ExcelImportDialogState>(ExcelImportDialogState.Idle)
  val excelImportState: StateFlow<ExcelImportDialogState> = _excelImportState

  // Observe all events to populate event selector dropdown
  private val allEventsFlow = eventRepository.getAllEvents()

  // Combined guests state flow reactive to selected event, search, status, quality, sort, and selection
  @OptIn(ExperimentalCoroutinesApi::class)
  val uiState: StateFlow<GuestsUiState> = combine(
    allEventsFlow,
    _selectedEventId,
    _searchQuery,
    _statusFilter,
  ) { events, selectedId, query, filter ->
    val currentSelectedEvent = when {
      events.isEmpty() -> null
      selectedId != null -> events.firstOrNull { it.id == selectedId } ?: events.first()
      else -> events.first()
    }
    if (_selectedEventId.value != currentSelectedEvent?.id) {
      _selectedEventId.value = currentSelectedEvent?.id
      _selectedGuestIds.value = emptySet()
    }
    Triple(events, currentSelectedEvent, Pair(query, filter))
  }.flatMapLatest { (events, selectedEvent, queryAndFilter) ->
    val (query, filter) = queryAndFilter
    if (selectedEvent == null) {
      flowOf(
        GuestsUiState.Success(
          events = events,
          selectedEvent = null,
          guests = emptyList(),
          totalGuestsInEvent = 0,
          searchQuery = query,
          selectedStatusFilter = filter,
          selectedQualityFilter = _qualityFilter.value,
          selectedSortOption = _sortOption.value,
          selectedGuestIds = emptySet(),
          qualitySummary = EventDataQualitySummary(),
        )
      )
    } else {
      combine(
        guestRepository.getGuestsForEvent(selectedEvent.id),
        _qualityFilter,
        _sortOption,
        _selectedGuestIds,
      ) { allGuests, quality, sort, selectedIds ->
        val filtered = allGuests.filter { guest ->
          val matchesStatus = filter == null || guest.invitationStatus == filter
          val matchesSearch = query.isBlank() ||
            guest.fullName.contains(query, ignoreCase = true) ||
            guest.email.contains(query, ignoreCase = true) ||
            guest.phone.contains(query, ignoreCase = true) ||
            guest.organization.contains(query, ignoreCase = true) ||
            guest.jobTitle.contains(query, ignoreCase = true)

          val matchesQuality = when (quality) {
            DataQualityFilter.ALL -> true
            DataQualityFilter.COMPLETE_ONLY -> {
              guest.fullName.isNotBlank() &&
                guest.email.isNotBlank() &&
                guest.phone.isNotBlank() &&
                guest.organization.isNotBlank() &&
                guest.jobTitle.isNotBlank()
            }
            DataQualityFilter.INCOMPLETE_ONLY -> {
              guest.fullName.isNotBlank() && (
                guest.email.isBlank() ||
                  guest.phone.isBlank() ||
                  guest.organization.isBlank() ||
                  guest.jobTitle.isBlank()
              )
            }
            DataQualityFilter.EMPTY_SLOTS_ONLY -> guest.fullName.isBlank()
          }

          matchesStatus && matchesSearch && matchesQuality
        }

        val sorted = when (sort) {
          GuestSortOption.NAME_ASC -> filtered.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.fullName })
          GuestSortOption.NAME_DESC -> filtered.sortedWith(compareByDescending(String.CASE_INSENSITIVE_ORDER) { it.fullName })
          GuestSortOption.ORG_ASC -> filtered.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.organization })
          GuestSortOption.CREATED_DESC -> filtered.sortedByDescending { it.createdAt }
          GuestSortOption.STATUS -> filtered.sortedBy { it.invitationStatus.name }
        }

        val qualitySummary = GuestDataQualityEvaluator.summarize(allGuests)

        GuestsUiState.Success(
          events = events,
          selectedEvent = selectedEvent,
          guests = sorted,
          totalGuestsInEvent = allGuests.size,
          searchQuery = query,
          selectedStatusFilter = filter,
          selectedQualityFilter = quality,
          selectedSortOption = sort,
          selectedGuestIds = selectedIds,
          qualitySummary = qualitySummary,
        )
      }
    }
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = GuestsUiState.Loading,
  )

  fun selectEvent(eventId: Long) {
    if (_selectedEventId.value != eventId) {
      _selectedEventId.value = eventId
      _selectedGuestIds.value = emptySet()
    }
  }

  fun updateSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setStatusFilter(status: InvitationStatus?) {
    _statusFilter.value = status
  }

  fun setQualityFilter(filter: DataQualityFilter) {
    _qualityFilter.value = filter
  }

  fun setSortOption(option: GuestSortOption) {
    _sortOption.value = option
  }

  fun toggleSelectGuest(guestId: Long) {
    val current = _selectedGuestIds.value
    _selectedGuestIds.value = if (current.contains(guestId)) {
      current - guestId
    } else {
      current + guestId
    }
  }

  fun selectAll(visibleGuests: List<GuestEntity>) {
    _selectedGuestIds.value = visibleGuests.map { it.id }.toSet()
  }

  fun clearSelection() {
    _selectedGuestIds.value = emptySet()
  }

  fun openBulkStatusDialog() { _showBulkStatusDialog.value = true }
  fun closeBulkStatusDialog() { _showBulkStatusDialog.value = false }

  fun openBulkOrgDialog() { _showBulkOrgDialog.value = true }
  fun closeBulkOrgDialog() { _showBulkOrgDialog.value = false }

  fun openBulkTitleDialog() { _showBulkTitleDialog.value = true }
  fun closeBulkTitleDialog() { _showBulkTitleDialog.value = false }

  fun openBulkDeleteDialog() { _showBulkDeleteDialog.value = true }
  fun closeBulkDeleteDialog() { _showBulkDeleteDialog.value = false }

  fun clearOperationFeedback() { _operationFeedback.value = null }

  fun bulkUpdateStatus(newStatus: InvitationStatus) {
    val targetEventId = _selectedEventId.value ?: return
    val ids = _selectedGuestIds.value.toList()
    if (ids.isEmpty()) return
    viewModelScope.launch {
      val updatedCount = guestRepository.bulkUpdateStatus(targetEventId, ids, newStatus)
      _selectedGuestIds.value = emptySet()
      _showBulkStatusDialog.value = false
      _operationFeedback.value = "Updated $updatedCount guests successfully"
    }
  }

  fun bulkUpdateOrganization(newOrg: String) {
    val targetEventId = _selectedEventId.value ?: return
    val ids = _selectedGuestIds.value.toList()
    if (ids.isEmpty()) return
    viewModelScope.launch {
      val updatedCount = guestRepository.bulkUpdateOrganization(targetEventId, ids, newOrg)
      _selectedGuestIds.value = emptySet()
      _showBulkOrgDialog.value = false
      _operationFeedback.value = "Updated $updatedCount guests successfully"
    }
  }

  fun bulkUpdateJobTitle(newTitle: String) {
    val targetEventId = _selectedEventId.value ?: return
    val ids = _selectedGuestIds.value.toList()
    if (ids.isEmpty()) return
    viewModelScope.launch {
      val updatedCount = guestRepository.bulkUpdateJobTitle(targetEventId, ids, newTitle)
      _selectedGuestIds.value = emptySet()
      _showBulkTitleDialog.value = false
      _operationFeedback.value = "Updated $updatedCount guests successfully"
    }
  }

  fun bulkDelete() {
    val targetEventId = _selectedEventId.value ?: return
    val ids = _selectedGuestIds.value.toList()
    if (ids.isEmpty()) return
    viewModelScope.launch {
      val deletedCount = guestRepository.bulkDeleteGuests(targetEventId, ids)
      _selectedGuestIds.value = emptySet()
      _showBulkDeleteDialog.value = false
      _operationFeedback.value = "Deleted $deletedCount guests successfully"
    }
  }

  // --- Add / Edit Form Actions ---

  fun openCreateForm() {
    val currentEventId = _selectedEventId.value ?: 0L
    _formState.value = GuestFormData(
      eventId = currentEventId,
      invitationStatus = InvitationStatus.INVITED,
    )
    _isFormOpen.value = true
  }

  fun openEditForm(guest: GuestEntity) {
    _formState.value = GuestFormData(
      id = guest.id,
      eventId = guest.eventId,
      uuid = guest.uuid,
      fullName = guest.fullName,
      email = guest.email,
      phone = guest.phone,
      organization = guest.organization,
      jobTitle = guest.jobTitle,
      invitationStatus = guest.invitationStatus,
      notes = guest.notes,
    )
    _isFormOpen.value = true
  }

  fun updateFormField(
    fullName: String? = null,
    email: String? = null,
    phone: String? = null,
    organization: String? = null,
    jobTitle: String? = null,
    invitationStatus: InvitationStatus? = null,
    notes: String? = null,
  ) {
    val current = _formState.value
    _formState.value = current.copy(
      fullName = fullName ?: current.fullName,
      email = email ?: current.email,
      phone = phone ?: current.phone,
      organization = organization ?: current.organization,
      jobTitle = jobTitle ?: current.jobTitle,
      invitationStatus = invitationStatus ?: current.invitationStatus,
      notes = notes ?: current.notes,
      fullNameError = if (fullName != null) fullName.trim().isEmpty() else current.fullNameError,
    )
  }

  fun closeForm() {
    _isFormOpen.value = false
    _formState.value = GuestFormData()
  }

  fun saveGuest() {
    val form = _formState.value
    if (form.fullName.trim().isEmpty()) {
      _formState.value = form.copy(fullNameError = true)
      return
    }

    viewModelScope.launch {
      val targetEventId = _selectedEventId.value ?: form.eventId
      if (form.id == 0L) {
        // Create new guest with strong UUID generated by repository
        guestRepository.createGuest(
          eventId = targetEventId,
          fullName = form.fullName,
          email = form.email,
          phone = form.phone,
          organization = form.organization,
          jobTitle = form.jobTitle,
          invitationStatus = form.invitationStatus,
          notes = form.notes,
        )
        // If total guests exceed event capacity, increase event capacity accordingly
        val event = eventRepository.getEventByIdSync(targetEventId)
        if (event != null) {
          val totalGuests = guestRepository.getGuestsForEventSync(targetEventId).size
          if (totalGuests > event.guestCapacity) {
            eventRepository.updateEvent(event.copy(guestCapacity = totalGuests))
          }
        }
      } else {
        // Update existing guest (UUID remains untouched)
        val existing = guestRepository.getGuestByIdSync(form.id)
        if (existing != null) {
          val updated = existing.copy(
            fullName = form.fullName,
            email = form.email,
            phone = form.phone,
            organization = form.organization,
            jobTitle = form.jobTitle,
            invitationStatus = form.invitationStatus,
            notes = form.notes,
          )
          guestRepository.updateGuest(updated)
        }
      }
      closeForm()
    }
  }

  // --- Guest Details Dialog Actions ---

  fun openDetails(guest: GuestEntity) {
    _detailsGuest.value = guest
  }

  fun closeDetails() {
    _detailsGuest.value = null
  }

  // --- Destructive Delete Dialog Actions ---

  fun confirmDelete(guest: GuestEntity) {
    _guestToDelete.value = guest
  }

  fun dismissDeleteDialog() {
    _guestToDelete.value = null
  }

  fun executeDelete() {
    val guest = _guestToDelete.value ?: return
    viewModelScope.launch {
      guestRepository.deleteGuest(guest.id)
      _guestToDelete.value = null
      if (_detailsGuest.value?.id == guest.id) {
        _detailsGuest.value = null
      }
    }
  }

  // --- Excel Import Actions ---

  fun processExcelInputStream(inputStream: InputStream, fileName: String) {
    val targetEventId = _selectedEventId.value
    if (targetEventId == null) {
      _excelImportState.value = ExcelImportDialogState.Error("No event is currently selected.")
      return
    }

    _excelImportState.value = ExcelImportDialogState.Parsing

    viewModelScope.launch(Dispatchers.IO) {
      try {
        val existingGuests = guestRepository.getGuestsForEventSync(targetEventId)
        val preview = ExcelGuestParser.parse(
          inputStream = inputStream,
          fileName = fileName,
          existingGuests = existingGuests,
        )

        withContext(Dispatchers.Main) {
          if (preview.totalRows == 0 && preview.detectedColumns.isEmpty()) {
            _excelImportState.value = ExcelImportDialogState.Error("Spreadsheet is empty or could not be read.")
          } else {
            _excelImportState.value = ExcelImportDialogState.Preview(preview)
          }
        }
      } catch (e: Exception) {
        withContext(Dispatchers.Main) {
          _excelImportState.value = ExcelImportDialogState.Error(
            e.localizedMessage ?: "Failed to parse Excel file",
          )
        }
      }
    }
  }

  fun confirmImport(preview: ExcelImportPreview) {
    val targetEventId = _selectedEventId.value ?: return
    val rowsToImport = preview.validRows.filter { it.isValid && !it.isDuplicate }

    if (rowsToImport.isEmpty()) {
      _excelImportState.value = ExcelImportDialogState.Result(
        ExcelImportResult(
          importedCount = 0,
          skippedCount = preview.duplicateRows.size + preview.invalidRows.size,
          invalidCount = preview.invalidRows.size,
          duplicateCount = preview.duplicateRows.size,
        )
      )
      return
    }

    _excelImportState.value = ExcelImportDialogState.Importing

    viewModelScope.launch(Dispatchers.IO) {
      val result = guestRepository.importGuestsTransaction(
        eventId = targetEventId,
        validRows = rowsToImport,
      )
      val finalResult = result.copy(
        skippedCount = preview.invalidRows.size + preview.duplicateRows.size,
        invalidCount = preview.invalidRows.size,
        duplicateCount = preview.duplicateRows.size,
      )
      withContext(Dispatchers.Main) {
        _excelImportState.value = ExcelImportDialogState.Result(finalResult)
      }
    }
  }

  fun dismissExcelImport() {
    _excelImportState.value = ExcelImportDialogState.Idle
  }

  companion object {
    fun provideFactory(
      guestRepository: GuestRepository,
      eventRepository: EventRepository,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return GuestsViewModel(guestRepository, eventRepository) as T
      }
    }
  }
}
