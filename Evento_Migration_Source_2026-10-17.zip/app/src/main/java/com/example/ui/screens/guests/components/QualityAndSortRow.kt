package com.example.ui.screens.guests.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.DataQualityFilter
import com.example.data.model.EventDataQualitySummary
import com.example.data.model.GuestSortOption

@Composable
fun QualitySummaryHeader(
  summary: EventDataQualitySummary,
  modifier: Modifier = Modifier,
) {
  if (summary.totalRecords == 0) return

  Surface(
    shape = RoundedCornerShape(12.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    modifier = modifier
      .fillMaxWidth()
      .testTag("quality_summary_header"),
  ) {
    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.quality_summary_label, summary.completenessPercentage),
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = "${summary.completeGuestsCount} / ${summary.registeredGuestsCount}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      LinearProgressIndicator(
        progress = { summary.completenessPercentage / 100f },
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .testTag("quality_progress_bar"),
      )
    }
  }
}

@Composable
fun QualityAndSortRow(
  selectedQualityFilter: DataQualityFilter,
  selectedSortOption: GuestSortOption,
  summary: EventDataQualitySummary,
  onQualityFilterChange: (DataQualityFilter) -> Unit,
  onSortOptionChange: (GuestSortOption) -> Unit,
  modifier: Modifier = Modifier,
) {
  var sortMenuExpanded by remember { mutableStateOf(false) }

  Row(
    modifier = modifier
      .fillMaxWidth()
      .horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    // Sort dropdown button
    Box {
      OutlinedButton(
        onClick = { sortMenuExpanded = true },
        modifier = Modifier.testTag("guest_sort_button"),
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.Sort,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        val sortLabel = when (selectedSortOption) {
          GuestSortOption.NAME_ASC -> stringResource(R.string.sort_name_asc)
          GuestSortOption.NAME_DESC -> stringResource(R.string.sort_name_desc)
          GuestSortOption.ORG_ASC -> stringResource(R.string.sort_org_asc)
          GuestSortOption.CREATED_DESC -> stringResource(R.string.sort_created_desc)
          GuestSortOption.STATUS -> stringResource(R.string.sort_status)
        }
        Text(
          text = sortLabel,
          style = MaterialTheme.typography.labelMedium,
        )
      }

      DropdownMenu(
        expanded = sortMenuExpanded,
        onDismissRequest = { sortMenuExpanded = false },
        modifier = Modifier.testTag("guest_sort_menu"),
      ) {
        DropdownMenuItem(
          text = { Text(stringResource(R.string.sort_name_asc)) },
          onClick = {
            onSortOptionChange(GuestSortOption.NAME_ASC)
            sortMenuExpanded = false
          },
          modifier = Modifier.testTag("sort_item_name_asc"),
        )
        DropdownMenuItem(
          text = { Text(stringResource(R.string.sort_name_desc)) },
          onClick = {
            onSortOptionChange(GuestSortOption.NAME_DESC)
            sortMenuExpanded = false
          },
          modifier = Modifier.testTag("sort_item_name_desc"),
        )
        DropdownMenuItem(
          text = { Text(stringResource(R.string.sort_org_asc)) },
          onClick = {
            onSortOptionChange(GuestSortOption.ORG_ASC)
            sortMenuExpanded = false
          },
          modifier = Modifier.testTag("sort_item_org_asc"),
        )
        DropdownMenuItem(
          text = { Text(stringResource(R.string.sort_created_desc)) },
          onClick = {
            onSortOptionChange(GuestSortOption.CREATED_DESC)
            sortMenuExpanded = false
          },
          modifier = Modifier.testTag("sort_item_created_desc"),
        )
        DropdownMenuItem(
          text = { Text(stringResource(R.string.sort_status)) },
          onClick = {
            onSortOptionChange(GuestSortOption.STATUS)
            sortMenuExpanded = false
          },
          modifier = Modifier.testTag("sort_item_status"),
        )
      }
    }

    // Quality Filter Chips
    FilterChip(
      selected = selectedQualityFilter == DataQualityFilter.ALL,
      onClick = { onQualityFilterChange(DataQualityFilter.ALL) },
      label = { Text(stringResource(R.string.quality_filter_all, summary.totalRecords)) },
      modifier = Modifier.testTag("quality_chip_all"),
    )

    FilterChip(
      selected = selectedQualityFilter == DataQualityFilter.COMPLETE_ONLY,
      onClick = { onQualityFilterChange(DataQualityFilter.COMPLETE_ONLY) },
      label = { Text(stringResource(R.string.quality_filter_complete, summary.completeGuestsCount)) },
      modifier = Modifier.testTag("quality_chip_complete"),
    )

    FilterChip(
      selected = selectedQualityFilter == DataQualityFilter.INCOMPLETE_ONLY,
      onClick = { onQualityFilterChange(DataQualityFilter.INCOMPLETE_ONLY) },
      label = { Text(stringResource(R.string.quality_filter_incomplete, summary.incompleteGuestsCount)) },
      modifier = Modifier.testTag("quality_chip_incomplete"),
    )

    if (summary.emptySlotsCount > 0) {
      FilterChip(
        selected = selectedQualityFilter == DataQualityFilter.EMPTY_SLOTS_ONLY,
        onClick = { onQualityFilterChange(DataQualityFilter.EMPTY_SLOTS_ONLY) },
        label = { Text(stringResource(R.string.quality_filter_empty_slots, summary.emptySlotsCount)) },
        modifier = Modifier.testTag("quality_chip_empty_slots"),
      )
    }
  }
}
