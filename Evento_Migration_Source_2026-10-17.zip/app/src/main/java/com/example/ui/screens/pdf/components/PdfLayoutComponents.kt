package com.example.ui.screens.pdf.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.model.BadgeOrientation
import com.example.util.pdf.PdfLayoutConfig
import com.example.util.pdf.PdfPageDimensions
import com.example.util.pdf.PdfPaperSize
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Real, mathematically accurate preview of the PDF badge page layout.
 * Reflects selected paper dimensions, orientation, card grid, margins, spacing, and card aspect ratio.
 */
@Composable
fun PdfPageLayoutPreview(
  layoutConfig: PdfLayoutConfig,
  template: BadgeTemplateEntity?,
  totalGuests: Int,
  modifier: Modifier = Modifier,
) {
  val isSingleBadge = layoutConfig.paperSize == PdfPaperSize.SINGLE_BADGE

  val cardW_mm = template?.let {
    if (it.orientation == BadgeOrientation.LANDSCAPE) max(it.widthMm, it.heightMm) else min(it.widthMm, it.heightMm)
  } ?: 85.6f
  val cardH_mm = template?.let {
    if (it.orientation == BadgeOrientation.LANDSCAPE) min(it.widthMm, it.heightMm) else max(it.widthMm, it.heightMm)
  } ?: 53.98f

  val paperW_mm = if (isSingleBadge) cardW_mm else layoutConfig.effectivePaperWidthMm()
  val paperH_mm = if (isSingleBadge) cardH_mm else layoutConfig.effectivePaperHeightMm()

  val paperAspectRatio = if (paperH_mm > 0f) paperW_mm / paperH_mm else 1f
  val fits = layoutConfig.fitsOnPage(cardW_mm, cardH_mm)

  val badgesPerPage = layoutConfig.badgesPerPage
  val totalPages = if (totalGuests > 0) {
    ceil(totalGuests.toFloat() / badgesPerPage.toFloat()).toInt()
  } else 1

  val parsedBgColor = remember(template?.backgroundColor) {
    try {
      Color(android.graphics.Color.parseColor(template?.backgroundColor ?: "#FFFFFF"))
    } catch (_: Exception) {
      Color.White
    }
  }

  Column(
    modifier = modifier.fillMaxWidth(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // Fits warning banner if layout overflows
    if (!fits && !isSingleBadge) {
      Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 12.dp)
          .testTag("pdf_overflow_warning"),
      ) {
        Row(
          modifier = Modifier.padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            Icons.Default.Warning,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.pdf_layout_fits_warning),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onErrorContainer,
            fontWeight = FontWeight.Medium,
          )
        }
      }
    }

    // Sheet Container Box
    BoxWithConstraints(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp),
      contentAlignment = Alignment.Center,
    ) {
      val maxPreviewWidth = if (maxWidth < 240.dp) maxWidth else 240.dp

      Box(
        modifier = Modifier
          .width(maxPreviewWidth)
          .aspectRatio(paperAspectRatio)
          .shadow(6.dp, RoundedCornerShape(6.dp))
          .clip(RoundedCornerShape(6.dp))
          .background(Color.White)
          .border(
            width = if (!fits && !isSingleBadge) 2.dp else 1.dp,
            color = if (!fits && !isSingleBadge) MaterialTheme.colorScheme.error else Color(0xFFCBD5E1),
            shape = RoundedCornerShape(6.dp),
          )
          .testTag("pdf_page_preview_sheet"),
      ) {
        Canvas(modifier = Modifier.matchParentSize()) {
          val canvasW = size.width
          val canvasH = size.height

          val scale = canvasW / paperW_mm

          if (isSingleBadge) {
            // Draw single badge filling the sheet
            drawRoundRect(
              color = parsedBgColor,
              topLeft = Offset.Zero,
              size = Size(canvasW, canvasH),
              cornerRadius = CornerRadius(4f * scale, 4f * scale),
            )
            drawRoundRect(
              color = Color(0xFF94A3B8),
              topLeft = Offset.Zero,
              size = Size(canvasW, canvasH),
              cornerRadius = CornerRadius(4f * scale, 4f * scale),
              style = Stroke(width = 1f * scale),
            )

            // Mini badge content representation
            val miniQrSize = min(canvasW, canvasH) * 0.35f
            drawRoundRect(
              color = Color(0xFF1E293B),
              topLeft = Offset(canvasW - miniQrSize - 8f * scale, (canvasH - miniQrSize) / 2f),
              size = Size(miniQrSize, miniQrSize),
              cornerRadius = CornerRadius(2f * scale, 2f * scale),
            )
            // Mini text lines
            val lineLeft = 8f * scale
            val lineW = (canvasW - miniQrSize - 24f * scale).coerceAtLeast(10f)
            drawRoundRect(
              color = Color(0xFF334155),
              topLeft = Offset(lineLeft, canvasH * 0.3f),
              size = Size(lineW * 0.85f, 6f * scale),
              cornerRadius = CornerRadius(1f * scale, 1f * scale),
            )
            drawRoundRect(
              color = Color(0xFF64748B),
              topLeft = Offset(lineLeft, canvasH * 0.5f),
              size = Size(lineW * 0.6f, 4f * scale),
              cornerRadius = CornerRadius(1f * scale, 1f * scale),
            )
          } else {
            // Margins guideline
            val marginL_px = layoutConfig.marginLeftMm * scale
            val marginT_px = layoutConfig.marginTopMm * scale
            val marginR_px = layoutConfig.marginRightMm * scale
            val marginB_px = layoutConfig.marginBottomMm * scale

            val printableW_px = canvasW - marginL_px - marginR_px
            val printableH_px = canvasH - marginT_px - marginB_px

            if (printableW_px > 0 && printableH_px > 0) {
              val dashPathEffect = PathEffect.dashPathEffect(floatArrayOf(4f * scale, 3f * scale), 0f)
              drawRect(
                color = Color(0x33475569),
                topLeft = Offset(marginL_px, marginT_px),
                size = Size(printableW_px, printableH_px),
                style = Stroke(width = 0.8f * scale, pathEffect = dashPathEffect),
              )
            }

            // Cards Grid
            val cardW_px = cardW_mm * scale
            val cardH_px = cardH_mm * scale
            val spacingH_px = layoutConfig.spacingHorizontalMm * scale
            val spacingV_px = layoutConfig.spacingVerticalMm * scale

            val cols = max(1, layoutConfig.columns)
            val rows = max(1, layoutConfig.rows)

            for (r in 0 until rows) {
              for (c in 0 until cols) {
                val x_px = marginL_px + c * (cardW_px + spacingH_px)
                val y_px = marginT_px + r * (cardH_px + spacingV_px)

                val isOutside = (x_px + cardW_px > canvasW + 0.5f) || (y_px + cardH_px > canvasH + 0.5f) || (x_px < -0.5f) || (y_px < -0.5f)

                // Fill card
                drawRoundRect(
                  color = if (isOutside) Color(0x33EF4444) else parsedBgColor,
                  topLeft = Offset(x_px, y_px),
                  size = Size(cardW_px, cardH_px),
                  cornerRadius = CornerRadius(2f * scale, 2f * scale),
                )

                // Border / Cut marks
                val borderColor = if (isOutside) Color(0xFFDC2626) else if (layoutConfig.showCutMarks) Color(0xFF64748B) else Color(0xFFCBD5E1)
                val strokeWidth = if (isOutside) 1.5f * scale else 0.8f * scale
                drawRoundRect(
                  color = borderColor,
                  topLeft = Offset(x_px, y_px),
                  size = Size(cardW_px, cardH_px),
                  cornerRadius = CornerRadius(2f * scale, 2f * scale),
                  style = Stroke(width = strokeWidth),
                )

                // Stylized micro QR inside each card
                val miniQr = min(cardW_px, cardH_px) * 0.28f
                if (miniQr > 3f) {
                  val qrX = x_px + cardW_px - miniQr - 3f * scale
                  val qrY = y_px + (cardH_px - miniQr) / 2f
                  drawRect(
                    color = if (isOutside) Color(0xFFDC2626) else Color(0xFF1E293B),
                    topLeft = Offset(qrX, qrY),
                    size = Size(miniQr, miniQr),
                  )
                }

                // Micro attendee line
                if (cardW_px > 12f * scale) {
                  val microLineW = (cardW_px * 0.45f).coerceAtLeast(4f)
                  drawRect(
                    color = Color(0xFF475569),
                    topLeft = Offset(x_px + 3f * scale, y_px + cardH_px * 0.35f),
                    size = Size(microLineW, 2f * scale),
                  )
                }
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Readout Summary
    val paperName = if (isSingleBadge) "Single Badge" else layoutConfig.paperSize.displayName
    val orientationText = if (isSingleBadge) {
      if (template?.orientation == BadgeOrientation.LANDSCAPE) "Landscape" else "Portrait"
    } else {
      if (layoutConfig.orientation == BadgeOrientation.LANDSCAPE) stringResource(R.string.pdf_layout_orientation_landscape) else stringResource(R.string.pdf_layout_orientation_portrait)
    }

    Text(
      text = "$paperName • $orientationText",
      style = MaterialTheme.typography.labelMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onSurface,
    )

    if (!isSingleBadge) {
      Text(
        text = stringResource(R.string.pdf_layout_grid_summary, layoutConfig.columns, layoutConfig.rows, badgesPerPage),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = stringResource(R.string.pdf_layout_pages_needed, totalPages),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
      )
    }
  }
}

/**
 * Full configuration card for PDF paper, orientation, grid, margins, and spacing.
 */
@Composable
fun PdfLayoutConfigCard(
  layoutConfig: PdfLayoutConfig,
  template: BadgeTemplateEntity?,
  totalGuests: Int,
  onPaperSizeChange: (PdfPaperSize) -> Unit,
  onOrientationChange: (BadgeOrientation) -> Unit,
  onGridChange: (cols: Int, rows: Int) -> Unit,
  onMarginsChange: (topMm: Float, bottomMm: Float, leftMm: Float, rightMm: Float) -> Unit,
  onSpacingChange: (hMm: Float, vMm: Float) -> Unit,
  onZeroMarginsClick: () -> Unit,
  onShowCutMarksChange: (Boolean) -> Unit,
  modifier: Modifier = Modifier,
) {
  var showPaperDropdown by remember { mutableStateOf(false) }
  var isExpanded by remember { mutableStateOf(false) }

  Card(
    modifier = modifier.fillMaxWidth().testTag("pdf_layout_config_card"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder(),
    shape = RoundedCornerShape(16.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.GridView,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.pdf_layout_config_title),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
          )
        }

        IconButton(
          onClick = { isExpanded = !isExpanded },
          modifier = Modifier.testTag("pdf_toggle_layout_expand"),
        ) {
          Icon(
            if (isExpanded) Icons.Default.ArrowDropDown else Icons.Default.ArrowDropDown,
            contentDescription = null,
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Real Page Preview always visible
      PdfPageLayoutPreview(
        layoutConfig = layoutConfig,
        template = template,
        totalGuests = totalGuests,
        modifier = Modifier.fillMaxWidth(),
      )

      Spacer(modifier = Modifier.height(16.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
      Spacer(modifier = Modifier.height(12.dp))

      // Paper Size Selector
      Text(
        text = stringResource(R.string.pdf_layout_paper_size),
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Spacer(modifier = Modifier.height(4.dp))

      Box(modifier = Modifier.fillMaxWidth()) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          border = CardDefaults.outlinedCardBorder(),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { showPaperDropdown = true }
            .testTag("pdf_paper_size_dropdown"),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = layoutConfig.paperSize.displayName,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Medium,
            )
            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
          }
        }

        DropdownMenu(
          expanded = showPaperDropdown,
          onDismissRequest = { showPaperDropdown = false },
        ) {
          PdfPaperSize.values().forEach { size ->
            DropdownMenuItem(
              text = { Text(size.displayName) },
              onClick = {
                onPaperSizeChange(size)
                showPaperDropdown = false
              },
            )
          }
        }
      }

      // Orientation Selector (if not Single Badge)
      if (layoutConfig.paperSize != PdfPaperSize.SINGLE_BADGE) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = stringResource(R.string.pdf_layout_orientation),
          style = MaterialTheme.typography.bodySmall,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          FilterChip(
            selected = layoutConfig.orientation == BadgeOrientation.PORTRAIT,
            onClick = { onOrientationChange(BadgeOrientation.PORTRAIT) },
            label = { Text(stringResource(R.string.pdf_layout_orientation_portrait)) },
            modifier = Modifier.weight(1f).testTag("pdf_orientation_portrait"),
          )
          FilterChip(
            selected = layoutConfig.orientation == BadgeOrientation.LANDSCAPE,
            onClick = { onOrientationChange(BadgeOrientation.LANDSCAPE) },
            label = { Text(stringResource(R.string.pdf_layout_orientation_landscape)) },
            modifier = Modifier.weight(1f).testTag("pdf_orientation_landscape"),
          )
        }

        // Grid Rows & Columns
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          // Columns
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.pdf_layout_columns),
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              IconButton(
                onClick = { onGridChange(max(1, layoutConfig.columns - 1), layoutConfig.rows) },
                modifier = Modifier.size(36.dp).testTag("pdf_col_decrement"),
              ) {
                Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(18.dp))
              }
              Text(
                text = "${layoutConfig.columns}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(32.dp),
                textAlign = TextAlign.Center,
              )
              IconButton(
                onClick = { onGridChange(min(10, layoutConfig.columns + 1), layoutConfig.rows) },
                modifier = Modifier.size(36.dp).testTag("pdf_col_increment"),
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              }
            }
          }

          // Rows
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.pdf_layout_rows),
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              IconButton(
                onClick = { onGridChange(layoutConfig.columns, max(1, layoutConfig.rows - 1)) },
                modifier = Modifier.size(36.dp).testTag("pdf_row_decrement"),
              ) {
                Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(18.dp))
              }
              Text(
                text = "${layoutConfig.rows}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(32.dp),
                textAlign = TextAlign.Center,
              )
              IconButton(
                onClick = { onGridChange(layoutConfig.columns, min(10, layoutConfig.rows + 1)) },
                modifier = Modifier.size(36.dp).testTag("pdf_row_increment"),
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              }
            }
          }
        }

        // Cut Marks Toggle
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.pdf_layout_cut_marks),
            style = MaterialTheme.typography.bodyMedium,
          )
          Switch(
            checked = layoutConfig.showCutMarks,
            onCheckedChange = onShowCutMarksChange,
            modifier = Modifier.testTag("pdf_cut_marks_switch"),
          )
        }

        // Unified Page Margin Control
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.pdf_margin_slider_label),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
          )
          val isZero = layoutConfig.marginTopMm == 0f && layoutConfig.marginBottomMm == 0f &&
            layoutConfig.marginLeftMm == 0f && layoutConfig.marginRightMm == 0f &&
            layoutConfig.spacingHorizontalMm == 0f && layoutConfig.spacingVerticalMm == 0f

          FilterChip(
            selected = isZero,
            onClick = {
              if (isZero) {
                onMarginsChange(10f, 10f, 10f, 10f)
                onSpacingChange(5f, 5f)
              } else {
                onZeroMarginsClick()
              }
            },
            label = { Text(if (isZero) stringResource(R.string.pdf_layout_zero_margins) else "0 mm") },
            modifier = Modifier.testTag("pdf_zero_margins_chip"),
          )
        }

        // Live margin display
        val currentMarginMm = layoutConfig.marginTopMm.coerceIn(0f, 40f)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.pdf_margin_display, currentMarginMm.roundToInt()),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.testTag("pdf_margin_display_text"),
          )
          Text(
            text = "0 - 40 mm",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        // Horizontal slider: moving right increases margin, moving left decreases margin
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
          Slider(
            value = currentMarginMm,
            onValueChange = { newMargin ->
              val rounded = newMargin.roundToInt().toFloat()
              onMarginsChange(rounded, rounded, rounded, rounded)
            },
            valueRange = 0f..40f,
            steps = 39,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("pdf_margin_slider"),
          )
        }

        // Fine Margins & Spacing (Collapsible)
        AnimatedVisibility(visible = isExpanded) {
          Column(modifier = Modifier.padding(top = 12.dp)) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = "Fine Margins & Spacing",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              MarginPresetChip("Standard (10mm)", layoutConfig.marginTopMm == 10f) {
                onMarginsChange(10f, 10f, 10f, 10f)
                onSpacingChange(5f, 5f)
              }
              MarginPresetChip("Narrow (5mm)", layoutConfig.marginTopMm == 5f) {
                onMarginsChange(5f, 5f, 5f, 5f)
                onSpacingChange(3f, 3f)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun MarginPresetChip(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
) {
  FilterChip(
    selected = selected,
    onClick = onClick,
    label = { Text(label, style = MaterialTheme.typography.labelSmall) },
  )
}
