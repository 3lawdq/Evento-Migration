package com.example.ui.screens.guests.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.InvitationStatus

@Composable
fun BulkActionBar(
  selectedCount: Int,
  totalVisible: Int,
  onSelectAll: () -> Unit,
  onClearSelection: () -> Unit,
  onUpdateStatus: () -> Unit,
  onUpdateOrg: () -> Unit,
  onUpdateTitle: () -> Unit,
  onDeleteSelected: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("bulk_action_bar"),
    shape = RoundedCornerShape(16.dp),
    color = MaterialTheme.colorScheme.secondaryContainer,
    tonalElevation = 4.dp,
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = stringResource(R.string.bulk_selected_count, selectedCount),
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.testTag("bulk_selected_count_text"),
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (selectedCount < totalVisible) {
            OutlinedButton(
              onClick = onSelectAll,
              modifier = Modifier
                .padding(end = 6.dp)
                .testTag("bulk_select_all_btn"),
            ) {
              Icon(Icons.Default.SelectAll, contentDescription = null)
              Spacer(modifier = Modifier.width(4.dp))
              Text(stringResource(R.string.bulk_select_all))
            }
          }

          IconButton(
            onClick = onClearSelection,
            modifier = Modifier.testTag("bulk_clear_btn"),
          ) {
            Icon(
              imageVector = Icons.Default.Clear,
              contentDescription = stringResource(R.string.bulk_clear_selection),
              tint = MaterialTheme.colorScheme.onSecondaryContainer,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Button(
          onClick = onUpdateStatus,
          modifier = Modifier.testTag("bulk_btn_status"),
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text(stringResource(R.string.bulk_update_status))
        }

        OutlinedButton(
          onClick = onUpdateOrg,
          modifier = Modifier.testTag("bulk_btn_org"),
        ) {
          Icon(Icons.Default.Business, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text(stringResource(R.string.bulk_update_organization))
        }

        OutlinedButton(
          onClick = onUpdateTitle,
          modifier = Modifier.testTag("bulk_btn_title"),
        ) {
          Icon(Icons.Default.Title, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text(stringResource(R.string.bulk_update_job_title))
        }

        Button(
          onClick = onDeleteSelected,
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error,
            contentColor = MaterialTheme.colorScheme.onError,
          ),
          modifier = Modifier.testTag("bulk_btn_delete"),
        ) {
          Icon(Icons.Default.Delete, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text(stringResource(R.string.bulk_delete_guests))
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkStatusDialog(
  selectedCount: Int,
  onConfirm: (InvitationStatus) -> Unit,
  onDismiss: () -> Unit,
) {
  var selectedStatus by remember { mutableStateOf(InvitationStatus.CONFIRMED) }
  var expanded by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = stringResource(R.string.bulk_status_dialog_title, selectedCount),
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column {
        Text(
          text = stringResource(R.string.label_guest_invitation_status),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(12.dp))

        ExposedDropdownMenuBox(
          expanded = expanded,
          onExpandedChange = { expanded = !expanded },
        ) {
          OutlinedTextField(
            value = selectedStatus.name,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
              .fillMaxWidth()
              .menuAnchor()
              .testTag("bulk_status_select"),
          )
          ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
          ) {
            InvitationStatus.entries.forEach { status ->
              DropdownMenuItem(
                text = { Text(status.name) },
                onClick = {
                  selectedStatus = status
                  expanded = false
                },
              )
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(selectedStatus) },
        modifier = Modifier.testTag("bulk_status_confirm_btn"),
      ) {
        Text(stringResource(R.string.btn_save))
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("bulk_status_dismiss_btn"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    shape = RoundedCornerShape(20.dp),
    modifier = Modifier.testTag("bulk_status_dialog"),
  )
}

@Composable
fun BulkTextUpdateDialog(
  title: String,
  label: String,
  initialValue: String = "",
  testTagPrefix: String,
  onConfirm: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  var textValue by remember { mutableStateOf(initialValue) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column {
        OutlinedTextField(
          value = textValue,
          onValueChange = { textValue = it },
          label = { Text(label) },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("${testTagPrefix}_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(textValue.trim()) },
        modifier = Modifier.testTag("${testTagPrefix}_confirm_btn"),
      ) {
        Text(stringResource(R.string.btn_save))
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("${testTagPrefix}_dismiss_btn"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    shape = RoundedCornerShape(20.dp),
    modifier = Modifier.testTag("${testTagPrefix}_dialog"),
  )
}

@Composable
fun BulkDeleteConfirmDialog(
  selectedCount: Int,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Delete,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.error,
      )
    },
    title = {
      Text(
        text = stringResource(R.string.bulk_delete_confirm_title, selectedCount),
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Text(
        text = stringResource(R.string.bulk_delete_confirm_msg, selectedCount),
        style = MaterialTheme.typography.bodyMedium,
      )
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.error,
          contentColor = MaterialTheme.colorScheme.onError,
        ),
        modifier = Modifier.testTag("bulk_delete_confirm_btn"),
      ) {
        Text(stringResource(R.string.btn_delete))
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("bulk_delete_dismiss_btn"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    shape = RoundedCornerShape(20.dp),
    modifier = Modifier.testTag("bulk_delete_dialog"),
  )
}
