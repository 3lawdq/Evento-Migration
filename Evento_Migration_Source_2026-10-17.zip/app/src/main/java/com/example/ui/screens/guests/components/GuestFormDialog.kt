package com.example.ui.screens.guests.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.InvitationStatus
import com.example.ui.screens.guests.GuestFormData

@Composable
fun GuestFormDialog(
  formData: GuestFormData,
  onFormFieldChange: (
    fullName: String?,
    email: String?,
    phone: String?,
    organization: String?,
    jobTitle: String?,
    invitationStatus: InvitationStatus?,
    notes: String?,
  ) -> Unit,
  onDismiss: () -> Unit,
  onSave: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val isEdit = formData.id != 0L

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = stringResource(
          if (isEdit) R.string.guest_form_edit_title else R.string.guest_form_add_title
        ),
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        // Full Name (Required)
        OutlinedTextField(
          value = formData.fullName,
          onValueChange = { onFormFieldChange(it, null, null, null, null, null, null) },
          label = { Text(stringResource(R.string.label_guest_full_name)) },
          isError = formData.fullNameError,
          supportingText = if (formData.fullNameError) {
            { Text(stringResource(R.string.error_guest_name_required)) }
          } else null,
          leadingIcon = {
            Icon(Icons.Default.Person, contentDescription = null)
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("guest_input_full_name"),
        )

        // Email (Optional)
        OutlinedTextField(
          value = formData.email,
          onValueChange = { onFormFieldChange(null, it, null, null, null, null, null) },
          label = { Text(stringResource(R.string.label_guest_email)) },
          leadingIcon = {
            Icon(Icons.Default.Email, contentDescription = null)
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Email,
            imeAction = ImeAction.Next,
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("guest_input_email"),
        )

        // Phone (Optional)
        OutlinedTextField(
          value = formData.phone,
          onValueChange = { onFormFieldChange(null, null, it, null, null, null, null) },
          label = { Text(stringResource(R.string.label_guest_phone)) },
          leadingIcon = {
            Icon(Icons.Default.Phone, contentDescription = null)
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Phone,
            imeAction = ImeAction.Next,
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("guest_input_phone"),
        )

        // Organization (Optional)
        OutlinedTextField(
          value = formData.organization,
          onValueChange = { onFormFieldChange(null, null, null, it, null, null, null) },
          label = { Text(stringResource(R.string.label_guest_organization)) },
          leadingIcon = {
            Icon(Icons.Default.Business, contentDescription = null)
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("guest_input_organization"),
        )

        // Job Title (Optional)
        OutlinedTextField(
          value = formData.jobTitle,
          onValueChange = { onFormFieldChange(null, null, null, null, it, null, null) },
          label = { Text(stringResource(R.string.label_guest_job_title)) },
          leadingIcon = {
            Icon(Icons.Default.Work, contentDescription = null)
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("guest_input_job_title"),
        )

        // Status Selector
        Text(
          text = stringResource(R.string.label_guest_invitation_status),
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          listOf(
            InvitationStatus.INVITED to R.string.guest_status_invited,
            InvitationStatus.CONFIRMED to R.string.guest_status_confirmed,
            InvitationStatus.DECLINED to R.string.guest_status_declined,
            InvitationStatus.CHECKED_IN to R.string.guest_status_checked_in,
          ).forEach { (status, labelRes) ->
            FilterChip(
              selected = formData.invitationStatus == status,
              onClick = { onFormFieldChange(null, null, null, null, null, status, null) },
              label = { Text(stringResource(labelRes), style = MaterialTheme.typography.labelSmall) },
              modifier = Modifier.testTag("guest_form_chip_${status.name}"),
            )
          }
        }

        // Notes (Optional)
        OutlinedTextField(
          value = formData.notes,
          onValueChange = { onFormFieldChange(null, null, null, null, null, null, it) },
          label = { Text(stringResource(R.string.label_guest_notes)) },
          leadingIcon = {
            Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.Notes, contentDescription = null)
          },
          maxLines = 3,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("guest_input_notes"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onSave,
        modifier = Modifier.testTag("guest_btn_save"),
      ) {
        Text(stringResource(R.string.btn_save))
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("guest_btn_cancel"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    properties = DialogProperties(usePlatformDefaultWidth = false),
    modifier = modifier
      .fillMaxWidth(0.95f)
      .padding(vertical = 16.dp)
      .imePadding()
      .testTag("guest_form_dialog"),
  )
}
