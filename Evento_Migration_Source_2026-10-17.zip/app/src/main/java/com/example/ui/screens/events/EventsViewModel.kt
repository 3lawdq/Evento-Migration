package com.example.ui.screens.events

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.EventEntity
import com.example.data.model.EventStatus
import com.example.data.repository.EventRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface EventsUiState {
  data object Loading : EventsUiState
  data class Success(
    val events: List<EventEntity>,
    val filteredEvents: List<EventEntity>,
    val selectedStatusFilter: EventStatus?,
    val totalCount: Int,
    val activeCount: Int,
    val draftCount: Int,
    val archivedCount: Int,
  ) : EventsUiState
  data class Error(val message: String) : EventsUiState
}

sealed interface EventFormMode {
  data object Create : EventFormMode
  data class Edit(val eventId: Long) : EventFormMode
}

data class EventFormState(
  val mode: EventFormMode = EventFormMode.Create,
  val name: String = "",
  val description: String = "",
  val date: String = "",
  val location: String = "",
  val organizer: String = "",
  val status: EventStatus = EventStatus.ACTIVE,
  val guestCapacity: String = "0",
  val autoCreateSlots: Boolean = false,
  val nameError: Boolean = false,
  val capacityError: String? = null,
  val isSaving: Boolean = false,
)

sealed interface EventUiEvent {
  data class ShowMessage(val messageRes: Int, val formatArgs: List<String> = emptyList()) : EventUiEvent
}

class EventsViewModel(
  private val repository: EventRepository,
) : ViewModel() {

  private val _statusFilter = MutableStateFlow<EventStatus?>(null)
  val statusFilter: StateFlow<EventStatus?> = _statusFilter.asStateFlow()

  val uiState: StateFlow<EventsUiState> = combine(
    repository.getAllEvents(),
    _statusFilter,
  ) { allEvents, filter ->
    val filtered = if (filter == null) {
      allEvents
    } else {
      allEvents.filter { it.status == filter }
    }
    EventsUiState.Success(
      events = allEvents,
      filteredEvents = filtered,
      selectedStatusFilter = filter,
      totalCount = allEvents.size,
      activeCount = allEvents.count { it.status == EventStatus.ACTIVE },
      draftCount = allEvents.count { it.status == EventStatus.DRAFT },
      archivedCount = allEvents.count { it.status == EventStatus.ARCHIVED },
    )
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = EventsUiState.Loading,
  )

  private val _formState = MutableStateFlow<EventFormState?>(null)
  val formState: StateFlow<EventFormState?> = _formState.asStateFlow()

  private val _viewingEvent = MutableStateFlow<EventEntity?>(null)
  val viewingEvent: StateFlow<EventEntity?> = _viewingEvent.asStateFlow()

  private val _pendingArchiveEvent = MutableStateFlow<EventEntity?>(null)
  val pendingArchiveEvent: StateFlow<EventEntity?> = _pendingArchiveEvent.asStateFlow()

  private val _pendingDeleteEvent = MutableStateFlow<EventEntity?>(null)
  val pendingDeleteEvent: StateFlow<EventEntity?> = _pendingDeleteEvent.asStateFlow()

  private val _pendingDuplicateEvent = MutableStateFlow<EventEntity?>(null)
  val pendingDuplicateEvent: StateFlow<EventEntity?> = _pendingDuplicateEvent.asStateFlow()

  private val _isDuplicating = MutableStateFlow(false)
  val isDuplicating: StateFlow<Boolean> = _isDuplicating.asStateFlow()

  private val _operationMessage = MutableStateFlow<String?>(null)
  val operationMessage: StateFlow<String?> = _operationMessage.asStateFlow()

  private val _eventFlow = MutableSharedFlow<EventUiEvent>()
  val eventFlow: SharedFlow<EventUiEvent> = _eventFlow.asSharedFlow()

  fun setFilter(status: EventStatus?) {
    _statusFilter.value = status
  }

  fun openCreateForm() {
    _formState.value = EventFormState(
      mode = EventFormMode.Create,
      status = EventStatus.ACTIVE,
      guestCapacity = "0",
      autoCreateSlots = true,
    )
  }

  fun openEditForm(event: EventEntity) {
    _formState.value = EventFormState(
      mode = EventFormMode.Edit(event.id),
      name = event.name,
      description = event.description,
      date = event.date,
      location = event.location,
      organizer = event.organizer,
      status = event.status,
      guestCapacity = event.guestCapacity.toString(),
      autoCreateSlots = false,
    )
  }

  fun closeForm() {
    _formState.value = null
  }

  fun openDetails(event: EventEntity) {
    _viewingEvent.value = event
  }

  fun closeDetails() {
    _viewingEvent.value = null
  }

  fun updateFormName(value: String) {
    _formState.value = _formState.value?.copy(name = value, nameError = false)
  }

  fun updateFormDescription(value: String) {
    _formState.value = _formState.value?.copy(description = value)
  }

  fun updateFormDate(value: String) {
    _formState.value = _formState.value?.copy(date = value)
  }

  fun updateFormLocation(value: String) {
    _formState.value = _formState.value?.copy(location = value)
  }

  fun updateFormOrganizer(value: String) {
    _formState.value = _formState.value?.copy(organizer = value)
  }

  fun updateFormStatus(status: EventStatus) {
    _formState.value = _formState.value?.copy(status = status)
  }

  fun updateFormGuestCapacity(value: String) {
    val sanitized = value.filter { it.isDigit() }.take(5)
    _formState.value = _formState.value?.copy(guestCapacity = sanitized, capacityError = null)
  }

  fun updateFormAutoCreateSlots(value: Boolean) {
    _formState.value = _formState.value?.copy(autoCreateSlots = value)
  }

  fun saveForm(slotNameFormat: String? = null) {
    val currentForm = _formState.value ?: return
    val trimmedName = currentForm.name.trim()

    if (trimmedName.isEmpty()) {
      _formState.value = currentForm.copy(nameError = true)
      return
    }

    _formState.value = currentForm.copy(isSaving = true)

    val capacityInt = currentForm.guestCapacity.toIntOrNull() ?: 0

    viewModelScope.launch {
      try {
        when (val mode = currentForm.mode) {
          is EventFormMode.Create -> {
            val shouldCreateSlots = currentForm.autoCreateSlots || capacityInt > 0
            repository.createEvent(
              name = trimmedName,
              description = currentForm.description,
              date = currentForm.date,
              location = currentForm.location,
              organizer = currentForm.organizer,
              status = currentForm.status,
              guestCapacity = capacityInt,
              autoCreateSlots = shouldCreateSlots,
              slotNameFormat = slotNameFormat,
            )
            _formState.value = null
          }
          is EventFormMode.Edit -> {
            val existing = repository.getEventByIdSync(mode.eventId)
            if (existing != null) {
              if (capacityInt != existing.guestCapacity) {
                when (val result = repository.updateEventCapacity(existing.id, capacityInt)) {
                  is com.example.data.repository.CapacityUpdateResult.Blocked -> {
                    _formState.value = currentForm.copy(
                      isSaving = false,
                      capacityError = result.reason,
                    )
                    return@launch
                  }
                  is com.example.data.repository.CapacityUpdateResult.Error -> {
                    _formState.value = currentForm.copy(
                      isSaving = false,
                      capacityError = result.message,
                    )
                    return@launch
                  }
                  is com.example.data.repository.CapacityUpdateResult.Success -> {
                    // Capacity successfully updated
                  }
                }
              }
              val updated = existing.copy(
                name = trimmedName,
                description = currentForm.description,
                date = currentForm.date,
                location = currentForm.location,
                organizer = currentForm.organizer,
                status = currentForm.status,
                guestCapacity = capacityInt,
              )
              repository.updateEvent(updated)
              if (_viewingEvent.value?.id == mode.eventId) {
                _viewingEvent.value = updated
              }
            }
            _formState.value = null
          }
        }
      } catch (_: Exception) {
        _formState.value = currentForm.copy(isSaving = false)
      }
    }
  }

  fun requestArchiveConfirmation(event: EventEntity) {
    _pendingArchiveEvent.value = event
  }

  fun dismissArchiveConfirmation() {
    _pendingArchiveEvent.value = null
  }

  fun confirmArchive() {
    val event = _pendingArchiveEvent.value ?: return
    viewModelScope.launch {
      repository.updateEventStatus(event.id, EventStatus.ARCHIVED)
      _pendingArchiveEvent.value = null
      if (_viewingEvent.value?.id == event.id) {
        _viewingEvent.value = _viewingEvent.value?.copy(status = EventStatus.ARCHIVED)
      }
    }
  }

  fun setEventActive(event: EventEntity) {
    viewModelScope.launch {
      repository.updateEventStatus(event.id, EventStatus.ACTIVE)
      if (_viewingEvent.value?.id == event.id) {
        _viewingEvent.value = _viewingEvent.value?.copy(status = EventStatus.ACTIVE)
      }
    }
  }

  fun requestDeleteConfirmation(event: EventEntity) {
    _pendingDeleteEvent.value = event
  }

  fun dismissDeleteConfirmation() {
    _pendingDeleteEvent.value = null
  }

  fun confirmDelete() {
    val event = _pendingDeleteEvent.value ?: return
    viewModelScope.launch {
      repository.deleteEvent(event.id)
      _pendingDeleteEvent.value = null
      if (_viewingEvent.value?.id == event.id) {
        _viewingEvent.value = null
      }
    }
  }

  fun requestDuplicate(event: EventEntity) {
    _pendingDuplicateEvent.value = event
  }

  fun dismissDuplicate() {
    _pendingDuplicateEvent.value = null
  }

  fun confirmDuplicate(newName: String, copyGuests: Boolean) {
    val event = _pendingDuplicateEvent.value ?: return
    _isDuplicating.value = true
    viewModelScope.launch {
      try {
        val newEventId = repository.duplicateEvent(
          sourceEventId = event.id,
          newName = newName,
          copyGuests = copyGuests,
        )
        _operationMessage.value = "Event duplicated successfully"
        _pendingDuplicateEvent.value = null
      } catch (e: Exception) {
        _operationMessage.value = e.localizedMessage ?: "Failed to duplicate event"
      } finally {
        _isDuplicating.value = false
      }
    }
  }

  fun clearOperationMessage() {
    _operationMessage.value = null
  }

  companion object {
    fun provideFactory(repository: EventRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return EventsViewModel(repository) as T
        }
      }
  }
}
