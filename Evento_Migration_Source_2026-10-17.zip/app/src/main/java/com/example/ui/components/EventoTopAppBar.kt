package com.example.ui.components

import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import com.example.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventoTopAppBar(
  title: String,
  modifier: Modifier = Modifier,
  showBackButton: Boolean = false,
  onNavigationClick: () -> Unit = {},
  actions: @Composable RowScope.() -> Unit = {},
) {
  TopAppBar(
    title = {
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
      )
    },
    navigationIcon = {
      IconButton(
        onClick = onNavigationClick,
        modifier = Modifier.testTag(if (showBackButton) "top_app_bar_back" else "top_app_bar_menu"),
      ) {
        if (showBackButton) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = stringResource(R.string.nav_close),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        } else {
          Icon(
            imageVector = Icons.Default.Menu,
            contentDescription = stringResource(R.string.nav_menu),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }
    },
    actions = actions,
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = MaterialTheme.colorScheme.surface,
      scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer,
    ),
    modifier = modifier.testTag("evento_top_app_bar"),
  )
}
