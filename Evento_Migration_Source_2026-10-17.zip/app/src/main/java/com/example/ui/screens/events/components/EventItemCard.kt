package com.example.ui.screens.events.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.EventEntity
import com.example.data.model.EventStatus

@Composable
fun EventItemCard(
  event: EventEntity,
  onClick: () -> Unit,
  onEdit: () -> Unit,
  onArchive: () -> Unit,
  onRestore: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier,
  onDuplicate: () -> Unit = {},
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("event_card_${event.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    ),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        EventStatusBadge(status = event.status)

        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onDuplicate,
            modifier = Modifier
              .size(48.dp)
              .testTag("duplicate_event_${event.id}"),
          ) {
            Icon(
              imageVector = Icons.Default.ContentCopy,
              contentDescription = stringResource(R.string.btn_duplicate),
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(20.dp),
            )
          }

          IconButton(
            onClick = onEdit,
            modifier = Modifier
              .size(48.dp)
              .testTag("edit_event_${event.id}"),
          ) {
            Icon(
              imageVector = Icons.Default.Edit,
              contentDescription = stringResource(R.string.btn_edit_event),
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp),
            )
          }

          if (event.status != EventStatus.ARCHIVED) {
            IconButton(
              onClick = onArchive,
              modifier = Modifier
                .size(48.dp)
                .testTag("archive_event_${event.id}"),
            ) {
              Icon(
                imageVector = Icons.Default.Archive,
                contentDescription = stringResource(R.string.btn_archive),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
              )
            }
          } else {
            IconButton(
              onClick = onRestore,
              modifier = Modifier
                .size(48.dp)
                .testTag("restore_event_${event.id}"),
            ) {
              Icon(
                imageVector = Icons.Default.Unarchive,
                contentDescription = stringResource(R.string.btn_restore),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp),
              )
            }
          }

          IconButton(
            onClick = onDelete,
            modifier = Modifier
              .size(48.dp)
              .testTag("delete_event_${event.id}"),
          ) {
            Icon(
              imageVector = Icons.Default.Delete,
              contentDescription = stringResource(R.string.btn_delete),
              tint = MaterialTheme.colorScheme.error,
              modifier = Modifier.size(20.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = event.name,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
      )

      if (event.description.isNotBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = event.description,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Metadata chips (Date, Location, Organizer)
      if (event.date.isNotBlank()) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(bottom = 4.dp),
        ) {
          Icon(
            imageVector = Icons.Default.CalendarToday,
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = MaterialTheme.colorScheme.primary,
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = event.date,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      if (event.location.isNotBlank()) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(bottom = 4.dp),
        ) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = MaterialTheme.colorScheme.secondary,
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = event.location,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      if (event.organizer.isNotBlank()) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Default.Person,
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = MaterialTheme.colorScheme.tertiary,
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = event.organizer,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }
  }
}

@Composable
fun EventStatusBadge(
  status: EventStatus,
  modifier: Modifier = Modifier,
) {
  val (bgColor, textColor, labelRes) = when (status) {
    EventStatus.ACTIVE -> Triple(
      MaterialTheme.colorScheme.primaryContainer,
      MaterialTheme.colorScheme.onPrimaryContainer,
      R.string.status_active,
    )
    EventStatus.DRAFT -> Triple(
      MaterialTheme.colorScheme.secondaryContainer,
      MaterialTheme.colorScheme.onSecondaryContainer,
      R.string.status_draft,
    )
    EventStatus.ARCHIVED -> Triple(
      MaterialTheme.colorScheme.surfaceContainerHighest,
      MaterialTheme.colorScheme.onSurfaceVariant,
      R.string.status_archived,
    )
  }

  Surface(
    shape = RoundedCornerShape(8.dp),
    color = bgColor,
    modifier = modifier,
  ) {
    Text(
      text = stringResource(labelRes),
      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
      color = textColor,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}
