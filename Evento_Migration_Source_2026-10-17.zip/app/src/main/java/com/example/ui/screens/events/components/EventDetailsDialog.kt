package com.example.ui.screens.events.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventStatus
import com.example.data.model.ProductionReadinessEvaluator
import com.example.data.model.ReadinessSeverity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EventDetailsDialog(
  event: EventEntity,
  onDismiss: () -> Unit,
  onEdit: () -> Unit,
  onArchive: () -> Unit,
  onRestore: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier,
  guests: List<GuestEntity> = emptyList(),
  activeBadgeTemplate: BadgeTemplateEntity? = null,
) {
  val dateFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
  val createdDateStr = dateFormatter.format(Date(event.createdAt))
  val updatedDateStr = dateFormatter.format(Date(event.updatedAt))
  val readiness = remember(event, guests, activeBadgeTemplate) {
    ProductionReadinessEvaluator.evaluate(
      event = event,
      guests = guests,
      activeBadgeTemplate = activeBadgeTemplate,
    )
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.dialog_event_details_title),
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )
        EventStatusBadge(status = event.status)
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        // Event Name
        Text(
          text = event.name,
          style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary,
        )

        // Description
        if (event.description.isNotBlank()) {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
              containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            ),
          ) {
            Text(
              text = event.description,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(12.dp),
            )
          }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        // Metadata grid
        if (event.date.isNotBlank()) {
          DetailRow(
            icon = Icons.Default.CalendarToday,
            label = stringResource(R.string.field_event_date),
            value = event.date,
          )
        }

        if (event.location.isNotBlank()) {
          DetailRow(
            icon = Icons.Default.LocationOn,
            label = stringResource(R.string.field_event_location),
            value = event.location,
          )
        }

        if (event.organizer.isNotBlank()) {
          DetailRow(
            icon = Icons.Default.Person,
            label = stringResource(R.string.field_event_organizer),
            value = event.organizer,
          )
        }

        DetailRow(
          icon = Icons.Default.Schedule,
          label = stringResource(R.string.label_created_at),
          value = createdDateStr,
        )

        if (event.updatedAt != event.createdAt) {
          DetailRow(
            icon = Icons.Default.Schedule,
            label = stringResource(R.string.label_last_updated),
            value = updatedDateStr,
          )
        }

        // Production Readiness Card
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (readiness.isProductionReady) {
              MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            } else {
              MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
            },
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("event_readiness_card"),
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = stringResource(R.string.readiness_card_title),
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              )
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (readiness.isProductionReady) {
                  MaterialTheme.colorScheme.primary
                } else {
                  MaterialTheme.colorScheme.error
                },
              ) {
                Text(
                  text = "${readiness.scorePercentage}%",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = if (readiness.isProductionReady) {
                    MaterialTheme.colorScheme.onPrimary
                  } else {
                    MaterialTheme.colorScheme.onError
                  },
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                )
              }
            }
            Spacer(modifier = Modifier.height(8.dp))
            readiness.checks.forEach { check ->
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 2.dp),
              ) {
                val (icon, tint) = when (check.severity) {
                  ReadinessSeverity.PASSED -> Icons.Default.CheckCircle to MaterialTheme.colorScheme.primary
                  ReadinessSeverity.WARNING -> Icons.Default.Warning to MaterialTheme.colorScheme.tertiary
                  ReadinessSeverity.CRITICAL -> Icons.Default.Error to MaterialTheme.colorScheme.error
                  ReadinessSeverity.INFO -> Icons.Default.Info to MaterialTheme.colorScheme.secondary
                }
                Icon(
                  imageVector = icon,
                  contentDescription = null,
                  tint = tint,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = check.detail,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurface,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Action Buttons Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedButton(
            onClick = onEdit,
            modifier = Modifier
              .weight(1f)
              .testTag("details_edit_button"),
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(stringResource(R.string.btn_edit_event))
          }

          if (event.status != EventStatus.ARCHIVED) {
            OutlinedButton(
              onClick = onArchive,
              modifier = Modifier
                .weight(1f)
                .testTag("details_archive_button"),
            ) {
              Icon(Icons.Default.Archive, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(stringResource(R.string.btn_archive))
            }
          } else {
            OutlinedButton(
              onClick = onRestore,
              modifier = Modifier
                .weight(1f)
                .testTag("details_restore_button"),
            ) {
              Icon(Icons.Default.Unarchive, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(stringResource(R.string.btn_restore))
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        modifier = Modifier.testTag("details_close_button"),
      ) {
        Text(stringResource(R.string.btn_close))
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDelete,
        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
          contentColor = MaterialTheme.colorScheme.error,
        ),
        modifier = Modifier.testTag("details_delete_button"),
      ) {
        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(stringResource(R.string.btn_delete))
      }
    },
    modifier = modifier.testTag("event_details_dialog"),
    shape = RoundedCornerShape(24.dp),
  )
}

@Composable
private fun DetailRow(
  icon: ImageVector,
  label: String,
  value: String,
  modifier: Modifier = Modifier,
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = modifier.fillMaxWidth(),
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      modifier = Modifier.size(18.dp),
      tint = MaterialTheme.colorScheme.primary,
    )
    Spacer(modifier = Modifier.width(10.dp))
    Column {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurface,
      )
    }
  }
}
