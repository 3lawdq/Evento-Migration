package com.example.ui.screens.pdf

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.BadgeTemplateWithElements
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.EventDataQualitySummary
import com.example.data.model.GuestDataQualityEvaluator
import com.example.data.model.InvitationStatus
import com.example.data.repository.BadgeTemplateRepository
import com.example.data.repository.EventRepository
import com.example.data.repository.GuestRepository
import com.example.util.pdf.PdfGenerationRequest
import com.example.util.pdf.PdfGenerationResult
import com.example.util.pdf.PdfGenerator
import com.example.util.pdf.PdfLayoutConfig
import com.example.util.pdf.PdfPaperSize
import com.example.util.pdf.PdfValidationResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.floor
import kotlin.math.max

enum class GuestExportMode {
  ALL,
  CONFIRMED,
  CUSTOM,
}

data class PdfGeneratorUiState(
  val events: List<EventEntity> = emptyList(),
  val selectedEvent: EventEntity? = null,
  val templateWithElements: BadgeTemplateWithElements? = null,
  val allGuests: List<GuestEntity> = emptyList(),
  val selectedGuestIds: Set<Long> = emptySet(),
  val exportMode: GuestExportMode = GuestExportMode.ALL,
  val searchQuery: String = "",
  val layoutConfig: PdfLayoutConfig = PdfLayoutConfig(),
  val includeEmptySlots: Boolean = true,
  val excludeIncompleteProfiles: Boolean = false,
  val showHighVolumeWarningDialog: Boolean = false,
  val isGenerating: Boolean = false,
  val currentProgress: Pair<Int, Int>? = null,
  val generationResult: PdfGenerationResult? = null,
  val validationError: String? = null,
  val isLoadingData: Boolean = true,
) {
  val confirmedGuests: List<GuestEntity>
    get() = allGuests.filter { it.invitationStatus == InvitationStatus.CONFIRMED }

  val qualitySummary: EventDataQualitySummary
    get() = GuestDataQualityEvaluator.summarize(allGuests)

  val effectiveGuestsToExport: List<GuestEntity>
    get() {
      val baseScope = when (exportMode) {
        GuestExportMode.ALL -> allGuests
        GuestExportMode.CONFIRMED -> confirmedGuests
        GuestExportMode.CUSTOM -> allGuests.filter { selectedGuestIds.contains(it.id) }
      }
      return baseScope.filter { guest ->
        val isEmptySlot = guest.fullName.isBlank()
        if (isEmptySlot && !includeEmptySlots) {
          false
        } else if (!isEmptySlot && excludeIncompleteProfiles) {
          GuestDataQualityEvaluator.evaluateGuest(guest).isComplete
        } else {
          true
        }
      }
    }

  val filteredGuestsForList: List<GuestEntity>
    get() {
      if (searchQuery.isBlank()) return allGuests
      return allGuests.filter {
        it.fullName.contains(searchQuery, ignoreCase = true) ||
          it.organization.contains(searchQuery, ignoreCase = true) ||
          it.jobTitle.contains(searchQuery, ignoreCase = true)
      }
    }
}

class PdfGeneratorViewModel(
  private val eventRepository: EventRepository,
  private val guestRepository: GuestRepository,
  private val badgeTemplateRepository: BadgeTemplateRepository,
  private val pdfGenerator: PdfGenerator,
) : ViewModel() {

  private val _uiState = MutableStateFlow(PdfGeneratorUiState())
  val uiState: StateFlow<PdfGeneratorUiState> = _uiState.asStateFlow()

  private var guestJob: Job? = null
  private var templateJob: Job? = null
  private var generationJob: Job? = null

  init {
    loadEvents()
  }

  private fun loadEvents() {
    viewModelScope.launch {
      eventRepository.getAllEvents().collect { eventList ->
        _uiState.update { current ->
          val selected = current.selectedEvent?.let { prev ->
            eventList.find { it.id == prev.id }
          } ?: eventList.firstOrNull()

          current.copy(
            events = eventList,
            selectedEvent = selected,
            isLoadingData = false,
          )
        }

        _uiState.value.selectedEvent?.let { event ->
          observeEventData(event.id)
        }
      }
    }
  }

  fun selectEvent(eventId: Long) {
    val event = _uiState.value.events.find { it.id == eventId } ?: return
    _uiState.update {
      it.copy(
        selectedEvent = event,
        selectedGuestIds = emptySet(),
        generationResult = null,
        validationError = null,
      )
    }
    observeEventData(eventId)
  }

  private fun observeEventData(eventId: Long) {
    guestJob?.cancel()
    guestJob = viewModelScope.launch {
      guestRepository.getGuestsForEvent(eventId).collect { guests ->
        _uiState.update { current ->
          // If custom mode had selections, preserve matching ones
          val validIds = guests.map { it.id }.toSet()
          val updatedSelections = current.selectedGuestIds.filter { validIds.contains(it) }.toSet()
          current.copy(
            allGuests = guests,
            selectedGuestIds = if (current.exportMode == GuestExportMode.CUSTOM) updatedSelections else validIds,
          )
        }
      }
    }

    templateJob?.cancel()
    templateJob = viewModelScope.launch {
      badgeTemplateRepository.getTemplateWithElements(eventId).collect { templateWithElements ->
        _uiState.update { it.copy(templateWithElements = templateWithElements) }
      }
    }
  }

  fun setExportMode(mode: GuestExportMode) {
    _uiState.update { current ->
      val newSelection = when (mode) {
        GuestExportMode.ALL -> current.allGuests.map { it.id }.toSet()
        GuestExportMode.CONFIRMED -> current.confirmedGuests.map { it.id }.toSet()
        GuestExportMode.CUSTOM -> current.selectedGuestIds
      }
      current.copy(
        exportMode = mode,
        selectedGuestIds = newSelection,
        validationError = null,
      )
    }
  }

  fun toggleGuestSelection(guestId: Long) {
    _uiState.update { current ->
      val newIds = current.selectedGuestIds.toMutableSet()
      if (newIds.contains(guestId)) {
        newIds.remove(guestId)
      } else {
        newIds.add(guestId)
      }
      current.copy(
        exportMode = GuestExportMode.CUSTOM,
        selectedGuestIds = newIds,
        validationError = null,
      )
    }
  }

  fun selectAllGuests() {
    _uiState.update { current ->
      current.copy(
        exportMode = GuestExportMode.CUSTOM,
        selectedGuestIds = current.allGuests.map { it.id }.toSet(),
        validationError = null,
      )
    }
  }

  fun deselectAllGuests() {
    _uiState.update { current ->
      current.copy(
        exportMode = GuestExportMode.CUSTOM,
        selectedGuestIds = emptySet(),
        validationError = null,
      )
    }
  }

  fun setSearchQuery(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun updateLayoutConfig(config: PdfLayoutConfig) {
    _uiState.update { it.copy(layoutConfig = config) }
  }

  fun setPaperSize(paperSize: PdfPaperSize) {
    _uiState.update { current ->
      current.copy(layoutConfig = current.layoutConfig.copy(paperSize = paperSize))
    }
  }

  fun setPaperOrientation(orientation: com.example.data.model.BadgeOrientation) {
    _uiState.update { current ->
      current.copy(layoutConfig = current.layoutConfig.copy(orientation = orientation))
    }
  }

  fun setGrid(columns: Int, rows: Int) {
    _uiState.update { current ->
      current.copy(
        layoutConfig = current.layoutConfig.copy(
          columns = columns.coerceAtLeast(1),
          rows = rows.coerceAtLeast(1),
        )
      )
    }
  }

  fun setMargins(topMm: Float, bottomMm: Float, leftMm: Float, rightMm: Float) {
    _uiState.update { current ->
      current.copy(
        layoutConfig = current.layoutConfig.copy(
          marginTopMm = topMm.coerceAtLeast(0f),
          marginBottomMm = bottomMm.coerceAtLeast(0f),
          marginLeftMm = leftMm.coerceAtLeast(0f),
          marginRightMm = rightMm.coerceAtLeast(0f),
        )
      )
    }
  }

  fun setSpacing(hMm: Float, vMm: Float) {
    _uiState.update { current ->
      current.copy(
        layoutConfig = current.layoutConfig.copy(
          spacingHorizontalMm = hMm.coerceAtLeast(0f),
          spacingVerticalMm = vMm.coerceAtLeast(0f),
        )
      )
    }
  }

  fun setZeroMargins() {
    _uiState.update { current ->
      current.copy(
        layoutConfig = current.layoutConfig.copy(
          marginTopMm = 0f,
          marginBottomMm = 0f,
          marginLeftMm = 0f,
          marginRightMm = 0f,
          spacingHorizontalMm = 0f,
          spacingVerticalMm = 0f,
        )
      )
    }
  }

  fun setShowCutMarks(show: Boolean) {
    _uiState.update { current ->
      current.copy(layoutConfig = current.layoutConfig.copy(showCutMarks = show))
    }
  }

  fun setIncludeEmptySlots(include: Boolean) {
    _uiState.update { it.copy(includeEmptySlots = include) }
  }

  fun setExcludeIncompleteProfiles(exclude: Boolean) {
    _uiState.update { it.copy(excludeIncompleteProfiles = exclude) }
  }

  fun dismissHighVolumeWarning() {
    _uiState.update { it.copy(showHighVolumeWarningDialog = false) }
  }

  fun proceedWithHighVolumeGeneration() {
    _uiState.update { it.copy(showHighVolumeWarningDialog = false) }
    executeGeneration()
  }

  fun generateBadges() {
    val currentState = _uiState.value
    val guestsToExport = currentState.effectiveGuestsToExport
    if (guestsToExport.size > 500) {
      _uiState.update { it.copy(showHighVolumeWarningDialog = true) }
      return
    }
    executeGeneration()
  }

  private fun executeGeneration() {
    val currentState = _uiState.value
    val event = currentState.selectedEvent
    if (event == null) {
      _uiState.update { it.copy(validationError = "Please select an event first.") }
      return
    }

    val templateWithElements = currentState.templateWithElements
    if (templateWithElements == null) {
      _uiState.update {
        it.copy(validationError = "No badge template found for this event. Please configure a template in Card Designer.")
      }
      return
    }

    val guestsToExport = currentState.effectiveGuestsToExport
    if (guestsToExport.isEmpty()) {
      _uiState.update {
        it.copy(validationError = "No attendees selected for badge export.")
      }
      return
    }

    val request = PdfGenerationRequest(
      event = event,
      templateWithElements = templateWithElements,
      guests = guestsToExport,
      layoutConfig = currentState.layoutConfig,
    )

    val validation = pdfGenerator.validate(request)
    if (validation is PdfValidationResult.Invalid) {
      _uiState.update { it.copy(validationError = validation.reason) }
      return
    }

    _uiState.update {
      it.copy(
        isGenerating = true,
        currentProgress = 0 to guestsToExport.size,
        validationError = null,
        generationResult = null,
      )
    }

    generationJob?.cancel()
    generationJob = viewModelScope.launch {
      val result = pdfGenerator.generateBadges(request) { current, total ->
        _uiState.update { it.copy(currentProgress = current to total) }
      }

      _uiState.update {
        it.copy(
          isGenerating = false,
          currentProgress = null,
          generationResult = result,
          validationError = if (result is PdfGenerationResult.Error) result.message else null,
        )
      }
    }
  }

  fun cancelGeneration() {
    generationJob?.cancel()
    _uiState.update {
      it.copy(
        isGenerating = false,
        currentProgress = null,
      )
    }
  }

  fun clearResult() {
    _uiState.update { it.copy(generationResult = null) }
  }

  fun clearError() {
    _uiState.update { it.copy(validationError = null) }
  }

  companion object {
    fun provideFactory(
      eventRepository: EventRepository,
      guestRepository: GuestRepository,
      badgeTemplateRepository: BadgeTemplateRepository,
      pdfGenerator: PdfGenerator,
    ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return PdfGeneratorViewModel(
          eventRepository,
          guestRepository,
          badgeTemplateRepository,
          pdfGenerator,
        ) as T
      }
    }
  }
}
