package com.example.ui.screens.designer.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType

val PRESET_COLORS = listOf(
  "#0F172A", // Slate Dark
  "#0284C7", // Sky Blue
  "#1E293B", // Charcoal
  "#B91C1C", // Crimson
  "#15803D", // Forest Green
  "#7C3AED", // Violet
  "#D97706", // Amber
  "#475569", // Gray
)

@Composable
fun ElementPropertiesPanel(
  element: BadgeElementEntity,
  onUpdateFontSize: (Float) -> Unit,
  onUpdateFontWeight: (String) -> Unit,
  onUpdateAlignment: (BadgeAlignment) -> Unit,
  onUpdateTextColor: (String) -> Unit,
  onUpdateRotation: (Float) -> Unit,
  onUpdateLogoUri: (String?) -> Unit,
  onDeleteElement: () -> Unit,
  onClose: () -> Unit,
  modifier: Modifier = Modifier,
  onUpdateQrSize: (Float) -> Unit = {},
) {
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
    onResult = { uri ->
      if (uri != null) {
        onUpdateLogoUri(uri.toString())
      }
    },
  )

  val elementTitle = when (element.type) {
    BadgeElementType.ATTENDEE_NAME -> stringResource(R.string.designer_element_attendee_name)
    BadgeElementType.JOB_TITLE -> stringResource(R.string.designer_element_job_title)
    BadgeElementType.ORGANIZATION -> stringResource(R.string.designer_element_organization)
    BadgeElementType.EVENT_NAME -> stringResource(R.string.designer_element_event_name)
    BadgeElementType.LOGO -> stringResource(R.string.designer_element_logo)
    BadgeElementType.QR_PLACEHOLDER,
    BadgeElementType.QR -> stringResource(R.string.designer_element_qr)
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
      .testTag("element_properties_panel"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
    ) {
      // Header: Element Title & Close Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = elementTitle,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onDeleteElement,
            modifier = Modifier.testTag("delete_element_button"),
          ) {
            Icon(
              imageVector = Icons.Default.Delete,
              contentDescription = stringResource(R.string.designer_action_delete),
              tint = MaterialTheme.colorScheme.error,
            )
          }
          IconButton(
            onClick = onClose,
            modifier = Modifier.testTag("close_properties_button"),
          ) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Special cases for LOGO and QR
      if (element.type == BadgeElementType.LOGO) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          FilledTonalButton(
            onClick = {
              photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
              )
            },
            modifier = Modifier.weight(1f).testTag("select_logo_button"),
          ) {
            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(stringResource(R.string.designer_select_logo))
          }

          if (!element.text.isNullOrBlank()) {
            OutlinedButton(
              onClick = { onUpdateLogoUri(null) },
              modifier = Modifier.testTag("remove_logo_button"),
            ) {
              Text(stringResource(R.string.designer_remove_logo))
            }
          }
        }
      } else if (element.type == BadgeElementType.QR_PLACEHOLDER || element.type == BadgeElementType.QR) {
        // Visual QR Notice
        Surface(
          color = MaterialTheme.colorScheme.surfaceVariant,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Default.Info,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.designer_qr_reserved_notice),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Horizontal QR Size Slider (Locks 1:1 Aspect Ratio)
        Text(
          text = stringResource(R.string.designer_qr_size_label),
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = stringResource(R.string.designer_qr_size_small),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Slider(
            value = element.width.coerceIn(0.12f, 0.65f),
            onValueChange = onUpdateQrSize,
            valueRange = 0.12f..0.65f,
            modifier = Modifier
              .weight(1f)
              .testTag("qr_size_slider"),
          )
          Text(
            text = stringResource(R.string.designer_qr_size_large),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      } else {
        // Text Controls: Font Size, Weight, Alignment, Colors
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          // Font Size Stepper
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = stringResource(R.string.designer_font_size, element.fontSize),
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Medium,
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
              onClick = { onUpdateFontSize((element.fontSize - 1f).coerceAtLeast(8f)) },
              modifier = Modifier.size(32.dp).testTag("font_size_minus"),
            ) {
              Icon(Icons.Default.Remove, contentDescription = "Decrease size")
            }
            IconButton(
              onClick = { onUpdateFontSize((element.fontSize + 1f).coerceAtMost(36f)) },
              modifier = Modifier.size(32.dp).testTag("font_size_plus"),
            ) {
              Icon(Icons.Default.Add, contentDescription = "Increase size")
            }
          }

          // Bold Toggle
          FilterChip(
            selected = element.fontWeight.equals("BOLD", ignoreCase = true),
            onClick = {
              val newWeight = if (element.fontWeight.equals("BOLD", ignoreCase = true)) "NORMAL" else "BOLD"
              onUpdateFontWeight(newWeight)
            },
            label = { Text(stringResource(R.string.designer_font_weight)) },
            leadingIcon = {
              Icon(Icons.Default.FormatBold, contentDescription = null)
            },
            modifier = Modifier.testTag("font_bold_toggle"),
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Alignment Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.designer_alignment),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          FilterChip(
            selected = element.alignment == BadgeAlignment.START,
            onClick = { onUpdateAlignment(BadgeAlignment.START) },
            label = { Text(stringResource(R.string.designer_align_start)) },
            leadingIcon = { Icon(Icons.AutoMirrored.Filled.FormatAlignLeft, contentDescription = null) },
            modifier = Modifier.weight(1f),
          )
          FilterChip(
            selected = element.alignment == BadgeAlignment.CENTER,
            onClick = { onUpdateAlignment(BadgeAlignment.CENTER) },
            label = { Text(stringResource(R.string.designer_align_center)) },
            leadingIcon = { Icon(Icons.Default.FormatAlignCenter, contentDescription = null) },
            modifier = Modifier.weight(1f),
          )
          FilterChip(
            selected = element.alignment == BadgeAlignment.END,
            onClick = { onUpdateAlignment(BadgeAlignment.END) },
            label = { Text(stringResource(R.string.designer_align_end)) },
            leadingIcon = { Icon(Icons.AutoMirrored.Filled.FormatAlignRight, contentDescription = null) },
            modifier = Modifier.weight(1f),
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Color Palette
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.designer_color),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          PRESET_COLORS.forEach { hexColor ->
            val color = try {
              Color(android.graphics.Color.parseColor(hexColor))
            } catch (_: Exception) {
              Color.Black
            }
            val isSelected = element.textColor.equals(hexColor, ignoreCase = true)

            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(color)
                .clickable { onUpdateTextColor(hexColor) }
                .then(
                  if (isSelected) {
                    Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                  } else {
                    Modifier.border(1.dp, Color(0x33000000), CircleShape)
                  },
                ),
            )
          }
        }
      }
    }
  }
}
