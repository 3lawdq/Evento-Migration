package com.example.ui.screens.events.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.EventStatus
import com.example.ui.screens.events.EventFormMode
import com.example.ui.screens.events.EventFormState

@Composable
fun EventFormDialog(
  formState: EventFormState,
  onNameChange: (String) -> Unit,
  onDescriptionChange: (String) -> Unit,
  onDateChange: (String) -> Unit,
  onLocationChange: (String) -> Unit,
  onOrganizerChange: (String) -> Unit,
  onStatusChange: (EventStatus) -> Unit,
  onGuestCapacityChange: (String) -> Unit = {},
  onAutoCreateSlotsChange: (Boolean) -> Unit = {},
  onSave: () -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val isEditMode = formState.mode is EventFormMode.Edit
  val title = if (isEditMode) {
    stringResource(R.string.dialog_edit_event_title)
  } else {
    stringResource(R.string.dialog_add_event_title)
  }

  AlertDialog(
    onDismissRequest = { if (!formState.isSaving) onDismiss() },
    title = {
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        // Event Name (Required)
        OutlinedTextField(
          value = formState.name,
          onValueChange = onNameChange,
          label = { Text(stringResource(R.string.field_event_name)) },
          placeholder = { Text(stringResource(R.string.field_event_name_hint)) },
          isError = formState.nameError,
          supportingText = {
            if (formState.nameError) {
              Text(
                text = stringResource(R.string.error_event_name_required),
                color = MaterialTheme.colorScheme.error,
              )
            }
          },
          leadingIcon = {
            Icon(Icons.Default.Event, contentDescription = null)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_event_name"),
        )

        // Description (Optional)
        OutlinedTextField(
          value = formState.description,
          onValueChange = onDescriptionChange,
          label = { Text(stringResource(R.string.field_event_description)) },
          placeholder = { Text(stringResource(R.string.field_event_description_hint)) },
          leadingIcon = {
            Icon(Icons.Default.Description, contentDescription = null)
          },
          minLines = 2,
          maxLines = 4,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_event_description"),
        )

        // Date & Time
        OutlinedTextField(
          value = formState.date,
          onValueChange = onDateChange,
          label = { Text(stringResource(R.string.field_event_date)) },
          placeholder = { Text(stringResource(R.string.field_event_date_hint)) },
          leadingIcon = {
            Icon(Icons.Default.CalendarToday, contentDescription = null)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_event_date"),
        )

        // Location / Venue
        OutlinedTextField(
          value = formState.location,
          onValueChange = onLocationChange,
          label = { Text(stringResource(R.string.field_event_location)) },
          placeholder = { Text(stringResource(R.string.field_event_location_hint)) },
          leadingIcon = {
            Icon(Icons.Default.LocationOn, contentDescription = null)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_event_location"),
        )

        // Organizer / Host
        OutlinedTextField(
          value = formState.organizer,
          onValueChange = onOrganizerChange,
          label = { Text(stringResource(R.string.field_event_organizer)) },
          placeholder = { Text(stringResource(R.string.field_event_organizer_hint)) },
          leadingIcon = {
            Icon(Icons.Default.Person, contentDescription = null)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_event_organizer"),
        )

        // Guest Capacity
        OutlinedTextField(
          value = formState.guestCapacity,
          onValueChange = onGuestCapacityChange,
          label = { Text(stringResource(R.string.event_field_guest_capacity)) },
          placeholder = { Text("0") },
          leadingIcon = {
            Icon(Icons.Default.ConfirmationNumber, contentDescription = null)
          },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          isError = formState.capacityError != null,
          supportingText = {
            if (formState.capacityError != null) {
              Text(
                text = formState.capacityError,
                color = MaterialTheme.colorScheme.error,
              )
            } else {
              Text(
                text = stringResource(R.string.event_capacity_info),
                style = MaterialTheme.typography.bodySmall,
              )
            }
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_event_capacity"),
        )

        // Pre-create Empty Guest Slots (Only available when creating new event with capacity > 0)
        if (!isEditMode && (formState.guestCapacity.toIntOrNull() ?: 0) > 0) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("checkbox_auto_create_slots_row"),
          ) {
            Checkbox(
              checked = formState.autoCreateSlots,
              onCheckedChange = onAutoCreateSlotsChange,
              modifier = Modifier.testTag("checkbox_auto_create_slots"),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.event_field_auto_create_slots),
              style = MaterialTheme.typography.bodyMedium,
            )
          }
        }

        // Status Selection
        Text(
          text = stringResource(R.string.field_event_status),
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          EventStatus.entries.forEach { status ->
            val labelRes = when (status) {
              EventStatus.ACTIVE -> R.string.status_active
              EventStatus.DRAFT -> R.string.status_draft
              EventStatus.ARCHIVED -> R.string.status_archived
            }
            FilterChip(
              selected = formState.status == status,
              onClick = { onStatusChange(status) },
              label = { Text(stringResource(labelRes)) },
              modifier = Modifier.testTag("status_chip_${status.name.lowercase()}"),
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onSave,
        enabled = !formState.isSaving,
        modifier = Modifier.testTag("dialog_save_button"),
      ) {
        if (formState.isSaving) {
          CircularProgressIndicator(
            color = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
              .height(16.dp)
              .width(16.dp),
            strokeWidth = 2.dp,
          )
          Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
          text = if (isEditMode) {
            stringResource(R.string.btn_save_changes)
          } else {
            stringResource(R.string.btn_save)
          },
        )
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        enabled = !formState.isSaving,
        modifier = Modifier.testTag("dialog_cancel_button"),
      ) {
        Text(stringResource(R.string.btn_cancel))
      }
    },
    properties = DialogProperties(usePlatformDefaultWidth = false),
    modifier = modifier
      .fillMaxWidth(0.95f)
      .padding(vertical = 16.dp)
      .imePadding()
      .testTag("event_form_dialog"),
    shape = RoundedCornerShape(24.dp),
  )
}
