package com.example.ui.screens.guests.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.entity.GuestEntity
import com.example.data.model.GuestDataQualityEvaluator
import com.example.data.model.InvitationStatus

@Composable
fun GuestItemCard(
  guest: GuestEntity,
  onCardClick: () -> Unit,
  onEditClick: () -> Unit,
  onDeleteClick: () -> Unit,
  modifier: Modifier = Modifier,
  isSelected: Boolean = false,
  onToggleSelect: () -> Unit = {},
  showCheckbox: Boolean = true,
  isReadOnly: Boolean = false,
) {
  var menuExpanded by remember { mutableStateOf(false) }
  val qualityReport = remember(guest) { GuestDataQualityEvaluator.evaluateGuest(guest) }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .clickable(onClick = onCardClick)
      .testTag("guest_card_${guest.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isSelected) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
      } else {
        MaterialTheme.colorScheme.surface
      },
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (showCheckbox) {
            Checkbox(
              checked = isSelected,
              onCheckedChange = { onToggleSelect() },
              modifier = Modifier.testTag("guest_select_checkbox_${guest.id}"),
            )
            Spacer(modifier = Modifier.width(4.dp))
          }

          // Initials Avatar
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(44.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              val initials = guest.fullName
                .split(" ")
                .filter { it.isNotBlank() }
                .take(2)
                .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                .joinToString("")
                .ifEmpty { "G" }

              Text(
                text = initials,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
              )
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = guest.fullName,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            if (guest.jobTitle.isNotBlank() || guest.organization.isNotBlank()) {
              Spacer(modifier = Modifier.height(2.dp))
              val subtitle = buildString {
                if (guest.jobTitle.isNotBlank()) append(guest.jobTitle)
                if (guest.jobTitle.isNotBlank() && guest.organization.isNotBlank()) append(" • ")
                if (guest.organization.isNotBlank()) append(guest.organization)
              }
              Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            if (qualityReport.isEmptySlot) {
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.padding(top = 4.dp).testTag("quality_tag_${guest.id}"),
              ) {
                Text(
                  text = stringResource(R.string.quality_badge_empty_slot),
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
              }
            } else if (!qualityReport.isComplete) {
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 4.dp).testTag("quality_tag_${guest.id}"),
              ) {
                Text(
                  text = stringResource(R.string.quality_badge_incomplete),
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onErrorContainer,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
              }
            }
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          InvitationStatusBadge(status = guest.invitationStatus)

          Box {
            IconButton(
              onClick = { menuExpanded = true },
              modifier = Modifier.testTag("guest_menu_button_${guest.id}"),
            ) {
              Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = "Options",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }

            DropdownMenu(
              expanded = menuExpanded,
              onDismissRequest = { menuExpanded = false },
              modifier = Modifier.testTag("guest_menu_${guest.id}"),
            ) {
              DropdownMenuItem(
                text = { Text(stringResource(R.string.action_view_details)) },
                leadingIcon = {
                  Icon(
                    Icons.Default.Visibility,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                  )
                },
                onClick = {
                  menuExpanded = false
                  onCardClick()
                },
                modifier = Modifier.testTag("guest_action_details_${guest.id}"),
              )
              if (!isReadOnly) {
                DropdownMenuItem(
                  text = { Text(stringResource(R.string.guests_action_edit)) },
                  leadingIcon = {
                    Icon(
                      Icons.Default.Edit,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.secondary,
                    )
                  },
                  onClick = {
                    menuExpanded = false
                    onEditClick()
                  },
                  modifier = Modifier.testTag("guest_action_edit_${guest.id}"),
                )
                DropdownMenuItem(
                  text = {
                    Text(
                      stringResource(R.string.guests_action_delete),
                      color = MaterialTheme.colorScheme.error,
                    )
                  },
                  leadingIcon = {
                    Icon(
                      Icons.Default.Delete,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.error,
                    )
                  },
                  onClick = {
                    menuExpanded = false
                    onDeleteClick()
                  },
                  modifier = Modifier.testTag("guest_action_delete_${guest.id}"),
                )
              }
            }
          }
        }
      }

      // Metadata info row (Email, Phone)
      if (guest.email.isNotBlank() || guest.phone.isNotBlank()) {
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(16.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (guest.email.isNotBlank()) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f, fill = false),
            ) {
              Icon(
                imageVector = Icons.Default.Email,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = guest.email,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }

          if (guest.phone.isNotBlank()) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f, fill = false),
            ) {
              Icon(
                imageVector = Icons.Default.Phone,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = guest.phone,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun InvitationStatusBadge(
  status: InvitationStatus,
  modifier: Modifier = Modifier,
) {
  val (containerColor, contentColor, labelRes) = when (status) {
    InvitationStatus.INVITED -> Triple(
      MaterialTheme.colorScheme.secondaryContainer,
      MaterialTheme.colorScheme.onSecondaryContainer,
      R.string.guest_status_invited,
    )
    InvitationStatus.CONFIRMED -> Triple(
      MaterialTheme.colorScheme.primaryContainer,
      MaterialTheme.colorScheme.onPrimaryContainer,
      R.string.guest_status_confirmed,
    )
    InvitationStatus.DECLINED -> Triple(
      MaterialTheme.colorScheme.errorContainer,
      MaterialTheme.colorScheme.onErrorContainer,
      R.string.guest_status_declined,
    )
    InvitationStatus.CHECKED_IN -> Triple(
      MaterialTheme.colorScheme.tertiaryContainer,
      MaterialTheme.colorScheme.onTertiaryContainer,
      R.string.guest_status_checked_in,
    )
  }

  Surface(
    shape = RoundedCornerShape(8.dp),
    color = containerColor,
    modifier = modifier.testTag("status_badge_${status.name}"),
  ) {
    Text(
      text = stringResource(labelRes),
      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
      color = contentColor,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}
