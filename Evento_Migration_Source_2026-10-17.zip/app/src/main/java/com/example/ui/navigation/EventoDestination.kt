package com.example.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.outlined.Assignment
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.R

enum class NavigationSection(@StringRes val titleRes: Int) {
  CORE(R.string.section_core),
  PRODUCTION(R.string.section_production),
  SYSTEM(R.string.section_system),
}

sealed class EventoDestination(
  val route: String,
  @StringRes val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val section: NavigationSection,
) {
  data object Dashboard : EventoDestination(
    route = "dashboard",
    labelRes = R.string.nav_dashboard,
    selectedIcon = Icons.Filled.Dashboard,
    unselectedIcon = Icons.Outlined.Dashboard,
    section = NavigationSection.CORE,
  )

  data object Events : EventoDestination(
    route = "events",
    labelRes = R.string.nav_events,
    selectedIcon = Icons.Filled.Event,
    unselectedIcon = Icons.Outlined.Event,
    section = NavigationSection.CORE,
  )

  data object Guests : EventoDestination(
    route = "guests",
    labelRes = R.string.nav_guests,
    selectedIcon = Icons.Filled.People,
    unselectedIcon = Icons.Outlined.People,
    section = NavigationSection.CORE,
  )

  data object CardDesigner : EventoDestination(
    route = "card_designer",
    labelRes = R.string.nav_designer,
    selectedIcon = Icons.Filled.Badge,
    unselectedIcon = Icons.Outlined.Badge,
    section = NavigationSection.PRODUCTION,
  )

  data object PdfGenerator : EventoDestination(
    route = "pdf_generator",
    labelRes = R.string.nav_pdf,
    selectedIcon = Icons.Filled.PictureAsPdf,
    unselectedIcon = Icons.Outlined.PictureAsPdf,
    section = NavigationSection.PRODUCTION,
  )

  data object EventPackage : EventoDestination(
    route = "event_package",
    labelRes = R.string.nav_package,
    selectedIcon = Icons.Filled.Archive,
    unselectedIcon = Icons.Outlined.Archive,
    section = NavigationSection.PRODUCTION,
  )

  data object Reports : EventoDestination(
    route = "reports",
    labelRes = R.string.nav_reports,
    selectedIcon = Icons.Filled.Analytics,
    unselectedIcon = Icons.Outlined.Analytics,
    section = NavigationSection.SYSTEM,
  )

  data object Settings : EventoDestination(
    route = "settings",
    labelRes = R.string.nav_settings,
    selectedIcon = Icons.Filled.Settings,
    unselectedIcon = Icons.Outlined.Settings,
    section = NavigationSection.SYSTEM,
  )

  companion object {
    val allDestinations: List<EventoDestination>
      get() = listOf(
        Dashboard,
        Events,
        Guests,
        CardDesigner,
        PdfGenerator,
        EventPackage,
        Reports,
        Settings,
      )

    fun fromRoute(route: String?): EventoDestination {
      return allDestinations.firstOrNull { it.route == route } ?: Dashboard
    }
  }
}
