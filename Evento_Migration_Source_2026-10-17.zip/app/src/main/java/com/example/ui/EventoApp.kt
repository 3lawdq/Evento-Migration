package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.evento.checkin.data.local.CheckInDatabase
import com.evento.checkin.data.repository.CheckInRepository
import com.example.data.local.EventDatabase
import com.example.data.repository.BadgeTemplateRepository
import com.example.data.repository.BadgeTemplateRepositoryImpl
import com.example.data.repository.EventPackageRepository
import com.example.data.repository.EventPackageRepositoryImpl
import com.example.data.repository.EventRepository
import com.example.data.repository.EventRepositoryImpl
import com.example.data.repository.GuestRepository
import com.example.data.repository.GuestRepositoryImpl
import com.example.ui.navigation.EventoDestination
import com.example.ui.navigation.NavigationSection
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.dashboard.DashboardViewModel
import com.example.ui.screens.designer.CardDesignerScreen
import com.example.ui.screens.designer.CardDesignerViewModel
import com.example.ui.screens.events.EventsScreen
import com.example.ui.screens.events.EventsViewModel
import com.example.ui.screens.guests.GuestsScreen
import com.example.ui.screens.guests.GuestsViewModel
import com.example.ui.screens.packageexport.EventPackageScreen
import com.example.ui.screens.packageexport.EventPackageViewModel
import com.example.ui.screens.pdf.PdfGeneratorScreen
import com.example.ui.screens.pdf.PdfGeneratorViewModel
import com.example.ui.screens.reports.AnalyticsViewModel
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.util.packageexport.EventoPackageWriter
import com.example.util.pdf.AndroidPdfGenerator
import com.example.util.pdf.PdfGenerator
import kotlinx.coroutines.launch

@Composable
fun EventoApp(
  modifier: Modifier = Modifier,
  eventRepository: EventRepository? = null,
  guestRepository: GuestRepository? = null,
  badgeTemplateRepository: BadgeTemplateRepository? = null,
  pdfGenerator: PdfGenerator? = null,
  packageRepository: EventPackageRepository? = null,
) {
  val context = LocalContext.current
  val db = remember { EventDatabase.getDatabase(context) }
  val eventRepo = remember(eventRepository) {
    eventRepository ?: EventRepositoryImpl(db.eventDao(), db, context.applicationContext)
  }
  val guestRepo = remember(guestRepository) {
    guestRepository ?: GuestRepositoryImpl(db.guestDao(), db)
  }
  val badgeRepo = remember(badgeTemplateRepository) {
    badgeTemplateRepository ?: BadgeTemplateRepositoryImpl(db.badgeDao())
  }
  val pdfGen = remember(pdfGenerator) {
    pdfGenerator ?: AndroidPdfGenerator(context)
  }

  val eventsViewModel: EventsViewModel = viewModel(
    factory = EventsViewModel.provideFactory(eventRepo),
  )

  val guestsViewModel: GuestsViewModel = viewModel(
    factory = GuestsViewModel.provideFactory(guestRepo, eventRepo),
  )

  val cardDesignerViewModel: CardDesignerViewModel = viewModel(
    factory = CardDesignerViewModel.provideFactory(badgeRepo, eventRepo, guestRepo),
  )

  val pdfGeneratorViewModel: PdfGeneratorViewModel = viewModel(
    factory = PdfGeneratorViewModel.provideFactory(eventRepo, guestRepo, badgeRepo, pdfGen),
  )

  val packageWriter = remember { EventoPackageWriter(context) }
  val packageRepo = remember(packageRepository) {
    packageRepository ?: EventPackageRepositoryImpl(packageWriter, db.exportedPackageDao())
  }

  val dashboardViewModel: DashboardViewModel = viewModel(
    factory = DashboardViewModel.provideFactory(eventRepo, guestRepo, badgeRepo, packageRepo),
  )

  val eventPackageViewModel: EventPackageViewModel = viewModel(
    factory = EventPackageViewModel.provideFactory(eventRepo, guestRepo, packageRepo),
  )

  val checkInRepo = remember {
    CheckInRepository(CheckInDatabase.getInstance(context).checkInDao())
  }

  val analyticsViewModel: AnalyticsViewModel = viewModel(
    factory = AnalyticsViewModel.provideFactory(eventRepo, guestRepo, checkInRepo),
  )

  val navController = rememberNavController()
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: EventoDestination.Dashboard.route

  BackHandler(enabled = drawerState.isOpen) {
    scope.launch { drawerState.close() }
  }

  fun navigateTo(destination: EventoDestination) {
    scope.launch { drawerState.close() }
    navController.navigate(destination.route) {
      popUpTo(navController.graph.findStartDestination().id) {
        saveState = true
      }
      launchSingleTop = true
      restoreState = true
    }
  }

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      ModalDrawerSheet(
        modifier = Modifier
          .width(320.dp)
          .fillMaxHeight()
          .testTag("navigation_drawer"),
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        ) {
          // Drawer Header with Evento branding
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(MaterialTheme.colorScheme.primaryContainer)
              .padding(horizontal = 20.dp, vertical = 24.dp),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Image(
                painter = painterResource(id = R.drawable.ic_evento_admin_logo),
                contentDescription = stringResource(R.string.app_name),
                modifier = Modifier
                  .size(48.dp)
                  .clip(RoundedCornerShape(12.dp)),
              )
              Spacer(modifier = Modifier.width(16.dp))
              Column {
                Text(
                  text = stringResource(R.string.app_name),
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                  text = stringResource(R.string.app_tagline),
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Group destinations by section
          val sections = listOf(
            NavigationSection.CORE,
            NavigationSection.PRODUCTION,
            NavigationSection.SYSTEM,
          )

          sections.forEachIndexed { index, section ->
            if (index > 0) {
              HorizontalDivider(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                color = MaterialTheme.colorScheme.outlineVariant,
              )
            }

            Text(
              text = stringResource(section.titleRes),
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )

            EventoDestination.allDestinations
              .filter { it.section == section }
              .forEach { destination ->
                val selected = currentRoute == destination.route
                NavigationDrawerItem(
                  icon = {
                    Icon(
                      imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                      contentDescription = null,
                    )
                  },
                  label = {
                    Text(
                      text = stringResource(destination.labelRes),
                      style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                      ),
                    )
                  },
                  selected = selected,
                  onClick = { navigateTo(destination) },
                  modifier = Modifier
                    .padding(NavigationDrawerItemDefaults.ItemPadding)
                    .testTag("nav_item_${destination.route}"),
                )
              }
          }

          Spacer(modifier = Modifier.height(16.dp))
        }
      }
    },
    modifier = modifier.fillMaxSize(),
  ) {
    NavHost(
      navController = navController,
      startDestination = EventoDestination.Dashboard.route,
      modifier = Modifier.fillMaxSize(),
    ) {
      composable(EventoDestination.Dashboard.route) {
        DashboardScreen(
          dashboardViewModel = dashboardViewModel,
          eventsViewModel = eventsViewModel,
          onNavigateTo = { dest -> navigateTo(dest) },
          onOpenMenu = { scope.launch { drawerState.open() } },
        )
      }
      composable(EventoDestination.Events.route) {
        EventsScreen(
          viewModel = eventsViewModel,
          onOpenMenu = { scope.launch { drawerState.open() } },
        )
      }
      composable(EventoDestination.Guests.route) {
        GuestsScreen(
          viewModel = guestsViewModel,
          onOpenMenu = { scope.launch { drawerState.open() } },
          onNavigateToEvents = { navigateTo(EventoDestination.Events) },
        )
      }
      composable(EventoDestination.CardDesigner.route) {
        CardDesignerScreen(
          viewModel = cardDesignerViewModel,
          onOpenMenu = { scope.launch { drawerState.open() } },
        )
      }
      composable(EventoDestination.PdfGenerator.route) {
        PdfGeneratorScreen(
          viewModel = pdfGeneratorViewModel,
          onOpenMenu = { scope.launch { drawerState.open() } },
          onNavigateToDesigner = { navigateTo(EventoDestination.CardDesigner) },
        )
      }
      composable(EventoDestination.EventPackage.route) {
        EventPackageScreen(
          viewModel = eventPackageViewModel,
          onOpenMenu = { scope.launch { drawerState.open() } },
        )
      }
      composable(EventoDestination.Reports.route) {
        ReportsScreen(
          viewModel = analyticsViewModel,
          onOpenMenu = { scope.launch { drawerState.open() } },
        )
      }
      composable(EventoDestination.Settings.route) {
        SettingsScreen(
          onOpenMenu = { scope.launch { drawerState.open() } },
        )
      }
    }
  }
}
