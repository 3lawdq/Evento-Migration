package com.example.util.qr

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

/**
 * QR Code Generator Service for Evento Badges.
 *
 * Responsibilities:
 * - Input: Guest UUID
 * - Output: Square, high-error-correction (Level H) black & white Bitmap.
 * - Validates UUID format before encoding.
 * - Encodes payload strictly as "EVT1:<uuid>" with zero PII.
 * - Does NOT access Room directly.
 * - Pure square output without decorative overlays, logos, or rounded corners to maximize print scanner reliability.
 */
interface QrCodeGenerator {
  /**
   * Generates a square QR bitmap for the given permanent guest UUID.
   *
   * @param guestUuid The permanent UUID of the guest.
   * @param sizePixels The dimension of the output square bitmap (e.g., 512px).
   * @return A high-quality black/white square Bitmap, or null if UUID is invalid or encoding fails.
   */
  fun generateQrBitmap(guestUuid: String, sizePixels: Int = 512): Bitmap?
}

class QrCodeGeneratorImpl(
  private val cache: QrCodeCache = InMemoryQrCodeCache(),
) : QrCodeGenerator {

  override fun generateQrBitmap(guestUuid: String, sizePixels: Int): Bitmap? {
    if (!QrPayload.isValidUuid(guestUuid)) {
      return null
    }

    val payload = QrPayload.buildPayload(guestUuid)

    // Check in-memory cache first
    cache.get(payload)?.let { cachedBitmap ->
      if (cachedBitmap.width == sizePixels && !cachedBitmap.isRecycled) {
        return cachedBitmap
      }
    }

    return try {
      val hints = mapOf(
        EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.H, // 30% error correction suitable for physical badge print & wear
        EncodeHintType.MARGIN to 2, // Standard quiet zone
        EncodeHintType.CHARACTER_SET to "UTF-8",
      )

      val bitMatrix = QRCodeWriter().encode(
        payload,
        BarcodeFormat.QR_CODE,
        sizePixels,
        sizePixels,
        hints,
      )

      val width = bitMatrix.width
      val height = bitMatrix.height
      val pixels = IntArray(width * height)

      for (y in 0 until height) {
        val offset = y * width
        for (x in 0 until width) {
          pixels[offset + x] = if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE
        }
      }

      val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
      bitmap.setPixels(pixels, 0, width, 0, 0, width, height)

      // Store in memory cache
      cache.put(payload, bitmap)
      bitmap
    } catch (_: Exception) {
      null
    }
  }
}
