package com.example.util.packageexport

import android.net.Uri
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.InvitationStatus
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import java.io.File

/**
 * Declared package format versions.
 * Version 1: Legacy SHA-256 integrity only.
 * Version 2: Authenticated with ECDSA P-256 digital signature.
 */
const val EVENTO_PACKAGE_FORMAT_VERSION_V1 = 1
const val EVENTO_PACKAGE_FORMAT_VERSION_V2 = 2
const val EVENTO_PACKAGE_FORMAT_VERSION = EVENTO_PACKAGE_FORMAT_VERSION_V2

/**
 * Declared package type constant.
 * Check-In applications must verify that packageType == EVENTO_PACKAGE_TYPE.
 */
const val EVENTO_PACKAGE_TYPE = "EVENTO_EVENT"

/**
 * Expected QR payload format definition.
 * Documents how Evento Check-In will match scanned optical codes to guest records.
 */
const val EVENTO_QR_PAYLOAD_FORMAT = "EVT1:<guest_uuid>"

/**
 * Hash and signature algorithms.
 */
const val EVENTO_HASH_ALGORITHM = "SHA-256"
const val EVENTO_SIGNATURE_ALGORITHM = "SHA256withECDSA"
const val EVENTO_SIGNATURE_VERSION_V2 = 2
const val EVENTO_DEFAULT_KEY_ID = "evento-admin-p256-v1"

/**
 * Scope of attendees included in the exported package.
 */
enum class PackageGuestScope {
  ALL,
  CONFIRMED,
  CUSTOM,
}

/**
 * DTO for manifest.json.
 * Root metadata of the .evento container.
 */
@JsonClass(generateAdapter = true)
data class EventoPackageManifest(
  @Json(name = "packageFormatVersion") val packageFormatVersion: Int = EVENTO_PACKAGE_FORMAT_VERSION,
  @Json(name = "packageType") val packageType: String = EVENTO_PACKAGE_TYPE,
  @Json(name = "eventId") val eventId: Long,
  @Json(name = "eventName") val eventName: String,
  @Json(name = "createdAt") val createdAt: String,
  @Json(name = "guestCount") val guestCount: Int,
  @Json(name = "guestScope") val guestScope: String,
  @Json(name = "payloadFormat") val payloadFormat: String = EVENTO_QR_PAYLOAD_FORMAT,
  @Json(name = "hashAlgorithm") val hashAlgorithm: String = EVENTO_HASH_ALGORITHM,
)

/**
 * DTO for event.json.
 * Minimum event fields required by Evento Check-In.
 * Does NOT expose internal database implementation details or unnecessary admin fields.
 */
@JsonClass(generateAdapter = true)
data class EventoPackageEvent(
  @Json(name = "eventId") val eventId: Long,
  @Json(name = "name") val name: String,
  @Json(name = "date") val date: String,
  @Json(name = "location") val location: String,
  @Json(name = "organizer") val organizer: String,
  @Json(name = "packageFormatVersion") val packageFormatVersion: Int = EVENTO_PACKAGE_FORMAT_VERSION,
) {
  companion object {
    fun fromEntity(entity: EventEntity): EventoPackageEvent {
      return EventoPackageEvent(
        eventId = entity.id,
        name = entity.name.trim(),
        date = entity.date.trim(),
        location = entity.location.trim(),
        organizer = entity.organizer.trim(),
        packageFormatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
      )
    }
  }
}

/**
 * DTO for individual guest items inside guests.json.
 * Strictly decoupled from GuestEntity.
 *
 * Excludes email, phone, and notes to protect attendee privacy.
 * Contains only data needed for QR validation (uuid) and attendee verification display (fullName, status, org, title).
 */
@JsonClass(generateAdapter = true)
data class EventoPackageGuest(
  @Json(name = "uuid") val uuid: String,
  @Json(name = "fullName") val fullName: String,
  @Json(name = "invitationStatus") val invitationStatus: String,
  @Json(name = "organization") val organization: String = "",
  @Json(name = "jobTitle") val jobTitle: String = "",
) {
  companion object {
    fun fromEntity(entity: GuestEntity): EventoPackageGuest {
      return EventoPackageGuest(
        uuid = entity.uuid.trim(),
        fullName = entity.fullName.trim(),
        invitationStatus = entity.invitationStatus.name,
        organization = entity.organization.trim(),
        jobTitle = entity.jobTitle.trim(),
      )
    }
  }
}

/**
 * DTO for license.json.
 * Embedded event package license specifying capacity, validity dates, and optional device binding.
 */
@JsonClass(generateAdapter = true)
data class EventoPackageLicense(
  @Json(name = "licenseId") val licenseId: String,
  @Json(name = "eventId") val eventId: Long,
  @Json(name = "issuedAt") val issuedAt: Long,
  @Json(name = "expiresAt") val expiresAt: Long,
  @Json(name = "maxGuests") val maxGuests: Int,
  @Json(name = "allowedDeviceCount") val allowedDeviceCount: Int = 1,
  @Json(name = "boundDeviceId") val boundDeviceId: String? = null,
  @Json(name = "licenseFormatVersion") val licenseFormatVersion: Int = 1,
)

/**
 * Root container for guests.json.
 */
@JsonClass(generateAdapter = true)
data class EventoPackageGuestsContainer(
  @Json(name = "guests") val guests: List<EventoPackageGuest>,
)

/**
 * DTO for signature.json.
 * For Version 1: contains SHA-256 integrity digests.
 * For Version 2: contains SHA-256 integrity digests + ECDSA digital signature over canonical content.
 */
@JsonClass(generateAdapter = true)
data class EventoPackageSignature(
  @Json(name = "algorithm") val algorithm: String = EVENTO_SIGNATURE_ALGORITHM,
  @Json(name = "eventJsonSha256") val eventJsonSha256: String,
  @Json(name = "guestsJsonSha256") val guestsJsonSha256: String,
  @Json(name = "licenseJsonSha256") val licenseJsonSha256: String? = null,
  @Json(name = "signatureVersion") val signatureVersion: Int? = EVENTO_SIGNATURE_VERSION_V2,
  @Json(name = "keyId") val keyId: String? = EVENTO_DEFAULT_KEY_ID,
  @Json(name = "signedContentDescriptor") val signedContentDescriptor: String? = EventoPackageCanonicalizer.DESCRIPTOR_V2,
  @Json(name = "signature") val signature: String? = null,
)

/**
 * Request payload for creating an Event Package.
 */
data class EventPackageExportRequest(
  val event: EventEntity,
  val guests: List<GuestEntity>,
  val scope: PackageGuestScope,
  val customFileName: String? = null,
  val license: EventoPackageLicense? = null,
)

/**
 * Result of the package creation operation.
 */
sealed interface EventPackageExportResult {
  data class Success(
    val file: File,
    val uri: Uri,
    val guestCount: Int,
    val fileSizeInBytes: Long,
    val manifest: EventoPackageManifest,
    val isLicensed: Boolean = false,
    val license: EventoPackageLicense? = null,
  ) : EventPackageExportResult

  data class Error(
    val message: String,
    val throwable: Throwable? = null,
  ) : EventPackageExportResult
}

/**
 * Pre-flight and post-flight validation result.
 */
sealed interface PackageValidationResult {
  data object Valid : PackageValidationResult
  data class Invalid(val reason: String) : PackageValidationResult
}
