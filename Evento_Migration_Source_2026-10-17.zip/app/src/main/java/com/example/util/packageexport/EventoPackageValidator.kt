package com.example.util.packageexport

import com.example.util.packageexport.security.EventoPackageSigner
import com.example.util.packageexport.security.EventoSigningKeyManager
import com.example.util.qr.QrPayload
import java.io.File
import java.security.PublicKey
import java.security.Signature
import java.util.Locale

/**
 * Reusable package verifier and tamper detector for Evento Admin.
 * Validates integrity hashes, schema constraints, guest consistency, and ECDSA digital signatures.
 */
class EventoPackageValidator(
  private val reader: EventoPackageReader = EventoPackageReader(),
  private val defaultPublicKeyProvider: () -> PublicKey = { EventoSigningKeyManager.getSigner().getPublicKey() },
) {

  fun validateFile(file: File): VerifiedPackageResult {
    val readResult = reader.readPackage(file)
    if (readResult is ReadPackageResult.Error) {
      return VerifiedPackageResult.Invalid("Package reading error: ${readResult.reason}")
    }

    val success = readResult as ReadPackageResult.Success
    val manifest = success.manifest
    val event = success.event
    val guests = success.guests
    val signature = success.signature

    // 1. Validate package type
    if (manifest.packageType != EVENTO_PACKAGE_TYPE) {
      return VerifiedPackageResult.Invalid("Unsupported package type '${manifest.packageType}'. Expected '$EVENTO_PACKAGE_TYPE'.")
    }

    // 2. Validate package format version (1 or 2)
    if (manifest.packageFormatVersion != EVENTO_PACKAGE_FORMAT_VERSION_V1 &&
      manifest.packageFormatVersion != EVENTO_PACKAGE_FORMAT_VERSION_V2
    ) {
      return VerifiedPackageResult.Invalid("Unsupported package format version '${manifest.packageFormatVersion}'. Expected 1 or 2.")
    }

    // 3. Verify SHA-256 integrity hash of event.json
    val actualEventHash = EventoPackageHash.sha256(success.rawEventBytes)
    if (!actualEventHash.equals(signature.eventJsonSha256, ignoreCase = true)) {
      return VerifiedPackageResult.Invalid(
        "Tamper detected! event.json SHA-256 checksum mismatch (expected ${signature.eventJsonSha256}, got $actualEventHash)."
      )
    }

    // 4. Verify SHA-256 integrity hash of guests.json
    val actualGuestsHash = EventoPackageHash.sha256(success.rawGuestsBytes)
    if (!actualGuestsHash.equals(signature.guestsJsonSha256, ignoreCase = true)) {
      return VerifiedPackageResult.Invalid(
        "Tamper detected! guests.json SHA-256 checksum mismatch (expected ${signature.guestsJsonSha256}, got $actualGuestsHash)."
      )
    }

    // 4b. Verify SHA-256 integrity hash of license.json if present
    val license = success.license
    val rawLicenseBytes = success.rawLicenseBytes
    if (license != null && rawLicenseBytes != null) {
      if (signature.licenseJsonSha256 == null) {
        return VerifiedPackageResult.Invalid("Package contains license.json but signature.json does not declare licenseJsonSha256.")
      }
      val actualLicenseHash = EventoPackageHash.sha256(rawLicenseBytes)
      if (!actualLicenseHash.equals(signature.licenseJsonSha256, ignoreCase = true)) {
        return VerifiedPackageResult.Invalid(
          "Tamper detected! license.json SHA-256 checksum mismatch (expected ${signature.licenseJsonSha256}, got $actualLicenseHash)."
        )
      }
      if (guests.size > license.maxGuests) {
        return VerifiedPackageResult.Invalid(
          "Guest count (${guests.size}) exceeds license maximum limit (${license.maxGuests})."
        )
      }
    } else if (signature.licenseJsonSha256 != null) {
      return VerifiedPackageResult.Invalid("Signature declares licenseJsonSha256 but license.json is missing.")
    }

    // 5. Verify payload format declaration
    if (manifest.payloadFormat != EVENTO_QR_PAYLOAD_FORMAT) {
      return VerifiedPackageResult.Invalid(
        "Unsupported QR payload format declaration '${manifest.payloadFormat}'. Expected '$EVENTO_QR_PAYLOAD_FORMAT'."
      )
    }

    // 6. Verify event consistency
    if (manifest.eventId != event.eventId) {
      return VerifiedPackageResult.Invalid(
        "Event ID mismatch between manifest (${manifest.eventId}) and event data (${event.eventId})."
      )
    }

    // 7. Verify guest count consistency
    if (manifest.guestCount != guests.size) {
      return VerifiedPackageResult.Invalid(
        "Guest count mismatch: manifest declares ${manifest.guestCount} guests, but found ${guests.size} in guests.json."
      )
    }

    // 8. Verify guest UUIDs
    val seenUuids = mutableSetOf<String>()
    for (guest in guests) {
      if (!QrPayload.isValidUuid(guest.uuid)) {
        return VerifiedPackageResult.Invalid("Guest '${guest.fullName}' has invalid UUID format: '${guest.uuid}'.")
      }
      val normalized = guest.uuid.lowercase(Locale.ROOT)
      if (!seenUuids.add(normalized)) {
        return VerifiedPackageResult.Invalid("Duplicate guest UUID detected: '${guest.uuid}'.")
      }
    }

    // 9. If Version 2: Verify authentic ECDSA P-256 digital signature
    if (manifest.packageFormatVersion == EVENTO_PACKAGE_FORMAT_VERSION_V2) {
      val rawSignatureBase64 = signature.signature
      if (rawSignatureBase64.isNullOrBlank()) {
        return VerifiedPackageResult.Invalid("Missing digital signature in Version 2 package.")
      }

      if (signature.algorithm != EVENTO_SIGNATURE_ALGORITHM) {
        return VerifiedPackageResult.Invalid(
          "Unsupported signature algorithm '${signature.algorithm}'. Expected '$EVENTO_SIGNATURE_ALGORITHM'."
        )
      }

      val signatureBytes = try {
        android.util.Base64.decode(rawSignatureBase64, android.util.Base64.DEFAULT)
      } catch (e: Exception) {
        return VerifiedPackageResult.Invalid("Malformed Base64 signature in signature.json: ${e.message}")
      }

      val canonicalBytes = if (signature.licenseJsonSha256 != null || signature.signedContentDescriptor == EventoPackageCanonicalizer.DESCRIPTOR_V2_1) {
        EventoPackageCanonicalizer.buildCanonicalBytesV2_1(
          packageFormatVersion = manifest.packageFormatVersion,
          packageType = manifest.packageType,
          eventId = event.eventId,
          eventName = event.name,
          eventDate = event.date,
          eventLocation = event.location,
          eventOrganizer = event.organizer,
          guestCount = guests.size,
          guestScope = manifest.guestScope,
          payloadFormat = manifest.payloadFormat,
          eventJsonSha256 = signature.eventJsonSha256,
          guestsJsonSha256 = signature.guestsJsonSha256,
          licenseJsonSha256 = signature.licenseJsonSha256 ?: "",
        )
      } else {
        EventoPackageCanonicalizer.buildCanonicalBytes(
          packageFormatVersion = manifest.packageFormatVersion,
          packageType = manifest.packageType,
          eventId = event.eventId,
          eventName = event.name,
          eventDate = event.date,
          eventLocation = event.location,
          eventOrganizer = event.organizer,
          guestCount = guests.size,
          guestScope = manifest.guestScope,
          payloadFormat = manifest.payloadFormat,
          eventJsonSha256 = signature.eventJsonSha256,
          guestsJsonSha256 = signature.guestsJsonSha256,
        )
      }

      val publicKey = try {
        defaultPublicKeyProvider()
      } catch (e: Exception) {
        return VerifiedPackageResult.Invalid("Cannot retrieve public key for verification: ${e.message}")
      }

      val sig = Signature.getInstance(signature.algorithm)
      sig.initVerify(publicKey)
      sig.update(canonicalBytes)
      val isValid = try {
        sig.verify(signatureBytes)
      } catch (e: Exception) {
        false
      }

      if (!isValid) {
        return VerifiedPackageResult.Invalid("Digital signature verification failed! Package may be forged or modified.")
      }
    }

    return VerifiedPackageResult.Valid(
      manifest = manifest,
      event = event,
      guests = guests,
      license = license,
    )
  }
}

sealed interface VerifiedPackageResult {
  data class Valid(
    val manifest: EventoPackageManifest,
    val event: EventoPackageEvent,
    val guests: List<EventoPackageGuest>,
    val license: EventoPackageLicense? = null,
  ) : VerifiedPackageResult

  data class Invalid(val reason: String) : VerifiedPackageResult
}
