package com.example.util.packageexport

import java.security.MessageDigest

/**
 * Utility for calculating deterministic SHA-256 digests.
 */
object EventoPackageHash {

  /**
   * Computes lowercase hex SHA-256 hash of the given byte array.
   */
  fun sha256(bytes: ByteArray): String {
    val digest = MessageDigest.getInstance("SHA-256")
    val hashBytes = digest.digest(bytes)
    return hashBytes.joinToString("") { "%02x".format(it) }
  }

  /**
   * Computes lowercase hex SHA-256 hash of a UTF-8 string.
   */
  fun sha256(text: String): String {
    return sha256(text.toByteArray(Charsets.UTF_8))
  }
}
