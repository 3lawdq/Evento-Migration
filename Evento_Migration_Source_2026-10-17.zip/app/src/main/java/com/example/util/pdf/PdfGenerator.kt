package com.example.util.pdf

/**
 * Reusable, UI-independent PDF Generator interface for Evento Admin.
 * Handles validation, vector badge rendering, deterministic QR code embedding,
 * and multi-guest batch pagination into standard PDF files.
 */
interface PdfGenerator {
  /**
   * Validates the generation request before attempting file writes.
   * Checks event existence, guest ownership, template dimensions, and element coordinates.
   */
  fun validate(request: PdfGenerationRequest): PdfValidationResult

  /**
   * Generates a print-ready PDF containing one badge per guest according to the template.
   *
   * @param request The request containing the target event, badge template, and guests.
   * @param onProgress Optional callback reporting (currentBadgeIndex, totalBadges).
   * @return [PdfGenerationResult.Success] on success with generated file details, or [PdfGenerationResult.Error].
   */
  suspend fun generateBadges(
    request: PdfGenerationRequest,
    onProgress: ((current: Int, total: Int) -> Unit)? = null,
  ): PdfGenerationResult
}
