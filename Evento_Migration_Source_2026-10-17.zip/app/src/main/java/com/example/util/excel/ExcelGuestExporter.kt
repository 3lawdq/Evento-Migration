package com.example.util.excel

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.local.entity.GuestEntity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Utility to export an event's attendee roster to standard Excel (.xlsx) format
 * using XlsxWriter and standard Android sharing/opening intents.
 */
object ExcelGuestExporter {

  fun exportGuestsToXlsx(
    context: Context,
    eventName: String,
    guests: List<GuestEntity>,
  ): File {
    val headers = listOf(
      "Name",
      "Organization",
      "Job Title",
      "Email",
      "Phone",
      "Status",
      "UUID",
      "Notes",
    )

    val rows = ArrayList<List<String>>(guests.size + 1)
    rows.add(headers)

    for (guest in guests) {
      rows.add(
        listOf(
          guest.fullName,
          guest.organization ?: "",
          guest.jobTitle ?: "",
          guest.email ?: "",
          guest.phone ?: "",
          guest.invitationStatus.name,
          guest.uuid,
          guest.notes ?: "",
        )
      )
    }

    val xlsxBytes = XlsxWriter.createXlsx(rows)

    val safeEventName = eventName
      .trim()
      .replace(Regex("[\\\\/:*?\"<>|\\x00-\\x1F]"), "_")
      .replace(Regex("\\s+"), "_")
      .take(40)
      .ifBlank { "Event" }

    val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
    val dateStr = dateFormat.format(Date())
    val fileName = "Evento_${safeEventName}_Guests_$dateStr.xlsx"

    val exportDir = File(context.cacheDir, "exported_excel").apply { mkdirs() }
    val exportFile = File(exportDir, fileName)
    exportFile.writeBytes(xlsxBytes)

    return exportFile
  }

  fun shareExcelFile(context: Context, file: File): Boolean {
    return try {
      val uri: Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file,
      )

      val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, file.name)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }

      val chooser = Intent.createChooser(
        intent,
        context.getString(R.string.guests_share_excel_chooser),
      ).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }

      context.startActivity(chooser)
      true
    } catch (_: Exception) {
      false
    }
  }
}
