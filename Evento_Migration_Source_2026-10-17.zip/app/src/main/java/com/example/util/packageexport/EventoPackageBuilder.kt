package com.example.util.packageexport

import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.util.packageexport.security.EventoPackageSigner
import com.example.util.packageexport.security.EventoSigningKeyManager
import com.example.util.qr.QrPayload
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Validates inputs, canonicalizes attendee ordering, and serializes JSON payload components
 * for the Evento Event Package with ECDSA P-256 digital signature.
 */
class EventoPackageBuilder(
  private val moshi: Moshi = Moshi.Builder()
    .addLast(KotlinJsonAdapterFactory())
    .build(),
  private val signer: EventoPackageSigner = EventoSigningKeyManager.getSigner(),
) {

  private val manifestAdapter = moshi.adapter(EventoPackageManifest::class.java).indent("  ")
  private val eventAdapter = moshi.adapter(EventoPackageEvent::class.java).indent("  ")
  private val guestsContainerAdapter = moshi.adapter(EventoPackageGuestsContainer::class.java).indent("  ")
  private val signatureAdapter = moshi.adapter(EventoPackageSignature::class.java).indent("  ")
  private val licenseAdapter = moshi.adapter(EventoPackageLicense::class.java).indent("  ")

  /**
   * Pre-flight validation before package packaging.
   */
  fun validateRequest(request: EventPackageExportRequest): PackageValidationResult {
    if (request.event.id <= 0) {
      return PackageValidationResult.Invalid("Invalid event ID: ${request.event.id}")
    }

    if (request.event.name.isBlank()) {
      return PackageValidationResult.Invalid("Event name cannot be blank.")
    }

    if (request.guests.isEmpty()) {
      return PackageValidationResult.Invalid("At least one guest is required to create an Event Package.")
    }

    // Validate event ownership
    val foreignGuests = request.guests.filter { it.eventId != request.event.id }
    if (foreignGuests.isNotEmpty()) {
      return PackageValidationResult.Invalid(
        "${foreignGuests.size} guests do not belong to event '${request.event.name}'."
      )
    }

    // Validate UUID format
    val invalidUuids = request.guests.filter { !QrPayload.isValidUuid(it.uuid) }
    if (invalidUuids.isNotEmpty()) {
      return PackageValidationResult.Invalid(
        "${invalidUuids.size} guests have invalid or malformed cryptographic UUIDs."
      )
    }

    // Validate UUID uniqueness
    val distinctCount = request.guests.map { it.uuid.trim().lowercase(Locale.ROOT) }.distinct().size
    if (distinctCount != request.guests.size) {
      return PackageValidationResult.Invalid("Duplicate guest UUIDs detected in export selection.")
    }

    // Validate license if provided
    request.license?.let { lic ->
      if (lic.licenseId.isBlank()) {
        return PackageValidationResult.Invalid("License identifier cannot be blank.")
      }
      if (lic.eventId != request.event.id) {
        return PackageValidationResult.Invalid("License eventId (${lic.eventId}) does not match event ID (${request.event.id}).")
      }
      if (lic.issuedAt <= 0L || lic.expiresAt <= 0L) {
        return PackageValidationResult.Invalid("License timestamps must be positive.")
      }
      if (lic.expiresAt <= lic.issuedAt) {
        return PackageValidationResult.Invalid("License expiresAt must be after issuedAt.")
      }
      if (lic.maxGuests <= 0) {
        return PackageValidationResult.Invalid("License maxGuests must be positive.")
      }
      if (request.guests.size > lic.maxGuests) {
        return PackageValidationResult.Invalid("Guest count (${request.guests.size}) exceeds license maxGuests (${lic.maxGuests}).")
      }
      if (lic.allowedDeviceCount <= 0) {
        return PackageValidationResult.Invalid("License allowedDeviceCount must be positive.")
      }
    }

    return PackageValidationResult.Valid
  }

  /**
   * Builds the in-memory package contents including canonical JSON strings and SHA-256 digests.
   */
  fun buildPackagePayload(
    request: EventPackageExportRequest,
    fixedIsoDate: String? = null,
  ): BuiltPackagePayload {
    val validation = validateRequest(request)
    if (validation is PackageValidationResult.Invalid) {
      throw IllegalArgumentException(validation.reason)
    }

    val eventDto = EventoPackageEvent.fromEntity(request.event)
    val eventJson = eventAdapter.toJson(eventDto) + "\n"

    // Canonicalize guests: sort deterministically by UUID ascending
    val sortedGuestDtos = request.guests
      .map { EventoPackageGuest.fromEntity(it) }
      .sortedBy { it.uuid.lowercase(Locale.ROOT) }

    val guestsContainer = EventoPackageGuestsContainer(guests = sortedGuestDtos)
    val guestsJson = guestsContainerAdapter.toJson(guestsContainer) + "\n"

    // Calculate SHA-256 digests over canonical UTF-8 bytes
    val eventHash = EventoPackageHash.sha256(eventJson.toByteArray(Charsets.UTF_8))
    val guestsHash = EventoPackageHash.sha256(guestsJson.toByteArray(Charsets.UTF_8))

    val licenseDto = request.license
    val licenseJson = licenseDto?.let { licenseAdapter.toJson(it) + "\n" }
    val licenseHash = licenseJson?.let { EventoPackageHash.sha256(it.toByteArray(Charsets.UTF_8)) }

    // Canonicalize all bound metadata for ECDSA digital signature
    val canonicalBytes = if (licenseHash != null) {
      EventoPackageCanonicalizer.buildCanonicalBytesV2_1(
        packageFormatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
        packageType = EVENTO_PACKAGE_TYPE,
        eventId = request.event.id,
        eventName = request.event.name,
        eventDate = request.event.date,
        eventLocation = request.event.location,
        eventOrganizer = request.event.organizer,
        guestCount = sortedGuestDtos.size,
        guestScope = request.scope.name,
        payloadFormat = EVENTO_QR_PAYLOAD_FORMAT,
        eventJsonSha256 = eventHash,
        guestsJsonSha256 = guestsHash,
        licenseJsonSha256 = licenseHash,
      )
    } else {
      EventoPackageCanonicalizer.buildCanonicalBytes(
        packageFormatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
        packageType = EVENTO_PACKAGE_TYPE,
        eventId = request.event.id,
        eventName = request.event.name,
        eventDate = request.event.date,
        eventLocation = request.event.location,
        eventOrganizer = request.event.organizer,
        guestCount = sortedGuestDtos.size,
        guestScope = request.scope.name,
        payloadFormat = EVENTO_QR_PAYLOAD_FORMAT,
        eventJsonSha256 = eventHash,
        guestsJsonSha256 = guestsHash,
      )
    }

    // Sign canonical bytes using non-exportable ECDSA P-256 private key
    val signatureBytes = signer.sign(canonicalBytes)
    val signatureBase64 = android.util.Base64.encodeToString(signatureBytes, android.util.Base64.NO_WRAP)

    val signatureDto = EventoPackageSignature(
      algorithm = signer.algorithm,
      eventJsonSha256 = eventHash,
      guestsJsonSha256 = guestsHash,
      licenseJsonSha256 = licenseHash,
      signatureVersion = EVENTO_SIGNATURE_VERSION_V2,
      keyId = signer.keyId,
      signedContentDescriptor = if (licenseHash != null) EventoPackageCanonicalizer.DESCRIPTOR_V2_1 else EventoPackageCanonicalizer.DESCRIPTOR_V2,
      signature = signatureBase64,
    )
    val signatureJson = signatureAdapter.toJson(signatureDto) + "\n"

    val createdAt = fixedIsoDate ?: formatCurrentIsoUtc()
    val manifestDto = EventoPackageManifest(
      packageFormatVersion = EVENTO_PACKAGE_FORMAT_VERSION,
      packageType = EVENTO_PACKAGE_TYPE,
      eventId = request.event.id,
      eventName = request.event.name.trim(),
      createdAt = createdAt,
      guestCount = sortedGuestDtos.size,
      guestScope = request.scope.name,
      payloadFormat = EVENTO_QR_PAYLOAD_FORMAT,
      hashAlgorithm = EVENTO_HASH_ALGORITHM,
    )
    val manifestJson = manifestAdapter.toJson(manifestDto) + "\n"

    return BuiltPackagePayload(
      manifest = manifestDto,
      manifestJson = manifestJson,
      eventDto = eventDto,
      eventJson = eventJson,
      guests = sortedGuestDtos,
      guestsJson = guestsJson,
      signatureDto = signatureDto,
      signatureJson = signatureJson,
      licenseDto = licenseDto,
      licenseJson = licenseJson,
    )
  }

  private fun formatCurrentIsoUtc(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }
    return sdf.format(Date())
  }
}

/**
 * In-memory representation of serialized package files and digests.
 */
data class BuiltPackagePayload(
  val manifest: EventoPackageManifest,
  val manifestJson: String,
  val eventDto: EventoPackageEvent,
  val eventJson: String,
  val guests: List<EventoPackageGuest>,
  val guestsJson: String,
  val signatureDto: EventoPackageSignature,
  val signatureJson: String,
  val licenseDto: EventoPackageLicense? = null,
  val licenseJson: String? = null,
)
