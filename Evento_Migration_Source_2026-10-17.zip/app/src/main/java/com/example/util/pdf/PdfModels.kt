package com.example.util.pdf

import android.net.Uri
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.BadgeTemplateWithElements
import com.example.data.local.entity.EventEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeOrientation
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class PdfPaperSize(
  val displayName: String,
  val widthMm: Float,
  val heightMm: Float,
) {
  SINGLE_BADGE("Single Badge", 0f, 0f),
  A4("A4 (210 × 297 mm)", 210f, 297f),
  A5("A5 (148 × 210 mm)", 148f, 210f),
  US_LETTER("US Letter (8.5 × 11 in)", 215.9f, 279.4f),
  A3("A3 (297 × 420 mm)", 297f, 420f);
}

data class PdfLayoutConfig(
  val paperSize: PdfPaperSize = PdfPaperSize.SINGLE_BADGE,
  val orientation: BadgeOrientation = BadgeOrientation.PORTRAIT,
  val columns: Int = 1,
  val rows: Int = 1,
  val marginTopMm: Float = 10f,
  val marginBottomMm: Float = 10f,
  val marginLeftMm: Float = 10f,
  val marginRightMm: Float = 10f,
  val spacingHorizontalMm: Float = 5f,
  val spacingVerticalMm: Float = 5f,
  val showCutMarks: Boolean = true,
) {
  val badgesPerPage: Int get() = if (paperSize == PdfPaperSize.SINGLE_BADGE) 1 else max(1, columns * rows)

  fun effectivePaperWidthMm(): Float = if (orientation == BadgeOrientation.LANDSCAPE) {
    max(paperSize.widthMm, paperSize.heightMm)
  } else {
    min(paperSize.widthMm, paperSize.heightMm)
  }

  fun effectivePaperHeightMm(): Float = if (orientation == BadgeOrientation.LANDSCAPE) {
    min(paperSize.widthMm, paperSize.heightMm)
  } else {
    max(paperSize.widthMm, paperSize.heightMm)
  }

  fun fitsOnPage(badgeWidthMm: Float, badgeHeightMm: Float): Boolean {
    if (paperSize == PdfPaperSize.SINGLE_BADGE) return true
    val paperW = effectivePaperWidthMm()
    val paperH = effectivePaperHeightMm()
    val totalWidthNeeded = marginLeftMm + marginRightMm + (columns * badgeWidthMm) + ((columns - 1).coerceAtLeast(0) * spacingHorizontalMm)
    val totalHeightNeeded = marginTopMm + marginBottomMm + (rows * badgeHeightMm) + ((rows - 1).coerceAtLeast(0) * spacingVerticalMm)
    return totalWidthNeeded <= (paperW + 0.1f) && totalHeightNeeded <= (paperH + 0.1f)
  }
}

/**
 * Encapsulates the physical badge dimensions translated into PDF points.
 * 1 PDF point = 1/72 inch.
 * 1 inch = 25.4 mm.
 * POINTS_PER_MM ≈ 2.8346457
 */
data class PdfPageDimensions(
  val widthPoints: Int,
  val heightPoints: Int,
  val widthMm: Float,
  val heightMm: Float,
  val orientation: BadgeOrientation,
) {
  companion object {
    const val POINTS_PER_INCH = 72f
    const val MM_PER_INCH = 25.4f
    const val POINTS_PER_MM = POINTS_PER_INCH / MM_PER_INCH

    fun fromTemplate(template: BadgeTemplateEntity): PdfPageDimensions {
      val isLandscape = template.orientation == BadgeOrientation.LANDSCAPE
      val effectiveWidthMm = if (isLandscape) {
        max(template.widthMm, template.heightMm)
      } else {
        min(template.widthMm, template.heightMm)
      }
      val effectiveHeightMm = if (isLandscape) {
        min(template.widthMm, template.heightMm)
      } else {
        max(template.widthMm, template.heightMm)
      }

      val widthPts = max(72, (effectiveWidthMm * POINTS_PER_MM).roundToInt())
      val heightPts = max(72, (effectiveHeightMm * POINTS_PER_MM).roundToInt())

      return PdfPageDimensions(
        widthPoints = widthPts,
        heightPoints = heightPts,
        widthMm = effectiveWidthMm,
        heightMm = effectiveHeightMm,
        orientation = template.orientation,
      )
    }

    fun fromPaperSize(
      paperSize: PdfPaperSize,
      orientation: BadgeOrientation = BadgeOrientation.PORTRAIT,
    ): PdfPageDimensions {
      val isLandscape = orientation == BadgeOrientation.LANDSCAPE
      val effWidthMm = if (isLandscape) max(paperSize.widthMm, paperSize.heightMm) else min(paperSize.widthMm, paperSize.heightMm)
      val effHeightMm = if (isLandscape) min(paperSize.widthMm, paperSize.heightMm) else max(paperSize.widthMm, paperSize.heightMm)
      val widthPts = max(72, (effWidthMm * POINTS_PER_MM).roundToInt())
      val heightPts = max(72, (effHeightMm * POINTS_PER_MM).roundToInt())
      return PdfPageDimensions(
        widthPoints = widthPts,
        heightPoints = heightPts,
        widthMm = effWidthMm,
        heightMm = effHeightMm,
        orientation = orientation,
      )
    }
  }
}

/**
 * Request payload for PDF badge generation.
 */
data class PdfGenerationRequest(
  val event: EventEntity,
  val templateWithElements: BadgeTemplateWithElements,
  val guests: List<GuestEntity>,
  val outputFileName: String? = null,
  val layoutConfig: PdfLayoutConfig = PdfLayoutConfig(),
)

/**
 * Validation outcome prior to executing PDF generation.
 */
sealed class PdfValidationResult {
  object Valid : PdfValidationResult()
  data class Invalid(val reason: String) : PdfValidationResult()
}

/**
 * Result returned after attempting PDF generation.
 */
sealed class PdfGenerationResult {
  data class Success(
    val file: File,
    val pageCount: Int,
    val fileSizeInBytes: Long,
    val uri: Uri? = null,
  ) : PdfGenerationResult()

  data class Error(
    val message: String,
    val cause: Throwable? = null,
  ) : PdfGenerationResult()
}
