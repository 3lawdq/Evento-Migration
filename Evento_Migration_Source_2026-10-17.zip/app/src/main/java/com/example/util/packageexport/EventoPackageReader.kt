package com.example.util.packageexport

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

/**
 * Reusable package reader component for reading and parsing .evento ZIP archives.
 * Usable by test suites and future Check-In integration.
 */
class EventoPackageReader(
  private val moshi: Moshi = Moshi.Builder()
    .addLast(KotlinJsonAdapterFactory())
    .build(),
) {

  private val manifestAdapter = moshi.adapter(EventoPackageManifest::class.java)
  private val eventAdapter = moshi.adapter(EventoPackageEvent::class.java)
  private val guestsContainerAdapter = moshi.adapter(EventoPackageGuestsContainer::class.java)
  private val signatureAdapter = moshi.adapter(EventoPackageSignature::class.java)
  private val licenseAdapter = moshi.adapter(EventoPackageLicense::class.java)

  /**
   * Reads an .evento file from disk.
   */
  fun readPackage(file: File): ReadPackageResult {
    if (!file.exists()) {
      return ReadPackageResult.Error("Package file does not exist: ${file.absolutePath}")
    }

    return try {
      ZipFile(file).use { zip ->
        val manifestEntry = zip.getEntry("manifest.json")
          ?: return ReadPackageResult.Error("Missing manifest.json inside .evento package")
        val eventEntry = zip.getEntry("event.json")
          ?: return ReadPackageResult.Error("Missing event.json inside .evento package")
        val guestsEntry = zip.getEntry("guests.json")
          ?: return ReadPackageResult.Error("Missing guests.json inside .evento package")
        val signatureEntry = zip.getEntry("signature.json")
          ?: return ReadPackageResult.Error("Missing signature.json inside .evento package")

        val licenseEntry = zip.getEntry("license.json")

        val manifestBytes = zip.getInputStream(manifestEntry).readBytes()
        val eventBytes = zip.getInputStream(eventEntry).readBytes()
        val guestsBytes = zip.getInputStream(guestsEntry).readBytes()
        val signatureBytes = zip.getInputStream(signatureEntry).readBytes()
        val licenseBytes = licenseEntry?.let { zip.getInputStream(it).readBytes() }

        val manifestJson = String(manifestBytes, Charsets.UTF_8)
        val eventJson = String(eventBytes, Charsets.UTF_8)
        val guestsJson = String(guestsBytes, Charsets.UTF_8)
        val signatureJson = String(signatureBytes, Charsets.UTF_8)
        val licenseJson = licenseBytes?.let { String(it, Charsets.UTF_8) }

        val manifest = manifestAdapter.fromJson(manifestJson)
          ?: return ReadPackageResult.Error("Failed to parse manifest.json")
        val event = eventAdapter.fromJson(eventJson)
          ?: return ReadPackageResult.Error("Failed to parse event.json")
        val guestsContainer = guestsContainerAdapter.fromJson(guestsJson)
          ?: return ReadPackageResult.Error("Failed to parse guests.json")
        val signature = signatureAdapter.fromJson(signatureJson)
          ?: return ReadPackageResult.Error("Failed to parse signature.json")
        val license = licenseJson?.let {
          licenseAdapter.fromJson(it) ?: return ReadPackageResult.Error("Failed to parse license.json")
        }

        ReadPackageResult.Success(
          manifest = manifest,
          event = event,
          guests = guestsContainer.guests,
          signature = signature,
          license = license,
          rawEventBytes = eventBytes,
          rawGuestsBytes = guestsBytes,
          rawManifestBytes = manifestBytes,
          rawSignatureBytes = signatureBytes,
          rawLicenseBytes = licenseBytes,
        )
      }
    } catch (e: Exception) {
      ReadPackageResult.Error("Failed to open .evento archive: ${e.message}", e)
    }
  }
}

sealed interface ReadPackageResult {
  data class Success(
    val manifest: EventoPackageManifest,
    val event: EventoPackageEvent,
    val guests: List<EventoPackageGuest>,
    val signature: EventoPackageSignature,
    val license: EventoPackageLicense? = null,
    val rawEventBytes: ByteArray,
    val rawGuestsBytes: ByteArray,
    val rawManifestBytes: ByteArray,
    val rawSignatureBytes: ByteArray,
    val rawLicenseBytes: ByteArray? = null,
  ) : ReadPackageResult

  data class Error(
    val reason: String,
    val throwable: Throwable? = null,
  ) : ReadPackageResult
}
