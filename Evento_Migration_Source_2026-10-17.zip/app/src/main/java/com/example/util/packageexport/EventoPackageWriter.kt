package com.example.util.packageexport

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Packages and writes the .evento ZIP container to disk.
 */
class EventoPackageWriter(
  private val context: Context,
  private val builder: EventoPackageBuilder = EventoPackageBuilder(),
  private val validator: EventoPackageValidator = EventoPackageValidator(),
) {

  suspend fun writePackage(
    request: EventPackageExportRequest,
    outputDirectory: File = File(context.cacheDir, "generated_packages").apply { mkdirs() },
  ): EventPackageExportResult = withContext(Dispatchers.IO) {
    try {
      val validation = builder.validateRequest(request)
      if (validation is PackageValidationResult.Invalid) {
        return@withContext EventPackageExportResult.Error(validation.reason)
      }

      val payload = builder.buildPackagePayload(request)

      val safeEventName = request.event.name
        .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        .take(30)
      val fileName = request.customFileName?.takeIf { it.isNotBlank() }
        ?: "Evento_Event_${request.event.id}_${safeEventName}_${System.currentTimeMillis()}.evento"

      val targetFile = File(outputDirectory, fileName)

      // Write ZIP container
      ZipOutputStream(FileOutputStream(targetFile)).use { zos ->
        // 1. manifest.json
        writeZipEntry(zos, "manifest.json", payload.manifestJson)
        // 2. event.json
        writeZipEntry(zos, "event.json", payload.eventJson)
        // 3. guests.json
        writeZipEntry(zos, "guests.json", payload.guestsJson)
        // 4. license.json (if present)
        payload.licenseJson?.let { licJson ->
          writeZipEntry(zos, "license.json", licJson)
        }
        // 5. signature.json
        writeZipEntry(zos, "signature.json", payload.signatureJson)
      }

      // Pre-export verification: verify generated package before presenting it as successful
      val verification = validator.validateFile(targetFile)
      if (verification is VerifiedPackageResult.Invalid) {
        targetFile.delete()
        return@withContext EventPackageExportResult.Error(
          "Pre-export verification failed: ${verification.reason}"
        )
      }

      // Generate FileProvider content URI
      val contentUri = try {
        FileProvider.getUriForFile(
          context,
          "${context.packageName}.fileprovider",
          targetFile,
        )
      } catch (_: Exception) {
        Uri.fromFile(targetFile)
      }

      EventPackageExportResult.Success(
        file = targetFile,
        uri = contentUri,
        guestCount = payload.manifest.guestCount,
        fileSizeInBytes = targetFile.length(),
        manifest = payload.manifest,
        isLicensed = payload.licenseDto != null,
        license = payload.licenseDto,
      )
    } catch (e: Exception) {
      EventPackageExportResult.Error("Failed to write Event Package: ${e.message}", e)
    }
  }

  private fun writeZipEntry(zos: ZipOutputStream, entryName: String, content: String) {
    val bytes = content.toByteArray(Charsets.UTF_8)
    val entry = ZipEntry(entryName)
    zos.putNextEntry(entry)
    zos.write(bytes)
    zos.closeEntry()
  }
}
