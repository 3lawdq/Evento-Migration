package com.example.util.excel

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Lightweight helper to create valid test or export .xlsx files purely in memory
 * using Java's standard ZipOutputStream and XML strings.
 */
object XlsxWriter {

  fun createXlsx(rows: List<List<String>>): ByteArray {
    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      // 1. [Content_Types].xml
      zos.putNextEntry(ZipEntry("[Content_Types].xml"))
      zos.write(
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>""".toByteArray(StandardCharsets.UTF_8)
      )
      zos.closeEntry()

      // 2. _rels/.rels
      zos.putNextEntry(ZipEntry("_rels/.rels"))
      zos.write(
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""".toByteArray(StandardCharsets.UTF_8)
      )
      zos.closeEntry()

      // 3. xl/_rels/workbook.xml.rels
      zos.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
      zos.write(
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>""".toByteArray(StandardCharsets.UTF_8)
      )
      zos.closeEntry()

      // 4. xl/workbook.xml
      zos.putNextEntry(ZipEntry("xl/workbook.xml"))
      zos.write(
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Sheet1" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>""".toByteArray(StandardCharsets.UTF_8)
      )
      zos.closeEntry()

      // 5. Gather unique strings for sharedStrings.xml
      val stringTable = mutableListOf<String>()
      val stringIndexMap = mutableMapOf<String, Int>()

      for (row in rows) {
        for (cell in row) {
          if (!stringIndexMap.containsKey(cell)) {
            stringIndexMap[cell] = stringTable.size
            stringTable.add(cell)
          }
        }
      }

      // Write xl/sharedStrings.xml
      zos.putNextEntry(ZipEntry("xl/sharedStrings.xml"))
      val ssBuilder = StringBuilder()
      ssBuilder.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
      ssBuilder.append("""<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${stringTable.size}" uniqueCount="${stringTable.size}">""")
      for (s in stringTable) {
        val escaped = escapeXml(s)
        ssBuilder.append("<si><t>$escaped</t></si>")
      }
      ssBuilder.append("</sst>")
      zos.write(ssBuilder.toString().toByteArray(StandardCharsets.UTF_8))
      zos.closeEntry()

      // 6. Write xl/worksheets/sheet1.xml
      zos.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
      val sheetBuilder = StringBuilder()
      sheetBuilder.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
      sheetBuilder.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
      sheetBuilder.append("<sheetData>")

      for ((rowIndex, row) in rows.withIndex()) {
        val rNum = rowIndex + 1
        sheetBuilder.append("""<row r="$rNum">""")
        for ((colIndex, cellValue) in row.withIndex()) {
          val colLetter = getColumnLetter(colIndex)
          val sIdx = stringIndexMap[cellValue] ?: 0
          sheetBuilder.append("""<c r="$colLetter$rNum" t="s"><v>$sIdx</v></c>""")
        }
        sheetBuilder.append("</row>")
      }

      sheetBuilder.append("</sheetData>")
      sheetBuilder.append("</worksheet>")
      zos.write(sheetBuilder.toString().toByteArray(StandardCharsets.UTF_8))
      zos.closeEntry()
    }
    return baos.toByteArray()
  }

  private fun getColumnLetter(colIndex: Int): String {
    var col = colIndex + 1
    val sb = StringBuilder()
    while (col > 0) {
      val rem = (col - 1) % 26
      sb.append(('A'.code + rem).toChar())
      col = (col - 1) / 26
    }
    return sb.reverse().toString()
  }

  private fun escapeXml(input: String): String {
    return input.replace("&", "&amp;")
      .replace("<", "&lt;")
      .replace(">", "&gt;")
      .replace("\"", "&quot;")
      .replace("'", "&apos;")
  }
}
