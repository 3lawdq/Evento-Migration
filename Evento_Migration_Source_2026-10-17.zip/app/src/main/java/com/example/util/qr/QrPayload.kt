package com.example.util.qr

import java.util.UUID

/**
 * QR Payload Builder and Parser for Evento.
 *
 * QR SECURITY RULES:
 * - Contains ONLY the guest's permanent UUID.
 * - MUST NOT contain full name, email, phone, organization, job title, notes, or any PII.
 * - Format: EVT1:<guest_uuid>
 * - Deterministic: Same UUID always yields the same payload.
 * - Independent of Room database.
 */
object QrPayload {
  const val VERSION_PREFIX = "EVT1:"

  private val UUID_REGEX = Regex(
    "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
  )

  /**
   * Validates if the string conforms to standard UUID format (RFC 4122).
   */
  fun isValidUuid(uuid: String?): Boolean {
    if (uuid.isNullOrBlank()) return false
    return UUID_REGEX.matches(uuid.trim())
  }

  /**
   * Builds the versioned, deterministic EVT1 payload for a valid guest UUID.
   * Throws IllegalArgumentException if the UUID is blank or malformed.
   */
  fun buildPayload(guestUuid: String): String {
    val trimmed = guestUuid.trim()
    require(isValidUuid(trimmed)) { "Invalid UUID format for QR payload: '$guestUuid'" }
    return "$VERSION_PREFIX$trimmed"
  }

  sealed interface ParseResult {
    data class Success(val guestUuid: String) : ParseResult
    data class Invalid(val error: ParseError, val details: String) : ParseResult
  }

  enum class ParseError {
    EMPTY_PAYLOAD,
    UNSUPPORTED_VERSION,
    MALFORMED_UUID,
    CONTAINS_PERSONAL_INFO,
    INVALID_STRUCTURE,
  }

  /**
   * Pure QR payload parser & validator. Reusable by future Check-In app and tests.
   * Does NOT access Room or any external state.
   */
  fun parse(payload: String?): ParseResult {
    if (payload.isNullOrBlank()) {
      return ParseResult.Invalid(ParseError.EMPTY_PAYLOAD, "Payload cannot be empty")
    }

    val trimmed = payload.trim()

    // Detect if payload looks like arbitrary personal data (JSON, vCard, email, URL, text without EVT prefix)
    if (!trimmed.startsWith("EVT", ignoreCase = true)) {
      if (trimmed.contains("@") || trimmed.startsWith("{") || trimmed.startsWith("BEGIN:VCARD") ||
        trimmed.contains("name=", ignoreCase = true) || trimmed.contains("phone=", ignoreCase = true)
      ) {
        return ParseResult.Invalid(ParseError.CONTAINS_PERSONAL_INFO, "Personal information payloads are strictly forbidden")
      }
      return ParseResult.Invalid(ParseError.UNSUPPORTED_VERSION, "Missing standard EVT prefix")
    }

    if (!trimmed.startsWith(VERSION_PREFIX)) {
      return ParseResult.Invalid(ParseError.UNSUPPORTED_VERSION, "Unsupported QR payload version: expected '$VERSION_PREFIX'")
    }

    val candidateUuid = trimmed.removePrefix(VERSION_PREFIX).trim()

    if (candidateUuid.isEmpty()) {
      return ParseResult.Invalid(ParseError.MALFORMED_UUID, "UUID portion is empty")
    }

    // Additional check for personal info slipped after prefix
    if (candidateUuid.contains(" ") || candidateUuid.contains("@") || candidateUuid.contains(":") || candidateUuid.contains(",")) {
      return ParseResult.Invalid(ParseError.CONTAINS_PERSONAL_INFO, "Payload contains invalid characters or personal info")
    }

    if (!isValidUuid(candidateUuid)) {
      return ParseResult.Invalid(ParseError.MALFORMED_UUID, "Malformed UUID format: '$candidateUuid'")
    }

    return ParseResult.Success(candidateUuid)
  }
}
