package com.example.util.qr

import android.graphics.Bitmap
import android.util.LruCache

/**
 * In-memory LRU Cache for rendered QR bitmaps.
 *
 * Requirements:
 * - Keyed by exact payload string ("EVT1:<uuid>").
 * - Never persists generated bitmaps to Room.
 * - Caps memory footprint (default 25 entries) to avoid storing hundreds of bitmaps simultaneously.
 */
interface QrCodeCache {
  fun get(payload: String): Bitmap?
  fun put(payload: String, bitmap: Bitmap)
  fun remove(payload: String): Bitmap?
  fun clear()
  fun size(): Int
}

class InMemoryQrCodeCache(maxEntries: Int = 25) : QrCodeCache {
  private val lru = object : LruCache<String, Bitmap>(maxEntries) {}

  override fun get(payload: String): Bitmap? = lru.get(payload)

  override fun put(payload: String, bitmap: Bitmap) {
    lru.put(payload, bitmap)
  }

  override fun remove(payload: String): Bitmap? = lru.remove(payload)

  override fun clear() {
    lru.evictAll()
  }

  override fun size(): Int = lru.size()
}
