package com.example.util.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.FileProvider
import com.example.data.local.entity.BadgeElementEntity
import com.example.data.local.entity.BadgeTemplateEntity
import com.example.data.local.entity.GuestEntity
import com.example.data.model.BadgeAlignment
import com.example.data.model.BadgeElementType
import com.example.util.qr.QrCodeGenerator
import com.example.util.qr.QrCodeGeneratorImpl
import com.example.util.qr.QrPayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Standard Android implementation of [PdfGenerator].
 * Emits vector badge graphics, native bidirectional typography, and dynamic QR barcodes
 * using Android's native [PdfDocument].
 */
class AndroidPdfGenerator(
  private val context: Context,
  private val qrCodeGenerator: QrCodeGenerator = QrCodeGeneratorImpl(),
) : PdfGenerator {

  override fun validate(request: PdfGenerationRequest): PdfValidationResult {
    if (request.event.name.isBlank()) {
      return PdfValidationResult.Invalid("Event name is missing.")
    }

    if (request.guests.isEmpty()) {
      return PdfValidationResult.Invalid("No guests selected for badge generation.")
    }

    val invalidEventGuests = request.guests.filter { it.eventId != request.event.id }
    if (invalidEventGuests.isNotEmpty()) {
      return PdfValidationResult.Invalid(
        "${invalidEventGuests.size} selected guests do not belong to event '${request.event.name}'."
      )
    }

    val invalidUuidGuests = request.guests.filter { !QrPayload.isValidUuid(it.uuid) }
    if (invalidUuidGuests.isNotEmpty()) {
      return PdfValidationResult.Invalid(
        "${invalidUuidGuests.size} guests have an invalid or malformed cryptographic UUID."
      )
    }

    val template = request.templateWithElements.template
    if (template.widthMm !in 20f..500f || template.heightMm !in 20f..500f) {
      return PdfValidationResult.Invalid(
        "Badge template dimensions (${template.widthMm}mm × ${template.heightMm}mm) are invalid. Width and height must be between 20mm and 500mm."
      )
    }

    val elements = request.templateWithElements.elements.filter { it.visible }
    for (elem in elements) {
      if (elem.x !in 0f..1f || elem.y !in 0f..1f || elem.width !in 0.01f..1.5f || elem.height !in 0.01f..1.5f) {
        return PdfValidationResult.Invalid("Badge element '${elem.type}' has invalid normalized coordinates.")
      }
      if ((elem.type == BadgeElementType.QR || elem.type == BadgeElementType.QR_PLACEHOLDER) &&
        (elem.width < 0.10f || elem.height < 0.10f)
      ) {
        return PdfValidationResult.Invalid("QR code element is too small for reliable print scanning (minimum 10% dimension required).")
      }
    }

    val layoutConfig = request.layoutConfig
    if (layoutConfig.paperSize != PdfPaperSize.SINGLE_BADGE) {
      if (layoutConfig.columns < 1 || layoutConfig.rows < 1) {
        return PdfValidationResult.Invalid("Rows and columns must be at least 1.")
      }
      val badgeDim = PdfPageDimensions.fromTemplate(template)
      if (!layoutConfig.fitsOnPage(badgeDim.widthMm, badgeDim.heightMm)) {
        return PdfValidationResult.Invalid(
          "Configured ${layoutConfig.columns}×${layoutConfig.rows} grid with margins exceeds ${layoutConfig.paperSize.displayName} page dimensions."
        )
      }
    }

    return PdfValidationResult.Valid
  }

  override suspend fun generateBadges(
    request: PdfGenerationRequest,
    onProgress: ((current: Int, total: Int) -> Unit)?,
  ): PdfGenerationResult = withContext(Dispatchers.IO) {
    val validation = validate(request)
    if (validation is PdfValidationResult.Invalid) {
      return@withContext PdfGenerationResult.Error(validation.reason)
    }

    val template = request.templateWithElements.template
    val elements = request.templateWithElements.elements
      .filter { it.visible }
      .sortedWith(compareBy<BadgeElementEntity> { it.zIndex }.thenBy { it.id })

    val badgesDir = File(context.cacheDir, "generated_badges").apply { mkdirs() }
    val safeFileName = request.outputFileName?.takeIf { it.isNotBlank() }
      ?: "evento_badges_event_${request.event.id}_${System.currentTimeMillis()}.pdf"
    val targetFile = File(badgesDir, safeFileName)

    val bgBitmap = decodeBitmapFromUri(template.backgroundImageUri)

    val pdfDocument = PdfDocument()

    try {
      val layoutConfig = request.layoutConfig
      val isSingleBadge = layoutConfig.paperSize == PdfPaperSize.SINGLE_BADGE
      var finalPageCount = 0

      val cutLinePaint = if (!isSingleBadge && layoutConfig.showCutMarks) {
        Paint().apply {
          color = Color.LTGRAY
          style = Paint.Style.STROKE
          strokeWidth = 1f
        }
      } else null

      if (isSingleBadge) {
        val dimensions = PdfPageDimensions.fromTemplate(template)
        val widthPts = dimensions.widthPoints
        val heightPts = dimensions.heightPoints
        val total = request.guests.size
        finalPageCount = total

        for ((index, guest) in request.guests.withIndex()) {
          onProgress?.invoke(index + 1, total)

          val pageNumber = index + 1
          val pageInfo = PdfDocument.PageInfo.Builder(widthPts, heightPts, pageNumber).create()
          val page = pdfDocument.startPage(pageInfo)

          drawBadge(
            canvas = page.canvas,
            guest = guest,
            template = template,
            elements = elements,
            eventName = request.event.name,
            bgBitmap = bgBitmap,
            widthPts = widthPts.toFloat(),
            heightPts = heightPts.toFloat(),
            cutLinePaint = null,
          )

          pdfDocument.finishPage(page)
        }
      } else {
        val pageDim = PdfPageDimensions.fromPaperSize(layoutConfig.paperSize, layoutConfig.orientation)
        val pageWidthPts = pageDim.widthPoints
        val pageHeightPts = pageDim.heightPoints

        val badgeDim = PdfPageDimensions.fromTemplate(template)
        val badgeW_pts = badgeDim.widthPoints.toFloat()
        val badgeH_pts = badgeDim.heightPoints.toFloat()

        val marginLeftPts = layoutConfig.marginLeftMm * PdfPageDimensions.POINTS_PER_MM
        val marginTopPts = layoutConfig.marginTopMm * PdfPageDimensions.POINTS_PER_MM
        val spacingHPts = layoutConfig.spacingHorizontalMm * PdfPageDimensions.POINTS_PER_MM
        val spacingVPts = layoutConfig.spacingVerticalMm * PdfPageDimensions.POINTS_PER_MM

        val cols = max(1, layoutConfig.columns)
        val rows = max(1, layoutConfig.rows)
        val badgesPerPage = cols * rows

        val guestChunks = request.guests.chunked(badgesPerPage)
        finalPageCount = guestChunks.size
        var totalProcessed = 0

        for ((pageIdx, pageGuests) in guestChunks.withIndex()) {
          val pageInfo = PdfDocument.PageInfo.Builder(pageWidthPts, pageHeightPts, pageIdx + 1).create()
          val page = pdfDocument.startPage(pageInfo)
          val canvas = page.canvas

          for ((cellIdx, guest) in pageGuests.withIndex()) {
            totalProcessed++
            onProgress?.invoke(totalProcessed, request.guests.size)

            val col = cellIdx % cols
            val row = cellIdx / cols
            val originX = marginLeftPts + col * (badgeW_pts + spacingHPts)
            val originY = marginTopPts + row * (badgeH_pts + spacingVPts)

            canvas.save()
            canvas.translate(originX, originY)
            canvas.clipRect(0f, 0f, badgeW_pts, badgeH_pts)
            drawBadge(
              canvas = canvas,
              guest = guest,
              template = template,
              elements = elements,
              eventName = request.event.name,
              bgBitmap = bgBitmap,
              widthPts = badgeW_pts,
              heightPts = badgeH_pts,
              cutLinePaint = cutLinePaint,
            )
            canvas.restore()
          }

          pdfDocument.finishPage(page)
        }
      }

      FileOutputStream(targetFile).use { out ->
        pdfDocument.writeTo(out)
      }

      val contentUri = try {
        FileProvider.getUriForFile(
          context,
          "${context.packageName}.fileprovider",
          targetFile,
        )
      } catch (_: Exception) {
        Uri.fromFile(targetFile)
      }

      PdfGenerationResult.Success(
        file = targetFile,
        pageCount = finalPageCount,
        fileSizeInBytes = targetFile.length(),
        uri = contentUri,
      )
    } catch (e: Exception) {
      PdfGenerationResult.Error("Failed to generate PDF document: ${e.message}", e)
    } finally {
      pdfDocument.close()
    }
  }

  private fun drawBadge(
    canvas: Canvas,
    guest: GuestEntity,
    template: BadgeTemplateEntity,
    elements: List<BadgeElementEntity>,
    eventName: String,
    bgBitmap: Bitmap?,
    widthPts: Float,
    heightPts: Float,
    cutLinePaint: Paint?,
  ) {
    // 1. Draw Background Color
    val cardBgColor = try {
      Color.parseColor(template.backgroundColor)
    } catch (_: Exception) {
      Color.WHITE
    }
    val bgPaint = Paint().apply {
      color = cardBgColor
      style = Paint.Style.FILL
    }
    canvas.drawRect(0f, 0f, widthPts, heightPts, bgPaint)

    // 2. Draw Background Image (if configured)
    if (bgBitmap != null && !bgBitmap.isRecycled) {
      val destRect = RectF(0f, 0f, widthPts, heightPts)
      val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
      canvas.drawBitmap(bgBitmap, null, destRect, imagePaint)
    }

    // 3. Render Elements in z-index order
    for (elem in elements) {
      val elemX = elem.x * widthPts
      val elemY = elem.y * heightPts
      val elemW = elem.width * widthPts
      val elemH = elem.height * heightPts

      // Optional element container background
      elem.backgroundColor?.let { hex ->
        try {
          val elemBgColor = Color.parseColor(hex)
          val elemBgPaint = Paint().apply {
            color = elemBgColor
            style = Paint.Style.FILL
          }
          canvas.drawRoundRect(
            RectF(elemX, elemY, elemX + elemW, elemY + elemH),
            4f,
            4f,
            elemBgPaint,
          )
        } catch (_: Exception) {
          // Ignore malformed background color
        }
      }

      when (elem.type) {
        BadgeElementType.ATTENDEE_NAME -> {
          drawText(
            canvas = canvas,
            text = guest.fullName,
            element = elem,
            elemX = elemX,
            elemY = elemY,
            elemW = elemW,
            elemH = elemH,
            maxLines = 2,
          )
        }

        BadgeElementType.JOB_TITLE -> {
          val title = guest.jobTitle ?: ""
          drawText(
            canvas = canvas,
            text = title,
            element = elem,
            elemX = elemX,
            elemY = elemY,
            elemW = elemW,
            elemH = elemH,
            maxLines = 1,
          )
        }

        BadgeElementType.ORGANIZATION -> {
          val org = guest.organization ?: ""
          drawText(
            canvas = canvas,
            text = org,
            element = elem,
            elemX = elemX,
            elemY = elemY,
            elemW = elemW,
            elemH = elemH,
            maxLines = 1,
          )
        }

        BadgeElementType.EVENT_NAME -> {
          val evtText = elem.text?.takeIf { it.isNotBlank() } ?: eventName
          drawText(
            canvas = canvas,
            text = evtText,
            element = elem,
            elemX = elemX,
            elemY = elemY,
            elemW = elemW,
            elemH = elemH,
            maxLines = 1,
          )
        }

        BadgeElementType.LOGO -> {
          val logoBitmap = decodeBitmapFromUri(elem.text)
          if (logoBitmap != null && !logoBitmap.isRecycled) {
            drawBitmapScaled(
              canvas = canvas,
              bitmap = logoBitmap,
              x = elemX,
              y = elemY,
              width = elemW,
              height = elemH,
            )
          }
        }

        BadgeElementType.QR,
        BadgeElementType.QR_PLACEHOLDER -> {
          val qrBitmap = qrCodeGenerator.generateQrBitmap(guest.uuid, sizePixels = 512)
          if (qrBitmap != null && !qrBitmap.isRecycled) {
            val side = min(elemW, elemH)
            val qrX = elemX + (elemW - side) / 2f
            val qrY = elemY + (elemH - side) / 2f
            val qrDest = RectF(qrX, qrY, qrX + side, qrY + side)
            val qrPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(qrBitmap, null, qrDest, qrPaint)
          }
        }
      }
    }

    // 4. Cut mark border
    cutLinePaint?.let {
      canvas.drawRect(0f, 0f, widthPts, heightPts, it)
    }
  }

  private fun drawText(
    canvas: Canvas,
    text: String,
    element: BadgeElementEntity,
    elemX: Float,
    elemY: Float,
    elemW: Float,
    elemH: Float,
    maxLines: Int,
  ) {
    if (text.isBlank()) return

    val textColor = try {
      Color.parseColor(element.textColor)
    } catch (_: Exception) {
      Color.parseColor("#1E293B")
    }

    val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
      color = textColor
      textSize = element.fontSize
      typeface = if (element.fontWeight.equals("BOLD", ignoreCase = true)) {
        Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      } else {
        Typeface.DEFAULT
      }
    }

    val layoutAlignment = when (element.alignment) {
      BadgeAlignment.START -> Layout.Alignment.ALIGN_NORMAL
      BadgeAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
      BadgeAlignment.END -> Layout.Alignment.ALIGN_OPPOSITE
    }

    val widthInt = max(1, elemW.roundToInt())
    val staticLayout = StaticLayout.Builder.obtain(
      text,
      0,
      text.length,
      textPaint,
      widthInt,
    )
      .setAlignment(layoutAlignment)
      .setIncludePad(false)
      .setMaxLines(maxLines)
      .setEllipsize(TextUtils.TruncateAt.END)
      .build()

    val verticalOffset = if (elemH > staticLayout.height) {
      (elemH - staticLayout.height) / 2f
    } else {
      0f
    }

    canvas.save()
    canvas.translate(elemX, elemY + verticalOffset)
    staticLayout.draw(canvas)
    canvas.restore()
  }

  private fun drawBitmapScaled(
    canvas: Canvas,
    bitmap: Bitmap,
    x: Float,
    y: Float,
    width: Float,
    height: Float,
  ) {
    val bmpRatio = bitmap.width.toFloat() / max(1, bitmap.height).toFloat()
    val targetRatio = width / max(1f, height)

    val (finalW, finalH) = if (bmpRatio > targetRatio) {
      width to (width / bmpRatio)
    } else {
      (height * bmpRatio) to height
    }

    val finalX = x + (width - finalW) / 2f
    val finalY = y + (height - finalH) / 2f
    val destRect = RectF(finalX, finalY, finalX + finalW, finalY + finalH)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    canvas.drawBitmap(bitmap, null, destRect, paint)
  }

  private fun decodeBitmapFromUri(uriString: String?): Bitmap? {
    if (uriString.isNullOrBlank()) return null
    return try {
      val uri = Uri.parse(uriString)
      if (uri.scheme == "content" || uri.scheme == "android.resource" || uri.scheme == "file") {
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
          BitmapFactory.decodeStream(inputStream)
        }
      } else {
        val file = File(uriString)
        if (file.exists()) {
          BitmapFactory.decodeFile(file.absolutePath)
        } else {
          null
        }
      }
    } catch (_: Exception) {
      null
    }
  }
}
