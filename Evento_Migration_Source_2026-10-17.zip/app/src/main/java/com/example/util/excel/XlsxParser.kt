package com.example.util.excel

import java.io.InputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element
import org.w3c.dom.NodeList

/**
 * Lightweight, robust, pure Android/Java XLSX parser.
 *
 * An .xlsx file is an Open Packaging Conventions (OPC) ZIP archive containing:
 *  - xl/sharedStrings.xml (shared string table)
 *  - xl/worksheets/sheet1.xml (cell data rows)
 *
 * This parser avoids heavy external Apache POI dependencies (which require AWT and bulky jars)
 * and leverages the built-in Android java.util.zip and javax.xml DOM/SAX parsers.
 * It is fast, memory-efficient, and runs smoothly on both Android runtime and JVM tests.
 */
object XlsxParser {

  /**
   * Parses an input stream of an .xlsx file into a list of row maps.
   * Each row is represented as a list of string values.
   */
  fun parse(inputStream: InputStream): List<List<String>> {
    var sharedStrings: List<String> = emptyList()
    var sheet1Bytes: ByteArray? = null

    // Extract xl/sharedStrings.xml and first worksheet from ZIP
    ZipInputStream(inputStream).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        when {
          entry.name.equals("xl/sharedStrings.xml", ignoreCase = true) -> {
            sharedStrings = parseSharedStrings(zis.readBytes().inputStream())
          }
          entry.name.matches(Regex("xl/worksheets/sheet[0-9]+\\.xml", RegexOption.IGNORE_CASE)) && sheet1Bytes == null -> {
            sheet1Bytes = zis.readBytes()
          }
        }
        zis.closeEntry()
        entry = zis.nextEntry
      }
    }

    if (sheet1Bytes == null) {
      return emptyList()
    }

    return parseSheet(sheet1Bytes!!.inputStream(), sharedStrings)
  }

  private fun parseSharedStrings(inputStream: InputStream): List<String> {
    val list = mutableListOf<String>()
    try {
      val factory = DocumentBuilderFactory.newInstance()
      // Disable entity expansion for security
      factory.isExpandEntityReferences = false
      val builder = factory.newDocumentBuilder()
      val doc = builder.parse(inputStream)
      val siNodes = doc.getElementsByTagName("si")

      for (i in 0 until siNodes.length) {
        val si = siNodes.item(i) as? Element ?: continue
        // An <si> may contain a single <t> or multiple rich text runs <r><t>...</t></r>
        val tNodes = si.getElementsByTagName("t")
        val sb = StringBuilder()
        for (j in 0 until tNodes.length) {
          sb.append(tNodes.item(j).textContent ?: "")
        }
        list.add(sb.toString())
      }
    } catch (e: Exception) {
      // Return whatever was parsed
    }
    return list
  }

  private fun parseSheet(inputStream: InputStream, sharedStrings: List<String>): List<List<String>> {
    val rows = mutableListOf<List<String>>()
    try {
      val factory = DocumentBuilderFactory.newInstance()
      factory.isExpandEntityReferences = false
      val builder = factory.newDocumentBuilder()
      val doc = builder.parse(inputStream)

      val rowNodes = doc.getElementsByTagName("row")
      for (i in 0 until rowNodes.length) {
        val rowElem = rowNodes.item(i) as? Element ?: continue
        val cellNodes = rowElem.getElementsByTagName("c")

        val cellMap = mutableMapOf<Int, String>()
        var maxColIndex = -1

        for (j in 0 until cellNodes.length) {
          val cell = cellNodes.item(j) as? Element ?: continue
          val cellRef = cell.getAttribute("r") // e.g., "A1", "B2", "AA5"
          val colIndex = if (cellRef.isNotEmpty()) getColumnIndex(cellRef) else j
          if (colIndex > maxColIndex) {
            maxColIndex = colIndex
          }

          val cellType = cell.getAttribute("t") // "s" for shared string, "str" for inline string
          val valueElem = cell.getElementsByTagName("v").item(0) as? Element
          val rawValue = valueElem?.textContent ?: ""

          val resolvedValue = when (cellType) {
            "s" -> {
              val sIndex = rawValue.toIntOrNull()
              if (sIndex != null && sIndex in sharedStrings.indices) {
                sharedStrings[sIndex]
              } else {
                rawValue
              }
            }
            "inlineStr" -> {
              val isElem = cell.getElementsByTagName("is").item(0) as? Element
              val tElem = isElem?.getElementsByTagName("t")?.item(0) as? Element
              tElem?.textContent ?: rawValue
            }
            else -> rawValue
          }

          cellMap[colIndex] = resolvedValue.trim()
        }

        if (maxColIndex >= 0) {
          val rowList = ArrayList<String>(maxColIndex + 1)
          for (c in 0..maxColIndex) {
            rowList.add(cellMap[c] ?: "")
          }
          // Only add rows that have at least one non-blank cell
          if (rowList.any { it.isNotBlank() }) {
            rows.add(rowList)
          }
        }
      }
    } catch (e: Exception) {
      // Fallback
    }
    return rows
  }

  /**
   * Converts cell reference like "A1", "B2", "Z1", "AA1" to 0-based column index.
   */
  fun getColumnIndex(cellRef: String): Int {
    var col = 0
    for (char in cellRef) {
      if (char in 'A'..'Z') {
        col = col * 26 + (char - 'A' + 1)
      } else if (char in 'a'..'z') {
        col = col * 26 + (char - 'a' + 1)
      } else {
        break
      }
    }
    return if (col > 0) col - 1 else 0
  }
}
