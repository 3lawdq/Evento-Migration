const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.APP_PORT || 3000;
const ROOT = __dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.apk': 'application/vnd.android.package-archive',
};

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, 'http://localhost');
  const pathname = decodeURIComponent(parsedUrl.pathname);

  // Normalize route shortcuts and APK endpoints
  if (pathname === '/download/admin' || pathname === '/admin.apk' || pathname === '/app-debug.apk' || pathname.endsWith('Evento-Admin.apk')) {
    serveApk(res, path.join(ROOT, 'distribution/admin/Evento-Admin.apk'), 'Evento-Admin.apk');
    return;
  }

  if (pathname === '/download/checkin' || pathname === '/checkin.apk' || pathname === '/checkin-debug.apk' || pathname.endsWith('Evento-Check-In.apk')) {
    serveApk(res, path.join(ROOT, 'distribution/checkin/Evento-Check-In.apk'), 'Evento-Check-In.apk');
    return;
  }

  // File resolution: try distribution, public, and root
  let targetPath = null;
  if (pathname.startsWith('/distribution/')) {
    targetPath = path.join(ROOT, pathname);
  } else if (pathname === '/' || pathname === '/index.html') {
    targetPath = path.join(ROOT, 'public/index.html');
  } else {
    // Try inside public first, then root
    const pubPath = path.join(ROOT, 'public', pathname);
    if (fs.existsSync(pubPath) && fs.statSync(pubPath).isFile()) {
      targetPath = pubPath;
    } else {
      const directPath = path.join(ROOT, pathname);
      if (fs.existsSync(directPath) && fs.statSync(directPath).isFile()) {
        targetPath = directPath;
      }
    }
  }

  if (!targetPath || !fs.existsSync(targetPath)) {
    // Fallback to index.html if route not found
    targetPath = path.join(ROOT, 'public/index.html');
  }

  if (!fs.existsSync(targetPath)) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
    return;
  }

  const stat = fs.statSync(targetPath);
  if (stat.isDirectory()) {
    targetPath = path.join(targetPath, 'index.html');
    if (!fs.existsSync(targetPath)) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not Found');
      return;
    }
  }

  const ext = path.extname(targetPath).toLowerCase();
  if (ext === '.apk') {
    const filename = path.basename(targetPath);
    serveApk(res, targetPath, filename);
    return;
  }

  const contentType = MIME_TYPES[ext] || 'application/octet-stream';
  res.writeHead(200, {
    'Content-Type': contentType,
    // 'Content-Length': stat.size,
    'Cache-Control': 'no-cache',
  });
  fs.createReadStream(targetPath).pipe(res);
});

function serveApk(res, filePath, filename) {
  // If distribution file does not exist, check fallback build outputs
  let finalPath = filePath;
  if (!fs.existsSync(finalPath)) {
    if (filename.toLowerCase().includes('admin')) {
      finalPath = path.join(ROOT, 'app/build/outputs/apk/debug/app-debug.apk');
    } else {
      finalPath = path.join(ROOT, 'checkin/build/outputs/apk/debug/checkin-debug.apk');
    }
  }

  if (!fs.existsSync(finalPath)) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end(`APK artifact not ready: ${filename}`);
    return;
  }

  const stat = fs.statSync(finalPath);
  res.writeHead(200, {
    'Content-Type': 'application/vnd.android.package-archive',
    // 'Content-Length': stat.size,
    'Content-Disposition': `attachment; filename="${filename}"`,
    'Cache-Control': 'public, max-age=3600',
  });
  fs.createReadStream(finalPath).pipe(res);
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Evento Distribution Web Portal listening on port ${PORT}`);
});
