package com.example.util.packageexport

import java.util.Locale

/**
 * Deterministic canonicalizer for Evento Package Version 2.
 *
 * SPECIFICATION:
 * Produces a standardized UTF-8 string containing strictly ordered, line-delimited key-value entries
 * binding all critical event package contents.
 *
 * Guaranteed properties:
 * 1. Deterministic order of keys.
 * 2. Strict LF line terminators ("\n").
 * 3. Stripped trailing/leading whitespace on text fields.
 * 4. Lowercase hexadecimal SHA-256 digests.
 * 5. Binds package format version, package type, event attributes, guest count, guest scope,
 *    payload format, and SHA-256 hashes of both event.json and guests.json.
 */
object EventoPackageCanonicalizer {

  const val DESCRIPTOR_V2 = "EVENTO-CANONICAL-V2"
  const val DESCRIPTOR_V2_1 = "EVENTO-CANONICAL-V2.1"

  /**
   * Generates the canonical UTF-8 bytes for V2 packages (without embedded license) to be signed with ECDSA P-256.
   */
  fun buildCanonicalBytes(
    packageFormatVersion: Int,
    packageType: String,
    eventId: Long,
    eventName: String,
    eventDate: String,
    eventLocation: String,
    eventOrganizer: String,
    guestCount: Int,
    guestScope: String,
    payloadFormat: String,
    eventJsonSha256: String,
    guestsJsonSha256: String,
  ): ByteArray {
    val canonicalText = buildString {
      append(DESCRIPTOR_V2).append("\n")
      append("formatVersion:").append(packageFormatVersion).append("\n")
      append("packageType:").append(packageType.trim()).append("\n")
      append("eventId:").append(eventId).append("\n")
      append("eventName:").append(eventName.trim()).append("\n")
      append("eventDate:").append(eventDate.trim()).append("\n")
      append("eventLocation:").append(eventLocation.trim()).append("\n")
      append("eventOrganizer:").append(eventOrganizer.trim()).append("\n")
      append("guestCount:").append(guestCount).append("\n")
      append("guestScope:").append(guestScope.trim()).append("\n")
      append("payloadFormat:").append(payloadFormat.trim()).append("\n")
      append("eventJsonSha256:").append(eventJsonSha256.trim().lowercase(Locale.ROOT)).append("\n")
      append("guestsJsonSha256:").append(guestsJsonSha256.trim().lowercase(Locale.ROOT)).append("\n")
    }
    return canonicalText.toByteArray(Charsets.UTF_8)
  }

  /**
   * Generates the canonical UTF-8 bytes for V2.1 packages (with embedded license) binding licenseJsonSha256.
   */
  fun buildCanonicalBytesV2_1(
    packageFormatVersion: Int,
    packageType: String,
    eventId: Long,
    eventName: String,
    eventDate: String,
    eventLocation: String,
    eventOrganizer: String,
    guestCount: Int,
    guestScope: String,
    payloadFormat: String,
    eventJsonSha256: String,
    guestsJsonSha256: String,
    licenseJsonSha256: String,
  ): ByteArray {
    val canonicalText = buildString {
      append(DESCRIPTOR_V2_1).append("\n")
      append("formatVersion:").append(packageFormatVersion).append("\n")
      append("packageType:").append(packageType.trim()).append("\n")
      append("eventId:").append(eventId).append("\n")
      append("eventName:").append(eventName.trim()).append("\n")
      append("eventDate:").append(eventDate.trim()).append("\n")
      append("eventLocation:").append(eventLocation.trim()).append("\n")
      append("eventOrganizer:").append(eventOrganizer.trim()).append("\n")
      append("guestCount:").append(guestCount).append("\n")
      append("guestScope:").append(guestScope.trim()).append("\n")
      append("payloadFormat:").append(payloadFormat.trim()).append("\n")
      append("eventJsonSha256:").append(eventJsonSha256.trim().lowercase(Locale.ROOT)).append("\n")
      append("guestsJsonSha256:").append(guestsJsonSha256.trim().lowercase(Locale.ROOT)).append("\n")
      append("licenseJsonSha256:").append(licenseJsonSha256.trim().lowercase(Locale.ROOT)).append("\n")
    }
    return canonicalText.toByteArray(Charsets.UTF_8)
  }
}
