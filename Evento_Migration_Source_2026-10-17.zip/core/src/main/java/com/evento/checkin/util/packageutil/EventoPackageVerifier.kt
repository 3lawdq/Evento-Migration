package com.evento.checkin.util.packageutil

import com.evento.core.R
import com.example.util.packageexport.EventoPackageCanonicalizer
import com.evento.checkin.domain.CheckInSecurityArchitecture
import com.evento.checkin.domain.license.EventLicenseValidator
import com.evento.checkin.domain.license.LicenseValidationResult
import com.evento.checkin.domain.model.CheckInEventDto
import com.evento.checkin.domain.model.CheckInGuestsContainerDto
import com.evento.checkin.domain.model.CheckInLicenseDto
import com.evento.checkin.domain.model.CheckInManifestDto
import com.evento.checkin.domain.model.CheckInSignatureDto
import com.evento.checkin.domain.model.EventLicense
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.ImportedGuest
import com.evento.checkin.domain.model.LicenseStatus
import com.evento.checkin.domain.model.PackageSecurityError
import com.evento.checkin.domain.model.PackageSecurityStatus
import com.evento.checkin.domain.model.PackageValidationResult
import com.evento.checkin.security.CheckInDeviceIdentityManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.Signature
import java.util.Locale
import java.util.zip.ZipInputStream

/**
 * Validates, decrypts (when applicable), verifies integrity, and extracts .evento archives.
 * Treats the ZIP archive and all contained payload streams as untrusted input.
 * Supports Version 1 (legacy integrity verification) and Version 2 (authentic ECDSA P-256 digital signature).
 * In Version 2.1, securely verifies embedded license.json and enforces offline licensing rules.
 */
class EventoPackageVerifier(
  private val moshi: Moshi = Moshi.Builder()
    .addLast(KotlinJsonAdapterFactory())
    .build(),
  private val licenseValidator: EventLicenseValidator = EventLicenseValidator(),
  private val deviceIdentityManager: CheckInDeviceIdentityManager? = null,
  private val timeProvider: () -> Long = { System.currentTimeMillis() },
) {

  companion object {
    const val ENTRY_MANIFEST = "manifest.json"
    const val ENTRY_EVENT = "event.json"
    const val ENTRY_GUESTS = "guests.json"
    const val ENTRY_SIGNATURE = "signature.json"
    const val ENTRY_LICENSE = "license.json"
  }

  private val manifestAdapter = moshi.adapter(CheckInManifestDto::class.java)
  private val eventAdapter = moshi.adapter(CheckInEventDto::class.java)
  private val guestsContainerAdapter = moshi.adapter(CheckInGuestsContainerDto::class.java)
  private val signatureAdapter = moshi.adapter(CheckInSignatureDto::class.java)
  private val licenseAdapter = moshi.adapter(CheckInLicenseDto::class.java)

  /**
   * Verifies an .evento package provided as an InputStream.
   * Optionally accepts [localDeviceId] to evaluate device binding constraint.
   */
  fun verifyPackage(
    inputStream: InputStream,
    localDeviceId: String? = null,
  ): PackageValidationResult {
    // 1. Safely extract all archive entries in memory with security boundaries
    val entriesMap = mutableMapOf<String, ByteArray>()
    val seenNames = mutableSetOf<String>()
    var totalBytesRead = 0L

    try {
      ZipInputStream(inputStream).use { zis ->
        var entry = zis.nextEntry
        while (entry != null) {
          val entryName = entry.name

          // Security: check path traversal / unsafe entry names
          if (!CheckInPackageSecurity.isEntryNameSafe(entryName)) {
            return PackageValidationResult.Invalid(
              userMessageRes = R.string.checkin_err_security_violation,
              technicalReason = "Security violation: Unsafe ZIP entry name '$entryName'",
              errorCategory = PackageSecurityError.SECURITY_VIOLATION,
            )
          }

          // Security: detect duplicate ZIP entries (case-insensitive)
          val normalizedName = entryName.lowercase(Locale.ROOT)
          if (!seenNames.add(normalizedName)) {
            return PackageValidationResult.Invalid(
              userMessageRes = R.string.checkin_err_security_violation,
              technicalReason = "Security violation: Duplicate entry detected for '$entryName'",
              errorCategory = PackageSecurityError.SECURITY_VIOLATION,
            )
          }

          // Read entry bytes up to limits
          val buffer = ByteArray(8192)
          val entryBaos = ByteArrayOutputStream()
          var bytesInEntry = 0L
          var read: Int

          while (zis.read(buffer).also { read = it } != -1) {
            bytesInEntry += read
            totalBytesRead += read

            if (bytesInEntry > CheckInPackageSecurity.MAX_SINGLE_ENTRY_BYTES) {
              return PackageValidationResult.Invalid(
                userMessageRes = R.string.checkin_err_security_violation,
                technicalReason = "Security violation: Entry '$entryName' exceeds maximum allowed size.",
                errorCategory = PackageSecurityError.SECURITY_VIOLATION,
              )
            }
            if (totalBytesRead > CheckInPackageSecurity.MAX_TOTAL_UNCOMPRESSED_BYTES) {
              return PackageValidationResult.Invalid(
                userMessageRes = R.string.checkin_err_security_violation,
                technicalReason = "Security violation: Total package decompressed size exceeds safety threshold.",
                errorCategory = PackageSecurityError.SECURITY_VIOLATION,
              )
            }

            entryBaos.write(buffer, 0, read)
          }

          entriesMap[normalizedName] = entryBaos.toByteArray()
          zis.closeEntry()
          entry = zis.nextEntry
        }
      }
    } catch (e: Exception) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_invalid_package,
        technicalReason = "Malformed ZIP archive: ${e.message ?: "Unknown error"}",
        errorCategory = PackageSecurityError.INVALID_PACKAGE,
      )
    }

    // 2. Validate all required entries exist
    val rawManifestBytes = entriesMap[ENTRY_MANIFEST]
      ?: return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_missing_entries,
        technicalReason = "Missing required entry: $ENTRY_MANIFEST",
        errorCategory = PackageSecurityError.INVALID_PACKAGE,
      )
    val rawEventBytes = entriesMap[ENTRY_EVENT]
      ?: return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_missing_entries,
        technicalReason = "Missing required entry: $ENTRY_EVENT",
        errorCategory = PackageSecurityError.INVALID_PACKAGE,
      )
    val rawGuestsBytes = entriesMap[ENTRY_GUESTS]
      ?: return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_missing_entries,
        technicalReason = "Missing required entry: $ENTRY_GUESTS",
        errorCategory = PackageSecurityError.INVALID_PACKAGE,
      )
    val rawSignatureBytes = entriesMap[ENTRY_SIGNATURE]
      ?: return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_missing_entries,
        technicalReason = "Missing required entry: $ENTRY_SIGNATURE",
        errorCategory = PackageSecurityError.INVALID_PACKAGE,
      )
    val rawLicenseBytes = entriesMap[ENTRY_LICENSE]

    // 3. Parse JSON structures
    val manifest: CheckInManifestDto
    val event: CheckInEventDto
    val guestsContainer: CheckInGuestsContainerDto
    val signature: CheckInSignatureDto
    val licenseDto: CheckInLicenseDto?

    try {
      manifest = manifestAdapter.fromJson(rawManifestBytes.toString(Charsets.UTF_8))
        ?: return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_package,
          technicalReason = "Failed to parse $ENTRY_MANIFEST",
          errorCategory = PackageSecurityError.INVALID_PACKAGE,
        )
      event = eventAdapter.fromJson(rawEventBytes.toString(Charsets.UTF_8))
        ?: return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_package,
          technicalReason = "Failed to parse $ENTRY_EVENT",
          errorCategory = PackageSecurityError.INVALID_PACKAGE,
        )
      guestsContainer = guestsContainerAdapter.fromJson(rawGuestsBytes.toString(Charsets.UTF_8))
        ?: return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_package,
          technicalReason = "Failed to parse $ENTRY_GUESTS",
          errorCategory = PackageSecurityError.INVALID_PACKAGE,
        )
      signature = signatureAdapter.fromJson(rawSignatureBytes.toString(Charsets.UTF_8))
        ?: return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_package,
          technicalReason = "Failed to parse $ENTRY_SIGNATURE",
          errorCategory = PackageSecurityError.INVALID_PACKAGE,
        )
      licenseDto = if (rawLicenseBytes != null) {
        licenseAdapter.fromJson(rawLicenseBytes.toString(Charsets.UTF_8))
          ?: return PackageValidationResult.Invalid(
            userMessageRes = R.string.checkin_err_license_invalid,
            technicalReason = "Failed to parse $ENTRY_LICENSE",
            errorCategory = PackageSecurityError.LICENSE_INVALID,
          )
      } else {
        null
      }
    } catch (e: Exception) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_invalid_package,
        technicalReason = "Malformed JSON payload: ${e.message ?: "Parsing error"}",
        errorCategory = PackageSecurityError.INVALID_PACKAGE,
      )
    }

    // 4. Validate package metadata & format version
    if (manifest.packageType != CheckInSecurityArchitecture.EXPECTED_PACKAGE_TYPE) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_unsupported_type,
        technicalReason = "Unsupported packageType '${manifest.packageType}'. Expected '${CheckInSecurityArchitecture.EXPECTED_PACKAGE_TYPE}'.",
        errorCategory = PackageSecurityError.UNSUPPORTED_FORMAT,
      )
    }

    if (!CheckInSecurityArchitecture.SUPPORTED_PACKAGE_FORMAT_VERSIONS.contains(manifest.packageFormatVersion)) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_unsupported_version,
        technicalReason = "Unsupported packageFormatVersion '${manifest.packageFormatVersion}'. Supported versions are ${CheckInSecurityArchitecture.SUPPORTED_PACKAGE_FORMAT_VERSIONS}.",
        errorCategory = PackageSecurityError.UNSUPPORTED_FORMAT,
      )
    }

    if (manifest.payloadFormat != "EVT1:<guest_uuid>") {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_invalid_package,
        technicalReason = "Unsupported payloadFormat '${manifest.payloadFormat}'. Expected 'EVT1:<guest_uuid>'.",
        errorCategory = PackageSecurityError.UNSUPPORTED_FORMAT,
      )
    }

    // 5. Independently recalculate and verify SHA-256 integrity checksums
    val recalculatedEventHash = CheckInPackageSecurity.sha256Hex(rawEventBytes)
    if (!recalculatedEventHash.equals(signature.eventJsonSha256, ignoreCase = true)) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_integrity_failed,
        technicalReason = "Tampered package! event.json SHA-256 checksum mismatch (declared: ${signature.eventJsonSha256}, actual: $recalculatedEventHash).",
        errorCategory = PackageSecurityError.INTEGRITY_CHECK_FAILED,
      )
    }

    val recalculatedGuestsHash = CheckInPackageSecurity.sha256Hex(rawGuestsBytes)
    if (!recalculatedGuestsHash.equals(signature.guestsJsonSha256, ignoreCase = true)) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_integrity_failed,
        technicalReason = "Tampered package! guests.json SHA-256 checksum mismatch (declared: ${signature.guestsJsonSha256}, actual: $recalculatedGuestsHash).",
        errorCategory = PackageSecurityError.INTEGRITY_CHECK_FAILED,
      )
    }

    // Check license presence and SHA-256 digest binding
    val isLicensedPackage = rawLicenseBytes != null ||
      signature.licenseJsonSha256 != null ||
      signature.signedContentDescriptor == EventoPackageCanonicalizer.DESCRIPTOR_V2_1

    if (isLicensedPackage && manifest.packageFormatVersion == CheckInSecurityArchitecture.PACKAGE_FORMAT_VERSION_2) {
      if (rawLicenseBytes == null) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_license_missing,
          technicalReason = "Signature declares license binding (licenseJsonSha256 / V2.1 descriptor) but $ENTRY_LICENSE is missing from archive.",
          errorCategory = PackageSecurityError.LICENSE_MISSING,
        )
      }
      if (signature.licenseJsonSha256.isNullOrBlank()) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_integrity_failed,
          technicalReason = "Package contains $ENTRY_LICENSE but signature.json does not declare licenseJsonSha256.",
          errorCategory = PackageSecurityError.LICENSE_INVALID,
        )
      }
      val recalculatedLicenseHash = CheckInPackageSecurity.sha256Hex(rawLicenseBytes)
      if (!recalculatedLicenseHash.equals(signature.licenseJsonSha256, ignoreCase = true)) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_integrity_failed,
          technicalReason = "Tampered package! license.json SHA-256 checksum mismatch (declared: ${signature.licenseJsonSha256}, actual: $recalculatedLicenseHash).",
          errorCategory = PackageSecurityError.INTEGRITY_CHECK_FAILED,
        )
      }
    }

    // 6. Validate Event attributes & consistency
    if (event.eventId <= 0L || event.name.isBlank()) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_invalid_event,
        technicalReason = "Event ID (${event.eventId}) or Name is invalid.",
        errorCategory = PackageSecurityError.EVENT_DATA_INVALID,
      )
    }

    if (manifest.eventId != event.eventId) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_invalid_event,
        technicalReason = "Event ID mismatch: manifest declares ${manifest.eventId} but event.json contains ${event.eventId}.",
        errorCategory = PackageSecurityError.EVENT_DATA_INVALID,
      )
    }

    if (manifest.eventName.trim() != event.name.trim()) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_invalid_event,
        technicalReason = "Event name mismatch: manifest declares '${manifest.eventName}' but event.json contains '${event.name}'.",
        errorCategory = PackageSecurityError.EVENT_DATA_INVALID,
      )
    }

    if (event.packageFormatVersion != manifest.packageFormatVersion) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_unsupported_version,
        technicalReason = "Package format version mismatch: manifest declares ${manifest.packageFormatVersion} but event.json contains ${event.packageFormatVersion}.",
        errorCategory = PackageSecurityError.UNSUPPORTED_FORMAT,
      )
    }

    // 7. Validate Guest list non-empty and matching manifest count
    val guests = guestsContainer.guests
    if (guests.isEmpty()) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_empty_guests,
        technicalReason = "Package has an empty guest list. Check-In requires an attendee roster.",
        errorCategory = PackageSecurityError.GUEST_DATA_INVALID,
      )
    }

    if (manifest.guestCount != guests.size) {
      return PackageValidationResult.Invalid(
        userMessageRes = R.string.checkin_err_guest_count_mismatch,
        technicalReason = "Guest count mismatch: manifest declares ${manifest.guestCount}, but guests.json contains ${guests.size}.",
        errorCategory = PackageSecurityError.GUEST_DATA_INVALID,
      )
    }

    // 8. Validate each guest UUID and ensure uniqueness
    val seenUuids = mutableSetOf<String>()
    val domainGuests = mutableListOf<ImportedGuest>()

    for (guest in guests) {
      if (guest.eventId != null && guest.eventId != event.eventId) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_guest,
          technicalReason = "Guest '${guest.fullName}' belongs to a different event ID (${guest.eventId} != ${event.eventId}).",
          errorCategory = PackageSecurityError.GUEST_DATA_INVALID,
        )
      }

      if (guest.fullName.isBlank()) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_guest,
          technicalReason = "Guest has an empty fullName.",
          errorCategory = PackageSecurityError.GUEST_DATA_INVALID,
        )
      }

      if (!CheckInPackageSecurity.isValidUuid(guest.uuid)) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_uuid,
          technicalReason = "Guest '${guest.fullName}' has invalid UUID '${guest.uuid}'.",
          errorCategory = PackageSecurityError.GUEST_DATA_INVALID,
        )
      }

      val normalizedUuid = guest.uuid.lowercase(Locale.ROOT)
      if (!seenUuids.add(normalizedUuid)) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_duplicate_uuid,
          technicalReason = "Duplicate guest UUID detected: '${guest.uuid}'.",
          errorCategory = PackageSecurityError.GUEST_DATA_INVALID,
        )
      }

      // Map to strictly privacy-preserving ImportedGuest (no email, phone, or notes!)
      domainGuests.add(
        ImportedGuest(
          uuid = guest.uuid.trim(),
          eventId = event.eventId,
          fullName = guest.fullName.trim(),
          invitationStatus = guest.invitationStatus.trim(),
          organization = guest.organization.trim(),
          jobTitle = guest.jobTitle.trim(),
          checkInStatus = "NOT_CHECKED_IN",
        )
      )
    }

    // 9. Digital Signature & Authenticity Verification
    val securityStatus: PackageSecurityStatus
    val verificationStatusString: String
    val validatedKeyId: String?
    var verifiedLicense: EventLicense? = null

    if (manifest.packageFormatVersion == CheckInSecurityArchitecture.PACKAGE_FORMAT_VERSION_2) {
      // Signature is strictly required for Version 2 packages
      val rawSignatureBase64 = signature.signature
      if (rawSignatureBase64.isNullOrBlank()) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_signature_missing,
          technicalReason = "Missing digital signature in signature.json for Version 2 package.",
          errorCategory = PackageSecurityError.SIGNATURE_MISSING,
        )
      }

      // Signature algorithm must match SHA256withECDSA
      if (signature.algorithm != CheckInSecurityArchitecture.EXPECTED_SIGNATURE_ALGORITHM) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_signature,
          technicalReason = "Unsupported signature algorithm '${signature.algorithm}'. Expected '${CheckInSecurityArchitecture.EXPECTED_SIGNATURE_ALGORITHM}'.",
          errorCategory = PackageSecurityError.UNSUPPORTED_SIGNATURE_ALGORITHM,
        )
      }

      // Key ID must be present
      val keyId = signature.keyId
      if (keyId.isNullOrBlank()) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_signature,
          technicalReason = "Missing keyId in signature.json.",
          errorCategory = PackageSecurityError.SIGNATURE_MISSING,
        )
      }

      // Lookup trusted public key from trust anchor registry (fail-closed)
      val trustedPublicKey = CheckInTrustAnchorRegistry.getTrustedPublicKey(keyId)
      if (trustedPublicKey == null) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_unknown_key,
          technicalReason = "Untrusted or unknown signing key: '$keyId'. Check-In trust anchor rejected this authority.",
          errorCategory = PackageSecurityError.UNKNOWN_SIGNING_KEY,
        )
      }

      // Decode Base64 signature
      val signatureBytes = try {
        android.util.Base64.decode(rawSignatureBase64, android.util.Base64.DEFAULT)
      } catch (e: Exception) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_signature,
          technicalReason = "Malformed Base64 signature encoding: ${e.message}",
          errorCategory = PackageSecurityError.MALFORMED_SIGNATURE,
        )
      }

      // Reconstruct deterministic canonical bytes over all bound metadata
      val canonicalBytes = if (isLicensedPackage) {
        val licSha = signature.licenseJsonSha256
        if (licSha.isNullOrBlank()) {
          return PackageValidationResult.Invalid(
            userMessageRes = R.string.checkin_err_invalid_signature,
            technicalReason = "V2.1 package requires licenseJsonSha256 in signature.",
            errorCategory = PackageSecurityError.CANONICALIZATION_FAILED,
          )
        }
        EventoPackageCanonicalizer.buildCanonicalBytesV2_1(
          packageFormatVersion = manifest.packageFormatVersion,
          packageType = manifest.packageType,
          eventId = event.eventId,
          eventName = event.name,
          eventDate = event.date,
          eventLocation = event.location,
          eventOrganizer = event.organizer,
          guestCount = domainGuests.size,
          guestScope = manifest.guestScope,
          payloadFormat = manifest.payloadFormat,
          eventJsonSha256 = signature.eventJsonSha256,
          guestsJsonSha256 = signature.guestsJsonSha256,
          licenseJsonSha256 = licSha,
        )
      } else {
        EventoPackageCanonicalizer.buildCanonicalBytes(
          packageFormatVersion = manifest.packageFormatVersion,
          packageType = manifest.packageType,
          eventId = event.eventId,
          eventName = event.name,
          eventDate = event.date,
          eventLocation = event.location,
          eventOrganizer = event.organizer,
          guestCount = domainGuests.size,
          guestScope = manifest.guestScope,
          payloadFormat = manifest.payloadFormat,
          eventJsonSha256 = signature.eventJsonSha256,
          guestsJsonSha256 = signature.guestsJsonSha256,
        )
      }

      // Verify authentic ECDSA P-256 signature
      val sig = Signature.getInstance(signature.algorithm)
      sig.initVerify(trustedPublicKey)
      sig.update(canonicalBytes)
      val isSigValid = try {
        sig.verify(signatureBytes)
      } catch (e: Exception) {
        false
      }

      if (!isSigValid) {
        return PackageValidationResult.Invalid(
          userMessageRes = R.string.checkin_err_invalid_signature,
          technicalReason = "Digital signature verification failed! The package was tampered with or signed by an unauthorized key.",
          errorCategory = PackageSecurityError.SIGNATURE_INVALID,
        )
      }

      // If package contains a verified license, evaluate governance rules
      if (isLicensedPackage && licenseDto != null) {
        val initialDomainLicense = licenseDto.toDomain(LicenseStatus.ACTIVE)
        val resolvedDeviceId = localDeviceId ?: deviceIdentityManager?.getOrCreateDeviceId()
        val licenseValidationResult = licenseValidator.validateLicense(
          license = initialDomainLicense,
          eventId = event.eventId,
          guestCount = domainGuests.size,
          localDeviceId = resolvedDeviceId,
          currentTime = timeProvider(),
        )

        when (licenseValidationResult) {
          is LicenseValidationResult.Valid -> {
            verifiedLicense = licenseValidationResult.license
          }
          is LicenseValidationResult.Invalid -> {
            val (resId, errorCategory) = when (licenseValidationResult.status) {
              LicenseStatus.EXPIRED -> Pair(R.string.checkin_err_license_expired, PackageSecurityError.LICENSE_EXPIRED)
              LicenseStatus.NOT_YET_VALID -> Pair(R.string.checkin_err_license_not_yet_valid, PackageSecurityError.LICENSE_NOT_YET_VALID)
              LicenseStatus.GUEST_LIMIT_EXCEEDED -> Pair(R.string.checkin_err_license_guest_limit_exceeded, PackageSecurityError.LICENSE_GUEST_LIMIT_EXCEEDED)
              LicenseStatus.DEVICE_MISMATCH -> Pair(R.string.checkin_err_license_device_mismatch, PackageSecurityError.LICENSE_DEVICE_MISMATCH)
              LicenseStatus.MISSING -> Pair(R.string.checkin_err_license_missing, PackageSecurityError.LICENSE_MISSING)
              else -> Pair(R.string.checkin_err_license_invalid, PackageSecurityError.LICENSE_INVALID)
            }
            return PackageValidationResult.Invalid(
              userMessageRes = resId,
              technicalReason = licenseValidationResult.reason,
              errorCategory = errorCategory,
            )
          }
        }
      }

      securityStatus = PackageSecurityStatus.SIGNED_VERIFIED
      verificationStatusString = "SIGNED_VERIFIED"
      validatedKeyId = keyId
    } else {
      // Version 1: Legacy SHA-256 integrity only
      securityStatus = PackageSecurityStatus.LEGACY_INTEGRITY_ONLY
      verificationStatusString = "LEGACY_INTEGRITY_ONLY"
      validatedKeyId = null
      verifiedLicense = null
    }

    val domainEvent = ImportedEvent(
      eventId = event.eventId,
      name = event.name.trim(),
      date = event.date.trim(),
      location = event.location.trim(),
      organizer = event.organizer.trim(),
      packageFormatVersion = event.packageFormatVersion,
      guestCount = domainGuests.size,
      importedAt = System.currentTimeMillis(),
      verificationStatus = verificationStatusString,
      license = verifiedLicense,
    )

    return PackageValidationResult.Valid(
      event = domainEvent,
      guests = domainGuests,
      manifest = manifest,
      securityStatus = securityStatus,
      keyId = validatedKeyId,
      license = verifiedLicense,
    )
  }

  /**
   * Overload for byte arrays (convenient for unit tests).
   */
  fun verifyPackage(
    bytes: ByteArray,
    localDeviceId: String? = null,
  ): PackageValidationResult {
    return verifyPackage(ByteArrayInputStream(bytes), localDeviceId)
  }
}

