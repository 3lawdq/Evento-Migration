package com.evento.checkin.domain.qr

import com.evento.checkin.domain.model.CheckInResult
import com.evento.checkin.domain.model.ImportedGuest

/**
 * Result representing the outcome of a QR-based attendee check-in attempt.
 *
 * Separates QR grammar validation failures from domain engine results.
 */
sealed interface QrCheckInResult {

  /** Attendee was successfully validated and check-in was recorded. */
  data class Success(
    val guest: ImportedGuest,
    val checkedInAt: Long,
  ) : QrCheckInResult

  /** Attendee was already recorded as checked in for this event; original timestamp is preserved. */
  data class AlreadyCheckedIn(
    val guest: ImportedGuest,
    val checkedInAt: Long,
  ) : QrCheckInResult

  /** QR payload is valid but attendee does not belong to the currently active event. */
  data object GuestNotFound : QrCheckInResult

  /** No active .evento package is loaded into the terminal. */
  data object NoActiveEvent : QrCheckInResult

  /** QR payload failed grammar validation; CheckInEngine was not called. */
  data class InvalidQr(
    val parseError: QrPayloadParseResult,
  ) : QrCheckInResult

  data class LicenseExpired(val reason: String) : QrCheckInResult

  data class LicenseNotYetValid(val reason: String) : QrCheckInResult

  data class LicenseGuestLimitExceeded(val reason: String) : QrCheckInResult

  data class LicenseDeviceMismatch(val reason: String) : QrCheckInResult

  data class LicenseInvalid(val reason: String) : QrCheckInResult

  data class LicenseMissing(val reason: String) : QrCheckInResult

  /** Convenience mapping to domain [CheckInResult], or null if the QR was invalid. */
  val checkInResult: CheckInResult?
    get() = when (this) {
      is Success -> CheckInResult.Success(guest, checkedInAt)
      is AlreadyCheckedIn -> CheckInResult.AlreadyCheckedIn(guest, checkedInAt)
      is GuestNotFound -> CheckInResult.GuestNotFound
      is NoActiveEvent -> CheckInResult.NoActiveEvent
      is InvalidQr -> null
      is LicenseExpired -> CheckInResult.LicenseExpired(reason)
      is LicenseNotYetValid -> CheckInResult.LicenseNotYetValid(reason)
      is LicenseGuestLimitExceeded -> CheckInResult.LicenseGuestLimitExceeded(reason)
      is LicenseDeviceMismatch -> CheckInResult.LicenseDeviceMismatch(reason)
      is LicenseInvalid -> CheckInResult.LicenseInvalid(reason)
      is LicenseMissing -> CheckInResult.LicenseMissing(reason)
    }
}
