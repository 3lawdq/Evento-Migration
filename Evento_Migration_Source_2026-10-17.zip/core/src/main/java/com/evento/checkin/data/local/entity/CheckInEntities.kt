package com.evento.checkin.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.evento.checkin.domain.model.AttendanceRecord
import com.evento.checkin.domain.model.EventLicense
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.ImportedGuest
import com.evento.checkin.domain.model.LicenseStatus

@Entity(tableName = "imported_events")
data class ImportedEventEntity(
  @PrimaryKey
  val eventId: Long,
  val name: String,
  val date: String,
  val location: String,
  val organizer: String,
  val packageFormatVersion: Int,
  val guestCount: Int,
  val importedAt: Long,
  val verificationStatus: String,
  val licenseId: String? = null,
  val licenseIssuedAt: Long? = null,
  val licenseExpiresAt: Long? = null,
  val licenseMaxGuests: Int? = null,
  val licenseAllowedDeviceCount: Int? = null,
  val licenseBoundDeviceId: String? = null,
  val licenseStatus: String? = null,
  val licenseFormatVersion: Int? = null,
) {
  fun toDomain(): ImportedEvent {
    val domainLicense = if (licenseId != null) {
      EventLicense(
        licenseId = licenseId,
        eventId = eventId,
        issuedAt = licenseIssuedAt ?: 0L,
        expiresAt = licenseExpiresAt ?: 0L,
        maxGuests = licenseMaxGuests ?: 0,
        allowedDeviceCount = licenseAllowedDeviceCount ?: 1,
        boundDeviceId = licenseBoundDeviceId,
        licenseStatus = try {
          licenseStatus?.let { LicenseStatus.valueOf(it) } ?: LicenseStatus.ACTIVE
        } catch (_: Exception) {
          LicenseStatus.ACTIVE
        },
        licenseFormatVersion = licenseFormatVersion ?: 1,
      )
    } else {
      null
    }

    return ImportedEvent(
      eventId = eventId,
      name = name,
      date = date,
      location = location,
      organizer = organizer,
      packageFormatVersion = packageFormatVersion,
      guestCount = guestCount,
      importedAt = importedAt,
      verificationStatus = verificationStatus,
      license = domainLicense,
    )
  }

  companion object {
    fun fromDomain(domain: ImportedEvent): ImportedEventEntity {
      return ImportedEventEntity(
        eventId = domain.eventId,
        name = domain.name,
        date = domain.date,
        location = domain.location,
        organizer = domain.organizer,
        packageFormatVersion = domain.packageFormatVersion,
        guestCount = domain.guestCount,
        importedAt = domain.importedAt,
        verificationStatus = domain.verificationStatus,
        licenseId = domain.license?.licenseId,
        licenseIssuedAt = domain.license?.issuedAt,
        licenseExpiresAt = domain.license?.expiresAt,
        licenseMaxGuests = domain.license?.maxGuests,
        licenseAllowedDeviceCount = domain.license?.allowedDeviceCount,
        licenseBoundDeviceId = domain.license?.boundDeviceId,
        licenseStatus = domain.license?.licenseStatus?.name,
        licenseFormatVersion = domain.license?.licenseFormatVersion,
      )
    }
  }
}

@Entity(tableName = "imported_guests")
data class ImportedGuestEntity(
  @PrimaryKey
  val uuid: String,
  val eventId: Long,
  val fullName: String,
  val invitationStatus: String,
  val organization: String,
  val jobTitle: String,
  val checkInStatus: String,
) {
  fun toDomain(): ImportedGuest = ImportedGuest(
    uuid = uuid,
    eventId = eventId,
    fullName = fullName,
    invitationStatus = invitationStatus,
    organization = organization,
    jobTitle = jobTitle,
    checkInStatus = checkInStatus,
  )

  companion object {
    fun fromDomain(domain: ImportedGuest): ImportedGuestEntity = ImportedGuestEntity(
      uuid = domain.uuid,
      eventId = domain.eventId,
      fullName = domain.fullName,
      invitationStatus = domain.invitationStatus,
      organization = domain.organization,
      jobTitle = domain.jobTitle,
      checkInStatus = domain.checkInStatus,
    )
  }
}

@Entity(
  tableName = "attendance_records",
  indices = [Index(value = ["eventId", "guestUuid"], unique = true)],
)
data class AttendanceRecordEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val eventId: Long,
  val guestUuid: String,
  val checkedInAt: Long,
) {
  fun toDomain(): AttendanceRecord = AttendanceRecord(
    id = id,
    eventId = eventId,
    guestUuid = guestUuid,
    checkedInAt = checkedInAt,
  )

  companion object {
    fun fromDomain(domain: AttendanceRecord): AttendanceRecordEntity = AttendanceRecordEntity(
      id = domain.id,
      eventId = domain.eventId,
      guestUuid = domain.guestUuid,
      checkedInAt = domain.checkedInAt,
    )
  }
}
