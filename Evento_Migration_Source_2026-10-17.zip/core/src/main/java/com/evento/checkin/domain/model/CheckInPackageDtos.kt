package com.evento.checkin.domain.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CheckInManifestDto(
  val packageFormatVersion: Int,
  val packageType: String,
  val eventId: Long,
  val eventName: String,
  val guestCount: Int,
  val guestScope: String,
  val payloadFormat: String,
  val exportedAt: Long = 0L,
)

@JsonClass(generateAdapter = true)
data class CheckInEventDto(
  val eventId: Long,
  val name: String,
  val date: String,
  val location: String,
  val organizer: String,
  val packageFormatVersion: Int,
  val guestCount: Int = 0,
)

@JsonClass(generateAdapter = true)
data class CheckInGuestDto(
  val uuid: String,
  val eventId: Long? = null,
  val fullName: String,
  val invitationStatus: String = "CONFIRMED",
  val organization: String = "",
  val jobTitle: String = "",
)

@JsonClass(generateAdapter = true)
data class CheckInGuestsContainerDto(
  val guests: List<CheckInGuestDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class CheckInSignatureDto(
  val formatVersion: Int = 1,
  val signedContentDescriptor: String? = null,
  val algorithm: String = "SHA256withECDSA",
  val keyId: String? = null,
  val eventJsonSha256: String = "",
  val guestsJsonSha256: String = "",
  val licenseJsonSha256: String? = null,
  val signature: String? = null,
)

@JsonClass(generateAdapter = true)
data class CheckInLicenseDto(
  val licenseId: String,
  val eventId: Long,
  val issuedAt: Long,
  val expiresAt: Long,
  val maxGuests: Int,
  val allowedDeviceCount: Int = 1,
  val boundDeviceId: String? = null,
  val licenseFormatVersion: Int = 1,
) {
  fun toDomain(status: LicenseStatus = LicenseStatus.ACTIVE): EventLicense {
    return EventLicense(
      licenseId = licenseId,
      eventId = eventId,
      issuedAt = issuedAt,
      expiresAt = expiresAt,
      maxGuests = maxGuests,
      allowedDeviceCount = allowedDeviceCount,
      boundDeviceId = boundDeviceId,
      licenseStatus = status,
      licenseFormatVersion = licenseFormatVersion,
    )
  }
}
