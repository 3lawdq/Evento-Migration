package com.evento.checkin.domain

object CheckInSecurityArchitecture {
  const val EXPECTED_PAYLOAD_PREFIX = "EVT1:"
  const val EXPECTED_PACKAGE_FORMAT_VERSION = 2
  const val EXPECTED_PACKAGE_TYPE = "EVENTO_EVENT"
  const val PACKAGE_FORMAT_VERSION_1 = 1
  const val PACKAGE_FORMAT_VERSION_2 = 2
  val SUPPORTED_PACKAGE_FORMAT_VERSIONS = setOf(1, 2)
  const val EXPECTED_SIGNATURE_ALGORITHM = "SHA256withECDSA"
}
