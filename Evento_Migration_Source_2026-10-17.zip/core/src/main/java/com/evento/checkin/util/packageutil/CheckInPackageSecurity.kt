package com.evento.checkin.util.packageutil

import java.security.MessageDigest
import java.util.Locale

object CheckInPackageSecurity {
  const val MAX_SINGLE_ENTRY_BYTES: Long = 50 * 1024 * 1024L // 50MB
  const val MAX_TOTAL_UNCOMPRESSED_BYTES: Long = 100 * 1024 * 1024L // 100MB

  private val UUID_REGEX = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

  fun isEntryNameSafe(name: String): Boolean {
    if (name.isBlank()) return false
    if (name.contains("..")) return false
    if (name.startsWith("/") || name.startsWith("\\")) return false
    if (name.contains(":") || name.contains("\u0000")) return false
    return true
  }

  fun sha256Hex(bytes: ByteArray): String {
    val md = MessageDigest.getInstance("SHA-256")
    val digest = md.digest(bytes)
    return digest.joinToString("") { "%02x".format(it) }.lowercase(Locale.ROOT)
  }

  fun isValidUuid(uuid: String?): Boolean {
    if (uuid.isNullOrBlank()) return false
    return UUID_REGEX.matches(uuid.trim())
  }
}
