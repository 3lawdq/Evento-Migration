package com.evento.checkin.domain.model

import androidx.annotation.StringRes

sealed interface PackageValidationResult {
  data class Valid(
    val event: ImportedEvent,
    val guests: List<ImportedGuest>,
    val manifest: CheckInManifestDto,
    val securityStatus: PackageSecurityStatus,
    val keyId: String?,
    val license: EventLicense? = null,
  ) : PackageValidationResult

  data class Invalid(
    @StringRes val userMessageRes: Int,
    val technicalReason: String,
    val errorCategory: PackageSecurityError,
  ) : PackageValidationResult
}
