package com.evento.checkin.data.repository

import com.evento.checkin.data.local.dao.CheckInDao
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.domain.model.AttendanceRecord
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.ImportedGuest
import com.evento.checkin.domain.model.RecentCheckInItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

open class CheckInRepository(
  private val dao: CheckInDao,
) {
  open suspend fun getActiveEvent(): ImportedEvent? {
    return dao.getActiveEvent()?.toDomain()
  }

  open fun getActiveEventFlow(): Flow<ImportedEvent?> {
    return dao.getActiveEventFlow().map { it?.toDomain() }
  }

  open suspend fun getGuestByUuid(uuid: String): ImportedGuest? {
    return dao.getGuestByUuid(uuid)?.toDomain()
  }

  open suspend fun getGuestByUuidForEvent(eventId: Long, uuid: String): ImportedGuest? {
    return dao.getGuestByEventAndUuid(eventId, uuid)?.toDomain()
  }

  open suspend fun getGuestCount(): Int {
    return dao.getGuestCount()
  }

  open fun getGuestCountFlow(): Flow<Int> {
    return dao.getGuestCountFlow()
  }

  open suspend fun getGuestCountForEvent(eventId: Long): Int {
    return dao.getGuestCountForEvent(eventId)
  }

  open fun getGuestCountForEventFlow(eventId: Long): Flow<Int> {
    return dao.getGuestCountForEventFlow(eventId)
  }

  open suspend fun getAttendance(eventId: Long, guestUuid: String): AttendanceRecord? {
    return dao.getAttendance(eventId, guestUuid)?.toDomain()
  }

  open suspend fun insertAttendance(record: AttendanceRecord): Long {
    return dao.insertAttendance(AttendanceRecordEntity.fromDomain(record))
  }

  open suspend fun getAttendanceCount(eventId: Long): Int {
    return dao.getAttendanceCount(eventId)
  }

  open fun getAttendanceCountFlow(eventId: Long): Flow<Int> {
    return dao.getAttendanceCountFlow(eventId)
  }

  open suspend fun getPendingGuestCount(eventId: Long): Int {
    return dao.getPendingGuestCount(eventId)
  }

  open fun getPendingGuestCountFlow(eventId: Long): Flow<Int> {
    return dao.getPendingGuestCountFlow(eventId)
  }

  open fun getAttendanceForEventFlow(eventId: Long): Flow<List<AttendanceRecord>> {
    return dao.getAttendanceForEventFlow(eventId).map { list -> list.map { it.toDomain() } }
  }

  open suspend fun getAttendanceForEvent(eventId: Long): List<AttendanceRecord> {
    return dao.getAttendanceForEvent(eventId).map { it.toDomain() }
  }

  open suspend fun getAllAttendanceItems(eventId: Long): List<RecentCheckInItem> {
    return dao.getAllAttendanceItems(eventId)
  }

  open fun getAllAttendanceItemsFlow(eventId: Long): Flow<List<RecentCheckInItem>> {
    return dao.getAllAttendanceItemsFlow(eventId)
  }

  open fun getRecentCheckInsFlow(eventId: Long, limit: Int = 10): Flow<List<RecentCheckInItem>> {
    return dao.getRecentCheckInsFlow(eventId, limit)
  }

  open suspend fun getRecentCheckIns(eventId: Long, limit: Int = 10): List<RecentCheckInItem> {
    return dao.getRecentCheckIns(eventId, limit)
  }

  open suspend fun getAttendanceItem(eventId: Long, guestUuid: String): RecentCheckInItem? {
    return dao.getAttendanceItem(eventId, guestUuid)
  }

  open suspend fun deleteAttendanceForEvent(eventId: Long) {
    dao.deleteAttendanceForEvent(eventId)
  }

  open suspend fun clearAllAttendance() {
    dao.clearAllAttendance()
  }

  open suspend fun clearActivePackage() {
    dao.clearAllAttendance()
    dao.clearGuests()
    dao.clearEvents()
  }

  open suspend fun replaceActivePackage(event: ImportedEvent, guests: List<ImportedGuest>) {
    val eventEntity = ImportedEventEntity.fromDomain(event)
    val guestEntities = guests.map { ImportedGuestEntity.fromDomain(it) }
    dao.replaceActivePackage(eventEntity, guestEntities)
  }
}
