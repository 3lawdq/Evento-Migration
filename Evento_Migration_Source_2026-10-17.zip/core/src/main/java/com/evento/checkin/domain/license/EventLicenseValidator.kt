package com.evento.checkin.domain.license

import com.evento.checkin.domain.model.EventLicense
import com.evento.checkin.domain.model.LicenseStatus

sealed interface LicenseValidationResult {
  data class Valid(val license: EventLicense) : LicenseValidationResult
  data class Invalid(val status: LicenseStatus, val reason: String) : LicenseValidationResult
}

class EventLicenseValidator(
  private val timeProvider: () -> Long = { System.currentTimeMillis() },
) {
  fun validateLicense(
    license: EventLicense?,
    eventId: Long,
    guestCount: Int,
    localDeviceId: String?,
    currentTime: Long = timeProvider(),
  ): LicenseValidationResult {
    if (license == null) {
      return LicenseValidationResult.Invalid(LicenseStatus.MISSING, "License is missing.")
    }
    if (license.licenseStatus == LicenseStatus.INVALID) {
      return LicenseValidationResult.Invalid(LicenseStatus.INVALID, "License status is marked INVALID.")
    }
    if (license.eventId != eventId) {
      return LicenseValidationResult.Invalid(
        LicenseStatus.INVALID,
        "License event ID (${license.eventId}) does not match event ($eventId)."
      )
    }
    if (currentTime < license.issuedAt) {
      return LicenseValidationResult.Invalid(
        LicenseStatus.NOT_YET_VALID,
        "License is not yet valid (issued at ${license.issuedAt}, current time $currentTime)."
      )
    }
    if (currentTime > license.expiresAt) {
      return LicenseValidationResult.Invalid(
        LicenseStatus.EXPIRED,
        "License has expired (expired at ${license.expiresAt}, current time $currentTime)."
      )
    }
    if (guestCount > license.maxGuests) {
      return LicenseValidationResult.Invalid(
        LicenseStatus.GUEST_LIMIT_EXCEEDED,
        "Guest limit exceeded: license allows ${license.maxGuests} guests, but package contains $guestCount."
      )
    }
    if (license.boundDeviceId != null) {
      if (localDeviceId == null) {
        return LicenseValidationResult.Invalid(
          LicenseStatus.DEVICE_MISMATCH,
          "Package is bound to specific device (${license.boundDeviceId}), but local device ID could not be resolved."
        )
      }
      if (!license.boundDeviceId.trim().equals(localDeviceId.trim(), ignoreCase = true)) {
        return LicenseValidationResult.Invalid(
          LicenseStatus.DEVICE_MISMATCH,
          "Device mismatch: package is bound to '${license.boundDeviceId}', but current terminal is '$localDeviceId'."
        )
      }
    }
    return LicenseValidationResult.Valid(license.copy(licenseStatus = LicenseStatus.ACTIVE))
  }
}
