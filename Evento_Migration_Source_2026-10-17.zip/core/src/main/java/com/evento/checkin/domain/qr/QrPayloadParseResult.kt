package com.evento.checkin.domain.qr

/**
 * Result of parsing a raw QR barcode payload according to the Evento badge grammar.
 *
 * Supported outcomes:
 * - [Valid]: Successfully extracted and validated RFC-4122 UUID from `EVT1:<uuid>`.
 * - [InvalidPrefix]: Payload does not start with the mandatory `EVT1:` prefix.
 * - [InvalidUuid]: Payload has the prefix but the identifier fails RFC-4122 validation.
 * - [InvalidFormat]: Payload is empty, contains whitespace/newlines, extra fields, JSON, URLs, or PII.
 */
sealed interface QrPayloadParseResult {

  data class Valid(
    val uuid: String,
  ) : QrPayloadParseResult {
    val payload: QrPayload get() = QrPayload(uuid)
  }

  data object InvalidPrefix : QrPayloadParseResult

  data object InvalidUuid : QrPayloadParseResult

  data object InvalidFormat : QrPayloadParseResult
}
