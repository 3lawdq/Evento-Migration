package com.evento.checkin.domain.engine

import android.database.sqlite.SQLiteConstraintException
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.license.EventLicenseValidator
import com.evento.checkin.domain.license.LicenseValidationResult
import com.evento.checkin.domain.model.AttendanceRecord
import com.evento.checkin.domain.model.CheckInResult
import com.evento.checkin.domain.model.LicenseStatus
import com.evento.checkin.security.CheckInDeviceIdentityManager
import com.evento.checkin.util.packageutil.CheckInPackageSecurity

/**
 * Domain engine orchestrating attendee check-in logic with runtime license enforcement.
 *
 * Responsibilities:
 * 1. Checks that an active, verified event package is loaded.
 * 2. Validates attendee identifier (RFC-4122 UUID).
 * 3. Scopes attendee lookup strictly to the current active event.
 * 4. Enforces runtime license validity (timestamps, max guests count, device binding).
 * 5. Verifies whether attendance was already recorded for this (eventId, guestUuid).
 * 6. Records check-in using an authoritative time provider.
 * 7. Handles concurrent check-in races gracefully via database unique constraints.
 * 8. Leaves guest identity data strictly immutable (invitationStatus is NOT modified).
 */
open class CheckInEngine(
  private val repository: CheckInRepository,
  private val timeProvider: () -> Long = { System.currentTimeMillis() },
  private val deviceIdentityManager: CheckInDeviceIdentityManager? = null,
  private val localDeviceIdProvider: (() -> String?)? = null,
  private val licenseValidator: EventLicenseValidator = EventLicenseValidator(timeProvider),
) {

  private fun getLocalDeviceId(): String? {
    return localDeviceIdProvider?.invoke() ?: deviceIdentityManager?.getOrCreateDeviceId()
  }

  /**
   * Evaluates and records check-in for the given [guestUuid].
   */
  open suspend fun checkIn(guestUuid: String): CheckInResult {
    // 1. Obtain the currently imported event
    val currentEvent = repository.getActiveEvent()
      ?: return CheckInResult.NoActiveEvent

    // 2. Validate the UUID format
    val cleanUuid = guestUuid.trim()
    if (!CheckInPackageSecurity.isValidUuid(cleanUuid)) {
      return CheckInResult.InvalidGuestUuid
    }

    // 3. Find the guest by UUID within the CURRENT imported event only
    val guest = repository.getGuestByUuidForEvent(currentEvent.eventId, cleanUuid)
      ?: return CheckInResult.GuestNotFound

    // 4. Runtime License Enforcement (if package has a verified license)
    val license = currentEvent.license
    if (license != null) {
      val now = timeProvider()
      val guestCount = repository.getGuestCountForEvent(currentEvent.eventId)
      val localDeviceId = getLocalDeviceId()

      val validationResult = licenseValidator.validateLicense(
        license = license,
        eventId = currentEvent.eventId,
        guestCount = guestCount,
        localDeviceId = localDeviceId,
        currentTime = now,
      )

      if (validationResult is LicenseValidationResult.Invalid) {
        return when (validationResult.status) {
          LicenseStatus.EXPIRED -> CheckInResult.LicenseExpired(validationResult.reason)
          LicenseStatus.NOT_YET_VALID -> CheckInResult.LicenseNotYetValid(validationResult.reason)
          LicenseStatus.GUEST_LIMIT_EXCEEDED -> CheckInResult.LicenseGuestLimitExceeded(validationResult.reason)
          LicenseStatus.DEVICE_MISMATCH, LicenseStatus.DEVICE_LIMIT_EXCEEDED -> CheckInResult.LicenseDeviceMismatch(validationResult.reason)
          LicenseStatus.MISSING -> CheckInResult.LicenseMissing(validationResult.reason)
          LicenseStatus.INVALID, LicenseStatus.ACTIVE -> CheckInResult.LicenseInvalid(validationResult.reason)
        }
      }
    }

    // 5. Check whether attendance already exists for: currentEvent.eventId + cleanUuid
    val existingAttendance = repository.getAttendance(currentEvent.eventId, cleanUuid)
    if (existingAttendance != null) {
      return CheckInResult.AlreadyCheckedIn(
        guest = guest,
        checkedInAt = existingAttendance.checkedInAt,
      )
    }

    // 6. Create attendance record with authoritative timestamp
    val checkInTimestamp = timeProvider()
    val record = AttendanceRecord(
      eventId = currentEvent.eventId,
      guestUuid = cleanUuid,
      checkedInAt = checkInTimestamp,
    )

    // 7. Persist with race and duplicate safety
    return try {
      repository.insertAttendance(record)
      CheckInResult.Success(
        guest = guest,
        checkedInAt = checkInTimestamp,
      )
    } catch (e: Exception) {
      // If a concurrent thread or race condition inserted this attendance record,
      // gracefully recover by retrieving the existing record instead of crashing.
      val concurrentAttendance = repository.getAttendance(currentEvent.eventId, cleanUuid)
      if (concurrentAttendance != null) {
        CheckInResult.AlreadyCheckedIn(
          guest = guest,
          checkedInAt = concurrentAttendance.checkedInAt,
        )
      } else {
        // Not a constraint collision on this guest record; rethrow
        throw e
      }
    }
  }
}
