package com.evento.checkin.domain.qr

/**
 * Domain model representing a validated Evento badge QR payload.
 *
 * CONTRACT:
 * - Payload contains solely the RFC-4122 guest UUID extracted from the `EVT1:<uuid>` badge format.
 * - Zero PII (no names, emails, phones, or organizer notes).
 */
data class QrPayload(
  val uuid: String,
)
