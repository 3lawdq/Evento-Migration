package com.evento.checkin.domain.model

enum class LicenseStatus {
  ACTIVE,
  EXPIRED,
  NOT_YET_VALID,
  GUEST_LIMIT_EXCEEDED,
  DEVICE_MISMATCH,
  DEVICE_LIMIT_EXCEEDED,
  MISSING,
  INVALID,
}

data class EventLicense(
  val licenseId: String,
  val eventId: Long,
  val issuedAt: Long,
  val expiresAt: Long,
  val maxGuests: Int,
  val allowedDeviceCount: Int = 1,
  val boundDeviceId: String? = null,
  val licenseStatus: LicenseStatus = LicenseStatus.ACTIVE,
  val licenseFormatVersion: Int = 1,
)

data class ImportedEvent(
  val eventId: Long,
  val name: String,
  val date: String,
  val location: String,
  val organizer: String,
  val packageFormatVersion: Int,
  val guestCount: Int,
  val importedAt: Long = System.currentTimeMillis(),
  val verificationStatus: String = "VERIFIED",
  val license: EventLicense? = null,
) {
  val isLicensed: Boolean
    get() = license != null
}

data class ImportedGuest(
  val uuid: String,
  val eventId: Long,
  val fullName: String,
  val invitationStatus: String = "CONFIRMED",
  val organization: String = "",
  val jobTitle: String = "",
  val checkInStatus: String = "NOT_CHECKED_IN",
)

data class AttendanceRecord(
  val id: Long = 0,
  val eventId: Long,
  val guestUuid: String,
  val checkedInAt: Long,
)

data class RecentCheckInItem(
  val guestUuid: String,
  val fullName: String,
  val organization: String?,
  val jobTitle: String?,
  val checkedInAt: Long,
)

sealed interface CheckInResult {
  data class Success(
    val guest: ImportedGuest,
    val checkedInAt: Long,
  ) : CheckInResult

  data class AlreadyCheckedIn(
    val guest: ImportedGuest,
    val checkedInAt: Long,
  ) : CheckInResult

  data object GuestNotFound : CheckInResult
  data object NoActiveEvent : CheckInResult
  data object InvalidGuestUuid : CheckInResult

  data class LicenseExpired(val reason: String) : CheckInResult
  data class LicenseNotYetValid(val reason: String) : CheckInResult
  data class LicenseGuestLimitExceeded(val reason: String) : CheckInResult
  data class LicenseDeviceMismatch(val reason: String) : CheckInResult
  data class LicenseInvalid(val reason: String) : CheckInResult
  data class LicenseMissing(val reason: String) : CheckInResult
}

enum class PackageSecurityStatus {
  SIGNED_VERIFIED,
  LEGACY_INTEGRITY_ONLY,
}

enum class PackageSecurityError {
  SECURITY_VIOLATION,
  INVALID_PACKAGE,
  UNSUPPORTED_FORMAT,
  INTEGRITY_CHECK_FAILED,
  EVENT_DATA_INVALID,
  GUEST_DATA_INVALID,
  SIGNATURE_MISSING,
  UNSUPPORTED_SIGNATURE_ALGORITHM,
  UNKNOWN_SIGNING_KEY,
  MALFORMED_SIGNATURE,
  SIGNATURE_INVALID,
  CANONICALIZATION_FAILED,
  LICENSE_MISSING,
  LICENSE_INVALID,
  LICENSE_EXPIRED,
  LICENSE_NOT_YET_VALID,
  LICENSE_GUEST_LIMIT_EXCEEDED,
  LICENSE_DEVICE_MISMATCH,
}
