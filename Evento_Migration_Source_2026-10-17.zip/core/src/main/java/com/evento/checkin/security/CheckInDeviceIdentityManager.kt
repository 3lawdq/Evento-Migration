package com.evento.checkin.security

import android.content.Context
import java.util.UUID

open class CheckInDeviceIdentityManager(
  private val context: Context,
) {
  companion object {
    private const val PREFS_NAME = "evento_checkin_device_identity"
    private const val KEY_DEVICE_ID = "device_id"
  }

  private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  open fun getOrCreateDeviceId(): String {
    val existing = prefs.getString(KEY_DEVICE_ID, null)
    if (!existing.isNullOrBlank()) {
      return existing
    }
    val newId = "TERM-${UUID.randomUUID().toString().take(8).uppercase()}"
    prefs.edit().putString(KEY_DEVICE_ID, newId).apply()
    return newId
  }

  open fun setCustomDeviceId(deviceId: String) {
    prefs.edit().putString(KEY_DEVICE_ID, deviceId.trim()).apply()
  }

  open fun clearDeviceId() {
    prefs.edit().remove(KEY_DEVICE_ID).apply()
  }
}
