package com.evento.checkin.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity
import com.evento.checkin.domain.model.RecentCheckInItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CheckInDao {
  @Query("SELECT * FROM imported_events LIMIT 1")
  fun getActiveEventFlow(): Flow<ImportedEventEntity?>

  @Query("SELECT * FROM imported_events LIMIT 1")
  suspend fun getActiveEvent(): ImportedEventEntity?

  @Query("SELECT * FROM imported_guests WHERE eventId = :eventId")
  fun getGuestsForEventFlow(eventId: Long): Flow<List<ImportedGuestEntity>>

  @Query("SELECT * FROM imported_guests")
  fun getAllGuestsFlow(): Flow<List<ImportedGuestEntity>>

  @Query("SELECT COUNT(*) FROM imported_guests")
  fun getGuestCountFlow(): Flow<Int>

  @Query("SELECT COUNT(*) FROM imported_guests")
  suspend fun getGuestCount(): Int

  @Query("SELECT COUNT(*) FROM imported_guests WHERE eventId = :eventId")
  fun getGuestCountForEventFlow(eventId: Long): Flow<Int>

  @Query("SELECT COUNT(*) FROM imported_guests WHERE eventId = :eventId")
  suspend fun getGuestCountForEvent(eventId: Long): Int

  @Query("SELECT g.uuid AS guestUuid, g.fullName, g.organization, g.jobTitle, a.checkedInAt FROM attendance_records a JOIN imported_guests g ON a.guestUuid = g.uuid AND a.eventId = g.eventId WHERE a.eventId = :eventId ORDER BY a.checkedInAt DESC LIMIT :limit")
  fun getRecentCheckInsFlow(eventId: Long, limit: Int): Flow<List<RecentCheckInItem>>

  @Query("SELECT g.uuid AS guestUuid, g.fullName, g.organization, g.jobTitle, a.checkedInAt FROM attendance_records a JOIN imported_guests g ON a.guestUuid = g.uuid AND a.eventId = g.eventId WHERE a.eventId = :eventId ORDER BY a.checkedInAt DESC LIMIT :limit")
  suspend fun getRecentCheckIns(eventId: Long, limit: Int): List<RecentCheckInItem>

  @Query("SELECT g.uuid AS guestUuid, g.fullName, g.organization, g.jobTitle, a.checkedInAt FROM attendance_records a JOIN imported_guests g ON a.guestUuid = g.uuid AND a.eventId = g.eventId WHERE a.eventId = :eventId ORDER BY a.checkedInAt DESC")
  fun getAllAttendanceItemsFlow(eventId: Long): Flow<List<RecentCheckInItem>>

  @Query("SELECT g.uuid AS guestUuid, g.fullName, g.organization, g.jobTitle, a.checkedInAt FROM attendance_records a JOIN imported_guests g ON a.guestUuid = g.uuid AND a.eventId = g.eventId WHERE a.eventId = :eventId ORDER BY a.checkedInAt DESC")
  suspend fun getAllAttendanceItems(eventId: Long): List<RecentCheckInItem>

  @Query("SELECT g.uuid AS guestUuid, g.fullName, g.organization, g.jobTitle, a.checkedInAt FROM attendance_records a JOIN imported_guests g ON a.guestUuid = g.uuid AND a.eventId = g.eventId WHERE a.eventId = :eventId AND a.guestUuid = :guestUuid LIMIT 1")
  suspend fun getAttendanceItem(eventId: Long, guestUuid: String): RecentCheckInItem?

  @Query("SELECT * FROM imported_guests WHERE uuid = :uuid LIMIT 1")
  suspend fun getGuestByUuid(uuid: String): ImportedGuestEntity?

  @Query("SELECT * FROM imported_guests WHERE eventId = :eventId AND uuid = :uuid LIMIT 1")
  suspend fun getGuestByEventAndUuid(eventId: Long, uuid: String): ImportedGuestEntity?

  suspend fun getGuestByUuidForEvent(eventId: Long, uuid: String): ImportedGuestEntity? {
    return getGuestByEventAndUuid(eventId, uuid)
  }

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertEvent(event: ImportedEventEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGuests(guests: List<ImportedGuestEntity>)

  @Query("DELETE FROM imported_events")
  suspend fun clearEvents()

  @Query("DELETE FROM imported_guests")
  suspend fun clearGuests()

  @Insert(onConflict = OnConflictStrategy.ABORT)
  suspend fun insertAttendance(attendance: AttendanceRecordEntity): Long

  @Query("SELECT * FROM attendance_records WHERE eventId = :eventId AND guestUuid = :guestUuid LIMIT 1")
  suspend fun getAttendance(eventId: Long, guestUuid: String): AttendanceRecordEntity?

  @Query("SELECT * FROM attendance_records WHERE eventId = :eventId ORDER BY checkedInAt ASC")
  fun getAttendanceForEventFlow(eventId: Long): Flow<List<AttendanceRecordEntity>>

  @Query("SELECT * FROM attendance_records WHERE eventId = :eventId ORDER BY checkedInAt ASC")
  suspend fun getAttendanceForEvent(eventId: Long): List<AttendanceRecordEntity>

  @Query("SELECT COUNT(*) FROM attendance_records WHERE eventId = :eventId")
  suspend fun getAttendanceCount(eventId: Long): Int

  @Query("SELECT COUNT(*) FROM attendance_records WHERE eventId = :eventId")
  fun getAttendanceCountFlow(eventId: Long): Flow<Int>

  @Query("SELECT COUNT(*) FROM imported_guests g WHERE g.eventId = :eventId AND g.uuid NOT IN (SELECT a.guestUuid FROM attendance_records a WHERE a.eventId = :eventId)")
  suspend fun getPendingGuestCount(eventId: Long): Int

  @Query("SELECT COUNT(*) FROM imported_guests g WHERE g.eventId = :eventId AND g.uuid NOT IN (SELECT a.guestUuid FROM attendance_records a WHERE a.eventId = :eventId)")
  fun getPendingGuestCountFlow(eventId: Long): Flow<Int>

  @Query("DELETE FROM attendance_records WHERE eventId = :eventId")
  suspend fun deleteAttendanceForEvent(eventId: Long)

  @Query("DELETE FROM attendance_records")
  suspend fun clearAllAttendance()

  suspend fun clearAttendance() {
    clearAllAttendance()
  }

  @Transaction
  suspend fun replaceActivePackage(event: ImportedEventEntity, guests: List<ImportedGuestEntity>) {
    clearAllAttendance()
    clearGuests()
    clearEvents()
    insertEvent(event)
    insertGuests(guests)
  }
}
