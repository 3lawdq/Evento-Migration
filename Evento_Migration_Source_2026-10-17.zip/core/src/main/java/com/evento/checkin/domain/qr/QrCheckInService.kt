package com.evento.checkin.domain.qr

import com.evento.checkin.domain.engine.CheckInEngine
import com.evento.checkin.domain.model.CheckInResult
import com.evento.checkin.security.CheckInDeviceIdentityManager

/**
 * Service bridging offline QR payload parsing and domain check-in processing.
 *
 * Responsibilities:
 * 1. Validates QR text syntax and grammar via [QrPayloadParser].
 * 2. Short-circuits invalid QR payloads immediately without invoking database operations.
 * 3. For valid payloads, passes extracted guest UUID to [CheckInEngine].
 * 4. Preserves complete offline isolation (no network, no cloud).
 */
open class QrCheckInService(
  private val engine: CheckInEngine,
  private val parsePayload: (String?) -> QrPayloadParseResult = { QrPayloadParser.parse(it) },
) {

  constructor(
    repository: com.evento.checkin.data.repository.CheckInRepository,
    deviceIdentityManager: CheckInDeviceIdentityManager? = null,
  ) : this(CheckInEngine(repository, deviceIdentityManager = deviceIdentityManager))

  /**
   * Processes the raw QR payload string, parses it according to Evento badge grammar,
   * and executes check-in against the active event roster if valid.
   */
  open suspend fun checkInWithQr(qrPayload: String?): QrCheckInResult {
    // 1. Strict grammar & format parsing
    val parseResult = parsePayload(qrPayload)
    if (parseResult !is QrPayloadParseResult.Valid) {
      // Short-circuit: Do NOT call CheckInEngine or perform any DB queries
      return QrCheckInResult.InvalidQr(parseResult)
    }

    // 2. Delegate to the authoritative domain CheckInEngine
    return when (val engineResult = engine.checkIn(parseResult.uuid)) {
      is CheckInResult.Success -> QrCheckInResult.Success(
        guest = engineResult.guest,
        checkedInAt = engineResult.checkedInAt,
      )
      is CheckInResult.AlreadyCheckedIn -> QrCheckInResult.AlreadyCheckedIn(
        guest = engineResult.guest,
        checkedInAt = engineResult.checkedInAt,
      )
      is CheckInResult.GuestNotFound -> QrCheckInResult.GuestNotFound
      is CheckInResult.NoActiveEvent -> QrCheckInResult.NoActiveEvent
      is CheckInResult.InvalidGuestUuid -> QrCheckInResult.InvalidQr(
        QrPayloadParseResult.InvalidUuid
      )
      is CheckInResult.LicenseExpired -> QrCheckInResult.LicenseExpired(engineResult.reason)
      is CheckInResult.LicenseNotYetValid -> QrCheckInResult.LicenseNotYetValid(engineResult.reason)
      is CheckInResult.LicenseGuestLimitExceeded -> QrCheckInResult.LicenseGuestLimitExceeded(engineResult.reason)
      is CheckInResult.LicenseDeviceMismatch -> QrCheckInResult.LicenseDeviceMismatch(engineResult.reason)
      is CheckInResult.LicenseInvalid -> QrCheckInResult.LicenseInvalid(engineResult.reason)
      is CheckInResult.LicenseMissing -> QrCheckInResult.LicenseMissing(engineResult.reason)
    }
  }

  open suspend fun checkIn(qrPayload: String?): QrCheckInResult = checkInWithQr(qrPayload)

  open suspend fun processQr(qrPayload: String?): QrCheckInResult = checkInWithQr(qrPayload)
}
