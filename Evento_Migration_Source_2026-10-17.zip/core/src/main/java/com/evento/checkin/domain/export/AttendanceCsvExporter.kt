package com.evento.checkin.domain.export

import com.evento.checkin.domain.model.RecentCheckInItem
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pure domain exporter converting local attendance records into offline, UTF-8 encoded CSV.
 *
 * Requirements:
 * - Human-readable fields: Full Name, Organization, Job Title, Check-In Date, Check-In Time.
 * - Arabic-friendly with UTF-8 BOM (\uFEFF) for immediate compatibility with Excel / Sheets.
 * - STRICT PRIVACY: Omits UUIDs, internal database IDs, emails, phone numbers, and QR payloads.
 * - Thread-safe and independent of UI/Android lifecycle.
 */
object AttendanceCsvExporter {

  const val UTF8_BOM = "\uFEFF"
  const val CSV_HEADER = "Full Name,Organization,Job Title,Check-In Date,Check-In Time"

  /**
   * Builds the complete CSV file contents as a UTF-8 string prefixed with the UTF-8 BOM.
   */
  fun generateCsvContent(records: List<RecentCheckInItem>): String {
    val sb = StringBuilder()
    sb.append(UTF8_BOM)
    sb.append(CSV_HEADER).append("\r\n")

    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    for (record in records) {
      val dateStr = dateFormat.format(Date(record.checkedInAt))
      val timeStr = timeFormat.format(Date(record.checkedInAt))

      sb.append(escapeCsv(record.fullName)).append(",")
      sb.append(escapeCsv(record.organization ?: "")).append(",")
      sb.append(escapeCsv(record.jobTitle ?: "")).append(",")
      sb.append(escapeCsv(dateStr)).append(",")
      sb.append(escapeCsv(timeStr)).append("\r\n")
    }

    return sb.toString()
  }

  /**
   * Writes the CSV content directly to an OutputStream (such as from SAF ContentResolver).
   */
  fun writeCsvToStream(records: List<RecentCheckInItem>, outputStream: OutputStream) {
    OutputStreamWriter(outputStream, StandardCharsets.UTF_8).use { writer ->
      writer.write(generateCsvContent(records))
      writer.flush()
    }
  }

  /**
   * Generates a safe, sanitized filename according to the pattern:
   * Evento_Attendance_<event-name>_<date>.csv
   */
  fun generateFileName(eventName: String, epochMillis: Long = System.currentTimeMillis()): String {
    val dateStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(epochMillis))
    val sanitized = eventName
      .replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF]"), "_")
      .trim('_')
      .take(40)
      .ifBlank { "Event" }
    return "Evento_Attendance_${sanitized}_$dateStr.csv"
  }

  /**
   * Escapes fields adhering strictly to RFC 4180 CSV standard.
   */
  fun escapeCsv(value: String): String {
    if (value.contains(',') || value.contains('"') || value.contains('\n') || value.contains('\r')) {
      return "\"" + value.replace("\"", "\"\"") + "\""
    }
    return value
  }
}
