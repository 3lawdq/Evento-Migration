package com.evento.checkin.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.evento.checkin.data.local.dao.CheckInDao
import com.evento.checkin.data.local.entity.AttendanceRecordEntity
import com.evento.checkin.data.local.entity.ImportedEventEntity
import com.evento.checkin.data.local.entity.ImportedGuestEntity

@Database(
  entities = [
    ImportedEventEntity::class,
    ImportedGuestEntity::class,
    AttendanceRecordEntity::class,
  ],
  version = 3,
  exportSchema = false,
)
abstract class CheckInDatabase : RoomDatabase() {
  abstract fun checkInDao(): CheckInDao

  companion object {
    private const val DATABASE_NAME = "evento_checkin.db"

    @Volatile
    private var instance: CheckInDatabase? = null

    val MIGRATION_1_2: Migration = object : Migration(1, 2) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `attendance_records` (
            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            `eventId` INTEGER NOT NULL,
            `guestUuid` TEXT NOT NULL,
            `checkedInAt` INTEGER NOT NULL
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE UNIQUE INDEX IF NOT EXISTS `index_attendance_records_eventId_guestUuid` 
          ON `attendance_records` (`eventId`, `guestUuid`)
          """.trimIndent()
        )
      }
    }

    val MIGRATION_2_3: Migration = object : Migration(2, 3) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `imported_events` ADD COLUMN `licenseId` TEXT DEFAULT NULL")
        db.execSQL("ALTER TABLE `imported_events` ADD COLUMN `licenseIssuedAt` INTEGER DEFAULT NULL")
        db.execSQL("ALTER TABLE `imported_events` ADD COLUMN `licenseExpiresAt` INTEGER DEFAULT NULL")
        db.execSQL("ALTER TABLE `imported_events` ADD COLUMN `licenseMaxGuests` INTEGER DEFAULT NULL")
        db.execSQL("ALTER TABLE `imported_events` ADD COLUMN `licenseAllowedDeviceCount` INTEGER DEFAULT NULL")
        db.execSQL("ALTER TABLE `imported_events` ADD COLUMN `licenseBoundDeviceId` TEXT DEFAULT NULL")
        db.execSQL("ALTER TABLE `imported_events` ADD COLUMN `licenseStatus` TEXT DEFAULT NULL")
        db.execSQL("ALTER TABLE `imported_events` ADD COLUMN `licenseFormatVersion` INTEGER DEFAULT NULL")
      }
    }

    fun getInstance(context: Context): CheckInDatabase {
      return instance ?: synchronized(this) {
        instance ?: Room.databaseBuilder(
          context.applicationContext,
          CheckInDatabase::class.java,
          DATABASE_NAME,
        )
          .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
          .build()
          .also { instance = it }
      }
    }

    fun createInMemory(context: Context): CheckInDatabase {
      return Room.inMemoryDatabaseBuilder(
        context.applicationContext,
        CheckInDatabase::class.java,
      )
        .allowMainThreadQueries()
        .build()
    }
  }
}
