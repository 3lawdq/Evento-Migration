package com.evento.checkin.util.packageutil

import java.security.KeyFactory
import java.security.PublicKey
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.ConcurrentHashMap

/**
 * Trust anchor registry for Evento Check-In.
 * Maintains explicitly trusted public keys indexed by keyId.
 *
 * CRITICAL SECURITY ARCHITECTURE (PHASE 7.6):
 * 1. Public-key-only trust model: Evento Check-In contains ZERO access to Admin private
 *    signing keys, Android Keystore signing aliases, or signing infrastructure.
 * 2. Public keys are NEVER accepted from within untrusted .evento archives.
 * 3. Check-In verifies signatures ONLY against public keys explicitly registered in this registry.
 * 4. Any package signed with an unknown or untrusted keyId is rejected immediately (fail-closed).
 * 5. Standalone public-key provisioning via raw PublicKey or X.509-encoded DER byte arrays.
 */
object CheckInTrustAnchorRegistry {

  const val DEFAULT_KEY_ID = "evento-admin-p256-v1"

  // Standard X.509 DER SubjectPublicKeyInfo for Evento Authority EC P-256 (NIST P-256 / secp256r1)
  const val DEFAULT_AUTHORITY_PUBLIC_KEY_B64 =
    "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEPQeP8GaUzQKM2iC29ePRRCXTHEzv/1lJykVGdDWvpiua6lE7CcmpRcYmeLsmXsHRQKUVVIxqcUkaS1npR05ZHg=="

  private val trustedKeys = ConcurrentHashMap<String, PublicKey>()

  init {
    loadDefaultTrustAnchors()
  }

  fun loadDefaultTrustAnchors() {
    try {
      val keyBytes = try {
        android.util.Base64.decode(DEFAULT_AUTHORITY_PUBLIC_KEY_B64, android.util.Base64.DEFAULT)
      } catch (_: Throwable) {
        java.util.Base64.getDecoder().decode(DEFAULT_AUTHORITY_PUBLIC_KEY_B64)
      }
      val spec = X509EncodedKeySpec(keyBytes)
      val kf = KeyFactory.getInstance("EC")
      trustedKeys[DEFAULT_KEY_ID] = kf.generatePublic(spec)
    } catch (_: Throwable) {
      // Handled gracefully in minimal test environments
    }
  }

  fun resetToDefaults() {
    trustedKeys.clear()
    loadDefaultTrustAnchors()
  }

  /**
   * Registers a trusted public key for an explicit key ID.
   */
  fun register(keyId: String, publicKey: PublicKey) {
    require(keyId.isNotBlank()) { "keyId cannot be blank" }
    trustedKeys[keyId] = publicKey
  }

  /**
   * Backward-compatible alias for register(keyId, publicKey).
   */
  fun registerTrustedKey(keyId: String, publicKey: PublicKey) {
    register(keyId, publicKey)
  }

  /**
   * Registers a trusted EC public key from standard X.509 encoded bytes.
   */
  fun registerFromX509(keyId: String, x509Bytes: ByteArray, algorithm: String = "EC") {
    require(keyId.isNotBlank()) { "keyId cannot be blank" }
    val spec = X509EncodedKeySpec(x509Bytes)
    val kf = KeyFactory.getInstance(algorithm)
    val publicKey = kf.generatePublic(spec)
    trustedKeys[keyId] = publicKey
  }

  /**
   * Resolves the trusted public key for a key ID.
   * Returns null if keyId is unknown or untrusted (fail-closed).
   */
  fun resolve(keyId: String): PublicKey? {
    if (keyId.isBlank()) return null
    return trustedKeys[keyId]
  }

  /**
   * Backward-compatible alias for resolve(keyId).
   */
  fun getTrustedPublicKey(keyId: String): PublicKey? {
    return resolve(keyId)
  }

  /**
   * Unregisters a key ID (useful for testing untrusted key rejection).
   */
  fun unregisterTrustedKey(keyId: String) {
    trustedKeys.remove(keyId)
  }

  /**
   * Checks whether a given key ID is trusted by this registry.
   */
  fun isKeyTrusted(keyId: String): Boolean {
    return resolve(keyId) != null
  }

  /**
   * Returns whether any trusted public keys are currently registered.
   */
  fun hasTrustedKeys(): Boolean {
    return trustedKeys.isNotEmpty()
  }

  /**
   * Returns the number of registered trusted public keys.
   */
  fun keyCount(): Int = trustedKeys.size

  /**
   * Clears dynamically registered keys and resets state.
   */
  fun clear() {
    trustedKeys.clear()
  }
}

