package com.evento.checkin.domain.qr

import com.evento.checkin.domain.CheckInSecurityArchitecture
import java.util.regex.Pattern

/**
 * Pure, isolated parser for Evento attendee badge QR code payloads.
 *
 * Strict Grammar Specification:
 * - Expected format: `EVT1:<RFC-4122 UUID>`
 * - Prefix must be strictly `EVT1:`.
 * - Payload must contain exactly one RFC-4122 UUID following the prefix.
 * - No leading, trailing, or internal whitespace.
 * - No newline or carriage return characters.
 * - No delimiters, JSON, URLs, or extra fields.
 * - Zero PII allowed.
 * - Never silently trims or repairs malformed input.
 */
object QrPayloadParser {

  /** Expected payload prefix matching the Evento badge specification */
  const val EXPECTED_PREFIX = CheckInSecurityArchitecture.EXPECTED_PAYLOAD_PREFIX

  /** Standard RFC-4122 UUID pattern (case-insensitive hexadecimal) */
  private val RFC4122_UUID_REGEX = Pattern.compile(
    "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
  )

  /**
   * Parses the given [rawPayload] string according to strict Evento QR grammar rules.
   */
  fun parse(rawPayload: String?): QrPayloadParseResult {
    if (rawPayload == null || rawPayload.isEmpty()) {
      return QrPayloadParseResult.InvalidFormat
    }

    // Reject leading, trailing, or newline whitespace strictly without trimming
    if (rawPayload.startsWith(" ") || rawPayload.startsWith("\t") ||
      rawPayload.endsWith(" ") || rawPayload.endsWith("\t") ||
      rawPayload.contains("\n") || rawPayload.contains("\r")
    ) {
      return QrPayloadParseResult.InvalidFormat
    }

    // Verify prefix strictly
    if (!rawPayload.startsWith(EXPECTED_PREFIX)) {
      return QrPayloadParseResult.InvalidPrefix
    }

    val remainder = rawPayload.substring(EXPECTED_PREFIX.length)
    if (remainder.isEmpty()) {
      return QrPayloadParseResult.InvalidFormat
    }

    // Reject internal whitespace, extra fields, delimiters, JSON tokens, URLs, and PII markers
    if (remainder.contains(" ") || remainder.contains("\t") ||
      remainder.contains(":") || remainder.contains(",") ||
      remainder.contains(";") || remainder.contains("/") ||
      remainder.contains("|") || remainder.contains("#") ||
      remainder.contains("{") || remainder.contains("}") ||
      remainder.contains("&") || remainder.contains("?") ||
      remainder.contains("=") || remainder.contains("\\") ||
      remainder.contains("@")
    ) {
      return QrPayloadParseResult.InvalidFormat
    }

    // Validate RFC-4122 compliance
    if (!RFC4122_UUID_REGEX.matcher(remainder).matches()) {
      return QrPayloadParseResult.InvalidUuid
    }

    return QrPayloadParseResult.Valid(remainder)
  }
}
