package com.evento.checkin.util.packageutil

import android.content.ContentResolver
import android.net.Uri
import androidx.annotation.StringRes
import com.evento.core.R
import com.evento.checkin.data.repository.CheckInRepository
import com.evento.checkin.domain.model.ImportedEvent
import com.evento.checkin.domain.model.PackageSecurityError
import com.evento.checkin.domain.model.PackageSecurityStatus
import com.evento.checkin.domain.model.PackageValidationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * Result of the full import-and-persist pipeline.
 */
sealed interface PackageImportResult {
  data class Success(
    val event: ImportedEvent,
    val guestCount: Int,
    val securityStatus: PackageSecurityStatus = PackageSecurityStatus.SIGNED_VERIFIED,
    val keyId: String? = null,
  ) : PackageImportResult

  data class Error(
    @StringRes val userMessageRes: Int,
    val technicalDetails: String,
    val errorCategory: PackageSecurityError? = null,
  ) : PackageImportResult
}

/**
 * High-level orchestrator that opens an .evento archive, validates integrity,
 * and atomically persists the event and guest roster.
 */
class EventoPackageImporter(
  private val repository: CheckInRepository,
  private val verifier: EventoPackageVerifier = EventoPackageVerifier(),
) {

  /**
   * Imports an .evento file from an Android content URI.
   * If validation fails or reading fails, the current active database remains untouched.
   */
  suspend fun importFromUri(
    uri: Uri,
    contentResolver: ContentResolver,
    localDeviceId: String? = null,
    onStepChange: ((ImportStep) -> Unit)? = null,
  ): PackageImportResult = withContext(Dispatchers.IO) {
    try {
      onStepChange?.invoke(ImportStep.READING)
      val inputStream: InputStream = contentResolver.openInputStream(uri)
        ?: return@withContext PackageImportResult.Error(
          userMessageRes = R.string.checkin_err_invalid_package,
          technicalDetails = "Unable to open content stream for URI: $uri",
        )

      onStepChange?.invoke(ImportStep.VERIFYING)
      val validationResult = inputStream.use { stream ->
        verifier.verifyPackage(stream, localDeviceId)
      }

      when (validationResult) {
        is PackageValidationResult.Invalid -> {
          PackageImportResult.Error(
            userMessageRes = validationResult.userMessageRes,
            technicalDetails = validationResult.technicalReason,
            errorCategory = validationResult.errorCategory,
          )
        }
        is PackageValidationResult.Valid -> {
          onStepChange?.invoke(ImportStep.SAVING)
          // Atomically replace in Room via transaction
          repository.replaceActivePackage(
            event = validationResult.event,
            guests = validationResult.guests,
          )
          PackageImportResult.Success(
            event = validationResult.event,
            guestCount = validationResult.guests.size,
            securityStatus = validationResult.securityStatus,
            keyId = validationResult.keyId,
          )
        }
      }
    } catch (e: Exception) {
      PackageImportResult.Error(
        userMessageRes = R.string.checkin_err_invalid_package,
        technicalDetails = "Import failure: ${e.message ?: "Unknown error"}",
      )
    }
  }

  /**
   * Direct InputStream import (primarily for testing or background worker).
   */
  suspend fun importFromStream(
    inputStream: InputStream,
    localDeviceId: String? = null,
    onStepChange: ((ImportStep) -> Unit)? = null,
  ): PackageImportResult = withContext(Dispatchers.IO) {
    try {
      onStepChange?.invoke(ImportStep.VERIFYING)
      val validationResult = verifier.verifyPackage(inputStream, localDeviceId)

      when (validationResult) {
        is PackageValidationResult.Invalid -> {
          PackageImportResult.Error(
            userMessageRes = validationResult.userMessageRes,
            technicalDetails = validationResult.technicalReason,
            errorCategory = validationResult.errorCategory,
          )
        }
        is PackageValidationResult.Valid -> {
          onStepChange?.invoke(ImportStep.SAVING)
          repository.replaceActivePackage(
            event = validationResult.event,
            guests = validationResult.guests,
          )
          PackageImportResult.Success(
            event = validationResult.event,
            guestCount = validationResult.guests.size,
            securityStatus = validationResult.securityStatus,
            keyId = validationResult.keyId,
          )
        }
      }
    } catch (e: Exception) {
      PackageImportResult.Error(
        userMessageRes = R.string.checkin_err_invalid_package,
        technicalDetails = "Import failure: ${e.message ?: "Unknown error"}",
      )
    }
  }
}

/**
 * Granular progress phases during import.
 */
enum class ImportStep {
  READING,
  VERIFYING,
  SAVING,
}
